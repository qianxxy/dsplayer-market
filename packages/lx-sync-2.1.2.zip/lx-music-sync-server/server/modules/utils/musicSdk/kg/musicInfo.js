"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getMusicInfosByList = exports.getMusicInfo = exports.getMusicInfoRaw = exports.getMusicInfos = exports.filterMusicInfoList = void 0;
const index_1 = require("../../index");
const util_1 = require("./util");
const createGetMusicInfosTask = (hashs) => {
    let data = {
        area_code: '1',
        show_privilege: 1,
        show_album_info: '1',
        is_publish: '',
        appid: 1005,
        clientver: 11451,
        mid: '1',
        dfid: '-',
        clienttime: Date.now(),
        key: 'OIlwieks28dk2k092lksi2UIkp',
        fields: 'album_info,author_name,audio_info,ori_audio_name,base,songname,classification,img,album_img',
    };
    let list = hashs;
    let tasks = [];
    while (list.length) {
        tasks.push(Object.assign({ data: list.slice(0, 100) }, data));
        if (list.length < 100)
            break;
        list = list.slice(100);
    }
    let url = 'http://gateway.kugou.com/v3/album_audio/audio';
    return tasks.map(task => (0, util_1.createHttpFetch)(url, {
        method: 'POST',
        body: task,
        headers: {
            'KG-THash': '13a3164',
            'KG-RC': '1',
            'KG-Fake': '0',
            'KG-RF': '00869891',
            'User-Agent': 'Android712-AndroidPhone-11451-376-0-FeeCacheUpdate-wifi',
            'x-router': 'kmr.service.kugou.com',
        },
    }).then(data => data.map(s => s[0])));
};
const filterMusicInfoList = (rawList) => {
    // console.log(rawList)
    let ids = new Set();
    let list = [];
    rawList.forEach(item => {
        if (!item)
            return;
        if (ids.has(item.audio_info.audio_id))
            return;
        ids.add(item.audio_info.audio_id);
        const types = [];
        const _types = {};
        if (item.audio_info.filesize !== '0') {
            let size = (0, index_1.sizeFormate)(parseInt(item.audio_info.filesize));
            types.push({ type: '128k', size, hash: item.audio_info.hash });
            _types['128k'] = {
                size,
                hash: item.audio_info.hash,
            };
        }
        if (item.audio_info.filesize_320 !== '0') {
            let size = (0, index_1.sizeFormate)(parseInt(item.audio_info.filesize_320));
            types.push({ type: '320k', size, hash: item.audio_info.hash_320 });
            _types['320k'] = {
                size,
                hash: item.audio_info.hash_320,
            };
        }
        if (item.audio_info.filesize_flac !== '0') {
            let size = (0, index_1.sizeFormate)(parseInt(item.audio_info.filesize_flac));
            types.push({ type: 'flac', size, hash: item.audio_info.hash_flac });
            _types.flac = {
                size,
                hash: item.audio_info.hash_flac,
            };
        }
        if (item.audio_info.filesize_high !== '0') {
            let size = (0, index_1.sizeFormate)(parseInt(item.audio_info.filesize_high));
            types.push({ type: 'flac24bit', size, hash: item.audio_info.hash_high });
            _types.flac24bit = {
                size,
                hash: item.audio_info.hash_high,
            };
        }
        list.push({
            singer: (0, index_1.decodeName)(item.author_name),
            name: (0, index_1.decodeName)(item.songname),
            albumName: (0, index_1.decodeName)(item.album_info.album_name),
            albumId: item.album_info.album_id,
            songmid: item.audio_info.audio_id,
            source: 'kg',
            interval: (0, index_1.formatPlayTime)(parseInt(item.audio_info.timelength) / 1000),
            img: (item.img || item.album_info?.sizable_cover || item.audio_info?.trans_param?.union_cover || item.album_info?.pic || item.album_info?.img || item.album_info?.s_img || '').replace('{size}', '1000') || null,
            lrc: null,
            hash: item.audio_info.hash,
            otherSource: null,
            types,
            _types,
            typeUrl: {},
        });
    });
    return list;
};
exports.filterMusicInfoList = filterMusicInfoList;
const getMusicInfos = async (hashs) => {
    return (0, exports.filterMusicInfoList)(await Promise.all(createGetMusicInfosTask(hashs)).then(data => data.flat()));
};
exports.getMusicInfos = getMusicInfos;
const getMusicInfoRaw = async (hash) => {
    return Promise.all(createGetMusicInfosTask([{ hash }])).then(data => data.flat()[0]);
};
exports.getMusicInfoRaw = getMusicInfoRaw;
const getMusicInfo = async (hash) => {
    return (0, exports.getMusicInfos)([{ hash }]).then(data => data[0]);
};
exports.getMusicInfo = getMusicInfo;
const getMusicInfosByList = (list) => {
    return (0, exports.getMusicInfos)(list.map(item => ({ hash: item.hash })));
};
exports.getMusicInfosByList = getMusicInfosByList;
