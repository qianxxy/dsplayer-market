"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sync = void 0;
// import { SYNC_CLOSE_CODE } from '../../../constants.js'
const constants_1 = require("../../../constants.js");
const user_1 = require("../../../user/index.js");
const utils_1 = require("../utils");
// type ListInfoType = LX.List.UserListInfoFull | LX.List.MyDefaultListInfoFull | LX.List.MyLoveListInfoFull
// let wss: LX.SocketServer | null
let syncingId = null;
const wait = async (time = 1000) => await new Promise((resolve, reject) => setTimeout(resolve, time));
const patchListData = (listData) => {
    return Object.assign({
        defaultList: [],
        loveList: [],
        userList: [],
    }, listData);
};
const getRemoteListData = async (socket) => {
    console.log('getRemoteListData');
    return patchListData(await socket.remoteQueueList.list_sync_get_list_data());
};
const getRemoteListMD5 = async (socket) => {
    return socket.remoteQueueList.list_sync_get_md5();
};
const getLocalListData = async (socket) => {
    return (0, user_1.getUserSpace)(socket.userInfo.name).listManage.getListData();
};
const getSyncMode = async (socket) => {
    const mode = await socket.remoteQueueList.list_sync_get_sync_mode();
    return constants_1.TRANS_MODE[mode] ?? 'cancel';
};
const finishedSync = async (socket) => {
    await socket.remoteQueueList.list_sync_finished();
};
const setLocalList = async (socket, listData) => {
    await global.event_list.list_data_overwrite(socket.userInfo.name, listData, true);
    const userSpace = (0, user_1.getUserSpace)(socket.userInfo.name);
    return userSpace.listManage.createSnapshot();
};
const overwriteRemoteListData = async (socket, listData, key, excludeIds = []) => {
    const action = { action: 'list_data_overwrite', data: listData };
    const tasks = [];
    const userSpace = (0, user_1.getUserSpace)(socket.userInfo.name);
    socket.broadcast((client) => {
        if (excludeIds.includes(client.keyInfo.clientId) || client.userInfo?.name != socket.userInfo.name || !client.moduleReadys?.list)
            return;
        tasks.push(client.remoteQueueList.onListSyncAction(action).then(async () => {
            return userSpace.listManage.updateDeviceSnapshotKey(client.keyInfo.clientId, key);
        }).catch(err => {
            // TODO send status
            client.close(constants_1.SYNC_CLOSE_CODE.failed);
            // client.moduleReadys.list = false
            console.log(err.message);
        }));
    });
    if (!tasks.length)
        return;
    await Promise.all(tasks);
};
const setRemotelList = async (socket, listData, key) => {
    await socket.remoteQueueList.list_sync_set_list_data(listData);
    const userSpace = (0, user_1.getUserSpace)(socket.userInfo.name);
    await userSpace.listManage.updateDeviceSnapshotKey(socket.keyInfo.clientId, key);
};
const createUserListDataObj = (listData) => {
    const userListDataObj = new Map();
    for (const list of listData.userList)
        userListDataObj.set(list.id, list);
    return userListDataObj;
};
const handleMergeList = (sourceList, targetList, addMusicLocationType) => {
    let newList;
    switch (addMusicLocationType) {
        case 'top':
            newList = [...targetList, ...sourceList];
            break;
        case 'bottom':
        default:
            newList = [...sourceList, ...targetList];
            break;
    }
    const map = new Map();
    const ids = [];
    switch (addMusicLocationType) {
        case 'top':
            newList = [...targetList, ...sourceList];
            for (let i = newList.length - 1; i > -1; i--) {
                const item = newList[i];
                if (map.has(item.id))
                    continue;
                ids.unshift(item.id);
                map.set(item.id, item);
            }
            break;
        case 'bottom':
        default:
            newList = [...sourceList, ...targetList];
            for (const item of newList) {
                if (map.has(item.id))
                    continue;
                ids.push(item.id);
                map.set(item.id, item);
            }
            break;
    }
    return ids.map(id => map.get(id));
};
const mergeList = (socket, sourceListData, targetListData) => {
    const addMusicLocationType = (0, user_1.getUserConfig)(socket.userInfo.name)['list.addMusicLocationType'];
    const newListData = {
        defaultList: [],
        loveList: [],
        userList: [],
    };
    newListData.defaultList = handleMergeList(sourceListData.defaultList, targetListData.defaultList, addMusicLocationType);
    newListData.loveList = handleMergeList(sourceListData.loveList, targetListData.loveList, addMusicLocationType);
    const userListDataObj = createUserListDataObj(sourceListData);
    newListData.userList = [...sourceListData.userList];
    targetListData.userList.forEach((list, index) => {
        const targetUpdateTime = list?.locationUpdateTime ?? 0;
        const sourceList = userListDataObj.get(list.id);
        if (sourceList) {
            sourceList.list = handleMergeList(sourceList.list, list.list, addMusicLocationType);
            const sourceUpdateTime = sourceList?.locationUpdateTime ?? 0;
            if (targetUpdateTime >= sourceUpdateTime)
                return;
            // 调整位置
            const [newList] = newListData.userList.splice(newListData.userList.findIndex(l => l.id == list.id), 1);
            newList.locationUpdateTime = targetUpdateTime;
            newListData.userList.splice(index, 0, newList);
        }
        else {
            if (targetUpdateTime) {
                newListData.userList.splice(index, 0, list);
            }
            else {
                newListData.userList.push(list);
            }
        }
    });
    return newListData;
};
const overwriteList = (sourceListData, targetListData) => {
    const newListData = {
        defaultList: [],
        loveList: [],
        userList: [],
    };
    newListData.defaultList = sourceListData.defaultList;
    newListData.loveList = sourceListData.loveList;
    const userListDataObj = createUserListDataObj(sourceListData);
    newListData.userList = [...sourceListData.userList];
    targetListData.userList.forEach((list, index) => {
        if (userListDataObj.has(list.id))
            return;
        if (list?.locationUpdateTime) {
            newListData.userList.splice(index, 0, list);
        }
        else {
            newListData.userList.push(list);
        }
    });
    return newListData;
};
const handleMergeListData = async (socket) => {
    const mode = await getSyncMode(socket);
    if (mode == 'cancel')
        throw new Error('cancel');
    const [remoteListData, localListData] = await Promise.all([getRemoteListData(socket), getLocalListData(socket)]);
    console.log('handleMergeListData', 'remoteListData, localListData');
    let listData;
    let requiredUpdateLocalListData = true;
    let requiredUpdateRemoteListData = true;
    switch (mode) {
        case 'merge_local_remote':
            listData = mergeList(socket, localListData, remoteListData);
            break;
        case 'merge_remote_local':
            listData = mergeList(socket, remoteListData, localListData);
            break;
        case 'overwrite_local_remote':
            listData = overwriteList(localListData, remoteListData);
            break;
        case 'overwrite_remote_local':
            listData = overwriteList(remoteListData, localListData);
            break;
        case 'overwrite_local_remote_full':
            listData = localListData;
            requiredUpdateLocalListData = false;
            break;
        case 'overwrite_remote_local_full':
            listData = remoteListData;
            requiredUpdateRemoteListData = false;
            break;
        // case 'none': return null
        // case 'cancel':
        default: throw new Error('cancel');
    }
    return [listData, requiredUpdateLocalListData, requiredUpdateRemoteListData];
};
const handleSyncList = async (socket) => {
    const [remoteListData, localListData] = await Promise.all([getRemoteListData(socket), getLocalListData(socket)]);
    console.log('handleSyncList', 'remoteListData, localListData');
    console.log('localListData', localListData.defaultList.length || localListData.loveList.length || localListData.userList.length);
    console.log('remoteListData', remoteListData.defaultList.length || remoteListData.loveList.length || remoteListData.userList.length);
    const userSpace = (0, user_1.getUserSpace)(socket.userInfo.name);
    const clientId = socket.keyInfo.clientId;
    if (localListData.defaultList.length || localListData.loveList.length || localListData.userList.length) {
        if (remoteListData.defaultList.length || remoteListData.loveList.length || remoteListData.userList.length) {
            const [mergedList, requiredUpdateLocalListData, requiredUpdateRemoteListData] = await handleMergeListData(socket);
            console.log('handleMergeListData', 'mergedList', requiredUpdateLocalListData, requiredUpdateRemoteListData);
            let key;
            if (requiredUpdateLocalListData) {
                key = await setLocalList(socket, mergedList);
                await overwriteRemoteListData(socket, mergedList, key, [clientId]);
                if (!requiredUpdateRemoteListData)
                    await userSpace.listManage.updateDeviceSnapshotKey(clientId, key);
            }
            if (requiredUpdateRemoteListData) {
                if (!key)
                    key = await userSpace.listManage.getCurrentListInfoKey();
                await setRemotelList(socket, mergedList, key);
            }
        }
        else {
            await setRemotelList(socket, localListData, await userSpace.listManage.getCurrentListInfoKey());
        }
    }
    else {
        let key;
        if (remoteListData.defaultList.length || remoteListData.loveList.length || remoteListData.userList.length) {
            key = await setLocalList(socket, remoteListData);
            await overwriteRemoteListData(socket, remoteListData, key, [clientId]);
        }
        key ??= await userSpace.listManage.getCurrentListInfoKey();
        await userSpace.listManage.updateDeviceSnapshotKey(clientId, key);
    }
};
const mergeListDataFromSnapshot = (sourceList, targetList, snapshotList, addMusicLocationType) => {
    const removedListIds = new Set();
    const sourceListItemIds = new Set();
    const targetListItemIds = new Set();
    for (const m of sourceList)
        sourceListItemIds.add(m.id);
    for (const m of targetList)
        targetListItemIds.add(m.id);
    if (snapshotList) {
        for (const m of snapshotList) {
            if (!sourceListItemIds.has(m.id) || !targetListItemIds.has(m.id))
                removedListIds.add(m.id);
        }
    }
    let newList;
    const map = new Map();
    const ids = [];
    switch (addMusicLocationType) {
        case 'top':
            newList = [...targetList, ...sourceList];
            for (let i = newList.length - 1; i > -1; i--) {
                const item = newList[i];
                if (map.has(item.id) || removedListIds.has(item.id))
                    continue;
                ids.unshift(item.id);
                map.set(item.id, item);
            }
            break;
        case 'bottom':
        default:
            newList = [...sourceList, ...targetList];
            for (const item of newList) {
                if (map.has(item.id) || removedListIds.has(item.id))
                    continue;
                ids.push(item.id);
                map.set(item.id, item);
            }
            break;
    }
    return ids.map(id => map.get(id));
};
const checkListLatest = async (socket) => {
    const remoteListMD5 = await getRemoteListMD5(socket);
    const userSpace = (0, user_1.getUserSpace)(socket.userInfo.name);
    const userCurrentListInfoKey = await userSpace.listManage.getDeviceCurrentSnapshotKey(socket.keyInfo.clientId);
    const currentListInfoKey = await userSpace.listManage.getCurrentListInfoKey();
    // console.log('checkListLatest', remoteListMD5, currentListInfoKey)
    const latest = remoteListMD5 == currentListInfoKey;
    if (latest && userCurrentListInfoKey != currentListInfoKey)
        await userSpace.listManage.updateDeviceSnapshotKey(socket.keyInfo.clientId, currentListInfoKey);
    return latest;
};
const selectData = (snapshot, local, remote) => {
    return snapshot == local
        ? remote
        // ? (snapshot == remote ? snapshot as T : remote)
        : local;
};
const handleMergeListDataFromSnapshot = async (socket, snapshot) => {
    if (await checkListLatest(socket))
        return;
    const addMusicLocationType = (0, user_1.getUserConfig)(socket.userInfo.name)['list.addMusicLocationType'];
    const [remoteListData, localListData] = await Promise.all([getRemoteListData(socket), getLocalListData(socket)]);
    const newListData = {
        defaultList: [],
        loveList: [],
        userList: [],
    };
    newListData.defaultList = mergeListDataFromSnapshot(localListData.defaultList, remoteListData.defaultList, snapshot.defaultList, addMusicLocationType);
    newListData.loveList = mergeListDataFromSnapshot(localListData.loveList, remoteListData.loveList, snapshot.loveList, addMusicLocationType);
    const localUserListData = createUserListDataObj(localListData);
    const remoteUserListData = createUserListDataObj(remoteListData);
    const snapshotUserListData = createUserListDataObj(snapshot);
    const removedListIds = new Set();
    const localUserListIds = new Set();
    const remoteUserListIds = new Set();
    for (const l of localListData.userList)
        localUserListIds.add(l.id);
    for (const l of remoteListData.userList)
        remoteUserListIds.add(l.id);
    for (const l of snapshot.userList) {
        if (!localUserListIds.has(l.id) || !remoteUserListIds.has(l.id))
            removedListIds.add(l.id);
    }
    let newUserList = [];
    for (const list of localListData.userList) {
        if (removedListIds.has(list.id))
            continue;
        const remoteList = remoteUserListData.get(list.id);
        let newList;
        if (remoteList) {
            const snapshotList = snapshotUserListData.get(list.id) ?? { name: null, source: null, sourceListId: null, list: [] };
            newList = (0, utils_1.buildUserListInfoFull)({
                id: list.id,
                name: selectData(snapshotList.name, list.name, remoteList.name),
                source: selectData(snapshotList.source, list.source, remoteList.source),
                sourceListId: selectData(snapshotList.sourceListId, list.sourceListId, remoteList.sourceListId),
                locationUpdateTime: list.locationUpdateTime,
                list: mergeListDataFromSnapshot(list.list, remoteList.list, snapshotList.list, addMusicLocationType),
            });
        }
        else {
            newList = { ...list };
        }
        newUserList.push(newList);
    }
    remoteListData.userList.forEach((list, index) => {
        if (removedListIds.has(list.id))
            return;
        const remoteUpdateTime = list?.locationUpdateTime ?? 0;
        if (localUserListData.has(list.id)) {
            const localUpdateTime = localUserListData.get(list.id)?.locationUpdateTime ?? 0;
            if (localUpdateTime >= remoteUpdateTime)
                return;
            // 调整位置
            const [newList] = newUserList.splice(newUserList.findIndex(l => l.id == list.id), 1);
            newList.locationUpdateTime = localUpdateTime;
            newUserList.splice(index, 0, newList);
        }
        else {
            if (remoteUpdateTime) {
                newUserList.splice(index, 0, { ...list });
            }
            else {
                newUserList.push({ ...list });
            }
        }
    });
    newListData.userList = newUserList;
    const key = await setLocalList(socket, newListData);
    const err = await setRemotelList(socket, newListData, key).catch(err => err);
    await overwriteRemoteListData(socket, newListData, key, [socket.keyInfo.clientId]);
    if (err)
        throw err;
};
const syncList = async (socket) => {
    // socket.data.snapshotFilePath = getSnapshotFilePath(socket.keyInfo)
    // console.log(socket.keyInfo)
    if (!socket.feature.list)
        throw new Error('list feature options not available');
    if (!socket.feature.list.skipSnapshot) {
        const user = (0, user_1.getUserSpace)(socket.userInfo.name);
        const userCurrentListInfoKey = await user.listManage.getDeviceCurrentSnapshotKey(socket.keyInfo.clientId);
        if (userCurrentListInfoKey) {
            const listData = await user.listManage.snapshotDataManage.getSnapshot(userCurrentListInfoKey);
            if (listData) {
                console.log('handleMergeListDataFromSnapshot');
                await handleMergeListDataFromSnapshot(socket, listData);
                return;
            }
        }
    }
    await handleSyncList(socket);
};
// export default async(_wss: LX.SocketServer, socket: LX.Socket) => {
//   if (!wss) {
//     wss = _wss
//     _wss.addListener('close', () => {
//       wss = null
//     })
//   }
//   let disconnected = false
//   socket.onClose(() => {
//     disconnected = true
//     if (syncingId == socket.keyInfo.clientId) syncingId = null
//   })
//   while (true) {
//     if (disconnected) throw new Error('disconnected')
//     if (!syncingId) break
//     await wait()
//   }
//   syncingId = socket.keyInfo.clientId
//   await syncList(socket).then(async() => {
//     return finishedSync(socket)
//   }).finally(() => {
//     syncingId = null
//   })
// }
// const removeSnapshot = async(keyInfo: LX.Sync.KeyInfo) => {
//   const filePath = getSnapshotFilePath(keyInfo)
//   await fsPromises.unlink(filePath)
// }
const sync = async (socket) => {
    let disconnected = false;
    socket.onClose(() => {
        disconnected = true;
        if (syncingId == socket.keyInfo.clientId)
            syncingId = null;
    });
    while (true) {
        if (disconnected)
            throw new Error('disconnected');
        if (!syncingId)
            break;
        await wait();
    }
    syncingId = socket.keyInfo.clientId;
    await syncList(socket).then(async () => {
        await finishedSync(socket);
        socket.moduleReadys.list = true;
    }).finally(() => {
        syncingId = null;
    });
};
exports.sync = sync;
