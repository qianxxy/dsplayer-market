"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sync = void 0;
// import { SYNC_CLOSE_CODE } from '../../../constants.js'
const constants_1 = require("../../../constants.js");
const user_1 = require("../../../user/index.js");
const utils_1 = require("../utils");
// type ListInfoType = LX.List.UserListInfoFull | LX.List.MyDefaultListInfoFull | LX.List.MyLoveListInfoFull
// let wss: LX.SocketServer | null
let syncingId = null;
const wait = async (time = 1000) => await new Promise((resolve, reject) => setTimeout(resolve, time));
const getRemoteListData = async (socket) => {
    console.log('getRemoteListData');
    return (await socket.remoteQueueDislike.dislike_sync_get_list_data()) ?? '';
};
const getRemoteDataMD5 = async (socket) => {
    return socket.remoteQueueDislike.dislike_sync_get_md5();
};
const getLocalListData = async (socket) => {
    return (0, user_1.getUserSpace)(socket.userInfo.name).dislikeManage.getDislikeRules();
};
const getSyncMode = async (socket) => {
    const mode = await socket.remoteQueueDislike.dislike_sync_get_sync_mode();
    return constants_1.TRANS_MODE[mode] ?? 'cancel';
};
const finishedSync = async (socket) => {
    await socket.remoteQueueDislike.dislike_sync_finished();
};
const setLocalList = async (socket, listData) => {
    await global.event_dislike.dislike_data_overwrite(socket.userInfo.name, listData, true);
    const userSpace = (0, user_1.getUserSpace)(socket.userInfo.name);
    return userSpace.dislikeManage.createSnapshot();
};
const overwriteRemoteListData = async (socket, listData, key, excludeIds = []) => {
    const action = { action: 'dislike_data_overwrite', data: listData };
    const tasks = [];
    const userSpace = (0, user_1.getUserSpace)(socket.userInfo.name);
    socket.broadcast((client) => {
        if (excludeIds.includes(client.keyInfo.clientId) || client.userInfo?.name != socket.userInfo.name || !client.moduleReadys?.dislike)
            return;
        tasks.push(client.remoteQueueDislike.onDislikeSyncAction(action).then(async () => {
            return userSpace.dislikeManage.updateDeviceSnapshotKey(client.keyInfo.clientId, key);
        }).catch(err => {
            // TODO send status
            client.close(constants_1.SYNC_CLOSE_CODE.failed);
            // client.moduleReadys.list = false
            console.log(err.message);
        }));
    });
    if (!tasks.length)
        return;
    await Promise.all(tasks);
};
const setRemotelList = async (socket, listData, key) => {
    await socket.remoteQueueDislike.dislike_sync_set_list_data(listData);
    const userSpace = (0, user_1.getUserSpace)(socket.userInfo.name);
    await userSpace.dislikeManage.updateDeviceSnapshotKey(socket.keyInfo.clientId, key);
};
const getRulesLength = (listData) => {
    if (typeof listData === 'string')
        return listData.length;
    return listData?.dislikeList?.length ?? 0;
};
const toRulesString = (listData) => {
    if (typeof listData === 'string')
        return listData;
    if (!listData?.dislikeList)
        return '';
    return listData.dislikeList.map(s => s.dislikeRule ?? '').filter(Boolean).join('\n');
};
const toDislikeRules = (rulesString) => {
    const rules = (0, utils_1.filterRules)(rulesString);
    return {
        dislikeList: Array.from(rules).map(rule => ({
            name: '',
            singer: '',
            dislikeRule: rule,
        })),
    };
};
const mergeList = (socket, sourceListData, targetListData) => {
    const combined = toRulesString(sourceListData) + '\n' + toRulesString(targetListData);
    return toDislikeRules(Array.from((0, utils_1.filterRules)(combined)).join('\n'));
};
const handleMergeListData = async (socket) => {
    const mode = await getSyncMode(socket);
    if (mode == 'cancel')
        throw new Error('cancel');
    const [remoteListData, localListData] = await Promise.all([getRemoteListData(socket), getLocalListData(socket)]);
    console.log('handleMergeListData', 'remoteListData, localListData');
    let listData;
    let requiredUpdateLocalListData = true;
    let requiredUpdateRemoteListData = true;
    switch (mode) {
        case 'merge_local_remote':
            listData = mergeList(socket, localListData, remoteListData);
            break;
        case 'merge_remote_local':
            listData = mergeList(socket, remoteListData, localListData);
            break;
        case 'overwrite_local_remote':
            listData = localListData;
            requiredUpdateLocalListData = false;
            break;
        case 'overwrite_remote_local':
            listData = remoteListData;
            requiredUpdateRemoteListData = false;
            break;
        // case 'none': return null
        // case 'cancel':
        default: throw new Error('cancel');
    }
    return [listData, requiredUpdateLocalListData, requiredUpdateRemoteListData];
};
const handleSyncList = async (socket) => {
    const [remoteListData, localListData] = await Promise.all([getRemoteListData(socket), getLocalListData(socket)]);
    const localLen = getRulesLength(localListData);
    const remoteLen = getRulesLength(remoteListData);
    console.log('handleSyncList', 'remoteListData, localListData');
    console.log('localListData', localLen);
    console.log('remoteListData', remoteLen);
    const userSpace = (0, user_1.getUserSpace)(socket.userInfo.name);
    const clientId = socket.keyInfo.clientId;
    if (localLen) {
        if (remoteLen) {
            const [mergedList, requiredUpdateLocalListData, requiredUpdateRemoteListData] = await handleMergeListData(socket);
            console.log('handleMergeListData', 'mergedList', requiredUpdateLocalListData, requiredUpdateRemoteListData);
            let key;
            if (requiredUpdateLocalListData) {
                key = await setLocalList(socket, mergedList);
                await overwriteRemoteListData(socket, mergedList, key, [clientId]);
                if (!requiredUpdateRemoteListData)
                    await userSpace.dislikeManage.updateDeviceSnapshotKey(clientId, key);
            }
            if (requiredUpdateRemoteListData) {
                if (!key)
                    key = await userSpace.dislikeManage.getCurrentListInfoKey();
                await setRemotelList(socket, mergedList, key);
            }
        }
        else {
            await setRemotelList(socket, localListData, await userSpace.dislikeManage.getCurrentListInfoKey());
        }
    }
    else {
        let key;
        if (remoteLen) {
            key = await setLocalList(socket, remoteListData);
            await overwriteRemoteListData(socket, remoteListData, key, [clientId]);
        }
        key ??= await userSpace.dislikeManage.getCurrentListInfoKey();
        await userSpace.dislikeManage.updateDeviceSnapshotKey(clientId, key);
    }
};
const mergeDataFromSnapshot = (sourceList, targetList, snapshotList) => {
    const removedRules = new Set();
    const sourceRules = (0, utils_1.filterRules)(toRulesString(sourceList));
    const targetRules = (0, utils_1.filterRules)(toRulesString(targetList));
    if (snapshotList) {
        const snapshotRules = (0, utils_1.filterRules)(toRulesString(snapshotList));
        for (const m of snapshotRules.values()) {
            if (!sourceRules.has(m) || !targetRules.has(m))
                removedRules.add(m);
        }
    }
    const mergedStr = Array.from(new Set(Array.from([...sourceRules, ...targetRules]).filter((rule) => {
        return !removedRules.has(rule);
    }))).join('\n');
    return toDislikeRules(mergedStr);
};
const checkListLatest = async (socket) => {
    const remoteListMD5 = await getRemoteDataMD5(socket);
    const userSpace = (0, user_1.getUserSpace)(socket.userInfo.name);
    const userCurrentListInfoKey = await userSpace.dislikeManage.getDeviceCurrentSnapshotKey(socket.keyInfo.clientId);
    const currentListInfoKey = await userSpace.dislikeManage.getCurrentListInfoKey();
    const latest = remoteListMD5 == currentListInfoKey;
    if (latest && userCurrentListInfoKey != currentListInfoKey)
        await userSpace.dislikeManage.updateDeviceSnapshotKey(socket.keyInfo.clientId, currentListInfoKey);
    return latest;
};
const handleMergeListDataFromSnapshot = async (socket, snapshot) => {
    if (await checkListLatest(socket))
        return;
    const [remoteListData, localListData] = await Promise.all([getRemoteListData(socket), getLocalListData(socket)]);
    const newDislikeData = mergeDataFromSnapshot(localListData, remoteListData, snapshot);
    const key = await setLocalList(socket, newDislikeData);
    const err = await setRemotelList(socket, newDislikeData, key).catch(err => err);
    await overwriteRemoteListData(socket, newDislikeData, key, [socket.keyInfo.clientId]);
    if (err)
        throw err;
};
const syncDislike = async (socket) => {
    // socket.data.snapshotFilePath = getSnapshotFilePath(socket.keyInfo)
    // console.log(socket.keyInfo)
    if (!socket.feature.dislike)
        throw new Error('dislike feature options not available');
    if (!socket.feature.dislike.skipSnapshot) {
        const user = (0, user_1.getUserSpace)(socket.userInfo.name);
        const userCurrentDislikeInfoKey = await user.dislikeManage.getDeviceCurrentSnapshotKey(socket.keyInfo.clientId);
        if (userCurrentDislikeInfoKey) {
            const listData = await user.dislikeManage.snapshotDataManage.getSnapshot(userCurrentDislikeInfoKey);
            if (listData) {
                console.log('handleMergeDislikeDataFromSnapshot');
                await handleMergeListDataFromSnapshot(socket, listData);
                return;
            }
        }
    }
    await handleSyncList(socket);
};
const sync = async (socket) => {
    let disconnected = false;
    socket.onClose(() => {
        disconnected = true;
        if (syncingId == socket.keyInfo.clientId)
            syncingId = null;
    });
    while (true) {
        if (disconnected)
            throw new Error('disconnected');
        if (!syncingId)
            break;
        await wait();
    }
    syncingId = socket.keyInfo.clientId;
    await syncDislike(socket).then(async () => {
        await finishedSync(socket);
        socket.moduleReadys.dislike = true;
    }).finally(() => {
        syncingId = null;
    });
};
exports.sync = sync;
