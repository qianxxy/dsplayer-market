# -*- coding: utf-8 -*-
"""内置健康检查源（docs/plugin/PY-PLUGIN-DESIGN.md §七.5）：返回固定数据，
作为插件 ping/call 全链路的自测源——不依赖任何外部网络。
"""
import json


class Spider:
    def __init__(self, t4_api=""):
        self.t4_api = t4_api
        self.extend = ""

    def init(self, ext=""):
        self.extend = ext or ""
        return {"status": "demo ok"}

    def homeContent(self, filter):
        return {
            "class": [
                {"type_id": "demo", "type_name": "演示分类"},
            ],
            "filters": {},
        }

    def homeVideoContent(self):
        return {"list": [
            {
                "vod_id": "demo1",
                "vod_name": "演示影片",
                "vod_pic": "",
                "vod_remarks": "内置演示",
            },
        ]}

    def categoryContent(self, tid, pg, filter, extend):
        return json.dumps({
            "list": [],
            "pagecount": 1,
            "total": 0,
        }, ensure_ascii=False)

    def detailContent(self, ids):
        return {"list": []}

    def searchContent(self, wd, quick, pg):
        return {"list": []}

    def playerContent(self, flag, id, vipFlags):
        return {"url": "", "jx": "", "parse": 0, "header": {}}

    def localProxy(self, params):
        return {}
