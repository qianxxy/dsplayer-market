# DsPlayer Python 运行时演示源：drpys 风格 T4 HTTP 服务（纯标准库零依赖）。
#
# 用法（服务页添加，或命令行验证）：
#   py.sh t4_demo.py --port 5758
# 然后在 DsPlayer 配置 T4 接口：http://127.0.0.1:5758
#
# T4 协议面：/（源目录）、/?ac=detail&ids=、/?wd=搜索、/proxy/do=play。
# 本 demo 数据为静态假数据，验证链路用；真实源请参考此结构替换抓取逻辑。
import argparse
import json
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

CLASSES = [
    {"type_id": "1", "type_name": "电影"},
    {"type_id": "2", "type_name": "剧集"},
]
VODS = [
    {"vod_id": "demo-1", "vod_name": "演示影片一", "vod_pic": "",
     "vod_remarks": "HD·演示", "type_id": "1", "type_name": "电影"},
    {"vod_id": "demo-2", "vod_name": "演示影片二", "vod_pic": "",
     "vod_remarks": "更新至2集", "type_id": "2", "type_name": "剧集"},
]


class Handler(BaseHTTPRequestHandler):
    def _json(self, obj):
        body = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        ac = q.get("ac", [""])[0]
        if u.path == "/proxy":
            self._json({"code": 200, "msg": "demo proxy", "url": ""})
            return
        if ac == "detail":
            ids = q.get("ids", [""])[0].split(",")
            hits = [v for v in VODS if v["vod_id"] in ids]
            for v in hits:
                v["vod_play_from"] = "demo"
                v["vod_play_url"] = "第01集$demo-play://ep1"
            self._json({"list": hits})
            return
        wd = q.get("wd", [""])[0]
        if wd:
            self._json({"list": [v for v in VODS if wd in v["vod_name"]]})
            return
        pg = int(q.get("pg", ["1"])[0] or 1)
        self._json({
            "class": CLASSES,
            "list": VODS if pg == 1 else [],
            "page": pg, "pagecount": 1, "limit": len(VODS), "total": len(VODS),
        })

    def log_message(self, fmt, *args):
        print(f"[t4_demo] {self.address_string()} {fmt % args}", flush=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=5758)
    ap.add_argument("--host", default="127.0.0.1")
    args = ap.parse_args()
    srv = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"[t4_demo] serving on http://{args.host}:{args.port}", flush=True)
    srv.serve_forever()
