/* GM 包装层探针（T4 验收 fixture）：booster 语境下逐项验 GM_* 并上报 */
(function () {
  var out = [];
  function rec(name, ok, detail) { out.push((ok ? 'PASS ' : 'FAIL ') + name + (detail ? ' :: ' + detail : '')); }
  function report() {
    console.log('[gm-probe] ' + out.join(' || '));
    window.__gmProbeSummary = { pass: out.filter(function (s) { return s.indexOf('PASS') === 0; }).length, total: out.length, results: out };
  }
  try {
    rec('__fmExt=true', window.__fmExt === true);
    var fns = ['GM_addStyle', 'GM_log', 'GM_getValue', 'GM_setValue', 'GM_deleteValue', 'GM_xmlhttpRequest'];
    var miss = fns.filter(function (f) { return typeof window[f] !== 'function'; });
    rec('GM 方法齐', miss.length === 0, miss.join(','));
    var st = window.GM_addStyle('#gm-probe-mark{color:red}');
    var st2 = window.GM_addStyle('#gm-probe-mark{color:red}');
    rec('GM_addStyle 幂等', !!st && st === st2 && st.textContent === '#gm-probe-mark{color:red}');
    window.GM_log('probe-log-line', { n: 1 });
    var k = 'probe_k_' + Date.now();
    window.GM_getValue(k, 'dflt').then(function (v) {
      rec('GM_getValue 默认值', v === 'dflt', String(v));
      return window.GM_setValue(k, 'v1');
    }).then(function () {
      return window.GM_getValue(k, 'dflt');
    }).then(function (v) {
      rec('GM_setValue→getValue 往返', v === 'v1', String(v));
      return window.GM_deleteValue(k);
    }).then(function () {
      return window.GM_getValue(k, 'gone');
    }).then(function (v) {
      rec('GM_deleteValue 后回落默认', v === 'gone', String(v));
      return window.fm.ext.info();
    }).then(function (info) {
      rec('fm.ext.info matched/enabled', info && info.matched === true && info.enabled === true,
          info && (info.siteKey + ' enabled=' + info.enabled));
      return window.fm.ext.log('probe ext.log ok');
    }).then(function () {
      var port = window.ds.env.gwPort;
      return new Promise(function (resolve) {
        window.GM_xmlhttpRequest({
          method: 'GET',
          url: 'http://127.0.0.1:' + port + '/',
          timeout: 8000,
          onload: function (r) { rec('GM_xmlhttpRequest onload', r.status === 200, 'status=' + r.status + ' len=' + String(r.responseText || '').length); resolve(); },
          onerror: function (e) { rec('GM_xmlhttpRequest onload', false, JSON.stringify(e)); resolve(); }
        });
      });
    }).then(report)['catch'](function (e) { rec('probe 异常', false, String(e)); report(); });
  } catch (e) { rec('probe 同步异常', false, String(e)); report(); }
})();
