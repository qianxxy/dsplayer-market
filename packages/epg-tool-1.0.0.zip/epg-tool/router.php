<?php
/**
 * @file router.php
 * @brief DsPlayer EPG 服务引导层（本文件为 DsPlayer 侧新增，非上游代码）
 *
 * 职责（包装上游 iptv-tool epg/，不改上游任何文件）：
 *  1. 非 PHP 静态资源直通（交 PHP 内置服务器默认处理）；PHP 路径一律
 *     走本引导层——否则内置服务器直接服务 index.php 会绕过建表逻辑；
 *  2. nginx 重写语义对齐（上游 Dockerfile 的 /t.xml 等短路由 → index.php?type=）；
 *  3. 建表引导：上游 index.php 假设表已存在（initialDB 只在其 manage.php/
 *     crond.php 调用，本服务跑 headless 无管理页，首启自建）；
 *  4. 数据新鲜度自愈：SQLite 缺失或超龄 → 后台异步 update.php（替换
 *     crond.php 常驻循环——移动端不驻 cron 进程，按需抓取）；
 *  5. 转发上游 index.php（DIYP: ?ch=&date= / XMLTV: t.xml / t.xml.gz）。
 *
 * 用法（DsPlayer 服务包自动生成）：
 *   php -S 0.0.0.0:<port> router.php   （workDir = 本目录）
 *
 * 上游项目：https://github.com/taksssss/iptv-tool （GPL-2.0，LICENSE
 * 见同目录 LICENSE.iptv-tool.txt）
 */

$root = __DIR__;
// CWD 钉到本目录：上游各文件的相对 require（'public.php' 等）与后台
// update.php 子进程的解析基准都靠它，防从任意目录起服务时解析失败
@chdir($root);

// ── 1. 静态直通（仅非 PHP 资源）──
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? '/';
$isPhp = strtolower(substr($path, -4)) === '.php';
if ($path !== '/' && !$isPhp) {
    $real = realpath($root . $path);
    if ($real !== false && is_file($real) && strncmp($real, $root, strlen($root)) === 0) {
        return false;
    }
}

// ── 2. 短路由重写（注入 QUERY_STRING，上游只读 $_SERVER['QUERY_STRING']）──
$rewrites = [
    '/tv.m3u' => 'type=m3u',
    '/tv.txt' => 'type=txt',
    '/t.xml' => 'type=xml',
    '/t.xml.gz' => 'type=gz',
];
if (isset($rewrites[$path])) {
    $_SERVER['QUERY_STRING'] = $rewrites[$path]
        . (($_SERVER['QUERY_STRING'] ?? '') !== '' ? '&' . $_SERVER['QUERY_STRING'] : '');
}

// ── 3. 建表引导（首启自建；后续请求 IF NOT EXISTS 零成本）──
require_once $root . '/public.php';
initialDB();

// ── 4. 数据新鲜度自愈（后台异步，不阻塞本次请求）──
// 判据 = update_log 最新记录时间（**不可用 data.db mtime**：initialDB 每次
// 请求都会建表，db 文件恒「新鲜」→ 永不触发抓取；真机实锤）。首次请求
// （无任何更新记录）即触发首抓；锁文件防重复触发（30 分钟窗口内视为在途）。
$interval = 6 * 3600;
$configFile = $root . '/data/config.json';
if (is_file($configFile)) {
    $cfg = json_decode((string) @file_get_contents($configFile), true);
    if (is_array($cfg) && !empty($cfg['interval_time'])) {
        $interval = max(1800, (int) $cfg['interval_time']);
    }
}
$latestLog = null;
try {
    $latestLog = $db->query('SELECT MAX(timestamp) FROM update_log')->fetchColumn();
} catch (Exception $e) {
    // 表缺失等异常：视为从未更新（下方触发抓取；update.php 自带 initialDB）
}
$stale = empty($latestLog) || (time() - (int) strtotime((string) $latestLog)) > $interval;
$lock = $root . '/data/.update.lock';
$locked = is_file($lock) && (time() - (int) @filemtime($lock)) < 1800;
if ($stale && !$locked) {
    @touch($lock);
    // PHP_BINARY 在 cli-server SAPI 下即当前 php 可执行文件；
    // 无 shell 元字符拼接（escapeshellarg 全参数包裹）
    $cmd = escapeshellarg(PHP_BINARY) . ' ' . escapeshellarg($root . '/update.php');
    if (function_exists('exec')) {
        @exec($cmd . ' > /dev/null 2>&1 &');
    } elseif (function_exists('proc_open')) {
        $p = @proc_open($cmd, [1 => ['file', '/dev/null', 'w'], 2 => ['file', '/dev/null', 'w']], $pipes);
        if (is_resource($p)) {
            @proc_close($p);
        }
    }
}

// ── 5. 转发上游查询入口 ──
// 注：index.php 内的 require_once 'public.php' 因 realpath 相同自动跳过
require $root . '/index.php';
