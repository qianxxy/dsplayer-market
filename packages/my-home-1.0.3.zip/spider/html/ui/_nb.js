/* ============================================================================
 * _nb.js —— DsPlayer 自定义界面（WEB 源 local_web_ui）适配层（NativeBridge shim）
 *
 * 14 套 UI 依赖 window.NativeBridge.getAllTabsSourcesAsync / getHomeContentAsync /
 * … 这套接口，而 DsPlayer 只暴露 window.fm / window.ds。本文件把这套接口桥接到
 * 本机网关 MCP（POST http://127.0.0.1:9978/mcp，工具 list_sites / site_home /
 * site_category / site_search / site_detail），并用 window.fm.vod 打开详情。
 *
 * 入口即本目录：DsPlayer 把 spider/html/ui 整个文件夹注册为 WEB 源（key
 * local_web_ui，api 指向文件夹 → index.html）。皮肤页由 index.html 同目录导航
 * 载入，运行在顶层帧（没有外层容器页），故详情/返回直接调 window.fm。
 *
 * 用法：必须放在 UI 页面 <head> 里、页面自身 <script> 之前。
 * ========================================================================== */
(function () {
  'use strict';

  var TOKEN_KEY = 'dsui_mcptoken';
  var GW_FALLBACK = 'http://127.0.0.1:9978';
  var PIC_FILL = true;      /* 是否用 site_detail 给列表补封面 */
  var PIC_CAP = 15;         /* 单次最多补多少张 */
  var PIC_CONC = 5;         /* 并发数 */
  var PIC_BUDGET = 4500;    /* 补图总预算(ms)，超时就用已有结果 */

  /* ---------------- 运行环境 ----------------
     网关端口只认壳子注入的 ds.env.gwPort（端口动态：9978 起顺延，换设备会变）。
     UI 皮肤跑在 iframe 里，ds 桥可能要逐级（本帧 → 父帧 → 顶层帧）才找得到。
     页面自身 origin 不可信（Web 源以 file:// 或虚拟宿主加载），仅在明确是本机
     回环时才采信；最后兜底 9978。容器帧还会通过 ?gw= 显式下发。 */
  var PORT_OVERRIDE = 0;

  function dsFrom(w) {
    try { return (w && w.ds) ? w.ds : null; } catch (e) { return null; }
  }
  function frames() {
    var a = [];
    try { a.push(window); } catch (e) {}
    try { if (window.parent && window.parent !== window) a.push(window.parent); } catch (e) {}
    try { if (window.top && window.top !== window && window.top !== window.parent) a.push(window.top); } catch (e) {}
    return a;
  }
  function gwPort() {
    if (PORT_OVERRIDE) return PORT_OVERRIDE;
    try {
      var m = /[?&]gw=(\d+)/.exec(String(location.search || ''));
      if (m) return m[1];
    } catch (e) {}
    var ws = frames();
    for (var i = 0; i < ws.length; i++) {
      var d = dsFrom(ws[i]);
      try { if (d && d.env && d.env.gwPort) return d.env.gwPort; } catch (e) {}
    }
    return 0;
  }

  function gwOrigin() {
    var p = gwPort();
    if (p) return 'http://127.0.0.1:' + p;
    try {
      var o = String(location.origin || '');
      if (/^https?:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/.test(o)) return o.replace(/\/+$/, '');
    } catch (e) {}
    return GW_FALLBACK;
  }

  function mcpUrl() { return gwOrigin() + '/mcp'; }

  /* ---------------- 鉴权 token ----------------
     每台设备的 MCP token 都不同，绝不能写死（否则换设备必 403），也绝不假设某条
     通道一定成功。Web 源以 file:// 形态加载（v0.9.10 已知限制），所以：
       · 对网关 / 的 fetch 属跨域，网关 / 无 CORS 响应头 → 大概率失败
       · location.origin 是 file://，不可信（端口只认 ds.env.gwPort / ?gw=）
       · 必须优先走壳子原生请求 ds.req / fm.req（无跨域），才拿得到 / 里内联的 token
     取值顺序：
       ① localStorage 里用户手填的（自动发现失败时弹层填一次并持久化）
       ② ds.env 里若恰好带 token 字段（mcpToken/token/gwToken）
       ③ 原生请求（ds.req → fm.req，逐帧找）读网关 /：壳子渲染该页时内联了本机 token
       ④ 跨域 fetch /（兜底）
       ⑤ 向容器帧要（postMessage dsui:needEnv）——容器跑在顶层，桥更全
     注意：空值不写缓存，且加 5s 冷却，避免一次失败后永久锁死与狂请求。 */
  var TOKEN_CACHE = null;
  var TOKEN_COOL = 0;   /* 空值冷却到期时间戳 */

  function extractToken(t) {
    var s = '';
    if (typeof t === 'string') s = t;
    else if (t && typeof t.text === 'string') s = t.text;
    else if (t) { try { s = JSON.stringify(t); } catch (e) { s = ''; } }
    var m = /Bearer\s+(mcp_[A-Za-z0-9_\-]+)/.exec(s);
    return m ? m[1] : '';
  }

  /* ds.env 里若带了 token 就直接用（不同版本字段名不定，逐个探） */
  function envToken() {
    var ws = frames();
    for (var i = 0; i < ws.length; i++) {
      var d = dsFrom(ws[i]);
      try {
        if (!d || !d.env) continue;
        var t = d.env.mcpToken || d.env.token || d.env.gwToken || '';
        if (t) return String(t).replace(/^Bearer\s+/, '');
      } catch (e) {}
    }
    return '';
  }

  /* 把 ds.req / fm.req / fetch 的各种返回形态归一后找 token */
  function digToken(r) {
    if (r == null) return Promise.resolve('');
    if (typeof r === 'string') return Promise.resolve(extractToken(r));
    if (typeof r.then === 'function') {
      return Promise.resolve(r).then(digToken, function () { return ''; });
    }
    if (typeof r.text === 'function') {
      try { return Promise.resolve(r.text()).then(digToken, function () { return ''; }); }
      catch (e) { return Promise.resolve(''); }
    }
    var keys = ['content', 'body', 'text', 'data', 'result', 'html', 'raw', 'response', 'responseText'];
    for (var i = 0; i < keys.length; i++) {
      var v = r[keys[i]];
      if (!v) continue;
      var hit = extractToken(v);
      if (hit) return Promise.resolve(hit);
    }
    return Promise.resolve(extractToken(r));
  }

  /* 收集某个 window 上可用的原生请求（ds.req 优先，fm.req 次之） */
  function tryReq(win, url) {
    var out = [];
    var d = dsFrom(win);
    if (d && typeof d.req === 'function') {
      out.push(function () { return d.req(url, { timeout: 8 }); });
    }
    var f = null;
    try { f = win.fm; } catch (e) {}
    if (f && typeof f.req === 'function') {
      out.push(function () { return f.req(url, { timeout: 8 }); });
    }
    return out;
  }

  /* 用壳子原生请求读 URL：Web 源是 file://，fetch 跨域会被拦，必须走 ds.req/fm.req。
     逐级在本帧 → 父帧 → 顶层帧里找，任一成功即返回。 */
  function nativeGet(url) {
    var ws = frames();
    var reqs = [];
    for (var i = 0; i < ws.length; i++) {
      var part = tryReq(ws[i], url);
      for (var j = 0; j < part.length; j++) reqs.push(part[j]);
    }
    var idx = -1;
    function next() {
      idx++;
      if (idx >= reqs.length) return Promise.resolve('');
      return Promise.resolve().then(reqs[idx]).then(digToken, function () { return ''; })
        .then(function (tk) { return tk || next(); });
    }
    return next();
  }

  /* 兜底：万一被别的页面以 iframe 嵌入（本帧桥不全）时，向父帧要端口 + token */
  function askParentEnv() {
    return new Promise(function (resolve) {
      var done = false;
      var timer = null;
      function onMsg(ev) {
        var d = ev && ev.data;
        if (!d || d.t !== 'dsui:env') return;
        if (done) return;
        done = true;
        try { window.removeEventListener('message', onMsg); } catch (e) {}
        if (timer) clearTimeout(timer);
        if (d.port) PORT_OVERRIDE = d.port;
        resolve(extractToken(String(d.token || '')));
      }
      try { window.addEventListener('message', onMsg); } catch (e) {}
      try {
        var w = (window.parent && window.parent !== window) ? window.parent : window.top;
        if (w && w !== window) w.postMessage({ t: 'dsui:needEnv' }, '*');
      } catch (e) {}
      timer = setTimeout(function () {
        if (done) return;
        done = true;
        try { window.removeEventListener('message', onMsg); } catch (e) {}
        resolve('');
      }, 1200);
    });
  }

  function discoverToken() {
    if (TOKEN_CACHE) return Promise.resolve(TOKEN_CACHE);
    if (Date.now() < TOKEN_COOL) return Promise.resolve('');
    var lt = '';
    try {
      lt = localStorage.getItem(TOKEN_KEY) || localStorage.getItem('myhome_mcptoken') || '';
    } catch (e) {}
    if (lt) { TOKEN_CACHE = lt; return Promise.resolve(lt); }

    var et = envToken();
    if (et) { TOKEN_CACHE = et; return Promise.resolve(et); }

    var url = gwOrigin() + '/';
    return nativeGet(url).then(function (tk) {
      if (tk) return tk;
      return fetch(url, { cache: 'no-store' })
        .then(function (r) { return r.text(); })
        .then(extractToken, function () { return ''; });
    }).then(function (tk) {
      if (tk) return tk;
      return askParentEnv();
    }).then(function (tk) {
      if (tk) { TOKEN_CACHE = tk; return tk; }
      TOKEN_COOL = Date.now() + 5000;   /* 失败冷却 5s，别狂请求 */
      return '';
    });
  }

  /* 取 DsPlayer 桥：本帧或父/顶层帧的 window.fm（iframe 场景） */
  function fm() {
    try { if (window.fm && window.fm.vod) return window.fm; } catch (e) {}
    try {
      if (window.parent && window.parent !== window && window.parent.fm && window.parent.fm.vod) return window.parent.fm;
    } catch (e) {}
    try {
      if (window.top && window.top !== window && window.top.fm && window.top.fm.vod) return window.top.fm;
    } catch (e) {}
    return null;
  }

  function done(id, res) {
    if (id && typeof window.__onNativeSuccess === 'function') {
      try { window.__onNativeSuccess(id, res, false); } catch (e) {}
    }
  }
  function fail(id, err) {
    if (id && typeof window.__onNativeError === 'function') {
      try { window.__onNativeError(id, String((err && err.message) || err)); } catch (e) {}
    }
  }

  /* ---------------- MCP 客户端 ----------------
     宿主两个坑：
     ① 请求体含非 ASCII → 服务端按 latin1 解码 → asciiJson() 全量转 \uXXXX
     ② Accept 声明 text/event-stream → SSE 分支 latin1 编码中文报错 500
        → Accept 只声明 application/json
  -------------------------------------------- */

  function asciiJson(o) {
    return JSON.stringify(o).replace(/[\u007f-\uffff]/g, function (c) {
      return '\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4);
    });
  }

  function httpPost(url, headers, body, timeoutMs) {
    var opt = { method: 'POST', headers: headers, body: asciiJson(body) };
    if (typeof AbortController === 'function') {
      var ac = new AbortController();
      opt.signal = ac.signal;
      var t = setTimeout(function () { try { ac.abort(); } catch (e) {} }, timeoutMs || 12000);
      return fetch(url, opt).then(function (r) { clearTimeout(t); return r; },
        function (e) { clearTimeout(t); throw e; });
    }
    return fetch(url, opt);
  }

  function parseSse(txt) {
    if (!txt) return null;
    var t = txt.trim();
    if (t.charAt(0) === '{') { try { return JSON.parse(t); } catch (e) {} }
    var data = [];
    t.split(/\r?\n/).forEach(function (ln) {
      if (ln.indexOf('data:') === 0) data.push(ln.slice(5).replace(/^\s/, ''));
    });
    var joined = data.join('\n').trim();
    if (!joined) return null;
    try { return JSON.parse(joined); } catch (e) { return null; }
  }

  function extractToolResult(msg) {
    var r = msg && msg.result;
    if (!r) return null;
    var txt = (r.content && r.content.length)
      ? r.content.map(function (c) { return (c && c.text) || ''; }).join('') : '';
    if (r.isError) throw new Error(txt || '工具执行失败');
    if (r.structuredContent) return r.structuredContent;
    if (txt) { try { return JSON.parse(txt); } catch (e) { return txt; } }
    return r;
  }

  function mcpHeaders(tk, sid) {
    var h = { 'Content-Type': 'application/json', 'Accept': 'application/json' };
    if (tk) h['Authorization'] = 'Bearer ' + tk;
    if (sid) h['Mcp-Session-Id'] = sid;
    return h;
  }

  function mcpHandshake(tk) {
    return httpPost(mcpUrl(), mcpHeaders(tk), {
      jsonrpc: '2.0', id: 1, method: 'initialize',
      params: { protocolVersion: '2025-06-18', capabilities: {}, clientInfo: { name: 'dsui', version: '1.0' } }
    }).then(function (res) {
      if (res.status === 401 || res.status === 403) {
        var e = new Error('网关拒绝（HTTP ' + res.status + ' ' + diag() + '）'); e.auth = true; throw e;
      }
      if (!res.ok && res.status !== 202) throw new Error('initialize HTTP ' + res.status + ' ' + diag());
      var sid = res.headers.get('Mcp-Session-Id') || res.headers.get('mcp-session-id');
      return res.text().then(function () { return sid; });
    }).then(function (sid) {
      return httpPost(mcpUrl(), mcpHeaders(tk, sid), { jsonrpc: '2.0', method: 'notifications/initialized' })
        .then(function (r) { return r.text(); })
        .then(function () { return sid; });
    });
  }

  var SESS = { sid: null, token: null, pend: null };

  /* 诊断串：让 UI 的错误区直接能看出端口/token 状态 */
  function diag() {
    return '@' + gwOrigin() + (SESS.token ? ' [token#' + SESS.token.slice(0, 8) + ']' : ' [no token]');
  }

  function resolveToken(tk) {
    if (typeof tk === 'string' && tk) return Promise.resolve(tk);
    if (SESS.token) return Promise.resolve(SESS.token);   /* 只认非空 token，空值允许重试 */
    return discoverToken();
  }

  function mcpInit(tk) {
    return resolveToken(tk).then(function (t) {
      if (SESS.sid && SESS.token === t) return SESS.sid;
      if (SESS.pend && SESS.token === t) return SESS.pend;
      SESS.token = t; SESS.sid = null;
      SESS.pend = mcpHandshake(t).then(function (sid) {
        SESS.sid = sid; SESS.pend = null; return sid;
      }, function (e) { SESS.pend = null; throw e; });
      return SESS.pend;
    });
  }

  function mcpTool(tool, args, tk) {
    return resolveToken(tk).then(function (t) {
      return mcpInit(t).then(function (sid) {
        return httpPost(mcpUrl(), mcpHeaders(t, sid), {
          jsonrpc: '2.0', id: 2, method: 'tools/call',
          params: { name: tool, arguments: args || {} }
        }).then(function (res) {
          if (!res.ok) {
            var e = new Error('tools/call HTTP ' + res.status + ' ' + diag());
            if (res.status === 401 || res.status === 403) e.auth = true; else e.http = res.status;
            throw e;
          }
          return res.text();
        }).then(function (txt) {
          var msg = parseSse(txt);
          if (!msg) throw new Error('MCP 空响应');
          if (msg.error) throw new Error(msg.error.message || JSON.stringify(msg.error));
          return extractToolResult(msg);
        });
      });
    })['catch'](function (err) {
      if (err && err.auth) promptToken();
      throw err;
    });
  }

  function mcpCall(tool, args, tk) {
    return mcpTool(tool, args, tk)['catch'](function (err) {
      if (err && err.http && SESS.sid) { SESS.sid = null; return mcpTool(tool, args, tk); }
      throw err;
    });
  }

  /* ---------------- 鉴权兜底 ----------------
     自动发现拿不到 token（或 token 被重置）时，弹层让用户手填一次。
     token 只存在本机 localStorage，不随插件包分发。 */
  var prompting = false;

  function promptToken() {
    if (prompting) return;
    if (!document.body) return;
    prompting = true;
    try {
      var old = document.querySelector('[data-dsui-token]');
      if (old && old.parentNode) old.parentNode.removeChild(old);
      var box = document.createElement('div');
      box.setAttribute('data-dsui-token', '1');
      box.style.cssText = 'position:fixed;left:0;top:0;right:0;bottom:0;z-index:2147483000;'
        + 'background:rgba(0,0,0,.66);display:flex;align-items:center;justify-content:center;padding:24px;'
        + 'font:14px/1.6 system-ui,"Microsoft YaHei",sans-serif';
      box.innerHTML = '<div style="width:min(580px,100%);background:#1b1b21;color:#eee;border:1px solid #33333d;'
        + 'border-radius:14px;padding:20px 22px;box-shadow:0 20px 60px rgba(0,0,0,.55)">'
        + '<div style="font-size:16px;font-weight:600;margin-bottom:6px">需要填写网关 Token</div>'
        + '<div style="color:#a6a6b0;font-size:13px;margin-bottom:12px">本机 DsPlayer 网关拒绝了请求。请在本机浏览器打开 '
        + '<b style="color:#8ab4ff;word-break:break-all">' + gwOrigin() + '/</b>，点「复制 Claude 配置 JSON」，'
        + '把其中 <b style="color:#8ab4ff">mcp_</b> 开头的一串粘贴到下面。</div>'
        + '<input data-tok spellcheck="false" placeholder="mcp_xxxxxxxxxxxxxxxx" style="width:100%;box-sizing:border-box;'
        + 'padding:10px 12px;border-radius:9px;border:1px solid #3a3a46;background:#111116;color:#eee;'
        + 'font:13px/1.4 ui-monospace,Consolas,monospace;outline:none">'
        + '<div style="display:flex;gap:10px;justify-content:flex-end;margin-top:14px">'
        + '<button data-cancel style="padding:8px 16px;border-radius:9px;border:1px solid #3a3a46;background:transparent;'
        + 'color:#c8c8d0;cursor:pointer">取消</button>'
        + '<button data-ok style="padding:8px 18px;border-radius:9px;border:0;background:#3b6ef5;color:#fff;'
        + 'cursor:pointer">保存并重试</button></div></div>';
      document.body.appendChild(box);

      var inp = box.querySelector('[data-tok]');
      function close() {
        prompting = false;
        try { box.parentNode.removeChild(box); } catch (e) {}
      }
      box.querySelector('[data-cancel]').onclick = close;
      box.querySelector('[data-ok]').onclick = function () {
        var m = /mcp_[A-Za-z0-9_\-]+/.exec(String(inp.value || '').trim());
        if (!m) { inp.style.borderColor = '#e0564f'; try { inp.focus(); } catch (e) {} return; }
        try { localStorage.setItem(TOKEN_KEY, m[0]); } catch (e) {}
        TOKEN_CACHE = m[0];
        try { location.reload(); } catch (e) { close(); }
      };
      setTimeout(function () { try { inp.focus(); } catch (e) {} }, 60);
    } catch (e) { prompting = false; }
  }

  /* ---------------- 封面补图 ----------------
     site_home / site_category / site_search 返回的条目只有 vod_id/vod_name/
     vod_remarks，没有封面；这里用 site_detail 有界补图（并发+预算+缓存），
     预算内拿不到就留空，由 UI 走占位图。 */
  var PIC_CACHE = {};

  function enrichPics(siteKey, items) {
    if (!PIC_FILL || !items || !items.length) return Promise.resolve();
    var todo = [], i;
    for (i = 0; i < items.length && todo.length < PIC_CAP; i++) {
      var it = items[i];
      if (!it || it.vod_pic || !it.vod_id) continue;
      var ck = siteKey + '|' + it.vod_id;
      if (PIC_CACHE[ck]) { it.vod_pic = PIC_CACHE[ck]; continue; }
      todo.push({ it: it, ck: ck });
    }
    if (!todo.length) return Promise.resolve();

    return new Promise(function (resolve) {
      var idx = 0, active = 0, settled = false;
      var timer = setTimeout(function () { settled = true; resolve(); }, PIC_BUDGET);
      function next() {
        if (settled) return;
        if (idx >= todo.length && active === 0) { settled = true; clearTimeout(timer); resolve(); return; }
        while (active < PIC_CONC && idx < todo.length) {
          (function (job) {
            active++;
            mcpCall('site_detail', { siteKey: siteKey, vodId: String(job.it.vod_id) })
              .then(function (d) {
                var p = d && d.vod_pic;
                if (p) { job.it.vod_pic = p; PIC_CACHE[job.ck] = p; }
                active--; next();
              }, function () { active--; next(); });
          })(todo[idx++]);
        }
      }
      next();
    });
  }

  /* ---------------- NativeBridge ---------------- */

  function listSites(id) {
    return mcpCall('list_sites', {}).then(function (ls) {
      var sites = (ls && ls.sites) || [];
      var res = { host: [], py: [], js: [], cj: [], xl: [], selfKey: 'local_web_ui' };
      sites.forEach(function (s) {
        if (!s || !s.key) return;
        var t = String(s.sourceType || '');
        if (/^web/i.test(t)) return;                       /* 屏蔽 WEB 规则 */
        var item = { key: s.key, name: s.name, sourceType: s.sourceType };
        if (/^py/i.test(t)) res.py.push(item);
        else if (/^qjs|^js/i.test(t)) res.js.push(item);
        else res.host.push(item);                          /* drpy3-local 等归入「宿主」 */
      });
      return res;
    }).then(function (res) { done(id, res); }, function (e) { fail(id, e); });
  }

  function getHome(sourceType, siteKey, id) {
    return mcpCall('site_home', { siteKey: siteKey }).then(function (h) {
      var list = (h && h.list) || [];
      return enrichPics(siteKey, list).then(function () {
        done(id, { 'class': (h && h.classes) || [], filters: {}, list: list });
      });
    })['catch'](function (e) { fail(id, e); });
  }

  function getCategory(sourceType, siteKey, tid, pg, filtersJson, id) {
    return mcpCall('site_category', { siteKey: siteKey, tid: String(tid), pg: String(pg) }).then(function (c) {
      var list = (c && c.list) || [];
      var p = Number((c && c.page) || pg) || Number(pg) || 1;
      var hasNext = !!(c && c.hasNext);
      return enrichPics(siteKey, list).then(function () {
        done(id, { list: list, pagecount: hasNext ? p + 1 : p, hasNext: hasNext });
      });
    })['catch'](function (e) { fail(id, e); });
  }

  function search(sourceType, siteKey, kw, id) {
    return mcpCall('site_search', { siteKey: siteKey, wd: String(kw), pg: '1' }).then(function (s) {
      var list = (s && s.list) || [];
      return enrichPics(siteKey, list).then(function () {
        done(id, { list: list, pagecount: 1, hasNext: false });
      });
    })['catch'](function (e) { fail(id, e); });
  }

  var NB = {
    /* —— 源枚举 / 记忆 —— */
    getAllTabsSourcesAsync: function (id) { listSites(id); },
    getLastSelectedSiteAsync: function (id) {
      var o = {};
      try { o = JSON.parse(localStorage.getItem('dsui_last_site') || '{}') || {}; } catch (e) {}
      done(id, o);
    },
    saveLastSelectedSite: function (type, key, name, id) {
      try { localStorage.setItem('dsui_last_site', JSON.stringify({ type: type, key: key, name: name })); } catch (e) {}
      done(id, {});
    },
    setHostHomeSite: function (key, id) {
      try { localStorage.setItem('dsui_host_home', String(key || '')); } catch (e) {}
      done(id, {});
    },

    /* —— 内容 —— */
    getHomeContentAsync: function (sourceType, siteKey, id) { getHome(sourceType, siteKey, id); },
    getCategoryContentAsync: function (sourceType, siteKey, tid, pg, filtersJson, id) {
      getCategory(sourceType, siteKey, tid, pg, filtersJson, id);
    },
    searchContentAsync: function (sourceType, siteKey, kw, id) { search(sourceType, siteKey, kw, id); },

    /* —— 打开详情（裸调用，无 id）：转发给外层容器，由顶层帧调壳子桥 ——
       实测：壳子的 fm.vod 只在顶层帧受理，iframe 内直接调会被静默忽略。 */
    openDetail: function (sourceType, siteKey, vodId, vodName, vodPic) {
      var msg = {
        t: 'dsui:openDetail', sourceType: sourceType, siteKey: siteKey,
        vodId: vodId, vodName: vodName, vodPic: vodPic
      };
      if (window.parent && window.parent !== window) {
        try { window.parent.postMessage(msg, '*'); return; } catch (e) {}
      }
      var b = fm();
      if (b && typeof b.vod === 'function') {
        try { b.vod(siteKey, vodId, vodName, vodPic); } catch (e) {}
      }
    },

    /* —— 退出 / 返回：通知外层容器关闭 UI 层 —— */
    exitSourceUi: function () {
      if (window.parent && window.parent !== window) {
        try { window.parent.postMessage({ t: 'dsui:exit' }, '*'); } catch (e) {}
      } else {
        var b = fm();
        if (b && typeof b.back === 'function') { try { b.back(); } catch (e) {} }
      }
    },

    /* —— 偏好：落 localStorage（同源，容器与 UI 共用） —— */
    saveUserPreference: function (themeKey, layout, baseColor, spotsJson, running) {
      try {
        if (themeKey) localStorage.setItem('dsui_theme', String(themeKey));
        if (layout) localStorage.setItem('dsui_layout', String(layout));
      } catch (e) {}
    },
    setStatusBarTheme: function () { /* 无原生状态栏，忽略 */ }
  };
  NB.exitSourceUI = NB.exitSourceUi;   /* 兼容个别 UI 的大小写写法 */

  window.NativeBridge = NB;

  /* ---------------- 浮动控制条（切换 UI） ---------------- */

  function injectBar() {
    if (window.__dsuiBar) return;
    window.__dsuiBar = 1;
    var root = document.createElement('div');
    root.id = '__dsui_bar';
    root.style.cssText = 'position:fixed;right:10px;bottom:96px;z-index:2147483000;display:flex;flex-direction:column;gap:8px;';
    function mk(txt) {
      var b = document.createElement('div');
      b.textContent = txt;
      b.style.cssText = 'width:42px;height:42px;border-radius:21px;display:flex;align-items:center;justify-content:center;' +
        'font-size:11px;font-weight:600;color:#fff;background:rgba(20,22,26,.62);-webkit-backdrop-filter:blur(6px);' +
        'backdrop-filter:blur(6px);box-shadow:0 2px 10px rgba(0,0,0,.35);border:1px solid rgba(255,255,255,.18);' +
        'cursor:pointer;-webkit-user-select:none;user-select:none;';
      b.addEventListener('click', function () {
        /* 容器页 我的首页.html 已删除：皮肤页此刻就是顶层帧，没有外层可转发，
           直接在同一目录内跳回选择页 index.html（相对路径与 index.html 选皮肤对称）。 */
        try { location.href = 'index.html'; } catch (e) {}
      });
      return b;
    }
    root.appendChild(mk('切换'));
    (document.body || document.documentElement).appendChild(root);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectBar);
  } else {
    injectBar();
  }
})();
