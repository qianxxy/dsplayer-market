DsPlayer 源安全检测规则包（优化版 2026-10-17.3）
============================================================

【本包是什么】
DsPlayer 源安全检测所用 risk_rules 的一份优化版规则文件，schema 与壳子内置
assets/security/risk_rules.json 完全一致（顶层四键：version / rules /
heuristics / counters），可直接被壳子解析，不会破坏内置规则。

内容：rules 124 条 + heuristics 19 条 + counters 6 条，version = 2026-10-17.3

【装到哪儿】
从市场点「导入」后，整包自动解压落盘到：
    /storage/emulated/0/dsplayer/
得到两个文件（直接位于该目录下，不建子目录）：
    risk_rules.optimized.json     规则本体
    risk_rules_README.txt         本说明

【怎么用（手动导入，不会自动生效）】
1. 打开 DsPlayer，进入「风险规则 / 源安全检测」相关设置页；
2. 点击「导入规则」（不同版本入口文字可能略有差异），弹出文件选择；
3. 选择 /storage/emulated/0/dsplayer/risk_rules.optimized.json ；
4. 导入后确认版号显示 2026-10-17.3 即为成功。

说明：本包不做任何自动覆盖。壳子内置规则文件（APK 资源内那份）一字不动，
      现有第三方 risk_rules.json 覆盖文件也不会被改。

【不想用了怎么退】
· 不导入 = 不生效；
· 已导入想回退：回到同一入口重新导入壳子内置版本，或点「恢复默认」；
· 彻底清掉：删除 /storage/emulated/0/dsplayer/ 下的
  risk_rules.optimized.json 与 risk_rules_README.txt 两个文件即可。

【相对内置版修了什么】
· 漏检修复：fs.*Sync 系列全漏检、PHP-SRC-03 非法 severity、HTML 标记与
  PHP 函数名 / scheme 的大小写绕过；
· 新增 23 条覆盖：unserialize 反序列化、反引号执行、动态包含、vm 沙箱逃逸、
  child_process、WebSocket 外传、顶层导航劫持等；
· 正则引擎适配：壳子用 Dart RegExp（V8 Irregexp 移植）求值，支持 lookbehind
  与命名组；已把 15 条依赖 JS 专有写法的回退为 (?<![\w.$]) 形式。

【说明】
规则为启发式检测，命中只代表「疑似」，请结合源的实际行为判断，不要据此
直接认定恶意。本文件由「DsPlayer 综合插件市场」（yydfys/dsplayer-market）分发。
