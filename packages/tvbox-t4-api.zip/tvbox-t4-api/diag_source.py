#!/usr/bin/env python3
"""站点侧真流量诊断 —— 替代这个部署里并不存在的 /diag/{source} 路由。

它做一件事:把源里 diag_urls() 写的探针**真打一遍**,并且用两个视角看同一
个 URL:

    ① 裸打     一次请求,不重试、不隐藏错误 —— 状态码 / 字节数 / cf-mitigated
    ② 框架视角 走 core.http_client(带重试 + 指纹 + 风控页识别)拿到的字节数
    ③ 解析视角 用源自己的 _parse_list() 过一遍,看能解出几条

然后直接给结论行:是「IP/指纹被挡」,还是「解析层(正则)问题」,还是通的。

用法:
    python3 diag_source.py sources/mysite.py
    python3 diag_source.py sources/mysite.py https://example.com/a/ https://example.com/b/
    python3 diag_source.py sources/mysite.py --proxy http://user:pass@host:port
"""

from __future__ import annotations

import argparse
import ast
import importlib.util
import sys
import time
from pathlib import Path

GREEN, RED, YELLOW, DIM, NC = "\033[32m", "\033[31m", "\033[33m", "\033[2m", "\033[0m"

ROOT = Path(__file__).resolve().parent
CHALLENGE_MARKERS = (
    "Just a moment",
    "cf-browser-verification",
    "Verifying you are human",
    "Attention Required",
    "Enable JavaScript and cookies",
    "您即将访问的页面不存在",
    "aks-404-page",
)


def _string_env(tree: ast.Module) -> dict[str, str]:
    """收集所有字面量字符串常量(模块级 + 类属性),用来还原拼出来的 URL。"""
    env: dict[str, str] = {}
    for node in ast.walk(tree):
        targets = []
        if isinstance(node, ast.Assign):
            targets = [t for t in node.targets if isinstance(t, ast.Name)]
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            targets = [node.target]
        if not targets:
            continue
        try:
            val = ast.literal_eval(node.value)
        except Exception:  # noqa: BLE001
            continue
        if isinstance(val, str):
            for t in targets:
                env[t.id] = val
    return env


def _eval_str(node: ast.AST, env: dict[str, str]) -> str | None:
    """尽量把表达式还原成字符串:HOST + "/x"、f"{self.HOST}/y" 都认。"""
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    if isinstance(node, ast.Name):
        return env.get(node.id)
    if isinstance(node, ast.Attribute):
        return env.get(node.attr)
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        left = _eval_str(node.left, env)
        right = _eval_str(node.right, env)
        return None if left is None or right is None else left + right
    if isinstance(node, ast.JoinedStr):
        parts = []
        for v in node.values:
            if isinstance(v, ast.Constant):
                parts.append(str(v.value))
            elif isinstance(v, ast.FormattedValue):
                got = _eval_str(v.value, env)
                parts.append(got if got is not None else "?")
        return "".join(parts)
    return None


def urls_from_source(path: Path) -> list[tuple[str, str]]:
    """从源文件里读 diag_urls() 的返回值(只解析,不执行)。"""
    try:
        text = path.read_text(encoding="utf-8")
        tree = ast.parse(text)
    except Exception as exc:  # noqa: BLE001
        print(f"{YELLOW}读不动 {path}: {exc}{NC}")
        return []
    env = _string_env(tree)
    out: list[tuple[str, str]] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == "diag_urls":
            for sub in ast.walk(node):
                if isinstance(sub, ast.Return) and isinstance(sub.value, ast.List):
                    for elt in sub.value.elts:
                        if isinstance(elt, ast.Tuple) and len(elt.elts) == 2:
                            label = _eval_str(elt.elts[0], env)
                            url = _eval_str(elt.elts[1], env)
                            if label and url:
                                out.append((label, url))
    return out


def load_handler(path: Path):
    """把源文件当独立模块导入,拿到 handler 实例(解析视角要用)。"""
    name = f"_diag_{path.stem}"
    try:
        spec = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)  # type: ignore[arg-type]
        sys.modules[name] = module
        spec.loader.exec_module(module)  # type: ignore[union-attr]
    except Exception as exc:  # noqa: BLE001
        print(f"{YELLOW}导入 {path.name} 失败({type(exc).__name__}: {exc}),跳过解析视角{NC}")
        return None
    try:
        from core.base import VodHandler
    except Exception:  # noqa: BLE001
        return None
    for attr in dir(module):
        obj = getattr(module, attr)
        if (
            isinstance(obj, type)
            and issubclass(obj, VodHandler)
            and obj is not VodHandler
            and getattr(obj, "__module__", "") == module.__name__
        ):
            try:
                return obj()
            except Exception as exc:  # noqa: BLE001
                print(f"{YELLOW}实例化 {obj.__name__} 失败:{exc}{NC}")
                return None
    return None


def raw_probe(url: str, proxy: str = "") -> dict:
    """一次请求,什么都不掩盖。"""
    out = {"status": 0, "length": 0, "mitigated": "", "final": url, "body": "", "err": ""}
    try:
        from curl_cffi import requests as cr

        kw: dict = {"impersonate": "chrome", "timeout": 25, "allow_redirects": True}
        if proxy:
            kw["proxies"] = {"http": proxy, "https": proxy}
        resp = cr.get(url, **kw)
        out["status"] = resp.status_code
        out["length"] = len(resp.content)
        out["mitigated"] = resp.headers.get("cf-mitigated", "") or ""
        out["final"] = str(getattr(resp, "url", url))
        out["body"] = resp.content.decode("utf-8", "ignore")
    except Exception as exc:  # noqa: BLE001
        out["err"] = f"{type(exc).__name__}: {exc}"
    return out


def framework_probe(url: str, handler) -> tuple[int, str]:
    try:
        html = handler._http.get(url)
        return len(html.encode("utf-8", "ignore")), ""
    except Exception as exc:  # noqa: BLE001
        return 0, f"{type(exc).__name__}: {exc}"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("source", help="源文件路径,例如 sources/mysite.py")
    ap.add_argument("urls", nargs="*", help="额外要探的 URL(不给就用源里的 diag_urls)")
    ap.add_argument("--proxy", default="", help="这次诊断走这个代理试")
    args = ap.parse_args()

    src = Path(args.source)
    if not src.is_file():
        src = ROOT / args.source
    if not src.is_file():
        print(f"{RED}找不到源文件 {args.source}{NC}")
        return 1

    probes: list[tuple[str, str]] = [(f"cli-{i+1}", u) for i, u in enumerate(args.urls)]
    probes += urls_from_source(src)
    if not probes:
        print(
            f"{YELLOW}{src.name} 里没有 diag_urls() 字面量探针,也没在命令行给 URL。\n"
            f"用法: python3 diag_source.py {args.source} https://站点/分类/路径/{NC}"
        )
        return 1

    handler = load_handler(src)
    label = getattr(handler, "display_name", src.stem) if handler else src.stem

    print("=" * 68)
    print(f"诊断 {label}  ({src.name})  探针 {len(probes)} 条")
    if args.proxy:
        print(f"代理:{args.proxy}")
    print("=" * 68)

    verdicts: list[str] = []
    for name, url in probes:
        t0 = time.time()
        raw = raw_probe(url, args.proxy)
        dt = time.time() - t0

        fw_len, fw_err = framework_probe(url, handler) if handler else (0, "无 handler")
        parsed = -1
        if handler and raw["body"] and hasattr(handler, "_parse_list"):
            try:
                parsed = len(handler._parse_list(raw["body"]))
            except Exception:  # noqa: BLE001
                parsed = -2

        print(f"\n[{name}] {url}")
        if raw["err"]:
            print(f"  裸打        : {RED}{raw['err']}{NC}")
        else:
            print(
                f"  裸打        : status={raw['status']}  {raw['length']}B  "
                f"cf-mitigated={raw['mitigated'] or '-'}  {dt:.2f}s"
            )
            if raw["final"] != url:
                print(f"                跳转到 {raw['final']}")
        print(f"  框架视角    : {fw_len}B" + (f"  {RED}{fw_err}{NC}" if fw_err else ""))
        if parsed >= 0:
            print(f"  解析视角    : {parsed} 条")

        # ── 结论 ──
        body = raw["body"]
        hit = next((m for m in CHALLENGE_MARKERS if m in body[:6000]), "")
        if raw["err"]:
            v = "网络层不通(域名/DNS/连接被断) —— 先确认域名还能解析、要不要挂代理"
        elif raw["status"] in (403, 429, 503) or raw["mitigated"]:
            v = "IP/指纹被挡(Cloudflare) —— 站点在拦你的出口 IP,给这个源配单源代理"
        elif hit:
            v = f"被风控页顶掉(命中「{hit}」) —— 换指纹/挂代理,重试没用"
        elif raw["length"] < 512:
            v = "响应体太小 —— 多半是空白页/风控壳,不是解析问题"
        elif parsed == 0:
            v = (
                "网络层是通的,但**解析出 0 条** → 解析层问题:站点改版了,对 _RE_* 正则"
                "(如果这一页本来就是空结果,忽略它)"
            )
        elif parsed > 0:
            v = f"通,解析正常({parsed} 条)"
        else:
            v = "网络层通(解析视角没跑,自己对着 _parse_list 看一下)"
        if handler and raw["status"] == 200 and parsed > 0 and fw_len == 0:
            v = "裸打通、框架侧却拿不到 —— 框架的风控标记误判了,看 INVALID_MARKERS"
        print(f"  {GREEN}结论{NC}        : {v}")
        verdicts.append(f"{name}: {v.split('——')[0].strip()}")

    print("\n" + "=" * 68)
    for v in verdicts:
        print("  ·", v)
    print("=" * 68)
    return 0


if __name__ == "__main__":
    sys.exit(main())
