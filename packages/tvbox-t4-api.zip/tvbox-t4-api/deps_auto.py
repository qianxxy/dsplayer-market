# -*- coding: utf-8 -*-
"""壳子源依赖自动化层：扫描 import → 缺啥装啥 → 装不上用内置实现兜底。

目标：**丢源的人只负责丢文件**。加载任何 TVBox 壳子源之前，先做三件事：

1. ``ast`` 解析源文件，抽出所有第三方模块（标准库 / 项目自带模块 / 相对导入全部跳过）；
2. 缺的模块自动 ``pip install``（清华镜像优先 → 阿里 → 官方；先只取 wheel 不编译，
   失败再允许编译），结果写进 ``.deps_state.json`` 缓存，装失败的短期内不反复重试；
3. 仍然缺的、且桥接内置了等价实现的（如 ``pyquery`` → 用 bs4 实现），直接把内置实现
   注册进 ``sys.modules``，源文件一行不改照样能跑。

命令行也能单独用：

    python3 deps_auto.py check                 # 体检 sources/ 下所有壳子源，列出缺什么
    python3 deps_auto.py check <文件>...       # 只体检指定文件
    python3 deps_auto.py install <包名>...     # 手动装包（走同样的镜像策略）

环境变量：

===========================  ===============================================
``TVBOX_DEPS_AUTO=0``        关掉自动安装（只体检 + 内置兜底，不动环境）
``TVBOX_DEPS_TIMEOUT=90``    单批安装超时秒数
``TVBOX_DEPS_FAIL_TTL=21600``装失败的包多久内不重试（秒）
``TVBOX_DEPS_MIRROR``        自定义第一个 pip 镜像
===========================  ===============================================
"""

from __future__ import annotations

import ast
import importlib
import importlib.util
import json
import logging
import os
import re
import subprocess
import sys
import threading
import time
from pathlib import Path

log = logging.getLogger("tvbox-deps")

PROJECT_DIR = Path(__file__).resolve().parent
STATE_FILE = PROJECT_DIR / ".deps_state.json"

AUTO_INSTALL = str(os.getenv("TVBOX_DEPS_AUTO", "1")).strip().lower() not in ("0", "false", "no", "off")
INSTALL_TIMEOUT = int(os.getenv("TVBOX_DEPS_TIMEOUT", "90") or 90)
FAIL_TTL = float(os.getenv("TVBOX_DEPS_FAIL_TTL", str(6 * 3600)) or 6 * 3600)
MAX_STATE = 400

_MIRROR_OVERRIDE = (os.getenv("TVBOX_DEPS_MIRROR") or "").strip()
MIRRORS = ([_MIRROR_OVERRIDE] if _MIRROR_OVERRIDE else []) + [
    "https://pypi.tuna.tsinghua.edu.cn/simple",
    "https://mirrors.aliyun.com/pypi/simple",
    "https://pypi.org/simple",
]

# 模块名 → pip 包名（不一致的必须列；一致的不列也行，会自动同名兜底）
MODULE_TO_PACKAGE = {
    "bs4": "beautifulsoup4",
    "Crypto": "pycryptodome",
    "Cryptodome": "pycryptodomex",
    "PIL": "Pillow",
    "cv2": "opencv-python",
    "yaml": "PyYAML",
    "socks": "PySocks",
    "dateutil": "python-dateutil",
    "dotenv": "python-dotenv",
    "jwt": "PyJWT",
    "jose": "python-jose",
    "OpenSSL": "pyOpenSSL",
    "serial": "pyserial",
    "attr": "attrs",
    "usb": "pyusb",
    "Levenshtein": "python-Levenshtein",
    "google": "protobuf",
    "wx": "wxPython",
    "execjs": "PyExecJS",
    "fake_useragent": "fake-useragent",
    "demjson": "demjson3",
    "demjson3": "demjson3",
    "jsonpath": "jsonpath",
    "jsonpath_ng": "jsonpath-ng",
    "requests_cache": "requests-cache",
    "snowland_smx": "snowland-smx",
    "websocket": "websocket-client",
    "win32com": "pywin32",  # 手机用不上，兜底避免误装
    "pyaes": "pyaes",
    "gmssl": "gmssl",
    "hjson": "hjson",
    "m3u8": "m3u8",
    "quickjs": "quickjs",
    "lxml": "lxml",
    "pyquery": "pyquery",
    "chardet": "chardet",
    "rarfile": "rarfile",
    "py7zr": "py7zr",
}

# 太大 / 手机必装不上 —— 不自动装，只在报告里说明
HEAVY_BLACKLIST = {
    "torch",
    "torchvision",
    "tensorflow",
    "paddlepaddle",
    "paddle",
    "jax",
    "transformers",
    "onnxruntime",
    "opencv-python",
    "scipy",
    "matplotlib",
    "moviepy",
    "pywin32",
}

# 项目自带的本地模块（不是第三方）
_LOCAL_NAMES = {
    "base",
    "core",
    "sources",
    "tvbox_bridge",
    "tvbox_compat",
    "deps_auto",
    "main",
    "check_source",
    "diag_source",
    "SOURCES_TEMPLATE",
}

_FALLBACK_STDLIB = {
    "abc", "argparse", "ast", "asyncio", "base64", "binascii", "bisect", "bz2", "calendar",
    "cmath", "collections", "colorsys", "concurrent", "configparser", "contextlib", "copy",
    "csv", "ctypes", "datetime", "decimal", "difflib", "email", "enum", "errno", "fcntl",
    "fnmatch", "fractions", "ftplib", "functools", "gc", "getpass", "gettext", "glob", "gzip",
    "hashlib", "heapq", "hmac", "html", "http", "imp", "importlib", "inspect", "io", "ipaddress",
    "itertools", "json", "keyword", "linecache", "locale", "logging", "lzma", "math", "mimetypes",
    "multiprocessing", "netrc", "numbers", "operator", "os", "pathlib", "pickle", "pkgutil",
    "platform", "plistlib", "pprint", "pty", "ptyprocess", "queue", "quopri", "random", "re",
    "readline", "secrets", "select", "selectors", "shlex", "shutil", "signal", "site", "smtplib",
    "socket", "socketserver", "sqlite3", "ssl", "stat", "statistics", "string", "struct",
    "subprocess", "sys", "tarfile", "telnetlib", "tempfile", "termios", "textwrap", "threading",
    "time", "timeit", "token", "tokenize", "traceback", "tracemalloc", "tty", "types", "typing",
    "unicodedata", "unittest", "urllib", "uuid", "venv", "warnings", "wave", "weakref", "webbrowser",
    "xml", "xmlrpc", "zipfile", "zlib", "__future__", "_thread", "array", "atexit", "audioop",
    "chunk", "codecs", "codeop", "compileall", "crypt", "curses", "dis", "doctest", "filecmp",
    "fileinput", "formatter", "grp", "imaplib", "imghdr", "marshal", "nis", "nntplib", "ntpath",
    "optparse", "ossaudiodev", "pipes", "poplib", "posixpath", "profile", "pstats", "pwd",
    "py_compile", "pyclbr", "pydoc", "rlcompleter", "runpy", "sched", "spwd", "sre_compile",
    "symtable", "sysconfig", "tabnanny", "threading_local", "turtle", "uu", "zipapp",
    "wsgiref", "pdb", "trace", "faulthandler", "parser", "symbol", "posix", "nt", "locale",
}


# ── 状态缓存 ────────────────────────────────────────────────────────


def _load_state() -> dict:
    try:
        with open(STATE_FILE, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception:  # noqa: BLE001
        return {}


def _save_state(state: dict) -> None:
    try:
        if len(state) > MAX_STATE:
            keep = sorted(state.items(), key=lambda kv: kv[1].get("ts", 0), reverse=True)[:MAX_STATE]
            state = dict(keep)
        tmp = STATE_FILE.with_suffix(".json.tmp")
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(state, fh, ensure_ascii=False, indent=1)
        os.replace(tmp, STATE_FILE)
    except Exception as exc:  # noqa: BLE001
        log.debug("写依赖状态失败（忽略）：%s", exc)


_lock = threading.RLock()
_state_cache: dict | None = None


def _state() -> dict:
    global _state_cache
    with _lock:
        if _state_cache is None:
            _state_cache = _load_state()
        return _state_cache


def _record(pkg: str, status: str, detail: str = "") -> None:
    st = _state()
    with _lock:
        st[pkg] = {"status": status, "ts": time.time(), "detail": detail[:400]}
        _save_state(st)


# ── 扫描 import ─────────────────────────────────────────────────────


def scan_imports(path) -> list[str]:
    """解析文件里 import 的顶层模块名（AST 优先，语法错时退化为正则）。"""
    p = Path(path)
    try:
        text = p.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return []
    names: set[str] = set()
    try:
        tree = ast.parse(text)
    except SyntaxError:
        for m in re.finditer(r"^[ \t]*import[ \t]+([A-Za-z_][\w.]*)", text, re.M):
            names.add(m.group(1).split(".")[0])
        for m in re.finditer(r"^[ \t]*from[ \t]+([A-Za-z_][\w.]*)[ \t]+import", text, re.M):
            names.add(m.group(1).split(".")[0])
        return sorted(names)
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                names.add(alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            if node.level:  # 相对导入 = 本地
                continue
            if node.module:
                names.add(node.module.split(".")[0])
    return sorted(names)


def _stdlib() -> set[str]:
    mods = set(getattr(sys, "stdlib_module_names", ()) or ())
    return mods | _FALLBACK_STDLIB | set(sys.builtin_module_names)


def _is_local(name: str, src_dir: Path | None) -> bool:
    if name in _LOCAL_NAMES:
        return True
    for root in (PROJECT_DIR, src_dir):
        if root is None:
            continue
        try:
            if (root / f"{name}.py").exists() or (root / name / "__init__.py").exists():
                return True
        except OSError:
            continue
    return False


def third_party_imports(path) -> list[str]:
    """该文件依赖的第三方模块（去重、排序）。"""
    src_dir = Path(path).resolve().parent
    std = _stdlib()
    out = []
    for name in scan_imports(path):
        if not name or name.startswith("_"):
            continue
        if name in std or _is_local(name, src_dir):
            continue
        out.append(name)
    return out


# ── 可用性判定 ──────────────────────────────────────────────────────


def is_available(name: str) -> bool:
    if name in sys.modules:
        return True
    try:
        return importlib.util.find_spec(name) is not None
    except Exception:  # noqa: BLE001
        return False


# ── 安装 ────────────────────────────────────────────────────────────


def package_for(module: str) -> str:
    return MODULE_TO_PACKAGE.get(module, module)


_pip_lock = threading.Lock()
_pip_checked = False


def _pip_ready() -> bool:
    """能不能跑 python -m pip（跑一次判一次，只判一次）。"""
    global _pip_checked
    if _pip_checked:
        return True
    try:
        r = subprocess.run([sys.executable, "-m", "pip", "--version"],
                           capture_output=True, text=True, timeout=60)
        if r.returncode == 0:
            _pip_checked = True
            return True
    except Exception:  # noqa: BLE001
        pass
    # 干净 rootfs 可能没 pip：ensurepip 自举一次
    try:
        r = subprocess.run([sys.executable, "-m", "ensurepip", "--upgrade"],
                           capture_output=True, text=True, timeout=300)
        ok = r.returncode == 0
        print(f"[deps_auto] pip 自举(ensurepip) {'成功' if ok else '失败: ' + (r.stderr or '')[-200:]}",
              flush=True)
        if ok:
            _pip_checked = True
        return ok
    except Exception as exc:  # noqa: BLE001
        print(f"[deps_auto] pip 自举失败: {exc}", flush=True)
        return False


def _pip(args: list[str], timeout: int) -> tuple[int, str]:
    """同进程串行：原生源兜底与壳子桥接可能同时来装，别让两个 pip 互相踩。"""
    with _pip_lock:
        _pip_ready()
        return _pip_locked(args, timeout)


def _pip_locked(args: list[str], timeout: int) -> tuple[int, str]:
    base = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "-q"]
    with_break = base + ["--break-system-packages"] + args
    for cmd in (with_break, base + args):
        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
                env=os.environ.copy(),
            )
        except subprocess.TimeoutExpired:
            return 124, f"安装超时（>{timeout}s）"
        except Exception as exc:  # noqa: BLE001
            return 1, f"{type(exc).__name__}: {exc}"
        out = ((proc.stdout or "") + (proc.stderr or "")).strip()
        if proc.returncode == 0:
            return 0, out[-400:]
        if "break-system-packages" in out:  # 老 pip 不认这个参数 → 换不带参数的再试
            continue
        return proc.returncode, out[-400:]
    return 1, "pip 调用失败"


def install_packages(packages: list[str], timeout: int | None = None) -> tuple[list[str], list[tuple[str, str]]]:
    """批量装包：镜像轮询 + 先只要 wheel（不编译）+ 整批失败就逐个再试。

    返回 (成功包, [(失败包, 原因)])。
    """
    timeout = timeout or INSTALL_TIMEOUT
    todo = [p for p in dict.fromkeys(packages) if p]
    if not todo:
        return [], []
    ok: list[str] = []
    bad: list[tuple[str, str]] = []
    for mirror in MIRRORS:
        if not todo:
            break
        code, out = _pip(["-i", mirror, "--only-binary=:all:"] + todo, timeout)
        if code == 0:
            ok.extend(todo)
            todo = []
            break
        log.warning("pip(wheel-only) 装 %s 失败（%s）：%s", todo, mirror, out[-200:])
        code, out = _pip(["-i", mirror] + todo, timeout)
        if code == 0:
            ok.extend(todo)
            todo = []
            break
        log.warning("pip 装 %s 失败（%s）：%s", todo, mirror, out[-200:])
        if len(todo) > 1:
            # 整批失败可能只是个别包拖累 → 逐个再试，能装的先装上
            still: list[str] = []
            for pkg in todo:
                done = False
                for extra in (["--only-binary=:all:"], []):
                    c2, _o2 = _pip(["-i", mirror] + extra + [pkg], timeout)
                    if c2 == 0:
                        ok.append(pkg)
                        done = True
                        break
                if not done:
                    still.append(pkg)
            todo = still
    for pkg in todo:
        bad.append((pkg, "所有镜像都装不上（可能需编译或网络不通）"))
    if ok:
        try:
            importlib.invalidate_caches()
        except Exception:  # noqa: BLE001
            pass
    return ok, bad


# ── 内置兜底实现（装不上也能跑）──────────────────────────────────────


class _PyQueryShim:
    """pyquery 的最小可用替代（基于 bs4）：够 TVBox 源里 find/attr/text/items 那套用法。"""

    def __init__(self, *args, _els=None, _root=None):
        self._root = _root
        self._els = list(_els) if _els is not None else []
        if _els is not None or not args:
            return
        content = args[0]
        if isinstance(content, (list, tuple)):
            self._els = list(content)
            return
        if not isinstance(content, (str, bytes, bytearray)):
            for attr in ("content", "text"):
                val = getattr(content, attr, None)
                if isinstance(val, (str, bytes, bytearray)):
                    content = val
                    break
        from bs4 import BeautifulSoup

        soup = BeautifulSoup(content, "html.parser")
        self._root = soup
        self._els = [soup]

    # —— 选择 ——
    def _select(self, selector):
        found = []
        for el in self._els:
            try:
                found.extend(el.select(selector))
            except Exception:  # noqa: BLE001
                continue
        return _PyQueryShim(_els=found, _root=self._root)

    def __call__(self, selector=None):
        return self if not selector else self._select(selector)

    def find(self, selector):
        return self._select(selector)

    def filter(self, selector):
        found = []
        for el in self._els:
            try:
                if el in el.parent.select(selector):
                    found.append(el)
            except Exception:  # noqa: BLE001
                continue
        return _PyQueryShim(_els=found, _root=self._root)

    def eq(self, idx):
        try:
            return _PyQueryShim(_els=[self._els[idx]], _root=self._root)
        except IndexError:
            return _PyQueryShim(_els=[], _root=self._root)

    def __getitem__(self, item):
        if isinstance(item, slice):
            return _PyQueryShim(_els=self._els[item], _root=self._root)
        return self.eq(item)

    def __iter__(self):
        for el in self._els:
            yield _PyQueryShim(_els=[el], _root=self._root)

    def items(self):
        return self.__iter__()

    def __len__(self):
        return len(self._els)

    def __bool__(self):
        return bool(self._els)

    # —— 取值 ——
    def text(self):
        parts = []
        for el in self._els:
            try:
                parts.append(el.get_text(" ", strip=True))
            except Exception:  # noqa: BLE001
                continue
        return " ".join(p for p in parts if p)

    def attr(self, name=None, value=None):
        if name is None:
            return None
        for el in self._els:
            try:
                got = el.get(name)
            except Exception:  # noqa: BLE001
                got = None
            if got is not None:
                return got
        return None

    def html(self):
        if not self._els:
            return None
        try:
            return self._els[0].decode()
        except Exception:  # noqa: BLE001
            return str(self._els[0])

    def outer_html(self):
        return self.html()

    def __str__(self):
        return self.html() or ""

    def __repr__(self):
        return f"<PyQueryShim {len(self._els)} 个节点>"

    def remove(self):
        for el in list(self._els):
            try:
                el.decompose()
            except Exception:  # noqa: BLE001
                pass
        self._els = []
        return self


def _build_pyquery_shim():
    import types

    mod = types.ModuleType("pyquery")
    mod.PyQuery = _PyQueryShim
    mod.pq = _PyQueryShim
    mod.__version__ = "shim-bs4"
    mod.__doc__ = "pyquery 兼容层（bs4 实现，由 deps_auto 自动注入）"
    return mod


SHIMS = {
    "pyquery": _build_pyquery_shim,
}
_shimmed: set[str] = set()


def apply_shim(module: str) -> bool:
    """给缺失的模块注入内置实现；成功返回 True。"""
    if module in _shimmed and module in sys.modules:
        return True
    factory = SHIMS.get(module)
    if factory is None:
        return False
    if module == "pyquery" and not is_available("bs4"):
        ok, bad = install_packages(["beautifulsoup4"])
        if not ok:
            log.warning("内置 pyquery 兼容层需要 bs4，但装不上：%s", bad)
            return False
    try:
        sys.modules[module] = factory()
        _shimmed.add(module)
        log.info("已为 %s 注入内置兼容实现（无需安装）", module)
        return True
    except Exception as exc:  # noqa: BLE001
        log.warning("注入 %s 兼容实现失败：%s", module, exc)
        return False


# ── 主入口 ──────────────────────────────────────────────────────────


def ensure_deps_for_file(path, install: bool | None = None, force: bool = False) -> dict:
    """确保某个源文件的第三方依赖可用。返回体检/处理结果字典。"""
    path = Path(path)
    want_install = AUTO_INSTALL if install is None else install
    result = {
        "file": path.name,
        "third_party": [],
        "missing": [],
        "installed": [],
        "shimmed": [],
        "failed": [],
        "blacklisted": [],
        "skipped_recent_fail": [],
    }
    try:
        mods = third_party_imports(path)
    except Exception as exc:  # noqa: BLE001
        log.debug("扫描 %s 依赖失败：%s", path.name, exc)
        return result
    result["third_party"] = mods
    missing = [m for m in mods if not is_available(m)]
    result["missing"] = missing
    if not missing:
        return result

    log.info("源 %s 缺依赖：%s", path.name, ", ".join(missing))
    st = _state()
    now = time.time()
    todo, wait = [], []
    for mod in missing:
        pkg = package_for(mod)
        if pkg in HEAVY_BLACKLIST:
            result["blacklisted"].append(mod)
            continue
        info = st.get(pkg) or st.get(mod) or {}
        if info.get("status") == "fail" and not force and (now - float(info.get("ts", 0))) < FAIL_TTL:
            wait.append(mod)
            continue
        todo.append(mod)

    result["skipped_recent_fail"] = wait
    if wait:
        log.info("源 %s 这些依赖之前装失败过，暂不重试：%s", path.name, ", ".join(wait))

    if not want_install:
        result["failed"] = [
            {"module": m, "package": package_for(m), "reason": "自动安装已关闭（TVBOX_DEPS_AUTO=0）"}
            for m in todo + wait
        ]
    elif todo:
        pkgs = list(dict.fromkeys(package_for(m) for m in todo))
        log.info("自动安装 %s（源 %s）…", ", ".join(pkgs), path.name)
        ok, bad = install_packages(pkgs)
        for pkg in ok:
            _record(pkg, "ok", "auto-installed")
        for pkg, why in bad:
            _record(pkg, "fail", why)
        bad_pkgs = {p for p, _ in bad}
        bad_reason = {p: w for p, w in bad}
        for mod in todo:
            pkg = package_for(mod)
            if pkg in ok and is_available(mod):
                result["installed"].append(mod)
            elif pkg in bad_pkgs:
                result["failed"].append({"module": mod, "package": pkg, "reason": bad_reason.get(pkg, "")})
            elif is_available(mod):
                result["installed"].append(mod)
            else:
                result["failed"].append({"module": mod, "package": pkg, "reason": "装完仍 import 不到"})

    # 缓期内不重试的，也要如实记进"仍缺"（否则报告里会凭空消失）
    for mod in wait:
        result["failed"].append(
            {"module": mod, "package": package_for(mod), "reason": "之前装失败，缓期内暂不重试"}
        )

    # 装不上 / 黑名单 / 缓期 → 试内置兜底实现
    still_missing = {f["module"] for f in result["failed"]} | set(result["blacklisted"])
    for mod in sorted(still_missing):
        if apply_shim(mod):
            result["shimmed"].append(mod)
            result["failed"] = [f for f in result["failed"] if f["module"] != mod]
            if mod in result["blacklisted"]:
                result["blacklisted"].remove(mod)

    if result["installed"] or result["shimmed"]:
        log.info(
            "源 %s 依赖已补齐：装好 %s；内置兜底 %s",
            path.name,
            ", ".join(result["installed"]) or "-",
            ", ".join(result["shimmed"]) or "-",
        )
    if result["failed"]:
        log.warning(
            "源 %s 仍缺依赖：%s",
            path.name,
            "; ".join(f"{f['module']}（{f['reason']}）" for f in result["failed"]),
        )
    return result


def summarize(result: dict) -> str:
    """把体检结果压成一句人话（给报告用）。"""
    bits = []
    if result.get("installed"):
        bits.append("自动装好 " + ", ".join(result["installed"]))
    if result.get("shimmed"):
        bits.append("内置兜底 " + ", ".join(result["shimmed"]))
    if result.get("failed"):
        bits.append(
            "仍缺 "
            + ", ".join(f"{f['module']}（{f['reason']}）" for f in result["failed"])
        )
    if result.get("blacklisted"):
        bits.append("跳过超大包 " + ", ".join(result["blacklisted"]))
    return "；".join(bits)


def _sources_root() -> Path:
    return PROJECT_DIR / "sources"


def _rel_display(path) -> str:
    """源文件相对 sources/ 的显示路径(子目录会带目录名)。"""
    try:
        return Path(path).relative_to(_sources_root()).as_posix()
    except ValueError:
        return Path(path).name


def _iter_sources(src_dir) -> list[Path]:
    """递归列出 sources/ 下的源文件(与加载器同一口径,支持子目录分类)。

    跳过 `_`/`.` 开头的目录与文件、__init__.py、桥接看门狗 tvbox_compat.py。
    """
    src = Path(src_dir)
    out: list[Path] = []
    for dirpath, dirnames, filenames in os.walk(str(src)):
        dirnames[:] = sorted(
            d for d in dirnames if not d.startswith("_") and not d.startswith(".")
        )
        for name in sorted(filenames):
            if not name.endswith(".py") or name.startswith("."):
                continue
            if name.startswith("_") or name in ("__init__.py", "tvbox_compat.py"):
                continue
            out.append(Path(dirpath) / name)
    return sorted(out)


def check_paths(paths) -> list[dict]:
    out = []
    for p in paths:
        res = ensure_deps_for_file(p)
        if isinstance(res, dict):
            res.setdefault("rel", _rel_display(p))
        out.append(res)
    return out


# ── 命令行 ──────────────────────────────────────────────────────────


def _cmd(argv: list[str]) -> int:
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    if not argv or argv[0] in ("-h", "--help", "help"):
        print(__doc__)
        return 0
    action = argv[0]
    if action == "install":
        pkgs = argv[1:]
        if not pkgs:
            print("用法：python3 deps_auto.py install <包名>...")
            return 2
        ok, bad = install_packages(pkgs)
        print("装好：", ", ".join(ok) or "-")
        for pkg, why in bad:
            print("失败：", pkg, why)
        return 0 if not bad else 1
    if action in ("check", "体检"):
        if len(argv) > 1:
            targets = [Path(a) for a in argv[1:]]
        else:
            src_dir = PROJECT_DIR / "sources"
            targets = []
            for p in _iter_sources(src_dir):
                text = p.read_text(encoding="utf-8", errors="ignore")
                if "VodHandler" in text:
                    continue
                targets.append(p)
        print(f"依赖体检：{len(targets)} 个源，自动安装={'开' if AUTO_INSTALL else '关'}")
        for res in check_paths(targets):
            if res["failed"]:
                flag = "缺  "
            elif res["blacklisted"]:
                flag = "⚠  "
            else:
                flag = "OK  "
            print(f"[{flag}] {(res.get('rel') or res['file']):<24} 三方依赖 {len(res['third_party']):>2} 个 {summarize(res) or ''}")
        return 0
    print(f"未知动作：{action}\n")
    print(__doc__)
    return 2


if __name__ == "__main__":
    raise SystemExit(_cmd(sys.argv[1:]))
