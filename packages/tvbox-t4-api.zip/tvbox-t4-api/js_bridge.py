# -*- coding: utf-8 -*-
"""T4 JS 源桥接（宿主侧 node 运行时）

壳子在宿主侧用 Android node 起一个 JS 宿主服务（``t4js_host.js serve``），把
用户目录下 ``sources/js/**/*.js``（无 ``js`` 子目录时退化为 ``sources/*.js``）
的 JS 源暴露成 HTTP 接口。本模块把这些 JS 源包装成 ``VodHandler`` 注册进 T4
服务，使 JS 源与 ``.py`` 源完全等价：首页 / 分类 / 详情 / 搜索 / 播放。

- JS 源目录：``<app>/sources/js``（支持任意层子目录作为分类）
- 宿主地址：环境变量 ``T4_JS_HOST``（默认 ``http://127.0.0.1:18777``）
- 探测周期：环境变量 ``T4_JS_WATCH``（默认 15 秒）

只依赖标准库 + 框架 ``core``。
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
import urllib.request

from core.base import VodHandler

JS_HOST = (os.environ.get("T4_JS_HOST") or "").strip() or "http://127.0.0.1:18777"
JS_HOST = JS_HOST.rstrip("/")
JS_DIR = (os.environ.get("T4_JS_DIR") or "").strip()

_log = logging.getLogger("js_bridge")
if not _log.handlers:
    _log.setLevel(logging.INFO)


def log(msg: str) -> None:
    try:
        _log.info("[js] %s", msg)
    except Exception:
        pass


def _env_float(name: str, default: float) -> float:
    try:
        v = float((os.environ.get(name) or "").strip() or default)
        return v if v > 0 else default
    except Exception:
        return default


WATCH_INTERVAL = _env_float("T4_JS_WATCH", 15.0)
CALL_TIMEOUT = _env_float("T4_JS_TIMEOUT", 25.0)
PROBE_TIMEOUT = 4.0


# --------------------------------------------------------------------------- #
# 访问宿主
# --------------------------------------------------------------------------- #
def _request(path: str, payload: dict | None = None, timeout: float = PROBE_TIMEOUT):
    url = JS_HOST + path
    data = None
    headers = {"Accept": "application/json", "Connection": "close"}
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read()
    if not raw:
        return None
    try:
        return json.loads(raw.decode("utf-8", "replace"))
    except Exception:
        return None


def host_alive() -> bool:
    try:
        r = _request("/health", timeout=PROBE_TIMEOUT)
        return bool(r and r.get("ok"))
    except Exception:
        return False


def host_list() -> list:
    """宿主里的 JS 源清单：[{key,name,rel,style,methods,sites}, ...]"""
    try:
        r = _request("/list", timeout=max(PROBE_TIMEOUT, 10.0))
    except Exception as exc:
        log("宿主 /list 失败: %s" % exc)
        return []
    if not isinstance(r, dict) or not r.get("ok"):
        return []
    data = r.get("data")
    if isinstance(data, dict):
        data = data.get("sources") or data.get("list") or []
    return data if isinstance(data, list) else []


def call_source(key: str, method: str, args: list | None = None, timeout: float = CALL_TIMEOUT):
    """调用 JS 源的某个 T4 方法；成功返回 data，失败返回 None。"""
    payload = {"key": key, "method": method, "args": args or []}
    try:
        r = _request("/call", payload, timeout=timeout)
    except Exception as exc:
        log("调用 %s.%s 失败: %s" % (key, method, exc))
        return None
    if not isinstance(r, dict):
        return None
    if not r.get("ok"):
        log("调用 %s.%s 报错: %s" % (key, method, r.get("error") or r.get("msg") or "unknown"))
        return None
    return r.get("data")


def reload_host() -> bool:
    try:
        r = _request("/reload", timeout=max(PROBE_TIMEOUT, 20.0))
        return bool(r and r.get("ok"))
    except Exception:
        return False


# --------------------------------------------------------------------------- #
# 结果整形
# --------------------------------------------------------------------------- #
def _as_dict(v):
    if isinstance(v, dict):
        return v
    if isinstance(v, str):
        try:
            j = json.loads(v)
            return j if isinstance(j, dict) else {}
        except Exception:
            return {}
    return {}


def _int(v, default=1):
    try:
        n = int(v)
        return n if n > 0 else default
    except Exception:
        return default


def _shape_home(data: dict) -> dict:
    out = {"class": data.get("class") or [], "list": data.get("list") or []}
    if data.get("filters"):
        out["filters"] = data["filters"]
    return out


def _shape_category(data: dict, page: int) -> dict:
    lst = data.get("list") or []
    page = _int(data.get("page"), page)
    limit = _int(data.get("limit"), len(lst) or 1)
    total = data.get("total")
    if total is None:
        total = (page - 1) * limit + (len(lst) if lst else limit)
    pagecount = _int(data.get("pagecount"), 0)
    if not pagecount:
        try:
            pagecount = max(1, (int(total) + limit - 1) // limit)
        except Exception:
            pagecount = page
    return {
        "list": lst,
        "page": page,
        "pagecount": pagecount,
        "limit": limit,
        "total": _int(total, page * limit),
    }


def _shape_detail(data: dict) -> dict:
    lst = data.get("list")
    if not isinstance(lst, list):
        lst = [data] if (data.get("vod_name") or data.get("vod_id")) else []
    return {"list": lst}


def _shape_search(data: dict) -> dict:
    return {"list": data.get("list") or []}


def _shape_player(data: dict) -> dict:
    out = {"parse": data.get("parse", 0), "url": data.get("url") or data.get("playUrl") or ""}
    if data.get("header"):
        out["header"] = data["header"]
    if data.get("jx") is not None:
        out["jx"] = data["jx"]
    return out


# --------------------------------------------------------------------------- #
# 包装成 VodHandler
# --------------------------------------------------------------------------- #
class JsSource(VodHandler):
    """把一个 JS 源包装成 T4 ``VodHandler``。"""

    display_name = ""
    _js_key = ""
    _js_rel = ""
    _js_style = ""
    _js_methods: tuple = ()

    def init(self, extend: str = "") -> None:
        try:
            call_source(self._js_key, "init", [extend or ""])
        except Exception:
            pass

    def home(self) -> dict:
        return _shape_home(_as_dict(call_source(self._js_key, "homeContent", [])))

    def category(self, type_id: str, page: int, ext: str = "") -> dict:
        data = _as_dict(
            call_source(self._js_key, "categoryContent", [str(type_id), _int(page), ext or ""])
        )
        return _shape_category(data, _int(page))

    def detail(self, ids) -> dict:
        if isinstance(ids, (list, tuple)):
            ids = ",".join(str(x) for x in ids)
        return _shape_detail(_as_dict(call_source(self._js_key, "detailContent", [str(ids or "")])))

    def search(self, keyword: str, page: int, ext: str = "") -> dict:
        data = _as_dict(
            call_source(self._js_key, "searchContent", [str(keyword or ""), _int(page), ext or ""])
        )
        return _shape_search(data)

    def player(self, flag: str, play_url: str) -> dict:
        data = _as_dict(
            call_source(self._js_key, "playerContent", [str(flag or ""), str(play_url or "")])
        )
        return _shape_player(data)

    def proxy(self, action: str = "proxy", **kwargs) -> dict:
        want = ["proxy"]
        if kwargs.get("kind"):
            want.append(str(kwargs["kind"]))
        if not any(w in (self._js_methods or ()) for w in want):
            return {"error": "proxy not supported"}
        args = [action]
        for name in ("flag", "url", "ext", "tid", "pg"):
            if kwargs.get(name) not in (None, ""):
                args.append(kwargs[name])
        return _as_dict(call_source(self._js_key, "proxy", args))


def make_class(meta: dict, taken: set):
    key = meta.get("key") or meta.get("rel") or ""
    if not key:
        return None
    name = (meta.get("name") or os.path.basename(str(key)).rsplit(".", 1)[0] or "").strip()
    if not name:
        return None
    source_name = name
    if source_name in taken:
        source_name = name + "[JS]"
        if source_name in taken:
            return None
    return type(
        "Js_" + str(abs(hash(key)) % (10 ** 8)),
        (JsSource,),
        {
            "source_name": source_name,
            "display_name": name + "（JS）",
            "_js_key": key,
            "_js_rel": meta.get("rel") or "",
            "_js_style": meta.get("style") or "",
            "_js_methods": tuple(meta.get("methods") or ()),
        },
    )


# --------------------------------------------------------------------------- #
# 注册 / 卸载
# --------------------------------------------------------------------------- #
_instances: dict = {}
_lock = threading.RLock()
_last_error = ""
_wrapped_report = False
_boot_ts = 0.0


def _registry() -> dict:
    try:
        from core import router as core_router

        reg = getattr(core_router, "_registry", None)
        return reg if isinstance(reg, dict) else {}
    except Exception:
        return {}


def _register(instance) -> bool:
    try:
        from core import router as core_router

        core_router.register(instance)
        return True
    except Exception as exc:
        reg = _registry()
        if instance.source_name not in reg:
            reg[instance.source_name] = instance
            return True
        log("注册 %s 失败: %s" % (getattr(instance, "source_name", "?"), exc))
        return False


def _unregister(source_name: str) -> None:
    _registry().pop(source_name, None)
    try:
        import sources as sources_mod

        loaded = getattr(sources_mod, "_loaded", None)
        if isinstance(loaded, dict):
            loaded.pop(source_name, None)
    except Exception:
        pass


def scan_once() -> int:
    """同步一次宿主清单，返回当前 JS 源数量。"""
    global _last_error
    metas = host_list()
    if not metas:
        if not host_alive():
            _last_error = "宿主未就绪（node 未运行或 JS 运行时缺失）"
        return len(_instances)

    with _lock:
        seen = set()
        taken = set(_registry().keys()) | set(_instances.keys())
        for meta in metas:
            if not isinstance(meta, dict):
                continue
            cls = make_class(meta, taken - set(_instances.keys()))
            if cls is None:
                continue
            name = cls.source_name
            seen.add(name)
            taken.add(name)
            old = _instances.get(name)
            if old is not None and getattr(old, "_js_key", None) == cls._js_key:
                continue
            if old is not None:
                _unregister(name)
            inst = cls()
            if _register(inst):
                _instances[name] = inst
                log("已接入 JS 源: %s (%s)" % (name, cls._js_style or "js"))
        for name in list(_instances.keys()):
            if name not in seen:
                _unregister(name)
                _instances.pop(name, None)
                log("JS 源下线: %s" % name)
        _last_error = ""
    return len(_instances)


def watch_loop() -> None:
    while True:
        try:
            scan_once()
        except Exception as exc:
            global _last_error
            _last_error = str(exc)
            log("扫描异常: %s" % exc)
        time.sleep(WATCH_INTERVAL)


def status() -> dict:
    return {
        "host": JS_HOST,
        "dir": JS_DIR,
        "alive": host_alive(),
        "count": len(_instances),
        "sources": [
            {"source_name": n, "key": getattr(i, "_js_key", ""), "rel": getattr(i, "_js_rel", "")}
            for n, i in sorted(_instances.items())
        ],
        "error": _last_error,
        "boot": _boot_ts,
    }


# --------------------------------------------------------------------------- #
# 框架钩子
# --------------------------------------------------------------------------- #
def _wrap_report() -> None:
    """把 JS 源并入 ``sources.report()``，让 /sources 与站点清单一并可见。"""
    global _wrapped_report
    if _wrapped_report:
        return
    try:
        import sources as sources_mod
    except Exception:
        return
    orig = getattr(sources_mod, "report", None)
    if not callable(orig):
        return

    def _report(*a, **kw):
        rep = orig(*a, **kw)
        if not isinstance(rep, dict):
            return rep
        try:
            items = rep.get("sources")
            if not isinstance(items, list):
                items = []
                rep["sources"] = items
            have = set()
            for it in items:
                if isinstance(it, dict):
                    have.add(it.get("source_name") or it.get("name"))
            for name, inst in sorted(_instances.items()):
                if name in have:
                    continue
                items.append(
                    {
                        "source_name": name,
                        "display_name": getattr(inst, "display_name", name),
                        "module": "js:" + str(getattr(inst, "_js_rel", "")),
                        "kind": "js",
                    }
                )
        except Exception:
            pass
        return rep

    try:
        sources_mod.report = _report
        _wrapped_report = True
    except Exception:
        pass


def _expose_routes() -> None:
    try:
        import json as _json

        from fastapi import Response

        from core import router as core_router

        def _endpoint():
            return Response(
                content=_json.dumps(status(), ensure_ascii=False, indent=2),
                media_type="application/json; charset=utf-8",
            )

        core_router.router.add_api_route("/js-sources", _endpoint, methods=["GET"])
    except Exception as exc:
        log("注册 /js-sources 失败: %s" % exc)


def boot() -> None:
    """导入即启动：包一层上报 + 起守护线程。"""
    global _boot_ts
    _boot_ts = time.time()
    if not JS_HOST:
        return
    _wrap_report()
    _expose_routes()

    def _initial():
        try:
            scan_once()
        except Exception as exc:
            log("首次扫描失败: %s" % exc)

    threading.Thread(target=_initial, name="js-bridge-first", daemon=True).start()
    threading.Thread(target=watch_loop, name="js-bridge-watch", daemon=True).start()
    log("已启动（host=%s dir=%s）" % (JS_HOST, JS_DIR or "auto"))
