#!/usr/bin/env python3
"""源自检(合并版):静态契约检查 + 活体联调(HTTP / 进程内两种打法)。

三层,由外到内:

  ① 静态契约检查   用 AST 读 core/ 里**真实存在**的成员当白名单,再拿你的源去比。
                   所以你调了框架里不存在的东西(比如 HttpClient.reset_session)、
                   传了 HttpClient 不接的参数、引用了 settings 里没有的常量,
                   一跑就报,不用等上线偶发 502。服务没起也能跑,零执行、零副作用。
  ② 活体 HTTP 联调  把 /t4/ 五个接口真打一遍(走真实路由 = 顺带验证路由层),
                   并当场校验最容易黑屏的两处:$$$ 段数一致、player 带没带 Referer。
  ③ 活体进程内直调  直接 import sources 调 handler,不经过 HTTP ——
                   服务没起 / 在容器里没端口也能查,定位"到底哪一层出的问题"。

默认:静态 + 活体 HTTP;HTTP 连不上会自动落到「进程内直调」,不用你手动切。

用法:
    python3 check_source.py                     # 全部源:静态 + 活体
    python3 check_source.py mysite              # 只查一个源
    python3 check_source.py --static            # 只静态,完全不碰网络
    python3 check_source.py mysite --inproc     # 强制进程内直调(服务不用起)
    python3 check_source.py mysite --no-inproc  # 强制 HTTP,不许自动降级
    python3 check_source.py --api http://127.0.0.1:12333
    python3 check_source.py mysite --search IPZZ

Docker 部署里跑:
    docker compose exec tvbox-t4-api python3 check_source.py mysite

退出码:0 = 全过;1 = 有 FAIL(可直接挂 CI / 定时任务)。
"""

from __future__ import annotations

import argparse
import ast
import json
import re
import sys
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCES = ROOT / "sources"
CORE = ROOT / "core"

GREEN, RED, YELLOW, DIM, NC = "\033[32m", "\033[31m", "\033[33m", "\033[2m", "\033[0m"
if not sys.stdout.isatty():          # 重定向到文件 / 挂 CI 时关掉颜色(合并自旧版自检)
    GREEN = RED = YELLOW = DIM = NC = ""


class Result:
    def __init__(self) -> None:
        self.fails: list[str] = []
        self.warns: list[str] = []

    def ok(self, msg: str) -> None:
        print(f"  {GREEN}✓{NC} {msg}")

    def fail(self, msg: str) -> None:
        print(f"  {RED}✗ {msg}{NC}")
        self.fails.append(msg)

    def warn(self, msg: str) -> None:
        print(f"  {YELLOW}!{NC} {msg}")
        self.warns.append(msg)


# ── 先把框架的真实能力用 AST 读出来(不 import,零执行)────────────────


def _parse(path: Path) -> ast.Module | None:
    try:
        return ast.parse(path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        print(f"{YELLOW}读不动 {path.name}: {exc}{NC}")
        return None


def _class_api(tree: ast.Module, cls_name: str) -> tuple[set[str], set[str]]:
    """返回 (方法名集合, __init__ 关键字参数集合)。"""
    methods: set[str] = set()
    init_kwargs: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef) and node.name == cls_name:
            for item in node.body:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    methods.add(item.name)
                    if item.name == "__init__":
                        args = item.args
                        for a in list(args.args) + list(args.kwonlyargs):
                            init_kwargs.add(a.arg)
    return methods, init_kwargs


def _module_names(tree: ast.Module) -> set[str]:
    """模块级常量名 / 函数名 / 类型名。"""
    names: set[str] = set()
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for t in node.targets:
                if isinstance(t, ast.Name):
                    names.add(t.id)
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            names.add(node.target.id)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names.add(node.name)
    return names


def framework_api() -> dict:
    http_tree = _parse(CORE / "http_client.py")
    set_tree = _parse(CORE / "settings.py")
    cache_tree = _parse(CORE / "cache.py")
    base_tree = _parse(CORE / "base.py")

    http_methods, http_kwargs = (
        _class_api(http_tree, "HttpClient") if http_tree else (set(), set())
    )
    public_http = {m for m in http_methods if not m.startswith("_")}
    cache_methods, cache_kwargs = (
        _class_api(cache_tree, "TTLCache") if cache_tree else (set(), set())
    )
    return {
        "http_public": public_http,
        "http_kwargs": http_kwargs,
        "settings_names": _module_names(set_tree) if set_tree else set(),
        "cache_public": {m for m in cache_methods if not m.startswith("_")},
        "cache_kwargs": cache_kwargs,
        "base_names": _module_names(base_tree) if base_tree else set(),
    }


# ── 静态检查 ───────────────────────────────────────────────────────────


def _is_placeholder_host(host: str) -> bool:
    """只认真正的占位域名(example.com/.org/.net 及其子域),别误伤真站。"""
    if not host:
        return True
    m = re.match(r"^https?://([^/?#]+)", host)
    hostname = (m.group(1) if m else host).lower().split(":")[0]
    return bool(re.search(r"(^|\.)example\.(com|org|net)$", hostname))


def _extract_source_name(tree: ast.Module) -> tuple[str, str, dict]:
    """返回 (类名, source_name, 类属性字典)。"""
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            names = [b.id for b in node.bases if isinstance(b, ast.Name)]
            attrs: dict = {}
            for item in node.body:
                if isinstance(item, ast.Assign):
                    for t in item.targets:
                        if isinstance(t, ast.Name):
                            try:
                                attrs[t.id] = ast.literal_eval(item.value)
                            except Exception:  # noqa: BLE001
                                attrs[t.id] = None
            if "VodHandler" in names or getattr(node, "name", "").endswith("Handler"):
                return node.name, str(attrs.get("source_name") or ""), attrs
    return "", "", {}


def static_check(path: Path, api: dict, res: Result) -> tuple[str, str, dict]:
    tree = _parse(path)
    if tree is None:
        res.fail(f"{path.name}: 语法错,读不动")
        return "", "", {}

    cls, source_name, attrs = _extract_source_name(tree)
    if not cls:
        res.warn(f"{path.name}: 没找到继承 VodHandler 的类,跳过")
        return "", "", {}

    aliases: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign):
            for t in node.targets:
                if isinstance(t, ast.Name) and isinstance(node.value, ast.Call):
                    f = node.value.func
                    if isinstance(f, ast.Name) and f.id == "HttpClient":
                        aliases.add(t.id)
                    if isinstance(f, ast.Attribute) and f.attr == "HttpClient":
                        aliases.add(t.id)

    # ① 用了框架里不存在的方法
    used: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            f = node.func
            if isinstance(f.value, ast.Attribute) and isinstance(f.value.value, ast.Name):
                if f.value.value.id in aliases or f.value.attr == "_http":
                    used.add(f.attr)
    bad = sorted(m for m in used if m not in api["http_public"])
    if bad:
        res.fail(
            f"{path.name}: 调了框架不存在的 HttpClient 方法 "
            f"{', '.join(bad)}  → 运行期 AttributeError;可用的是: "
            f"{', '.join(sorted(api['http_public']))}"
        )
    else:
        res.ok(f"{path.name}: HttpClient 方法调用全部存在")

    # ② HttpClient(...) 传了不存在的参数
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            f = node.func
            is_hc = (isinstance(f, ast.Name) and f.id == "HttpClient") or (
                isinstance(f, ast.Attribute) and f.attr == "HttpClient"
            )
            if not is_hc:
                continue
            bad_kw = [k.arg for k in node.keywords if k.arg and k.arg not in api["http_kwargs"]]
            if bad_kw:
                res.fail(
                    f"{path.name}: HttpClient(...) 传了不支持的参数 "
                    f"{', '.join(bad_kw)}  → 启动即 TypeError;支持的是: "
                    f"{', '.join(sorted(api['http_kwargs']))}"
                )
            else:
                res.ok(f"{path.name}: HttpClient(...) 参数合法")

    # ③ settings 里不存在的常量
    bad_settings = {
        n.attr
        for n in ast.walk(tree)
        if isinstance(n, ast.Attribute)
        and isinstance(n.value, ast.Name)
        and n.value.id == "settings"
        and n.attr not in api["settings_names"]
    }
    if bad_settings:
        res.fail(
            f"{path.name}: settings 里没有 "
            f"{', '.join(sorted(bad_settings))}  → AttributeError;"
            f"单源降速请用自己的类属性,别去 settings 加变量"
        )
    else:
        res.ok(f"{path.name}: settings 引用合法")

    # ④ 五个契约方法全不全
    defined = {
        n.name
        for n in ast.walk(tree)
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
    }
    missing = [m for m in ("home", "category", "detail", "player", "search") if m not in defined]
    if missing:
        res.fail(f"{path.name}: 少了契约方法 {', '.join(missing)} → 实例化直接 TypeError")
    else:
        res.ok(f"{path.name}: 五个契约方法齐全")

    # ⑤ 模板残留(模板文件本身不算错,只提示;真源才算 FAIL)
    host = str(attrs.get("HOST") or "")
    is_template = bool(attrs.get("IS_TEMPLATE")) or "template" in path.stem.lower()
    if is_template:
        res.warn(
            f"{path.name}: 是模板骨架(占位 HOST={host!r})—— 复制改名成真源后请删掉 "
            f"IS_TEMPLATE 并填上真实 HOST"
        )
    else:
        if attrs.get("IS_TEMPLATE"):
            res.fail(f"{path.name}: 还留着 IS_TEMPLATE = True(真源请删掉这一行)")
        if _is_placeholder_host(host):
            res.fail(f"{path.name}: HOST 还是占位地址({host!r})")

    # ⑥ 自造 requests / aiohttp
    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            mods = [a.name for a in node.names] if isinstance(node, ast.Import) else [node.module or ""]
            if any(m.split(".")[0] in {"requests", "aiohttp", "cloudscraper"} for m in mods):
                res.warn(f"{path.name}: 自己 import 了 {mods[0]} —— 建议统一走 self._http")

    # ⑦ 多线路一致性(有 _episodes 却自己拼字符串 → 提醒)
    if "_episodes" in defined and "_build_play" not in defined:
        res.warn(
            f"{path.name}: 有 _episodes() 却没 _build_play() —— "
            f"自己拼 $$$ 很容易段数对不上,建议用模板里的 _build_play()"
        )

    # ⑧ 探针 URL(合并自旧版自检,新版原来漏了这一项)
    diag_fn = next(
        (
            n
            for n in ast.walk(tree)
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == "diag_urls"
        ),
        None,
    )
    if diag_fn is None:
        res.warn(f"{path.name}: 没实现 diag_urls() —— 站点改版时没法分层定位,建议补上")
    else:
        lits = [
            n.value
            for n in ast.walk(diag_fn)
            if isinstance(n, ast.Constant) and isinstance(n.value, str)
        ]
        probes = sum(1 for n in ast.walk(diag_fn) if isinstance(n, ast.Tuple))
        marks = (
            "REPLACE",
            "YOUR-SITE",
            "YOURSITE",
            "EXAMPLE.COM",
            "EXAMPLE.ORG",
            "EXAMPLE.NET",
            "待填",
            "占位",
        )
        bad = [s for s in lits if any(m in s.upper() for m in marks)]
        if bad:
            msg = f"{path.name}: diag_urls() 里还有占位地址 {bad} → 探针等于没有,换成真实 URL"
            res.warn(msg) if is_template else res.fail(msg)
        elif not lits and not probes:
            res.warn(f"{path.name}: diag_urls() 是空的 —— 补上首页 + 最容易挂的分类 + 一个真实详情页")
        else:
            res.ok(f"{path.name}: diag_urls() {probes or len(lits)} 个探针,没留占位符")

    return cls, source_name, attrs


# ── 活体 T4 联调 ───────────────────────────────────────────────────────


def _get(api_base: str, path: str, params: dict | None = None, timeout: int = 60):
    url = api_base.rstrip("/") + path
    if params:
        url += "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": "check_source/3"})
    t0 = time.time()
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        body = json.loads(resp.read().decode("utf-8", "ignore"))
        return body, resp.status, time.time() - t0


def live_check(api_base: str, source: str, res: Result, keyword: str = "") -> None:
    print(f"\n  {DIM}── 活体 T4 联调:{source} @ {api_base}{NC}")

    # 1. 首页
    try:
        home, status, dt = _get(api_base, f"/t4/{source}/homeContent")
    except Exception as exc:  # noqa: BLE001
        res.fail(f"{source}: /t4/{source}/homeContent 打不通({type(exc).__name__}: {exc})")
        return
    if status != 200 or "error" in home:
        res.fail(f"{source}: homeContent 返回异常 {home.get('error') if isinstance(home, dict) else home}")
    elif not home.get("class"):
        res.fail(f"{source}: homeContent 没有 class 分类清单 → TVBox 左侧顶栏会空")
    else:
        res.ok(f"homeContent  {len(home['class'])} 个分类 / {len(home.get('list') or [])} 条推荐  ({dt:.2f}s)")

    cats = home.get("class") or []
    if not cats:
        return
    tid = cats[0].get("type_id", "")

    # 2. 分类
    try:
        cat, _, dt = _get(api_base, f"/t4/{source}/categoryContent", {"t": tid, "pg": 1})
    except Exception as exc:  # noqa: BLE001
        res.fail(f"{source}: categoryContent 打不通({exc})")
        return
    cat_list = (cat or {}).get("list") or []
    if not cat_list:
        res.fail(f"{source}: categoryContent(t={tid}) 返回 0 条 → 分类正则/URL 拼法有问题")
    else:
        res.ok(f"categoryContent  t={tid}  {len(cat_list)} 条  ({dt:.2f}s)")

    first = cat_list[0] if cat_list else {}

    # 3. 搜索
    kw = keyword or str(first.get("vod_name") or first.get("vod_id") or "")[:12]
    if kw:
        try:
            s, _, dt = _get(api_base, f"/t4/{source}/searchContent", {"wd": kw, "pg": 1})
            n = len((s or {}).get("list") or [])
            if n:
                res.ok(f"searchContent   wd={kw}  {n} 条  ({dt:.2f}s)")
            else:
                res.warn(f"searchContent   wd={kw} 返回 0 条(搜索路径/正则可能要看一下,也可能就是没结果)")
        except Exception as exc:  # noqa: BLE001
            res.fail(f"{source}: searchContent 打不通({exc})")

    # 4. 详情 + $$$ 段数
    vid = str(first.get("vod_id") or "")
    if not vid:
        return
    try:
        det, _, dt = _get(api_base, f"/t4/{source}/detailContent", {"ids": vid})
    except Exception as exc:  # noqa: BLE001
        res.fail(f"{source}: detailContent 打不通({exc})")
        return
    dl = (det or {}).get("list") or []
    if not dl:
        res.fail(f"{source}: detailContent(ids={vid}) 返回空 → 详情页正则或路径有问题")
        return
    v = dl[0]
    pfrom = str(v.get("vod_play_from") or "")
    purl = str(v.get("vod_play_url") or "")
    if not purl:
        res.fail(f"{source}: 详情缺 vod_play_url → 客户端点进去必黑屏")
    elif ".m3u8" not in purl:
        res.warn(f"{source}: vod_play_url 里没有 .m3u8,确认下播放地址对不对")
    if pfrom.count("$$$") != purl.count("$$$"):
        res.fail(
            f"{source}: vod_play_from 与 vod_play_url 的 $$$ 段数不一致"
            f"({pfrom.count('$$$') + 1} vs {purl.count('$$$') + 1}) → 客户端会错线路/黑屏"
        )
    else:
        res.ok(
            f"detailContent  ids={vid}  {len(dl)} 条 / "
            f"{pfrom.count('$$$') + 1} 条线路  ({dt:.2f}s)"
        )

    # 5. 播放
    flag = pfrom.split("$$$")[0]
    play = purl.split("$$$")[0].split("#")[0].split("$")[-1]
    if not play:
        res.fail(f"{source}: 详情里解析不出播放地址")
        return
    try:
        pb, _, dt = _get(api_base, f"/t4/{source}/playerContent", {"flag": flag, "id": play})
    except Exception as exc:  # noqa: BLE001
        res.fail(f"{source}: playerContent 打不通({exc})")
        return
    url = str((pb or {}).get("url") or "")
    hdr = (pb or {}).get("header") or {}
    if not url:
        res.fail(f"{source}: playerContent 没返回 url")
    elif not any(k.lower() == "referer" for k in hdr):
        res.fail(f"{source}: playerContent 的 header 里没有 Referer → CDN 会 403/黑屏")
    else:
        res.ok(f"playerContent  {url[:70]}…  header 带 Referer  ({dt:.2f}s)")


# ── 活体:进程内直调(合并自旧版自检 —— 服务没起也能查)──────────────────


def _api_alive(api_base: str) -> bool:
    """探一下服务在不在。HTTPError 也算「在」(只是那个路径不存在)。"""
    try:
        urllib.request.urlopen(api_base.rstrip("/") + "/", timeout=5).close()
        return True
    except urllib.error.HTTPError:
        return True
    except Exception:  # noqa: BLE001
        return False


def _load_handlers() -> dict:
    """在**本进程**里 import sources,拿注册表。

    注意:这会真的执行 sources/ 下的模块(也就是实例化 handler)。
    加载期异常、__init__ 里发请求、依赖缺失都会在这里暴露 ——
    这正是它比 HTTP 早一步的价值:HTTP 只告诉你 502,这里告诉你为什么。
    """
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    import importlib

    mod = importlib.import_module("sources")
    return {h.source_name: h for h in getattr(mod, "ALL_HANDLERS", [])}


def inproc_check(source: str, res: Result, keyword: str = "") -> None:
    print(f"\n  {DIM}── 进程内直调(不经过 HTTP):{source}{NC}")
    try:
        handlers = _load_handlers()
    except Exception as exc:  # noqa: BLE001
        res.fail(
            f"import sources 失败({type(exc).__name__}: {exc}) —— "
            f"先解决加载期异常,否则 HTTP 那边必定也是 502"
        )
        return
    h = handlers.get(source)
    if h is None:
        res.fail(f"注册表里没有 {source};当前已注册:{', '.join(sorted(handlers)) or '(空)'}")
        return

    # ① home
    try:
        t0 = time.time()
        home = h.home() or {}
        dt = time.time() - t0
        cats = home.get("class") or []
        if not cats:
            res.fail(f"{source}: home() 没有 class 分类清单 → 客户端左侧顶栏会空")
            return
        res.ok(f"home()      {len(cats)} 个分类 / {len(home.get('list') or [])} 条推荐  ({dt:.2f}s)")
    except Exception as exc:  # noqa: BLE001
        res.fail(f"{source}: home() 抛异常 {type(exc).__name__}: {exc}")
        traceback.print_exc()
        return

    tid = cats[0].get("type_id", "")

    # ② category
    lst: list = []
    try:
        t0 = time.time()
        cat = h.category(tid, "1", "") or {}
        dt = time.time() - t0
        lst = cat.get("list") or []
        if not lst:
            res.fail(f"{source}: category({tid!r}, 1) 返回 0 条 → 分类 URL / 正则有问题")
        else:
            res.ok(
                f"category()  t={tid}  {len(lst)} 条 / pagecount={cat.get('pagecount')}  ({dt:.2f}s)"
            )
    except Exception as exc:  # noqa: BLE001
        res.fail(f"{source}: category() 抛异常 {type(exc).__name__}: {exc}")

    first: dict = lst[0] if lst else {}

    # ③ search
    kw = keyword or str(first.get("vod_name") or first.get("vod_id") or "")[:12]
    if kw:
        try:
            t0 = time.time()
            s = h.search(kw, "1", "") or {}
            dt = time.time() - t0
            n = len(s.get("list") or [])
            if n:
                res.ok(f"search()    wd={kw}  {n} 条  ({dt:.2f}s)")
            else:
                res.warn(f"search()    wd={kw} 返回 0 条(搜索路径 / 正则可能要看下,也可能真没结果)")
        except Exception as exc:  # noqa: BLE001
            res.fail(f"{source}: search() 抛异常 {type(exc).__name__}: {exc}")

    # ④ detail(含 m3u8 与 $$$ 段数)
    vid = str(first.get("vod_id") or "")
    if not vid:
        res.warn(f"{source}: 列表里拿不到 vod_id,detail / player 没法测")
        return
    try:
        t0 = time.time()
        det = h.detail(vid) or {}
        dt = time.time() - t0
        dl = det.get("list") or []
        if not dl:
            res.fail(f"{source}: detail({vid!r}) 返回空 → 详情路径 / 正则有问题")
            return
        v = dl[0]
        pfrom = str(v.get("vod_play_from") or "")
        purl = str(v.get("vod_play_url") or "")
        if not purl:
            res.fail(f"{source}: 详情缺 vod_play_url → 客户端点进去必黑屏")
        elif ".m3u8" not in purl:
            res.warn(f"{source}: vod_play_url 里没有 .m3u8,确认下地址对不对")
        if pfrom.count("$$$") != purl.count("$$$"):
            res.fail(
                f"{source}: vod_play_from 与 vod_play_url 的 $$$ 段数不一致"
                f"({pfrom.count('$$$') + 1} vs {purl.count('$$$') + 1}) → 客户端会错线路/黑屏"
            )
        else:
            res.ok(
                f"detail()    ids={vid}  {len(dl)} 条 / {pfrom.count('$$$') + 1} 条线路  ({dt:.2f}s)"
            )

        # ⑤ player
        flag = pfrom.split("$$$")[0]
        play = purl.split("$$$")[0].split("#")[0].split("$")[-1]
        if not play:
            res.fail(f"{source}: 详情里解析不出播放地址")
        else:
            pb = h.player(flag, play) or {}
            url = str(pb.get("url") or "")
            hdr = pb.get("header") or {}
            if not url:
                res.fail(f"{source}: player() 没返回 url")
            elif not any(str(k).lower() == "referer" for k in hdr):
                res.fail(f"{source}: player() 的 header 里没有 Referer → CDN 会 403/黑屏")
            else:
                res.ok(f"player()    {url[:60]}…  header 带 Referer")
    except Exception as exc:  # noqa: BLE001
        res.fail(f"{source}: detail() / player() 抛异常 {type(exc).__name__}: {exc}")

    # ⑥ 探针
    try:
        probes = h.diag_urls() or []
        if probes:
            res.ok(f"diag_urls() {len(probes)} 个探针已配置")
        else:
            res.warn(f"{source}: diag_urls() 是空的")
    except Exception as exc:  # noqa: BLE001
        res.fail(f"{source}: diag_urls() 抛异常 {exc!r}")


def _iter_sources() -> list[Path]:
    """递归列出 sources/ 下的源文件(与加载器同一口径,支持子目录分类)。

    跳过 `_`/`.` 开头的目录与文件、__init__.py。
    """
    out: list[Path] = []
    for path in sorted(SOURCES.rglob("*.py")):
        try:
            rel = path.relative_to(SOURCES)
        except ValueError:
            continue
        if any(part.startswith("_") or part.startswith(".") for part in rel.parts):
            continue
        out.append(path)
    return out


def _rel_of(path: Path) -> str:
    """源文件相对 sources/ 的显示路径(子目录会带目录名)。"""
    try:
        return path.relative_to(SOURCES).as_posix()
    except ValueError:
        return path.name



def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("source", nargs="?", default="", help="只查这个源")
    ap.add_argument("--static", action="store_true", help="只做静态检查,不联调")
    ap.add_argument("--api", default="http://127.0.0.1:12333")
    ap.add_argument("--search", default="", help="活体搜索用的关键词")
    ap.add_argument("--inproc", action="store_true", help="强制进程内直调(服务不用起)")
    ap.add_argument("--no-inproc", action="store_true", help="强制 HTTP,连不上就报错,不自动降级")
    args = ap.parse_args()

    res = Result()
    if not SOURCES.is_dir():
        print(f"{RED}找不到 sources/ 目录(请在项目根目录下跑本脚本){NC}")
        return 1

    print("=" * 68)
    print("静态契约检查")
    print("=" * 68)
    api = framework_api()
    print(
        f"{DIM}框架白名单: HttpClient → {', '.join(sorted(api['http_public']))}\n"
        f"            settings → {', '.join(sorted(n for n in api['settings_names'] if n.isupper()))}{NC}"
    )

    names: dict[str, str] = {}
    checked: list[str] = []
    for path in _iter_sources():
        if path.name == "__init__.py" or path.name.startswith("_"):
            continue
        rel = _rel_of(path)
        if args.source and args.source not in rel:
            continue
        print(f"\n[{rel}]")
        cls, name, _attrs = static_check(path, api, res)
        if name:
            checked.append(name)
            if name in names:
                res.fail(
                    f"撞名: {rel} 和 {names[name]} 都用 source_name='{name}' "
                    f"→ 后加载的那个会被静默丢掉(不注册)"
                )
            else:
                names[name] = rel

    if args.static:
        print("\n(--static 模式,跳过活体联调)")
    else:
        targets = [args.source] if args.source else sorted(names)
        use_inproc = args.inproc
        if not use_inproc and not _api_alive(args.api):
            if args.no_inproc:
                res.fail(
                    f"{args.api} 连不上 —— 服务没起?要么先把服务起来,"
                    f"要么去掉 --no-inproc 改用进程内直调"
                )
                targets = []
            else:
                res.warn(
                    f"{args.api} 连不上(服务没起?)—— 自动改用「进程内直调」,"
                    f"不经过 HTTP;想跑真实路由就把服务起起来"
                )
                use_inproc = True
        print("\n" + "=" * 68)
        print("活体联调:进程内直调(不经过 HTTP)" if use_inproc else "活体 T4 联调(HTTP)")
        print("=" * 68)
        for s in targets:
            if use_inproc:
                inproc_check(s, res, args.search)
            else:
                live_check(args.api, s, res, args.search)

    print("\n" + "=" * 68)
    if res.fails:
        print(f"{RED}FAIL — {len(res.fails)} 个问题,先修这些:{NC}")
        for f in res.fails:
            print(f"  · {f}")
    else:
        print(f"{GREEN}PASS — 没发现阻塞问题{NC}")
    if res.warns:
        print(f"\n{YELLOW}另有 {len(res.warns)} 条提示(不影响运行):{NC}")
        for w in res.warns:
            print(f"  · {w}")
    print("=" * 68)
    return 1 if res.fails else 0


if __name__ == "__main__":
    sys.exit(main())
