"""VOD Scraper API – Python version.

Usage:
    pip install -r requirements.txt
    python main.py [--port 12333]

Project layout:
    core/           Framework: base handler ABC, HTTP client, cache, router
    sources/        Concrete handler implementations (jable, javday, missav)
"""

import argparse
import logging
import time

from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

from core.router import router as vod_router, register, all_sources
from core.t4 import router as t4_router
from core import settings
from sources import ALL_HANDLERS

# ── Logging ────────────────────────────────────────────────────────────────

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y/%m/%d %H:%M:%S",
    level=logging.INFO,
)
log = logging.getLogger("scraper")

# ── App ────────────────────────────────────────────────────────────────────

app = FastAPI(title="VOD Scraper", docs_url=None, redoc_url=None)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def log_requests(request: Request, call_next):
    start = time.time()
    response = await call_next(request)
    latency = time.time() - start
    log.info(
        "%s %d %s %.3fs",
        request.client.host if request.client else "-",
        response.status_code,
        request.url.path + ("?" + str(request.query_params) if request.query_params else ""),
        latency,
    )
    return response


# ── Register handlers & mount router ──────────────────────────────────────

for handler in ALL_HANDLERS:
    register(handler)
    log.info("registered source: %s", handler.source_name)

app.include_router(vod_router)
app.include_router(t4_router)


@app.get("/")
async def index():
    """服务自述:一眼看到有哪些源、有哪些接口。"""
    return {
        "service": "tvbox-t4-api",
        "sources": all_sources(),
        "endpoints": {
            "vod": "/vod/{source}?ac=&t=&pg=&ids=&play=&wd=&ext=",
            "t4_home": "/t4/{source}/homeContent",
            "t4_category": "/t4/{source}/categoryContent?t=&pg=&ext=",
            "t4_detail": "/t4/{source}/detailContent?ids=",
            "t4_search": "/t4/{source}/searchContent?wd=&pg=",
            "t4_player": "/t4/{source}/playerContent?flag=&id=",
            "sites": "/t4/sites",
            "tvbox_config": "/t4/tvbox.json",
        },
    }


@app.get("/ping")
async def ping():
    return Response(content="pong")


# ── Entry point ────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default=settings.APP_HOST)
    parser.add_argument("--port", type=int, default=settings.APP_PORT)
    args = parser.parse_args()
    log.info("listening on %s:%d", args.host, args.port)
    uvicorn.run(app, host=args.host, port=args.port, log_level="warning")
