"""TVBox type:4 源 —— 模板骨架(已按实际部署的真实契约校准)。

复制这个文件到 sources/,改名成站点的名字,例如:

    cp SOURCES_TEMPLATE.py sources/mysite.py

然后只改下面标了「← 改」的地方,一共六处:

    1. 类名 / source_name / display_name / HOST / UA
    2. CATEGORIES 分类清单
    3. FILTERS 分类筛选器(不需要就整块删掉)
    4. _RE_* 正则(对着站点真实 HTML 抓一份来写)
    5. URL 拼法(_category_url / _search_url / _detail_url)
    6. diag_urls() 里的探针 URL

挂进框架:什么都不用改。把文件丢进 sources/ 就生效(加载器自动扫描),
3 秒内 /t4/<source_name>/... 就能调。⛔ 千万别再去改 sources/__init__.py,
那里是自动扫描器,手动加 import 反而会被覆盖。

写完自检(在项目根目录跑):

    python3 check_source.py mysite              # ①静态契约 ②活体联调(HTTP,连不上自动降级)
    python3 check_source.py mysite --inproc     # 强制进程内直调:服务不用起也能查
    python3 diag_source.py sources/mysite.py    # 站点侧分层诊断:网络层 or 解析层

硬性约定(详见《写源规范.md》):
    · source_name 必须唯一、纯小写字母数字,它同时是 URL 段和 TVBox 侧的 api 名
    · 所有网络请求走 self._http(core.http_client),别自己 import requests
    · 5 个方法必须全部实现,返回结构照下面注释里的写
    · detail 出来的 vod_play_url 必须真的带上 m3u8,否则客户端黑屏
    · player 返回的 header 里必须有 Referer,否则 CDN 403
    · 抓空了不要写缓存

⚠️ 框架真实能力边界(这些是**这个部署里**实际有的,别写超出范围的调用):
    HttpClient 公开方法  get / get_bytes / get_json / close / probe
                        (没有 reset_session、没有 min_interval 参数 —— 本模板
                         已用「重建实例」和「类属性 MIN_INTERVAL」把这两件事自己做掉)
    settings 可用常量    HTTP_TIMEOUT / HTTP_RETRY / HTTP_MIN_INTERVAL / HTTP_MIN_LEN
                        HTTP_PROXY / IMPERSONATE / INVALID_MARKERS / USE_DOH / DOH_URL
                        APP_HOST / APP_PORT / source_proxy()
    core.cache.TTLCache  TTLCache(ttl).get(key) / .set(key, value)
    core.base             VodHandler / VodItem / VodDetailItem / VodListResult /
                          HomeResult / PlayerResult
"""

from __future__ import annotations

import base64
import json
import re
import threading
import time
import urllib.parse
from urllib.parse import quote, urlencode

from core import settings
from core.base import (
    HomeResult,
    PlayerResult,
    VodDetailItem,
    VodHandler,
    VodItem,
    VodListResult,
)
from core.cache import TTLCache
from core.http_client import HttpClient


class MySite(VodHandler):
    # IS_TEMPLATE = True 让加载器认出这是模板,就算忘了改名直接丢进 sources/
    # 也不会被注册(否则它会以 mysite 的身份占住一个位置,还带着 example.com)。
    # 真正开写的时候把这一行删掉。
    IS_TEMPLATE = True              # ← 改成自己的源时删掉这一行

    # ── 1. 身份 ────────────────────────────────────────────────────────
    source_name = "mysite"          # ← 改(小写字母数字,URL 段就是它)
    display_name = "MySite"         # ← 改(显示名,可以中文)

    # ── 2. 站点常量 ────────────────────────────────────────────────────
    HOST = "https://example.com"    # ← 改(结尾不要带 /)
    LANG = ""                       # 有多语言路径的站才用

    UA = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    )

    # 这个源单独的最小请求间隔(秒)。框架的 HttpClient 不接 min_interval 参数,
    # 所以降速在模板里自己做 —— 被 Cloudflare 咬的源写 1.0 就行,别的源不受影响。
    MIN_INTERVAL = 0.0              # ← 被风控就改 1.0

    # ── 3. 分类清单 ────────────────────────────────────────────────────
    CATEGORIES = [                  # ← 改
        {"type_id": "new",      "type_name": "最近更新"},
        {"type_id": "censored", "type_name": "有码"},
    ]

    # ── 4. 分类筛选器(可选) ────────────────────────────────────────────
    FILTERS = [                     # ← 改(或删掉整块,并把 home() 的 filters 返回 {})
        {"key": "sort", "name": "排序", "value": [
            {"n": "默认", "v": ""},
            {"n": "最新", "v": "new"},
            {"n": "最热", "v": "hot"},
        ]},
    ]

    # ── 5. 正则 ────────────────────────────────────────────────────────
    #
    # 写正则的正确姿势:
    #   · 先找一个「稳定的切分锚点」(_RE_BLOCK),再在每块里搜字段,别一把梭。
    #   · 图片常在 data-src / data-original / background-image:url(...) 里,不是 src。
    #   · 链接可能带镜像前缀、/index.php 前缀,用 (?:...)? 把可选前缀吃掉,
    #     否则整页抓空。
    #
    _RE_BLOCK    = re.compile(r'class="video-box[^"]*"', re.I)                    # ← 改
    _RE_ID       = re.compile(r'href="(?:/index\.php)?/videos/([^"/]+)/"', re.I)  # ← 改
    _RE_PIC      = re.compile(r'data-src="(https?://[^"]+\.(?:jpg|jpeg|png|webp))"', re.I)
    _RE_TITLE    = re.compile(r'class="title"[^>]*>([\s\S]*?)</', re.I)
    _RE_REMARKS  = re.compile(r'class="duration"[^>]*>\s*([\d:]+)\s*<', re.I)
    _RE_HTML_TAG = re.compile(r"<[^>]+>")

    _RE_OG_TITLE = re.compile(r'property="og:title"\s+content="([^"]+)"', re.I)
    _RE_OG_IMAGE = re.compile(r'property="og:image"\s+content="([^"]+)"', re.I)
    _RE_DATE     = re.compile(r"(\d{4}-\d{2}-\d{2})")
    _RE_M3U8     = re.compile(r"""url:\s*['"]([^'"]+\.m3u8[^'"]*)['"]""", re.I)
    # 兜底正则(合并自旧版模板):主正则抓不到时,整页搜任意 m3u8 链接。
    # 有些站把地址塞进打包/混淆过的 JS 里,主正则那种"精确形状"就对不上了,
    # 这时候先用兜底把地址捞出来跑通链路,再回头把主正则写准。
    _RE_M3U8_ANY = re.compile(r"""(https?://[^\s"'<>\\]+\.m3u8[^\s"'<>\\]*)""", re.I)

    # ── 初始化 ─────────────────────────────────────────────────────────

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._last_hit = 0.0
        self._http = self._new_http()
        self._cache = TTLCache(1800)

    def _new_http(self) -> HttpClient:
        """按站点身份造一个 HttpClient。

        注意:这里**只能**传框架真实支持的参数
        (headers / timeout / doh_url / proxy / retry / impersonate),
        多传一个就会 TypeError —— 服务起不来,而且报错发生在加载期,
        容易误判成"文件没生效"。
        """
        return HttpClient(
            headers={
                "User-Agent": self.UA,
                "Accept": "text/html,application/xhtml+xml,*/*;q=0.9",
                "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
                "Referer": self.HOST + "/",
            },
            timeout=settings.HTTP_TIMEOUT,
            doh_url=settings.DOH_URL if settings.USE_DOH else None,
            proxy=self._proxy(),
        )

    def _proxy(self) -> str | None:
        """单源代理。框架的 settings.source_proxy() 只认 SOURCE_PROXY_<NAME>,
        这里把 <NAME>_PROXY 也一起认了,两种写法都能用。
        """
        up = self.source_name.upper()
        import os

        val = (
            os.getenv(f"SOURCE_PROXY_{up}", "")
            or os.getenv(f"{up}_PROXY", "")
            or settings.HTTP_PROXY
            or ""
        )
        return val or None

    # ── 内部工具 ───────────────────────────────────────────────────────

    def _throttle(self) -> None:
        """自己实现的单源限速(框架不支持 per-source min_interval)。"""
        if self.MIN_INTERVAL <= 0:
            return
        with self._lock:
            wait = self.MIN_INTERVAL - (time.monotonic() - self._last_hit)
            if wait > 0:
                time.sleep(wait)
            self._last_hit = time.monotonic()

    def _get(self, url: str, recover: bool = True) -> str:
        """取页面。

        失败时**不调用** self._http.reset_session()(框架没有这个方法),
        改成「关掉旧实例、造一个新的」—— 效果一样(丢连接池和 cookie),
        但只用框架的公开接口。
        """
        self._throttle()
        html = self._http.get(url)
        if html or not recover:
            return html
        try:
            self._http.close()
        except Exception:                       # noqa: BLE001
            pass
        self._http = self._new_http()
        self._throttle()
        return self._http.get(url)

    def _absolute(self, url: str) -> str:
        """把 //cdn.x.com/a.jpg 和 /a.jpg 补成完整地址。"""
        if not url:
            return ""
        url = url.strip().strip("'\"")
        if url.startswith("//"):
            return "https:" + url
        if url.startswith("/"):
            return self.HOST + url
        return url

    @staticmethod
    def _decode_ext(ext: str) -> dict[str, str]:
        """解客户端传进来的筛选项(base64 url-safe JSON,可能没 padding)。"""
        if not ext or ext in ("{}", "null"):
            return {}
        try:
            raw = json.loads(ext)
            return {str(k): str(v) for k, v in raw.items()}
        except Exception:                       # noqa: BLE001
            pass
        s = ext.replace("-", "+").replace("_", "/")
        while len(s) % 4:
            s += "="
        try:
            return json.loads(base64.b64decode(s))
        except Exception:                       # noqa: BLE001
            return {}

    # ── 列表页解析 ─────────────────────────────────────────────────────

    def _parse_list(self, html: str) -> list[dict]:
        """列表页 → [{vod_id, vod_name, vod_pic, vod_remarks}, ...]

        抓不到就返回 [],**不要抛异常** —— 一个分类空不该把整个接口搞 502。
        """
        if not html:
            return []
        blocks = self._RE_BLOCK.split(html)[1:]
        if not blocks:
            return []

        items: list[dict] = []
        seen: set[str] = set()
        for block in blocks:
            m = self._RE_ID.search(block)
            if not m:
                continue
            vid = m.group(1).strip()
            if not vid or vid in seen:
                continue

            title = ""
            if tm := self._RE_TITLE.search(block):
                title = self._RE_HTML_TAG.sub("", tm.group(1)).strip()
            if not title:
                continue                        # 没标题的卡片是广告位/占位

            pic = ""
            if pm := self._RE_PIC.search(block):
                pic = self._absolute(pm.group(1))

            remarks = ""
            if rm := self._RE_REMARKS.search(block):
                remarks = rm.group(1).strip()

            seen.add(vid)
            items.append(
                VodItem(
                    vod_id=vid, vod_name=title, vod_pic=pic, vod_remarks=remarks
                ).to_dict()
            )
        return items

    # ── URL 拼法 ───────────────────────────────────────────────────────

    def _category_url(self, type_id: str, page: int, ext: dict[str, str]) -> str:
        """← 改:按站点真实路径改。"""
        params: dict[str, str] = {}
        if ext.get("sort"):
            params["sort"] = ext["sort"]
        query = ("?" + urlencode(params)) if params else ""
        if page <= 1:
            path = f"/category/{type_id}/"
        else:
            path = f"/category/{type_id}/page/{page}/"
        return self.HOST + path + query

    def _search_url(self, keyword: str, page: int) -> str:
        """← 改:按站点真实搜索路径改。"""
        kw = quote(keyword, safe="")
        if page <= 1:
            return f"{self.HOST}/search/{kw}/"
        return f"{self.HOST}/search/{kw}/page/{page}/"

    def _detail_url(self, vid: str) -> str:
        """← 改:按站点真实详情页路径改。"""
        return f"{self.HOST}/videos/{vid}/"

    # ── 多集 / 多线路 ──────────────────────────────────────────────────
    #
    # TB4 的播放字段是两条平行字符串,规则(TVBox 认的就这套):
    #     vod_play_from = "线路A$$$线路B"          ← $$$ 分段
    #     vod_play_url  = "第1集$url1#第2集$url2$$$第1集$url3"  ← # 分集,$ 分隔集名和地址
    #   · 两边的 $$$ 段数必须**完全一致**,少一段客户端直接黑屏或错线路
    #   · 地址里不能再出现 #(会被当成分集),_build_play() 会自动削掉

    def _episodes(self, vid: str, html: str) -> dict[str, list[tuple[str, str]]]:
        """← 改:返回 {线路名: [(集名, m3u8 地址), ...]}。

        单集单线路就返回一条;多集站一次塞多集;多线路站塞多个 key。
        编字符串的活交给 _build_play(),别自己拼。
        """
        out: dict[str, list[tuple[str, str]]] = {}
        m = self._RE_M3U8.search(html) or self._RE_M3U8_ANY.search(html)
        if m:
            out["MySite"] = [("播放", m.group(1))]
        return out

    @staticmethod
    def _build_play(episodes: dict[str, list[tuple[str, str]]]) -> tuple[str, str]:
        """{线路: [(集名, 地址)]} → (vod_play_from, vod_play_url)。"""
        froms: list[str] = []
        urls: list[str] = []
        for line, eps in episodes.items():
            # 地址里的 # 会拆集;$$$ 会拆线路,一起削掉
            clean = [(n, u.replace("#", "").replace("$$$", "")) for n, u in eps if u]
            if not clean:
                continue                    # 空线路必须整个丢掉,否则段数对不上
            froms.append(line)
            urls.append("#".join(f"{n}${u}" for n, u in clean))
        return "$$$".join(froms), "$$$".join(urls)

    # ── 五个契约方法(全部要实现) ──────────────────────────────────────

    def home(self) -> dict:
        """返回 {"class": [...], "filters": {...}, "list": [...]}"""
        if cached := self._cache.get("home"):
            return cached

        lst = self._parse_list(self._get(self.HOST + "/"))
        filters = (
            {c["type_id"]: self.FILTERS for c in self.CATEGORIES}
            if self.FILTERS else {}
        )
        result = HomeResult(classes=self.CATEGORIES, filters=filters, list=lst).to_dict()

        # ⚠️ 抓空了**不要**写缓存 —— 否则一次网络抖动会把空首页锁 1800 秒。
        if lst:
            self._cache.set("home", result)
        return result

    def category(self, type_id: str, page: str, ext: str = "") -> dict:
        """返回 {"page", "pagecount", "limit", "total", "list"}"""
        pg = self.safe_int(page)
        url = self._category_url(type_id, pg, self._decode_ext(ext))
        lst = self._parse_list(self._get(url))
        return VodListResult(
            list=lst,
            page=pg,
            pagecount=pg + 1 if lst else pg,
            limit=len(lst) or 20,
        ).to_dict()

    def search(self, keyword: str, page: str, ext: str = "") -> dict:
        """返回 {"page", "pagecount", "limit", "total", "list"}"""
        pg = self.safe_int(page)
        kw = (keyword or "").strip()
        # 空关键词直接返回空(合并自旧版模板):TVBox 有时会拿空 wd 打过来,
        # 没必要为此发一次必然抓空的请求,更别让空结果进缓存。
        if not kw:
            return VodListResult(list=[], page=1, pagecount=1).to_dict()
        lst = self._parse_list(self._get(self._search_url(kw, pg)))
        return VodListResult(
            list=lst, page=pg, pagecount=pg + 1 if lst else pg, limit=len(lst) or 20
        ).to_dict()

    def detail(self, ids: str) -> dict:
        """返回 {"list": [vod, ...]};ids 可能是逗号分隔的多个。"""
        results: list[dict] = []
        for vid in (x.strip() for x in ids.split(",")):
            if not vid:
                continue
            html = self._get(self._detail_url(vid))
            if not html:
                continue

            name = vid
            if m := self._RE_OG_TITLE.search(html):
                name = self._RE_HTML_TAG.sub("", m.group(1)).strip() or vid
            pic = ""
            if m := self._RE_OG_IMAGE.search(html):
                pic = m.group(1)
            year = ""
            if m := self._RE_DATE.search(html):
                year = m.group(1)

            play_from, play_url = self._build_play(self._episodes(vid, html))
            results.append(
                VodDetailItem(
                    vod_id=vid,
                    vod_name=name,
                    vod_pic=pic,
                    vod_year=year,
                    vod_play_from=play_from,
                    vod_play_url=play_url,
                ).to_dict()
            )
        return {"list": results}

    def player(self, flag: str, play_url: str) -> dict:
        """返回 {"parse": 0, "url": "...", "header": {...}}。

        header 里必须有 Referer,否则 CDN 403 —— 这条最容易漏,漏了就是黑屏。
        """
        if not play_url:
            return PlayerResult(parse=0, url="", header={}).to_dict()
        return PlayerResult(
            url=play_url,
            header={"User-Agent": self.UA, "Referer": self.HOST + "/"},
        ).to_dict()

    # ── 诊断 ───────────────────────────────────────────────────────────
    # 这个部署里**没有** /diag/{source} 路由,别去 curl 它。
    # 探针写在这里,由 diag_source.py 读出来真打一遍。

    def diag_urls(self) -> list[tuple[str, str]]:
        return [                        # ← 改
            ("首页", self.HOST + "/"),
            ("分类 new", f"{self.HOST}/category/new/"),
        ]
