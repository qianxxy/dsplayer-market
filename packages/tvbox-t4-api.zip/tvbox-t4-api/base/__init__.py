# -*- coding: utf-8 -*-
"""TVBox 壳子运行时兼容层。

壳子（Chaquopy / TVBox Python 源）里 `from base.spider import Spider` 的基类
是 App 注入的；T4 服务里没有，所以这里补一份等价实现，让现成的 TVBox Python
源不改一行就能跑起来。
"""

from base.spider import Spider  # noqa: F401

__all__ = ["Spider"]
