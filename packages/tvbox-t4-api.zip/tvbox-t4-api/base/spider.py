# -*- coding: utf-8 -*-
"""TVBox 壳子基类 `base.spider.Spider` 的兼容实现。

壳子里这个类由 App（Chaquopy）注入，负责网络请求、日志、缓存、本地代理等。
T4 服务（FastAPI）里没有，这里照着补一份最小可用实现，使得**现成的 TVBox
Python 源（`from base.spider import Spider`）一行不改就能跑**。

已覆盖的壳子 API：
    fetch()            同步 HTTP 请求，返回文本（优先 curl_cffi 过 CF，回退 requests）
    getProxyUrl()      返回本地代理前缀，供源拼 ?url=... 走 localProxy
    localProxy()       子类实现，本模块不提供（由桥接层转成 HTTP 路由）
    log() / getName() / isVideoFormat() / destroy()
    getCache() / saveCache() / delCache()
"""

from __future__ import annotations

import json
import logging
import os
import ssl
import threading
import time
import urllib.parse
import urllib.request

log = logging.getLogger("base.spider")

DEFAULT_UA = os.getenv("TVBOX_SPIDER_UA", "okhttp/4.12.0")


def _app_port() -> str:
    """服务实际监听端口（供 getProxyUrl 拼自访问地址）。"""
    if os.getenv("APP_PORT"):
        return os.environ["APP_PORT"]
    try:
        from core import settings

        return str(getattr(settings, "APP_PORT", 12333))
    except Exception:  # pragma: no cover
        return "12333"

try:  # 首选：浏览器 TLS 指纹，过 Cloudflare
    from curl_cffi import requests as _cffi
except Exception:  # pragma: no cover
    _cffi = None

try:
    import requests as _requests
except Exception:  # pragma: no cover
    _requests = None

_cache_lock = threading.Lock()
_cache_store: dict[str, tuple[float, object]] = {}


class FetchResult(str):
    """fetch() 的返回值：**既是字符串，又像 requests.Response**。

    壳子源两种写法都有 —— ``html = self.fetch(url)``（当字符串用）和
    ``rsp = self.fetch(url); rsp.text / rsp.content / rsp.json() / rsp.status_code``
    （当 Response 用）。这个类两边都满足。
    """

    def __new__(cls, text="", content=b"", status_code=200, headers=None, url="", encoding="utf-8"):
        obj = super().__new__(cls, text)
        obj.content = content if content else text.encode("utf-8", "ignore")
        obj.status_code = int(status_code)
        obj.headers = dict(headers or {})
        obj.url = url
        obj.encoding = encoding
        return obj

    # Response 风格
    @property
    def text(self):
        return str(self)

    @property
    def ok(self):
        return 200 <= self.status_code < 400

    def json(self, **kwargs):
        return json.loads(str(self), **kwargs)

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(f"HTTP {self.status_code} for {self.url}")
        return self


class Spider:
    """TVBox 壳子基类（兼容版）。

    子类照常实现 ``init / getName / homeContent / categoryContent /
    detailContent / searchContent / playerContent / localProxy``。
    """

    # 由桥接层在注册时写入（用于 getProxyUrl 拼地址）
    source_name = ""

    def __init__(self):  # 壳子里子类一般自己重写 __init__
        pass

    # ── 壳子生命周期 ────────────────────────────────────────────────

    def init(self, extend=""):
        """壳子启动时调用；子类按需重写。"""

    def getName(self):
        return ""

    def isVideoFormat(self, url):
        return False

    def destroy(self):
        """壳子退出时调用；子类按需重写。"""

    def log(self, msg):
        log.info("[spider] %s", msg)

    # ── 网络 ────────────────────────────────────────────────────────

    def fetch(
        self,
        url,
        headers=None,
        timeout=None,
        method="GET",
        data=None,
        params=None,
        cookies=None,
        allow_redirects=True,
        **kwargs,
    ):
        """同步取文本。

        兼容壳子 `self.fetch(url)` / `self.fetch(url, headers=...)` 两种写法。
        """
        h = {"User-Agent": DEFAULT_UA}
        if headers:
            h.update({str(k): str(v) for k, v in headers.items()})
        t = timeout or 15
        url = str(url)
        if params:
            url = f"{url}{'&' if '?' in url else '?'}{urllib.parse.urlencode(params)}"

        if _cffi is not None:
            try:
                resp = _cffi.request(
                    method.upper(),
                    url,
                    headers=h,
                    data=data,
                    cookies=cookies,
                    timeout=t,
                    allow_redirects=allow_redirects,
                )
                if resp.status_code < 400:
                    return FetchResult(
                        text=resp.text,
                        content=resp.content,
                        status_code=resp.status_code,
                        headers=dict(resp.headers or {}),
                        url=url,
                    )
                log.debug("curl_cffi HTTP %s: %s", resp.status_code, url)
            except Exception as exc:  # noqa: BLE001
                log.debug("curl_cffi 失败(%s)，回退 requests: %s", type(exc).__name__, url)

        if _requests is not None:
            try:
                resp = _requests.request(
                    method.upper(),
                    url,
                    headers=h,
                    data=data,
                    cookies=cookies,
                    timeout=t,
                    verify=False,
                    allow_redirects=allow_redirects,
                )
                if not resp.encoding or resp.encoding.lower() == "iso-8859-1":
                    resp.encoding = resp.apparent_encoding or resp.encoding
                return FetchResult(
                    text=resp.text,
                    content=resp.content,
                    status_code=resp.status_code,
                    headers=dict(resp.headers or {}),
                    url=str(resp.url or url),
                    encoding=resp.encoding or "utf-8",
                )
            except Exception as exc:  # noqa: BLE001
                log.warning("requests 失败(%s): %s", type(exc).__name__, url)

        # 最后兜底：urllib（中文路径需先编码）
        try:
            safe_url = urllib.parse.quote(url, safe=":/?&=#%+,$@!~*'()[]")
            req = urllib.request.Request(safe_url, headers=h, method=method.upper())
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            with urllib.request.urlopen(req, timeout=t, context=ctx) as r:
                raw = r.read()
                return FetchResult(
                    text=raw.decode("utf-8", "ignore"),
                    content=raw,
                    status_code=getattr(r, "status", 200),
                    headers=dict(r.headers or {}),
                    url=safe_url,
                )
        except Exception as exc:  # noqa: BLE001
            log.warning("urllib 兜底也失败(%s): %s", type(exc).__name__, url)
            return FetchResult("", b"", 502, url=url)

    def getProxyUrl(self, *args, **kwargs):
        """本地代理前缀（源会拼 ?url=... 使用，由 /tbproxy/<源名> 路由处理）。"""
        base = os.getenv("TVBOX_SPIDER_PROXY_BASE") or f"http://127.0.0.1:{_app_port()}"
        return f"{base}/tbproxy/{self.source_name}?do=py&"

    def localProxy(self, params):
        raise NotImplementedError("localProxy 未实现")

    # ── 缓存 ────────────────────────────────────────────────────────

    def getCache(self, key, default=None):
        with _cache_lock:
            item = _cache_store.get(str(key))
            if not item:
                return default
            expire_at, value = item
            if time.time() > expire_at:
                _cache_store.pop(str(key), None)
                return default
            return value

    def saveCache(self, key, value, ttl=3600):
        with _cache_lock:
            _cache_store[str(key)] = (time.time() + float(ttl or 3600), value)

    def delCache(self, key):
        with _cache_lock:
            _cache_store.pop(str(key), None)
