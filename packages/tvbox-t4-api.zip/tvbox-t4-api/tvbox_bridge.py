# -*- coding: utf-8 -*-
"""TVBox 壳子 Python 源 → T4（VodHandler）适配桥。

TVBox 壳子的 Python 源是这么写的::

    from base.spider import Spider
    class Spider(Spider):
        def homeContent(self, filter): ...
        def categoryContent(self, tid, pg, filter, extend): ...
        def detailContent(self, ids): ...          # ids 是 list
        def searchContent(self, key, quick, pg): ...
        def playerContent(self, flag, id, vipFlags): ...

T4 框架（本项目）是::

    class Xxx(VodHandler):
        def home(self): ...
        def category(self, type_id, page, ext): ...
        def detail(self, ids): ...                 # ids 是逗号串
        def search(self, keyword, page, ext): ...
        def player(self, flag, play_url): ...

两边返回的 JSON 结构本来就一样（class/list、page/pagecount/limit/total、
list[vod]、parse/url/header），所以只需一层薄适配：**源文件一行不改**。

用法（见 sources/tvbox_compat.py，自动扫描，一般不用手写）:

    cls = make_source_class(Path("sources/河马短剧.py"), "hema", "河马短剧")
    register(cls())          # 挂进 core.router
"""

from __future__ import annotations

import base64
import hashlib
import importlib.util
import json
import logging
import sys
import threading
import time
from pathlib import Path
from urllib.parse import parse_qs, urlencode

from core.base import VodHandler

log = logging.getLogger("tvbox-bridge")


def ext_to_dict(ext) -> dict:
    """把筛选参数归一成壳子契约要的 **字典**。

    两条通道送筛选的方式不一样:
      · type:3 —— 壳子直接把 HashMap 交给源(本来就是 dict)；
      · type:4 —— 壳子把筛选塞进 URL 的 ``ext`` 查询参数,**urlsafe-base64(JSON)**,
        而且**没有任何筛选时也会带**(值就是 base64("{}")=``e30=``)。

    所以 type:4 过来的 ``ext`` 不能原样当 extend 用,必须先解。三种形态都收:

      · 空 / None / "{}" / "null"      -> {}
      · plain JSON 对象                 -> dict
      · urlsafe-base64(JSON 对象)       -> dict(自动补 padding)
      · 其它(解不出来)                  -> {}(宁可当"没筛选",也不给源一个字符串)

    值统一转成 str,和壳子 HashMap<String,String> 一致。
    """
    if ext is None:
        return {}
    if isinstance(ext, dict):
        return {str(k): str(v) for k, v in ext.items()}
    text = str(ext).strip()
    if not text or text in ("{}", "null", "None"):
        return {}
    try:  # 形态 1: plain JSON
        raw = json.loads(text)
        if isinstance(raw, dict):
            return {str(k): str(v) for k, v in raw.items()}
    except Exception:  # noqa: BLE001
        pass
    try:  # 形态 2: urlsafe-base64(JSON)
        s = text.replace("-", "+").replace("_", "/")
        s += "=" * (-len(s) % 4)
        raw = json.loads(base64.b64decode(s).decode("utf-8", "replace"))
        if isinstance(raw, dict):
            return {str(k): str(v) for k, v in raw.items()}
    except Exception:  # noqa: BLE001
        pass
    return {}

# TVBox 壳子契约要求的 5 个方法
TVBOX_METHODS = (
    "homeContent",
    "categoryContent",
    "detailContent",
    "searchContent",
    "playerContent",
)

# 文件（不含 .py）→ (URL 段名, 显示名)。没登记的走 md5 短名（同远端 srcXXXX 风格）
NAME_MAP = {
    "星芽短剧": ("xingya", "星芽短剧"),
    "有声小说": ("yousheng", "黑料不打烊"),
    "河马短剧": ("hema", "河马短剧"),
    "酷我音乐": ("kuwo", "酷我音乐"),
    "275听书": ("t275", "275听书"),
    "乐橙": ("lecheng", "乐橙"),
    "短剧": ("duanju", "短剧"),
}


def looks_like_tvbox_spider(cls) -> bool:
    """类是不是壳子风格源（5 个方法齐全，且不是本项目的 VodHandler）。"""
    if not isinstance(cls, type):
        return False
    if issubclass(cls, VodHandler):
        return False
    return all(callable(getattr(cls, m, None)) for m in TVBOX_METHODS)


def slug_for(path: Path) -> tuple[str, str]:
    """给源文件起 URL 段名 + 显示名。"""
    stem = path.stem
    if stem in NAME_MAP:
        return NAME_MAP[stem]
    short = hashlib.md5(stem.encode("utf-8")).hexdigest()[:8]
    return f"src{short}", stem


def load_spider_instance(path: Path, slug: str = ""):
    """按文件路径加载壳子源并实例化（模块名唯一，避免与扫描器缓存串味）。"""
    mod_name = "tvboxsrc_" + hashlib.md5(str(path).encode("utf-8")).hexdigest()[:10]
    spec = importlib.util.spec_from_file_location(mod_name, str(path))
    module = importlib.util.module_from_spec(spec)
    sys.modules[mod_name] = module
    spec.loader.exec_module(module)  # 执行失败由调用方处理

    classes = [c for c in vars(module).values() if looks_like_tvbox_spider(c)]
    if not classes:
        return None
    cls = next((c for c in classes if c.__name__ == "Spider"), classes[-1])
    inst = cls()
    if slug:
        try:
            inst.source_name = slug
        except Exception:  # noqa: BLE001
            pass
    try:
        inst.init("")
    except Exception:  # noqa: BLE001
        log.exception("源 %s 的 init() 报错（继续用默认状态）", path.name)
    return inst


def _normalize_proxy(raw) -> tuple[int, str, bytes]:
    """把壳子 localProxy 的各种返回收敛成 (code, content_type, body)。"""
    if raw is None:
        return 404, "text/plain", b""
    if isinstance(raw, (list, tuple)):
        if len(raw) >= 4:                       # [code, type, {}, ''] 这种四元组
            code = int(raw[0] or 200)
            ctype = str(raw[1] or "application/octet-stream")
            body = raw[3] if raw[3] not in (None, "") else raw[2]
        elif len(raw) == 3:
            code, ctype, body = int(raw[0] or 200), str(raw[1] or "application/octet-stream"), raw[2]
        elif len(raw) == 2:
            code, ctype, body = 200, "application/octet-stream", raw[1]
        else:
            return 502, "text/plain", b""
    elif isinstance(raw, dict):
        if raw.get("url"):
            return 302, "text/plain", str(raw["url"]).encode()
        code = int(raw.get("code") or 200)
        ctype = str((raw.get("headers") or {}).get("Content-Type") or "application/octet-stream")
        body = raw.get("content")
    else:
        body = raw.encode("utf-8", "ignore") if isinstance(raw, str) else raw
        return 200, "application/octet-stream", body

    if isinstance(body, str):
        body = body.encode("utf-8", "ignore")
    elif body is None:
        body = b""
    elif not isinstance(body, (bytes, bytearray)):
        body = str(body).encode("utf-8", "ignore")
    return code, ctype, bytes(body)


def _jsonable(obj, _depth=0):
    """把结果收敛成可 JSON 序列化的结构（bytes→base64、set→list、异常对象→str）。"""
    if _depth > 8:
        return str(obj)
    if obj is None or isinstance(obj, (bool, int, float, str)):
        return obj
    if isinstance(obj, bytes):
        return base64.b64encode(obj).decode("ascii")
    if isinstance(obj, dict):
        return {str(k): _jsonable(v, _depth + 1) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [_jsonable(v, _depth + 1) for v in obj]
    if isinstance(obj, BaseException):
        return f"{type(obj).__name__}: {obj}"
    return str(obj)


class TvboxSource(VodHandler):
    """壳子源适配器：实现 T4 契约，内部全部转调壳子方法。"""

    spider_file: str = ""       # 绝对/相对文件路径
    display_name: str = ""
    spider = None               # 壳子源实例
    last_load_error: str = ""
    _lock = threading.Lock()

    # ── 内部 ───────────────────────────────────────────────────────

    def _call(self, method: str, *args, default=None):
        """调壳子方法，统一兜异常（一个源报错不影响服务）。"""
        fn = getattr(self.spider, method, None)
        if fn is None:
            raise NotImplementedError(f"{self.source_name}: 源里没有 {method}()")
        with self._lock:
            result = fn(*args)
        return result

    def _safe(self, method: str, *args, default=None):
        try:
            return _jsonable(self._call(method, *args))
        except NotImplementedError:
            raise
        except Exception as exc:  # noqa: BLE001
            log.exception("[%s] %s 调用失败", self.source_name, method)
            return default if default is not None else {"error": f"{type(exc).__name__}: {exc}"}

    # ── T4 契约 ───────────────────────────────────────────────────

    def home(self) -> dict:
        data = self._safe("homeContent", False, default={})
        if not isinstance(data, dict):
            data = {}
        return {
            "class": data.get("class") or data.get("classes") or [],
            "filters": data.get("filters") or {},
            "list": data.get("list") or [],
        }

    def category(self, type_id: str, page: str, ext: str = "") -> dict:
        # type:4 通道的 ext 是 urlsafe-base64(筛选JSON)（无筛选也会带 e30=），
        # 必须先解成字典；type:3 通道直接给字典。空筛选 == 老行为(传空值)。
        extend = ext_to_dict(ext)
        data = self._safe("categoryContent", type_id, str(page or "1"), bool(extend), extend, default={})
        if not isinstance(data, dict):
            data = {}
        return {
            "page": data.get("page") or self.safe_int(str(page or 1)),
            "pagecount": data.get("pagecount") or 1,
            "limit": data.get("limit") or 20,
            "total": data.get("total") or 9999,
            "list": data.get("list") or [],
        }

    def detail(self, ids: str) -> dict:
        id_list = [i for i in str(ids).split(",") if i]
        data = self._safe("detailContent", id_list, default={})
        if isinstance(data, list):
            data = {"list": data}
        if not isinstance(data, dict):
            data = {}
        return {"list": data.get("list") or []}

    def search(self, keyword: str, page: str = "1", ext: str = "") -> dict:
        data = self._safe("searchContent", keyword, False, str(page or "1"), default={})
        if not isinstance(data, dict):
            data = {}
        return {
            "page": data.get("page") or self.safe_int(str(page or 1)),
            "pagecount": data.get("pagecount") or 1,
            "limit": data.get("limit") or 20,
            "total": data.get("total") or 9999,
            "list": data.get("list") or [],
        }

    def player(self, flag: str, play_url: str) -> dict:
        data = self._safe("playerContent", flag, play_url, [], default={})
        if not isinstance(data, dict):
            return {"parse": 0, "url": "", "header": {}}
        out = dict(data)  # 壳子的 jx / format / 多音质数组等字段原样透传
        out.setdefault("parse", 0)
        if not out.get("url"):
            # 壳子源偶尔把地址塞在 'data'/'playUrl' 里
            out["url"] = data.get("data") or data.get("playUrl") or ""
        out["header"] = out.get("header") or {}
        return out

    def proxy(self, action: str, target: str, ext: str = "") -> dict:
        """T4 的 /vod/<源>?proxy=xx 入口：转成 dict 调 localProxy，结果转 JSON 友好形式。"""
        params = {"do": action}
        if target:
            params["url"] = target
        if ext:
            params.update({k: (v[0] if v else "") for k, v in parse_qs(ext).items()})
        status, content_type, body = self.proxy_response(params)
        return _jsonable({"code": status, "headers": {"Content-Type": content_type}, "content": body})

    def proxy_response(self, params: dict) -> tuple[int, str, bytes]:
        """调壳子源的 localProxy，统一成 ``(状态码, MIME, 字节)``。

        壳子约定：入参是**已解析好的 dict**，返回 ``[code, content_type, body]``
        （有的源返回 dict，有的返回 None）。这里全部兜住。
        """
        fn = getattr(self.spider, "localProxy", None)
        if fn is None:
            raise NotImplementedError(f"{self.source_name}: 源里没有 localProxy()")
        query = urlencode(params)
        with self._lock:
            try:
                raw = fn(dict(params))          # 绝大多数壳子源：dict
            except (TypeError, KeyError, AttributeError):
                raw = fn(query)                 # 少数源：自己解析字符串
        return _normalize_proxy(raw)

    def raw_proxy(self, params):
        """兼容旧调用：参数串 → (dict) → proxy_response 的原始返回。"""
        if isinstance(params, str):
            params = {k: (v[0] if v else "") for k, v in parse_qs(params.lstrip("?")).items()}
        status, content_type, body = self.proxy_response(params or {})
        return [status, content_type, body]

    # ── 热加载 ─────────────────────────────────────────────────────

    def reload(self) -> bool:
        """按文件重新加载壳子源（文件更新后调用）。"""
        try:
            inst = load_spider_instance(Path(self.spider_file), self.source_name)
        except Exception as exc:  # noqa: BLE001
            self.last_load_error = f"{type(exc).__name__}: {exc}"
            log.error("[%s] 重新加载失败: %s", self.source_name, self.last_load_error)
            return False
        if inst is None:
            self.last_load_error = "文件里找不到壳子风格源类"
            log.error("[%s] %s", self.source_name, self.last_load_error)
            return False
        with self._lock:
            old = self.spider
            self.spider = inst
            self.last_load_error = ""
        # 显示名跟着走（NAME_MAP 里显式指定过的以映射为准）
        if Path(self.spider_file).stem not in NAME_MAP:
            try:
                new_name = str(inst.getName() or "")
                if new_name:
                    self.display_name = new_name
            except Exception:  # noqa: BLE001
                pass
        try:  # 老实例有机会释放资源
            if old is not None and hasattr(old, "destroy"):
                old.destroy()
        except Exception:  # noqa: BLE001
            pass
        return True


def make_source_class(path: Path, slug: str, display_name: str, spider):
    """按文件动态生成一个 TvboxSource 子类（类名即源名，便于日志辨认）。"""
    cls_name = "Tvbox_" + "".join(ch if ch.isalnum() else "_" for ch in slug) or "Tvbox_source"
    return type(
        cls_name,
        (TvboxSource,),
        {
            "source_name": slug,
            "display_name": display_name,
            "spider_file": str(path),
            "spider": spider,
            "__doc__": f"TVBox 壳子源桥接：{path.name}",
        },
    )
