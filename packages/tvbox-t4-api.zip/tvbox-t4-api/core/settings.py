"""Application settings loaded from environment variables (.env supported)."""

from __future__ import annotations

import os

from dotenv import load_dotenv

load_dotenv()


def _to_bool(val: str | None, default: bool = False) -> bool:
    if val is None:
        return default
    return val.strip().lower() in {"1", "true", "yes", "on"}


def _to_int(val: str | None, default: int) -> int:
    if val is None or val == "":
        return default
    try:
        return int(val)
    except ValueError:
        return default


def _to_float(val: str | None, default: float) -> float:
    if val is None or val == "":
        return default
    try:
        return float(val)
    except ValueError:
        return default


APP_HOST = os.getenv("APP_HOST", "0.0.0.0")
APP_PORT = _to_int(os.getenv("APP_PORT"), 12333)

HTTP_TIMEOUT = _to_int(os.getenv("HTTP_TIMEOUT"), 10)

# 三个站都挂了 Cloudflare:失败自动重试 + 同域最小间隔,能大幅降低 403 概率。
HTTP_RETRY = _to_int(os.getenv("HTTP_RETRY"), 3)
HTTP_MIN_INTERVAL = _to_float(os.getenv("HTTP_MIN_INTERVAL"), 0.2)

# curl_cffi 的浏览器指纹,用来过 Cloudflare 的 TLS 校验。
IMPERSONATE = os.getenv("IMPERSONATE", "chrome")

# 被限流时站点常拿 HTTP 200 回一页 404 / 人机验证页(实测 javday 会)。
# 命中这些标记就当失败重试,免得解析出 0 条。
_RAW_MARKERS = os.getenv(
    "INVALID_MARKERS",
    "aks-404-page|Just a moment...|Attention Required|cf-browser-verification"
    "|Verifying you are human|Enable JavaScript and cookies to continue|"
    "您即将访问的页面不存在",
)
INVALID_MARKERS: tuple[str, ...] = tuple(m for m in _RAW_MARKERS.split("|") if m)

# 小于这个字节数的响应一律当异常重试。
HTTP_MIN_LEN = _to_int(os.getenv("HTTP_MIN_LEN"), 512)

# 可选:上游代理(形如 http://user:pass@host:port),留空则直连。
HTTP_PROXY = os.getenv("HTTP_PROXY", "")

USE_DOH = _to_bool(os.getenv("USE_DOH"), False)
DOH_URL = os.getenv("DOH_URL", "https://1.1.1.1/dns-query")


def source_proxy(source_name: str) -> str:
    """按源名返回代理地址。

    优先读 SOURCE_PROXY_<SOURCE_NAME>(全大写),没配则回退到 HTTP_PROXY。
    留空则返回空字符串(直连)。
    """
    if not source_name:
        return HTTP_PROXY or ""
    key = f"SOURCE_PROXY_{source_name.upper()}"
    return os.getenv(key, "") or HTTP_PROXY or ""
