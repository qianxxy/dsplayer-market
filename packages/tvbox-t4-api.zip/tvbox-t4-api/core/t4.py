"""TVBox type:4 + type:3 双契约层(均支持 HTTP 直连,无需 JAR)。

TVBox 的 type:4 站点,客户端调的是一组固定名字的方法:

    homeContent()                        -> {class, filters, list}
    categoryContent(t, pg, filter, ext)  -> {page, pagecount, limit, total, list}
    detailContent(ids)                   -> {list: [vod]}
    searchContent(wd, quick)             -> {page, pagecount, limit, total, list}
    playerContent(flag, id, vipFlags)    -> {parse, url, header}

这个模块把上面每个方法都摊成一个 GET 路由,**方法名和参数名原样照搬契约**,
所以任何"远程 spider"式的调用方(或你自己写的 T4 客户端)都能直接打:

    GET /t4/{source}/homeContent
    GET /t4/{source}/categoryContent?t=new&pg=1&filter=0&ext=
    GET /t4/{source}/detailContent?ids=xxx
    GET /t4/{source}/searchContent?wd=xxx&quick=0
    GET /t4/{source}/playerContent?flag=MissAV&id=<播放地址>&vipFlags=

便利接口(两套并存,均输出 HTTP 直连地址,不需要 JAR):

    T4 格式(type:4 + HTTP api):
        GET /t4/sites
        GET /t4/tvbox.json

    T3 格式(type:3 + HTTP api):
        GET /t3/sites
        GET /t3/tvbox.json

原有的 /vod/{source}?ac=... 路由一行没动,三套并存。
"""

from __future__ import annotations

import os

import json
from urllib.parse import quote

from fastapi import APIRouter, Request, Response

from core.cache import cache_key, cached_call
from core.router import all_sources, get_handler

router = APIRouter()


def _json(data: object, status: int = 200) -> Response:
    return Response(
        content=json.dumps(data, ensure_ascii=False, indent=2),
        media_type="application/json; charset=utf-8",
        status_code=status,
    )


def _base_url(request: Request) -> str:
    """生成配置里的自引用地址（反代/局域网都考虑）。

    默认锁成 127.0.0.1（壳子在本机永远能通，不依赖 Wi-Fi）；
    要让局域网/其它设备也能用，把环境变量 T4_FORCE_HOST 设成那个 IP/域名
    （可带端口，不带就沿用当前端口），或设成 host / auto 表示跟随请求 Host。
    """
    proto = request.headers.get("x-forwarded-proto") or request.url.scheme
    host = request.headers.get("x-forwarded-host") or request.headers.get("host") or request.url.netloc
    prefix = (request.headers.get("x-forwarded-prefix") or "").rstrip("/")
    forced = (os.getenv("T4_FORCE_HOST", "127.0.0.1") or "").strip()
    if forced and forced.lower() not in ("host", "auto"):
        if ":" not in forced:
            port = host.rsplit(":", 1)[1] if ":" in host else ""
            if port:
                forced = f"{forced}:{port}"
        host = forced
    return f"{proto}://{host}{prefix}"

def _site_meta(source: str, handler, site_type: int = 4, base: str = "") -> dict:
    """生成站点配置。type=3/4 都用 HTTP 直连地址,无需 JAR。"""
    name = getattr(handler, "display_name", None) or source
    api_url = f"{base}/vod/{source}" if base else f"/vod/{source}"
    return {
        "key": source,
        "name": name,
        "type": site_type,
        "api": api_url,
        "searchable": 1,
        "quickSearch": 1,
        "filterable": 1,
        "ext": "",
    }


def _build_sites(request: Request, site_type: int) -> dict:
    base = _base_url(request)
    sites = []
    for source in all_sources():
        handler = get_handler(source)
        if handler is None:
            continue
        meta = _site_meta(source, handler, site_type=site_type, base=base)
        sites.append(meta)
    return {"sites": sites, "total": len(sites)}


# ── 站点清单 / TVBox 配置 ──────────────────────────────────────────────
# 下面全部用同步 def:源是阻塞 IO,同步函数由 FastAPI 丢线程池执行 → 真正并发。
# home/category/detail/search 走 45 秒短缓存(T4_CACHE_TTL 可调),player 不缓存。


@router.get("/t4/sites")
def t4_sites(request: Request):
    """T4 格式站点清单(type:4 + HTTP 直连)。"""
    return _json(_build_sites(request, site_type=4))


@router.get("/t4/tvbox.json")
def t4_tvbox_json(request: Request):
    """T4 格式 TVBox 配置。"""
    data = _build_sites(request, site_type=4)
    data["lives"] = []
    data["parses"] = []
    data["flags"] = []
    return _json(data)


@router.get("/t3/sites")
def t3_sites(request: Request):
    """T3 格式站点清单(type:3 + HTTP 直连)。"""
    return _json(_build_sites(request, site_type=3))


@router.get("/t3/tvbox.json")
def t3_tvbox_json(request: Request):
    """T3 格式 TVBox 配置。"""
    data = _build_sites(request, site_type=3)
    data["lives"] = []
    data["parses"] = []
    data["flags"] = []
    return _json(data)


# ── T4 契约方法 ────────────────────────────────────────────────────────


@router.api_route("/t4/{source}/homeContent", methods=["GET", "POST"])
@router.api_route("/t4/{source}/home", methods=["GET", "POST"])
def t4_home(source: str):
    handler = get_handler(source)
    if handler is None:
        return _json({"error": f"unknown source: {source}"}, 404)
    return _json(_safe(lambda: cached_call(cache_key(source, "home"), handler.home)))


@router.api_route("/t4/{source}/categoryContent", methods=["GET", "POST"])
@router.api_route("/t4/{source}/category", methods=["GET", "POST"])
def t4_category(source: str, request: Request):
    handler = get_handler(source)
    if handler is None:
        return _json({"error": f"unknown source: {source}"}, 404)
    q = request.query_params
    t = q.get("t") or q.get("type_id") or ""
    pg = q.get("pg") or q.get("page") or "1"
    ext = q.get("ext") or q.get("extend") or q.get("filter") or ""
    return _json(
        _safe(
            lambda: cached_call(
                cache_key(source, "category", t, pg, ext),
                lambda: handler.category(t, pg, ext),
            )
        )
    )


@router.api_route("/t4/{source}/detailContent", methods=["GET", "POST"])
@router.api_route("/t4/{source}/detail", methods=["GET", "POST"])
def t4_detail(source: str, request: Request):
    handler = get_handler(source)
    if handler is None:
        return _json({"error": f"unknown source: {source}"}, 404)
    ids = request.query_params.get("ids") or request.query_params.get("id") or ""
    return _json(
        _safe(
            lambda: cached_call(
                cache_key(source, "detail", ids), lambda: handler.detail(ids)
            )
        )
    )


@router.api_route("/t4/{source}/searchContent", methods=["GET", "POST"])
@router.api_route("/t4/{source}/search", methods=["GET", "POST"])
def t4_search(source: str, request: Request):
    handler = get_handler(source)
    if handler is None:
        return _json({"error": f"unknown source: {source}"}, 404)
    q = request.query_params
    wd = q.get("wd") or q.get("keyword") or ""
    pg = q.get("pg") or q.get("page") or "1"
    ext = q.get("ext") or q.get("extend") or ""
    return _json(
        _safe(
            lambda: cached_call(
                cache_key(source, "search", wd, pg, ext),
                lambda: handler.search(wd, pg, ext),
            )
        )
    )


@router.api_route("/t4/{source}/playerContent", methods=["GET", "POST"])
@router.api_route("/t4/{source}/player", methods=["GET", "POST"])
def t4_player(source: str, request: Request):
    handler = get_handler(source)
    if handler is None:
        return _json({"error": f"unknown source: {source}"}, 404)
    q = request.query_params
    flag = q.get("flag") or ""
    play = q.get("id") or q.get("play") or q.get("url") or ""
    return _json(_safe(lambda: handler.player(flag, play)))


@router.api_route("/t4/{source}/proxy", methods=["GET", "POST"])
def t4_proxy(source: str, request: Request):
    handler = get_handler(source)
    if handler is None:
        return _json({"error": f"unknown source: {source}"}, 404)
    q = request.query_params
    action = q.get("do") or q.get("action") or ""
    target = q.get("url") or ""
    ext = q.get("ext") or q.get("extend") or ""
    try:
        return _json(handler.proxy(action, target, ext))
    except NotImplementedError as exc:
        return _json({"error": str(exc)}, 404)


def _safe(fn):
    """把 handler 抛出的未知异常收敛成 502,别让调用方拿到 500 堆栈。"""
    try:
        return fn()
    except NotImplementedError as exc:
        return {"error": str(exc)}
    except Exception as exc:  # noqa: BLE001
        import logging

        logging.getLogger("t4").exception("t4 调用失败")
        return {"error": f"internal error: {type(exc).__name__}: {exc}"}
