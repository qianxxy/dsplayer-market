"""共享 HTTP 客户端。

三个站点都挂了 Cloudflare,macOS/服务器上直接 httpx 打过去多半吃 403。
这里默认走 curl_cffi 的浏览器 TLS/JA3 指纹(impersonate=chrome),再叠一层
"失败重试 + 同域限速",CF 偶发 403 基本能被重试吃掉。

对外接口保持不变:
    HttpClient(headers=..., timeout=..., doh_url=...)
    .get(url, extra_headers=None) -> str
    .get_bytes(url, extra_headers=None) -> bytes
"""

from __future__ import annotations

import logging
import threading
import time
import urllib.parse

try:  # pragma: no cover - 取决于运行环境
    from curl_cffi import requests as cffi_requests

    HAS_CURL_CFFI = True
except Exception:  # pragma: no cover
    cffi_requests = None  # type: ignore[assignment]
    HAS_CURL_CFFI = False

try:
    import httpx
except Exception:  # pragma: no cover
    httpx = None  # type: ignore[assignment]

from core import settings

log = logging.getLogger("http")


class HttpClient:
    """带浏览器指纹 / 重试 / 限速 / 可选代理的同步 HTTP 客户端。"""

    def __init__(
        self,
        headers: dict[str, str] | None = None,
        timeout: float | None = None,
        doh_url: str | None = None,
        proxy: str | None = None,
        retry: int | None = None,
        impersonate: str | None = None,
    ) -> None:
        self._headers = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            **(headers or {}),
        }
        self._timeout = timeout or settings.HTTP_TIMEOUT
        self._doh_url = doh_url
        self._proxy = proxy if proxy is not None else (settings.HTTP_PROXY or None)
        self._retry = retry if retry is not None else settings.HTTP_RETRY
        self._impersonate = impersonate or settings.IMPERSONATE
        self._min_interval = settings.HTTP_MIN_INTERVAL
        # 站点被限流/风控时会拿 HTTP 200 回一页 404 或 CF 验证页。
        # 这种"假成功"必须当失败重试,否则解析出来就是 0 条。
        self._invalid_markers = settings.INVALID_MARKERS
        self._min_len = settings.HTTP_MIN_LEN
        self._last_hit: dict[str, float] = {}
        self._lock = threading.Lock()

        self._session = None
        if HAS_CURL_CFFI:
            try:
                kw: dict[str, object] = {"impersonate": self._impersonate, "timeout": self._timeout}
                if self._proxy:
                    kw["proxies"] = {"http": self._proxy, "https": self._proxy}
                self._session = cffi_requests.Session(**kw)  # type: ignore[union-attr]
            except Exception as exc:  # noqa: BLE001
                log.warning("curl_cffi 会话创建失败,退回 httpx: %s", exc)
        else:
            log.warning("未安装 curl_cffi,退回 httpx(Cloudflare 站点可能返回 403)")

        self._httpx = None
        if self._session is None and httpx is not None:
            self._httpx = httpx.Client(
                timeout=self._timeout,
                verify=False,
                follow_redirects=True,
                http2=False,
                limits=httpx.Limits(max_connections=100, max_keepalive_connections=20),
            )

    # ── 内部工具 ───────────────────────────────────────────────────────

    def _throttle(self, url: str) -> None:
        """同一个域名之间强制留最小间隔,避免触发风控。"""
        if self._min_interval <= 0:
            return
        host = urllib.parse.urlsplit(url).netloc
        with self._lock:
            wait = self._min_interval - (time.time() - self._last_hit.get(host, 0.0))
            if wait > 0:
                time.sleep(wait)
            self._last_hit[host] = time.time()

    def _request(self, url: str, extra_headers: dict[str, str] | None) -> bytes:
        merged = {**self._headers, **(extra_headers or {})}
        if self._session is not None:
            resp = self._session.get(url, headers=merged)
            if resp.status_code >= 400:
                raise RuntimeError(f"HTTP {resp.status_code}")
            return resp.content
        if self._httpx is not None:
            resp = self._httpx.get(url, headers=merged)
            resp.raise_for_status()
            return resp.content
        raise RuntimeError("没有可用的 HTTP 传输层(请 pip install curl_cffi)")

    def _fetch(self, url: str, extra_headers: dict[str, str] | None) -> bytes:
        last_err = ""
        for attempt in range(self._retry + 1):
            self._throttle(url)
            try:
                body = self._request(url, extra_headers)
                if not body:
                    last_err = "empty body"
                elif len(body) < self._min_len:
                    last_err = f"body too short ({len(body)}B, 疑似风控页)"
                elif (marker := self._hit_marker(body)) is not None:
                    last_err = f"命中风控页标记 {marker!r}"
                else:
                    return body
            except Exception as exc:  # noqa: BLE001
                last_err = f"{type(exc).__name__}: {exc}"
                log.debug("GET %s 第 %d 次失败: %s", url, attempt + 1, last_err)
            if attempt < self._retry:
                time.sleep(0.5 * (attempt + 1))
        log.warning("GET %s 最终失败: %s", url, last_err)
        return b""

    def _hit_marker(self, body: bytes) -> str | None:
        head = body[:6000].decode("utf-8", "ignore")
        for marker in self._invalid_markers:
            if marker in head:
                return marker
        return None

    # ── 对外接口 ───────────────────────────────────────────────────────

    def get(self, url: str, extra_headers: dict[str, str] | None = None) -> str:
        """GET *url*,返回文本;彻底失败返回空串。"""
        return self._fetch(url, extra_headers).decode("utf-8", "ignore")

    def get_bytes(self, url: str, extra_headers: dict[str, str] | None = None) -> bytes:
        """GET *url*,返回原始字节;彻底失败返回空字节。"""
        return self._fetch(url, extra_headers)

    def get_json(self, url: str, extra_headers: dict[str, str] | None = None):
        import json

        try:
            return json.loads(self.get(url, extra_headers))
        except Exception:  # noqa: BLE001
            return None

    def close(self) -> None:
        for obj in (self._session, self._httpx):
            if obj is not None:
                try:
                    obj.close()
                except Exception:  # noqa: BLE001
                    pass
