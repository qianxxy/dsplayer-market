"""FastAPI router factory – dispatches ``/vod/{source}`` to registered handlers."""

from __future__ import annotations

import json
import logging
import time

from fastapi import APIRouter, Request, Response

from core.base import VodHandler
from core.cache import cache_key, cached_call

log = logging.getLogger("scraper")

router = APIRouter()

# source_name → handler instance
_registry: dict[str, VodHandler] = {}


def register(handler: VodHandler) -> None:
    """Register a ``VodHandler`` subclass; called once at startup."""
    if handler.source_name in _registry:
        prev = _registry[handler.source_name].__class__.__name__
        curr = handler.__class__.__name__
        raise ValueError(f"duplicate source_name '{handler.source_name}': {prev} vs {curr}")
    _registry[handler.source_name] = handler


def get_handler(source: str) -> VodHandler | None:
    """Return the registered handler for *source*, or ``None``."""
    return _registry.get(source)


def all_sources() -> list[str]:
    """Registered source names, in registration order."""
    return list(_registry.keys())


def _json(data: object, status: int = 200) -> Response:
    return Response(
        content=json.dumps(data, ensure_ascii=False, indent=2),
        media_type="application/json; charset=utf-8",
        status_code=status,
    )


@router.api_route("/vod/{source}", methods=["GET", "POST"])
@router.api_route("/vod/{source}/{rest:path}", methods=["GET", "POST"])
def vod_dispatch(request: Request, source: str, rest: str = ""):
    """注意:这里是 ``def`` 而不是 ``async def``。

    源(尤其 py 源)内部都是阻塞 IO,写成 async 会让它们全挤在同一个事件循环上,
    壳子连着打多个请求时就变成「串行 = 各源耗时之和」。同步函数由 FastAPI 丢进
    线程池跑,天然并发。
    """
    handler = _registry.get(source)
    if handler is None:
        return _json({"error": f"unknown source: {source}"}, 404)

    q = request.query_params
    ac = q.get("ac", "")
    proxy_action = q.get("proxy", "")
    if not proxy_action and ac == "proxy":
        proxy_action = q.get("do", "")
    proxy_target = q.get("url", "")
    type_id = q.get("t", "")
    page = q.get("pg", "")
    ids = q.get("ids", "")
    play = q.get("play", "")
    flag = q.get("flag", "")
    wd = q.get("wd", "")
    ext = q.get("ext", "") or q.get("extend", "")

    try:
        if proxy_action:
            result = handler.proxy(proxy_action, proxy_target, ext)
        elif type_id and page:
            result = cached_call(
                cache_key(source, "category", type_id, page, ext),
                lambda: handler.category(type_id, page, ext),
            )
        elif ids and "," not in ids and "%2C" not in ids:
            result = cached_call(
                cache_key(source, "detail", ids), lambda: handler.detail(ids)
            )
        elif play:
            # 播放地址不缓存
            result = handler.player(flag, play)
        elif wd:
            result = cached_call(
                cache_key(source, "search", wd, page, ext),
                lambda: handler.search(wd, page, ext),
            )
        else:
            result = cached_call(cache_key(source, "home"), handler.home)
    except NotImplementedError as e:
        return _json({"error": str(e)}, 404)
    except Exception:
        log.exception("[vod/%s] error", source)
        return _json({"error": "internal error"}, 502)

    return _json(result)
