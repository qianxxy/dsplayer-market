"""Abstract base handler and response dataclasses for VOD sources."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict


# ── Response models ────────────────────────────────────────────────────────


@dataclass
class VodItem:
    """A video card shown in list / search results."""
    vod_id: str
    vod_name: str
    vod_pic: str = ""
    vod_remarks: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class VodDetailItem:
    """Full detail for a single video."""
    vod_id: str
    vod_name: str
    vod_pic: str = ""
    vod_year: str = ""
    vod_content: str = ""
    vod_actor: str = ""
    vod_director: str = ""
    vod_remarks: str = ""
    vod_play_from: str = ""
    vod_play_url: str = ""

    def to_dict(self) -> dict:
        return {k: v for k, v in asdict(self).items() if v != ""}


@dataclass
class VodListResult:
    """Paginated video list response."""
    list: list[dict] = field(default_factory=list)
    page: int = 1
    pagecount: int = 1
    limit: int = 20
    total: int = 9999

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class HomeResult:
    """Home page response with categories + video list."""
    classes: list[dict] = field(default_factory=list)
    filters: dict = field(default_factory=dict)
    list: list[dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {"class": self.classes, "filters": self.filters, "list": self.list}


@dataclass
class PlayerResult:
    """Direct playback response."""
    parse: int = 0
    url: str = ""
    header: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


# ── Abstract handler ───────────────────────────────────────────────────────


class VodHandler(ABC):
    """Interface that every VOD source must implement.

    Mirrors the Go ``vod.Handler`` interface so the URL scheme stays compatible:
    - ``GET /vod/{source}``              → home()
    - ``GET /vod/{source}?t=X&pg=Y``    → category()
    - ``GET /vod/{source}?ids=X``        → detail()
    - ``GET /vod/{source}?play=X``       → player()
    - ``GET /vod/{source}?wd=X``         → search()
    """

    # Subclass must set this; used as the URL path segment.
    source_name: str = ""

    @abstractmethod
    def home(self) -> dict:
        ...

    @abstractmethod
    def category(self, type_id: str, page: str, ext: str = "") -> dict:
        ...

    @abstractmethod
    def detail(self, ids: str) -> dict:
        ...

    @abstractmethod
    def player(self, flag: str, play_url: str) -> dict:
        ...

    @abstractmethod
    def search(self, keyword: str, page: str, ext: str = "") -> dict:
        ...

    def proxy(self, action: str, target: str, ext: str = "") -> dict:
        """Optional extension hook for custom proxy/decrypt/ocr workflows.

        Subclasses can override this method to support extra actions, e.g.:
        - image decrypt pipeline
        - ddddocr verification
        - custom upstream proxy

        The router maps:
        - ``?proxy=<action>&url=<target>&ext=<...>``
        - ``?ac=proxy&do=<action>&url=<target>&ext=<...>``
        """
        raise NotImplementedError(f"proxy action is not implemented for source '{self.source_name}'")

    # ── convenience helpers for subclasses ─────────────────────────────

    @staticmethod
    def safe_int(val: str, default: int = 1, minimum: int = 1) -> int:
        """Parse *val* as int, clamped to *minimum*."""
        try:
            return max(int(val), minimum)
        except (ValueError, TypeError):
            return default
