"""Thread-safe in-memory TTL cache."""

from __future__ import annotations

import os
import threading
import time


class TTLCache:
    """Simple key→value store where every entry expires after *ttl* seconds."""

    def __init__(self, ttl: float = 1800) -> None:
        self._ttl = ttl
        self._data: dict[str, tuple[float, object]] = {}
        self._lock = threading.Lock()
        threading.Thread(target=self._gc, daemon=True).start()

    def get(self, key: str) -> object | None:
        with self._lock:
            entry = self._data.get(key)
            if entry is None:
                return None
            expires_at, val = entry
            if time.time() > expires_at:
                del self._data[key]
                return None
            return val

    def set(self, key: str, value: object, ttl: float | None = None) -> None:
        with self._lock:
            t = self._ttl if ttl is None else ttl
            self._data[key] = (time.time() + t, value)

    def _gc(self) -> None:
        """Background thread: purge expired entries every 15 min."""
        while True:
            time.sleep(900)
            now = time.time()
            with self._lock:
                to_del = [k for k, (exp, _) in self._data.items() if now > exp]
                for k in to_del:
                    del self._data[k]


# ── 接口级短缓存 ───────────────────────────────────────────────────────
# 壳子对同一部片常常连着打 home/category/detail/search(列表页 + 详情页 + 返回),
# 每个请求都真跑一次源就是纯浪费。这里按 (源|方法|参数) 缓存一小段时间,
# 窗口内的重复请求直接回放,不再触发上游抓取。player(播放地址) 永不缓存。

CALL_CACHE_TTL = float(os.getenv("T4_CACHE_TTL", "45"))

_call_cache: TTLCache | None = None


def call_cache() -> TTLCache:
    global _call_cache
    if _call_cache is None:
        _call_cache = TTLCache(ttl=CALL_CACHE_TTL)
    return _call_cache


def cache_key(source: str, method: str, *args: object) -> str:
    return "|".join([str(source), str(method)] + [str(a) for a in args])


def cached_call(key: str, fn, ttl: float | None = None):
    """Memoise ``fn()`` for a short TTL. 错误结果不缓存,免得把一次失败钉死。"""
    c = call_cache()
    hit = c.get(key)
    if hit is not None:
        return hit
    val = fn()
    if not (isinstance(val, dict) and val.get("error")):
        c.set(key, val, ttl)
    return val

