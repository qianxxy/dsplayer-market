/**
 * 黄果短剧 (huangguo) — T4 插件
 * 站点: https://huangguoai.com (SSR + JSON API, 免登录)
 * 契约:
 *   home    = 首页聚合(SSR) → 用 /api/videos?sort=hot 兜底列表
 *   category= /api/videos/category/{slug}?page=N&size=21  (4分类: ai-duanju/ai-manju/ai-huanlian/ai-mogai)
 *   search  = /api/videos?keyword=X&page=N  (JSON, pagination.total=全库模糊搜索)
 *   detail  = /api/videos/{id}              (episodes[{ep_num,title,duration}] + 简介/封面/tags)
 *   play    = /api/videos/{id}/play?ep=N    (video_url=带auth_key的m3u8, 有效期约5分钟)
 * 媒体: AES-128 标准 HLS, yd-hls.nkgjoa.cn; 必须带 UA + Referer: https://huangguoai.com/ 否则403
 * 时效红线: m3u8 auth_key 仅约5分钟有效 → play() 必须实时请求, 禁止缓存直链
 */
"use strict";
const axios = require("axios");
const crypto = require("crypto");

// ============================================================================
// 常量
// ============================================================================
const SITE = "https://huangguoai.com";
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36";
const PAGE_SIZE = 21;

// 封面图=站点图床 AES-CBC 加密密文（前端 crypto-worker.js 硬编码密钥解密后显示；
// 图床 CDN 返回密文, Content-Type=binary/octet-stream → 壳子图片解码器无法直接显示）。
// 数字串为各字节 ASCII 码（下划线分隔）: 102_53_... 转字符 = "f5d965df75336270"(key 16B)
//                                               57_55_... 转字符 = "97b60394abc2fbe1"(iv 16B)
// 算法 AES-128-CBC NoPadding；本站 47/47 图样全部同一 key/iv 解出有效图。
const IMG_AES_KEY = Buffer.from([102,53,100,57,54,53,100,102,55,53,51,51,54,50,55,48]);
const IMG_AES_IV  = Buffer.from([57,55,98,54,48,51,57,52,97,98,99,50,102,98,101,49]);
function decryptCover(buf) {
  if (!buf || !buf.length || buf.length % 16 !== 0) return null;
  try {
    const d = crypto.createDecipheriv("aes-128-cbc", IMG_AES_KEY, IMG_AES_IV);
    d.setAutoPadding(false);
    return Buffer.concat([d.update(buf), d.final()]);
  } catch (e) {
    return null;
  }
}
// 图片解密代理端点路径（本脚本自注册, 供壳子加载明文封面）
const PIC_PROXY_PATH = "/video/huangguoduanju/pic";

// 分类: slug + 展示名 (来自站点导航 SSR 实测; chigua 是帖子社区, 非视频链路, 不接入)
// 末位 "排行榜" 为聚合分类: 走 /api/videos?sort=… 全库排行, 同样支持 rank 筛选
const CATS = [
  { slug: "ai-duanju", name: "AI成人短剧" },
  { slug: "ai-manju", name: "AI成人漫剧" },
  { slug: "ai-huanlian", name: "AI换脸" },
  { slug: "ai-mogai", name: "AI魔改" },
  { slug: "__rank__", name: "排行榜" },
];
const CAT_MAP = Object.fromEntries(CATS.map((c) => [c.slug, c.name]));

function headers(extra) {
  return Object.assign(
    {
      "user-agent": UA,
      referer: SITE + "/",
      accept: "application/json, text/plain, */*",
    },
    extra || {}
  );
}

async function apiGet(path, params) {
  const res = await axios.get(SITE + path, {
    headers: headers(),
    params: params || {},
    timeout: 20000,
  });
  const d = res.data && res.data.data;
  if (d === undefined) throw new Error((res.data && res.data.msg) || "响应异常");
  return d;
}

// ============================================================================
// 业务层
// ============================================================================
function toStr(v, fallback = "") {
  return v == null || v === "" ? String(fallback || "") : String(v);
}

// 封面图 URL: 站点 auth_key 约2小时过期，过期后 CDN 拒连(HTTP 000)导致客户端图挂；
// 实测裸 URL（无 query）长期可用且与带 key 同图（MD5 一致）→ 统一剥离时效 query
function stableCover(v) {
  const c = toStr(v);
  return c ? c.split("?")[0] : "";
}

function mapListItem(it) {
  if (!it) return null;
  const id = toStr(it.id);
  const name = toStr(it.title);
  if (!id || !name) return null;
  const fin = it.is_finished;
  const eps = it.episode_count ? `${it.episode_count}集` : "";
  const remark = eps ? (fin ? `已完结·${eps}` : eps) : toStr(it.score) ? `${it.score}分` : "";
  return {
    vod_id: id,
    vod_name: name,
    vod_pic: stableCover(it.cover),
    vod_remarks: remark,
  };
}

function decodeExt(ext) {
  if (!ext) return {};
  try {
    return JSON.parse(Buffer.from(String(ext), "base64").toString("utf8")) || {};
  } catch {
    return {};
  }
}

// 排行榜筛选：普通分类用站点 Tab（sort 参数），排行榜分类用官方三榜
const RANK_TABS = [
  { n: "当前热播", v: "" },
  { n: "最新更新", v: "new" },
  { n: "独家原创", v: "original" },
  { n: "随机推荐", v: "random" },
];
const RANK_CATEGORY_TABS = [
  { n: "热播榜", v: "hot" },
  { n: "推荐榜", v: "recommend" },
  { n: "潜力榜", v: "potential" },
]

async function home() {
  const classes = CATS.map((c, i) => ({ type_id: String(i + 1), type_name: c.name }));
  // 首页列表: 全库热门
  let list = [];
  try {
    const r = await apiGet("/api/videos", { sort: "hot", size: PAGE_SIZE, page: 1 });
    list = ((r && r.items) || []).map(mapListItem).filter(Boolean);
  } catch {
    list = [];
  }
  const filters = {};
  for (const c of classes) {
    filters[c.type_id] = [
      {
        key: "rank",
        name: "排行榜",
        init: c.type_id === "5" ? "hot" : "",
        value: (c.type_id === "5" ? RANK_CATEGORY_TABS : RANK_TABS).map((t) => ({ n: t.n, v: t.v })),
      },
    ];
  }
  return {
    class: classes,
    filters,
    list,
    page: 1,
    pagecount: 1,
    limit: PAGE_SIZE,
    total: list.length,
  };
}

async function category(tid, page, ext) {
  const pg = Math.max(1, parseInt(page, 10) || 1);
  const idx = parseInt(tid, 10) - 1;
  const cat = CATS[idx];
  if (!cat) return { page: pg, pagecount: 1, limit: PAGE_SIZE, total: 0, list: [] };
  // 排行榜分类: 官方三榜 /api/ranks/{hot|recommend|potential}（每榜20条，无分页）
  if (cat.slug === "__rank__") {
    const rk = toStr(ext && (ext.rank || ext["1"]), "hot");
    const api = rk === "recommend" ? "recommend" : rk === "potential" ? "potential" : "hot";
    const r = await apiGet(`/api/ranks/${api}`);
    const items = (r && r.items) || [];
    const list = items
      .map((it) => {
        if (!it) return null;
        const id = toStr(it.video_id);
        if (!id) return null;
        return {
          vod_id: id,
          vod_name: toStr(it.title),
          vod_pic: stableCover(it.cover),
          vod_remarks: `${it.metric_label || ""}${it.metric_value != null ? "·" + it.metric_value : ""}`,
        };
      })
      .filter(Boolean);
    return { page: 1, pagecount: 1, limit: list.length, total: list.length, list };
  }
  // ext.rank: ""=热播 / new / original / random
  const rank = toStr(ext && (ext.rank || ext["1"]));
  const params = { page: pg, size: PAGE_SIZE };
  if (rank === "new") params.sort = "new";
  else if (rank === "random") params.sort = "random";
  else if (rank === "original") { params.sort = "hot"; params.is_original = 1; }
  else params.sort = "hot";
  const r = await apiGet(`/api/videos/category/${cat.slug}`, params);
  const items = (r && r.items) || [];
  const pag = (r && r.pagination) || {};
  const list = items.map(mapListItem).filter(Boolean);
  return {
    page: pg,
    pagecount: toNum(pag.pages, pg),
    limit: toNum(pag.size, PAGE_SIZE),
    total: toNum(pag.total, list.length),
    list,
  };
}

function toNum(v, fallback) {
  const n = parseInt(v, 10);
  return Number.isFinite(n) && n > 0 ? n : fallback;
}

async function detail(idList) {
  const out = [];
  for (const rawId of Array.isArray(idList) ? idList : [idList]) {
    const id = toStr(rawId);
    if (!id) continue;
    const d = await apiGet(`/api/videos/${id}`);
    const info = d || {};
    const episodes = Array.isArray(info.episodes) ? info.episodes : [];
    // playId = "hg_{video_id}_{ep_num}"; 集名按黄豆短剧同款规则规整：
    // 原始 title 为"第N集"/纯数字/剧名拼数字/空 → 统一重写"第N集"；剧情描述类长文本保留
    const normEpName = (ep, n) => {
      const raw = toStr(ep.title).trim();
      if (!raw || /^(第\s*\d+\s*集|\d+)$/.test(raw)) return `第${n}集`;
      if (/^第[0-9\\u4e00-\\u9fa5]{1,3}集$/.test(raw)) return raw; // 标准中文集名保留
      // 数字结尾且等于集号（"我的女友景甜 2"/"我的女友景甜3"拼接型） → 第N集
      const numTail = raw.match(/(?:^|[^0-9])(\d{1,3})\s*$/);
      if (numTail && parseInt(numTail[1], 10) === n) return `第${n}集`;
      // 超长剧情描述型(>40字) → 第N集, 避免选集列表刷屏
      if (raw.length > 40) return `第${n}集`;
      return raw;
    };
    const playUrl = episodes
      .map((ep) => `${normEpName(ep, ep.ep_num)}$hg_${id}_${toStr(ep.ep_num)}`)
      .join("#");
    const cats = (info.breadcrumb || []).map((b) => toStr(b.name)).join("/");
    const tags = (info.tags || []).join(",");
    out.push({
      vod_id: id,
      vod_name: toStr(info.title),
      vod_pic: stableCover(info.cover),
      vod_remarks: info.episode_count
        ? `${info.episode_count}集${info.is_finished ? "·完结" : ""}`
        : "",
      type_name: cats || tags,
      vod_content: toStr(info.description),
      vod_play_from: "黄果短剧",
      vod_play_url: playUrl,
    });
  }
  return { list: out };
}

async function play(flag, id) {
  // id = "hg_{video_id}_{ep_num}"; auth_key 约5分钟时效 → 实时请求, 不缓存
  const m = /^hg_(\d+)_(\d+)$/.exec(String(id));
  if (!m) throw new Error("playId 格式错误");
  const vid = m[1], ep = m[2];
  const d = await apiGet(`/api/videos/${vid}/play`, { ep });
  const url = toStr(d.video_url);
  if (!url) throw new Error("未取到播放直链");
  return {
    parse: 0,
    jx: 0,
    url,
    playUrl: "",
    play_url: "",
    header: { "user-agent": UA, referer: SITE + "/" },
    headers: { "user-agent": UA, referer: SITE + "/" },
    flag,
    // 单线路: 直链实时签发, 无备用镜像
    urls: [{ name: "主线路", url }],
    playUrls: [{ name: "主线路", url }],
    play_urls: [{ name: "主线路", url }],
    qualitys: [{ name: "主线路", url }],
    qualities: [{ name: "主线路", url }],
    qualityUrl: url,
    quality_url: url,
    defaultUrl: url,
    default_url: url,
    currentUrl: url,
    current_url: url,
    extra: { nodanmu: true },
  };
}

async function search(wd, pg) {
  const kw = toStr(wd).trim();
  if (!kw) return { list: [] };
  const page = Math.max(1, parseInt(pg, 10) || 1);
  const r = await apiGet("/api/videos", { keyword: kw, page, size: PAGE_SIZE });
  const items = (r && r.items) || [];
  const pag = (r && r.pagination) || {};
  const list = items.map(mapListItem).filter(Boolean);
  return {
    parse: 0,
    jx: 0,
    page,
    limit: PAGE_SIZE,
    pagecount: toNum(pag.pages, page),
    total: toNum(pag.total, list.length),
    list,
  };
}

const meta = {
  key: "huangguoduanju",
  name: "[短]黄果短剧",
  type: 4,
  api: "/video/huangguoduanju",
  searchable: 1,
  quickSearch: 1,
  filterable: 1,
  changeable: 0,
};

// 按解密后字节嗅探真实图片 Content-Type
function sniffImageContentType(b) {
  if (!b || b.length < 2) return "application/octet-stream";
  if (b[0] === 0xff && b[1] === 0xd8) return "image/jpeg";
  if (b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x38) return "image/gif";
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return "image/png";
  if (b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 &&
      b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) return "image/webp";
  if (b[0] === 0x42 && b[1] === 0x4d) return "image/bmp";
  return "application/octet-stream";
}

module.exports = async (app, opt) => {
  // 封面解密端点：GET {PIC_PROXY_PATH}?u=<加密图URL> → 下载密文 → AES-CBC 解密 → 明文图
  app.get(PIC_PROXY_PATH, async (req, reply) => {
    const u = (req.query && req.query.u) || "";
    if (!u) return reply.code(400).send("missing u");
    try {
      const res = await axios.get(u, {
        headers: headers(),
        timeout: 20000,
        responseType: "arraybuffer",
      });
      const plain = decryptCover(Buffer.from(res.data));
      if (!plain) return reply.code(502).send("decrypt failed");
      reply.header("content-type", sniffImageContentType(plain));
      reply.header("cache-control", "public, max-age=86400");
      return reply.send(plain);
    } catch (e) {
      app.log && app.log.error && app.log.error(`[黄果短剧] pic ${e && e.message || e}`);
      return reply.code(502).send("pic error");
    }
  });

  app.get(meta.api, async (req) => {
    const q = req.query || {};
    const { ac, t, pg, wd, play: playId, ids, ext, flag } = q;
    const filters = decodeExt(ext);
    try {
      let result;
      if (playId) result = await play(flag, playId);
      else if (wd) result = await search(wd, pg);
      else if (ids) result = await detail([String(ids)]);
      else if (t) result = await category(t, pg || "1", filters);
      else if (ac === "list") result = await category("1", pg || "1");
      else result = await home();
      // 把列表/详情里的 CDN 封面密文 URL 改写为本脚本解密端点（壳子加载即得明文图）
      if (result && Array.isArray(result.list)) {
        const host = (req.headers && req.headers.host) || "";
        const proto = (req.headers && req.headers["x-forwarded-proto"]) || "http";
        const base = host ? `${proto}://${host}` : "";
        if (base) {
          for (const it of result.list) {
            if (it && typeof it.vod_pic === "string" && it.vod_pic && /^https?:\/\//.test(it.vod_pic)) {
              it.vod_pic = base + PIC_PROXY_PATH + "?u=" + encodeURIComponent(it.vod_pic);
            }
          }
        }
      }
      return result;
    } catch (e) {
      app.log && app.log.error && app.log.error(`[黄果短剧] ${e && e.message || e}`);
      return { list: [] };
    }
  });

  opt.sites.push(meta);
};
