const axios = require("axios");
const CryptoJS = require("crypto-js");

// --- 配置区域 (参考 [2] Python代码配置) ---
const hemaConfig = {
    siteUrl: "https://www.kuaikaw.cn",
    headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",
        "Referer": "https://www.kuaikaw.cn",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8"
    }
};

// 分类映射 (源自 [2] self.cateManual)
const classMapping = {
    "462": "甜宠",
    "1102": "古装仙侠",
    "1145": "现代言情",
    "1170": "青春",
    "585": "豪门恩怨",
    "417-464": "逆袭",
    "439-465": "重生",
    "1159": "系统",
    "1147": "总裁",
    "943": "职场商战"
};

// 辅助函数：解析 __NEXT_DATA__ (逻辑源自 [2])
const parseNextData = (html) => {
    try {
        const pattern = /<script id="__NEXT_DATA__" type="application\/json">(.*?)<\/script>/s;
        const match = html.match(pattern);
        if (match && match[1]) {
            return JSON.parse(match[1]);
        }
    } catch (e) {
        console.error("JSON Parse Error:", e);
    }
    return null;
};

// 获取分类列表对象
const getClasses = () => {
    return Object.keys(classMapping).map(key => ({
        type_id: key,
        type_name: classMapping[key]
    }));
};

// 获取首页/分类内容
const getCategoryList = async (tid, page = 1) => {
    try {
        let url;
        let isHome = false;

        // 逻辑参考 [2] homeVideoContent 和 categoryContent
        if (!tid) {
            url = hemaConfig.siteUrl;
            isHome = true;
        } else {
            url = `${hemaConfig.siteUrl}/browse/${tid}/${page}`;
        }

        const response = await axios.get(url, { headers: hemaConfig.headers });
        const json = parseNextData(response.data);
        if (!json) return { list: [], page: 1, pagecount: 1 };

        const pageProps = json.props?.pageProps || {};
        let videos = [];

        if (isHome) {
            // 首页处理：Banner + SEO Columns (源自 [2])
            if (pageProps.bannerList) {
                pageProps.bannerList.forEach(banner => {
                    if (banner.bookId) {
                        videos.push({
                            vod_id: `/drama/${banner.bookId}`,
                            vod_name: banner.bookName,
                            vod_pic: banner.coverWap,
                            vod_remarks: `${banner.statusDesc || ''} ${banner.totalChapterNum || ''}集`.trim()
                        });
                    }
                });
            }
            if (pageProps.seoColumnVos) {
                pageProps.seoColumnVos.forEach(column => {
                    if (column.bookInfos) {
                        column.bookInfos.forEach(book => {
                            if (book.bookId) {
                                videos.push({
                                    vod_id: `/drama/${book.bookId}`,
                                    vod_name: book.bookName,
                                    vod_pic: book.coverWap,
                                    vod_remarks: `${book.statusDesc || ''} ${book.totalChapterNum || ''}集`.trim()
                                });
                            }
                        });
                    }
                });
            }
            // 去重
            const seen = new Set();
            videos = videos.filter(v => {
                const duplicate = seen.has(v.vod_id);
                seen.add(v.vod_id);
                return !duplicate;
            });
        } else {
            // 分类页处理 (源自 [2])
            const bookList = pageProps.bookList || [];
            bookList.forEach(book => {
                if (book.bookId) {
                    videos.push({
                        vod_id: `/drama/${book.bookId}`,
                        vod_name: book.bookName,
                        vod_pic: book.coverWap,
                        vod_remarks: `${book.statusDesc || ''} ${book.totalChapterNum || ''}集`.trim()
                    });
                }
            });
        }

        return {
            list: videos,
            page: parseInt(page),
            pagecount: pageProps.pages || 1,
            limit: 20,
            total: 999
        };
    } catch (error) {
        console.error("Category Error:", error);
        return { list: [], page: 1, pagecount: 1 };
    }
};

// 获取搜索内容 (逻辑源自 [2] searchContentPage)
const searchContent = async (key, page = 1) => {
    try {
        const url = `${hemaConfig.siteUrl}/search?searchValue=${encodeURIComponent(key)}&page=${page}`;
        const response = await axios.get(url, { headers: hemaConfig.headers });
        const json = parseNextData(response.data);
        if (!json) return { list: [], page: 1, pagecount: 1 };

        const pageProps = json.props?.pageProps || {};
        const bookList = pageProps.bookList || [];
        let list = [];

        bookList.forEach(book => {
            if (book.bookId) {
                list.push({
                    vod_id: `/drama/${book.bookId}`,
                    vod_name: book.bookName,
                    vod_pic: book.coverWap,
                    vod_remarks: `${book.statusDesc || ''} ${book.totalChapterNum || ''}集`.trim()
                });
            }
        });

        return {
            list: list,
            page: parseInt(page),
            pagecount: pageProps.pages || 1,
            limit: 20,
            total: 999
        };
    } catch (error) {
        console.error("Search Error:", error);
        return { list: [], page: 1, pagecount: 1 };
    }
};

// 获取详情和章节 (逻辑源自 [2] detailContent)
const getDetail = async (id) => {
    try {
        if (!id.startsWith('/drama/')) {
            id = `/drama/${id}`;
        }
        const url = `${hemaConfig.siteUrl}${id}`;
        const response = await axios.get(url, { headers: hemaConfig.headers });
        const json = parseNextData(response.data);
        
        if (!json) return null;

        const pageProps = json.props?.pageProps || {};
        const bookInfo = pageProps.bookInfoVo || {};
        const chapterList = pageProps.chapterList || [];

        if (!bookInfo.bookId) return null;

        // 格式化播放列表: 标题$id
        // 逻辑源自 [2]: 如果有直链直接用，否则构造参数
        let playList = [];
        chapterList.forEach(chapter => {
            const chapterId = chapter.chapterId;
            const chapterName = chapter.chapterName;
            
            // 尝试获取直链 (源自 [2] getDirectVideoUrl)
            let videoUrl = null;
            if (chapter.chapterVideoVo) {
                const v = chapter.chapterVideoVo;
                if (v.mp4) videoUrl = v.mp4;
                else if (v.mp4720p) videoUrl = v.mp4720p;
                else if (v.vodMp4Url) videoUrl = v.vodMp4Url;
            }

            if (videoUrl && videoUrl.includes('.mp4')) {
                playList.push(`${chapterName}$${videoUrl}`);
            } else {
                // 构造中间格式：dramaId+chapterId，供 getPlayUrl 解析
                // 对应 Python 代码中的 fallback 逻辑
                const dramaId = id.replace('/drama/', '');
                playList.push(`${chapterName}$${dramaId}+${chapterId}`);
            }
        });

        return {
            vod_id: id,
            vod_name: bookInfo.title || bookInfo.bookName,
            type_name: (bookInfo.categoryList || []).map(c => c.name).join(','),
            vod_pic: bookInfo.coverWap,
            vod_area: bookInfo.countryName,
            vod_remarks: `${bookInfo.statusDesc || ''} ${bookInfo.totalChapterNum || ''}集`.trim(),
            vod_actor: (bookInfo.performerList || []).map(p => p.name).join(', '),
            vod_content: bookInfo.introduction,
            vod_play_from: '河马剧场',
            vod_play_url: playList.join('#')
        };
    } catch (error) {
        console.error("Detail Error:", error);
        return null;
    }
};

// 获取播放链接 (逻辑源自 [2] playerContent / getEpisodeVideoUrl)
const getPlayUrl = async (id) => {
    try {
        // 如果已经是直链 (mp4/m3u8)
        if (id.includes('.mp4') || id.includes('.m3u8')) {
            return {
                parse: 0,
                url: id,
                header: hemaConfig.headers
            };
        }

        // 解析参数: dramaId+chapterId
        const parts = id.split('+');
        if (parts.length < 2) return { parse: 0, url: "" };
        
        const dramaId = parts[0];
        const chapterId = parts[1];

        const url = `${hemaConfig.siteUrl}/episode/${dramaId}/${chapterId}`;
        const response = await axios.get(url, { headers: hemaConfig.headers });
        
        // 尝试方法1: 从 JSON 提取 (源自 [2])
        const json = parseNextData(response.data);
        if (json) {
            const videoInfo = json.props?.pageProps?.chapterInfo?.chapterVideoVo || {};
            let videoUrl = videoInfo.mp4 || videoInfo.mp4720p || videoInfo.vodMp4Url;
            if (videoUrl) {
                return {
                    parse: 0,
                    url: videoUrl,
                    header: hemaConfig.headers
                };
            }
        }

        // 尝试方法2: 正则直接提取 HTML (源自 [2])
        const html = response.data;
        const mp4Matches = html.match(/(https?:\/\/[^"']+\.mp4)/);
        if (mp4Matches && mp4Matches[1]) {
            return {
                parse: 0,
                url: mp4Matches[1],
                header: hemaConfig.headers
            };
        }

        return { parse: 0, url: "" };

    } catch (error) {
        console.error("Play Error:", error);
        return { parse: 0, url: "" };
    }
};

// 请求分发处理 (参考 [1] handleT4Request)
const handleT4Request = async (req) => {
    const { ac, t, pg, wd, ids, play } = req.query;

    if (play) {
        return await getPlayUrl(play);
    }

    if (ids) {
        const detail = await getDetail(ids);
        return {
            list: detail ? [detail] : [],
            page: 1,
            pagecount: 1,
            total: detail ? 1 : 0
        };
    }

    if (wd) {
        return await searchContent(wd, pg || 1);
    }

    // 分类页
    if (t) {
        return await getCategoryList(t, pg || 1);
    }

    // 首页 (ac为空或ac=class时)
    const classes = getClasses();
    // 首页不需要传tid，传入null
    const homeResult = await getCategoryList(null, 1);
    
    return {
        class: classes,
        list: homeResult.list,
        page: 1,
        pagecount: homeResult.pagecount,
        limit: homeResult.limit,
        total: homeResult.total
    };
};

const meta = {
    key: "hema",
    name: "[短]河马短剧",
    type: 4,
    api: "/video/hema",
    searchable: 1,
    quickSearch: 0,
    filterable: 0 
};

module.exports = async (app, opt) => {
    app.get(meta.api, async (req, reply) => {
        try {
            return await handleT4Request(req);
        } catch (error) {
            console.error(error);
            return { error: 'Internal Server Error' };
        }
    });
    opt.sites.push(meta);
};