"use strict";

const axios = require("axios");
const crypto = require("node:crypto");

const LOGIN_URL = "https://u.shytkjgs.com/user/v3/account/login";
const API_BASE = "https://app.whjzjx.cn";
const AES_KEY = "B@ecf920Od8A4df7";
let auth = "";

const meta = {
  key: "duanjuxingya",
  name: "[短]星芽短剧",
  type: 4,
  api: "/video/duanjuxingya",
  searchable: 1,
  quickSearch: 1,
  filterable: 1,
  changeable: 0,
};

function headers(json = false) {
  const h = { "User-Agent": "okhttp/4.10.0", platform: "1", version_name: "3.9.2" };
  if (auth) h.Authorization = auth;
  if (json) h["Content-Type"] = "application/json; charset=utf-8";
  return h;
}

function decodeExt(ext) {
  if (!ext) return {};
  try { return JSON.parse(Buffer.from(String(ext), "base64").toString("utf8")) || {}; }
  catch { return {}; }
}

function pageNo(v) {
  const n = Number.parseInt(v, 10);
  return Number.isFinite(n) && n > 0 ? n : 1;
}

function encryptLogin(data) {
  const cipher = crypto.createCipheriv("aes-128-ecb", Buffer.from(AES_KEY, "utf8"), null);
  return Buffer.concat([cipher.update(JSON.stringify(data), "utf8"), cipher.final()]).toString("base64");
}

async function login() {
  const now = Date.now();
  const body = encryptLogin({
    device: crypto.createHash("md5").update(String(now), "utf8").digest("hex"),
    package_name: "com.jz.xydj",
    install_first_open: true,
    first_install_time: now,
    last_update_time: now,
    timestamp: now,
  });
  const res = await axios.post(LOGIN_URL, body, {
    headers: headers(true), timeout: 15000, responseType: "json", transformRequest: [(v) => v],
  });
  auth = res.data && res.data.data && res.data.data.token || "";
  if (!auth) throw new Error("星芽登录失败");
}

async function ensureAuth() {
  if (!auth) await login();
}

async function get(url, retry = true) {
  await ensureAuth();
  try {
    const res = await axios.get(url, { headers: headers(), timeout: 15000, responseType: "json" });
    return res.data || {};
  } catch (e) {
    if (retry && e.response && e.response.status === 401) { auth = ""; return get(url, false); }
    throw e;
  }
}

async function post(url, data, retry = true) {
  await ensureAuth();
  try {
    const res = await axios.post(url, JSON.stringify(data), {
      headers: headers(true), timeout: 15000, responseType: "json", transformRequest: [(v) => v],
    });
    return res.data || {};
  } catch (e) {
    if (retry && e.response && e.response.status === 401) { auth = ""; return post(url, data, false); }
    throw e;
  }
}

function card(v) {
  return { vod_id: String(v.id || ""), vod_name: String(v.title || ""), vod_pic: String(v.cover_url || ""), vod_remarks: v.total ? `${v.total}集` : String(v.score_str || "") };
}

async function home() {
  const data = await get(`${API_BASE}/cloud/v2/theater/classes`);
  const rows = data.data && data.data.list || [];
  const classes = rows.filter((v) => !String(v.show_type || "").includes("Bookstore")).map((v) => ({ type_id: String(v.id), type_name: String(v.class_name || "") })).filter((v) => v.type_id && v.type_name);
  const filters = {};
  for (const row of rows) {
    const id = String(row.id || "");
    if (Array.isArray(row.alg_class)) filters[id] = [{ key: "class", name: String(row.class_name || "分类"), value: row.alg_class.map((v) => ({ n: String(v.class_name || ""), v: String(v.id || "") })) }];
    if (Array.isArray(row.first_level_ranking)) filters[id] = [{ key: "rank", name: String(row.class_name || "排行"), value: row.first_level_ranking.map((v) => ({ n: String(v.name || ""), v: String(v.id || "") })) }];
  }
  return { class: classes, filters };
}

async function category(id, pg, ext) {
  const page = pageNo(pg);
  let rows = [];
  if (String(id) === "9") {
    if (page > 1) return { page, pagecount: page, limit: 0, total: 0, list: [] };
    const data = await get(`${API_BASE}/cloud/v1/first_level_ranking/detail?id=${encodeURIComponent(ext.rank || "1")}`);
    rows = data.data && data.data.list || [];
  } else {
    const url = `${API_BASE}/cloud/v2/theater/home_page?theater_class_id=${encodeURIComponent(id)}&class2_ids=${encodeURIComponent(ext.class || "0")}&type=1&page_num=${page}&page_size=24`;
    const data = await get(url);
    rows = (data.data && data.data.list || []).map((v) => v && v.theater).filter(Boolean);
  }
  const list = rows.map(card).filter((v) => v.vod_id && v.vod_name);
  return { page, pagecount: list.length >= 24 ? page + 1 : page, limit: 24, total: 0, list };
}

async function detail(id) {
  const data = await get(`${API_BASE}/v2/theater_parent/detail?theater_parent_id=${encodeURIComponent(id)}`);
  const v = data.data || {};
  const urls = (v.theaters || []).filter((e) => e.son_video_url).map((e) => `${e.num}$${e.son_video_url}`);
  return { list: [{ vod_id: id, vod_name: String(v.title || ""), vod_pic: String(v.cover_url || ""), type_name: Array.isArray(v.desc_tags) ? v.desc_tags.join(",") : "", vod_content: String(v.introduction || ""), vod_play_from: "星芽", vod_play_url: urls.join("#") }] };
}

async function search(wd) {
  const data = await post(`${API_BASE}/v3/search`, { text: String(wd || "").trim() });
  const rows = data.data && data.data.theater && data.data.theater.search_data || [];
  return { list: rows.map(card).filter((v) => v.vod_id && v.vod_name) };
}

module.exports = async (app, opt) => {
  app.get(meta.api, async (req) => {
    const q = req.query || {};
    try {
      if (q.play) return { parse: 0, url: String(q.play), extra: { nodanmu: true } };
      if (q.wd) return await search(q.wd);
      if (q.ids) return await detail(String(q.ids));
      if (q.t) return await category(String(q.t), q.pg, decodeExt(q.ext));
      return await home();
    } catch (e) {
      app.log && app.log.error && app.log.error(`[星芽短剧] ${e.message || e}`);
      return { list: [] };
    }
  });
  opt.sites.push(meta);
};
