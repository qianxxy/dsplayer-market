/**
 * 美剧天堂 - Fastify T4 JS 源
 * ============================================================================
 * 站点：https://www.meijutt.cc  （美剧天堂，UTF-8）
 *
 * 功能：
 *  - 首页分类：魔幻科幻 / 灵异惊悚 / 都市情感 / 犯罪历史 / 选秀综艺 / 动漫卡通
 *  - 分类列表：/mjtt/{tid}.html 与 /mjtt/{tid}-{pg}.html 翻页
 *  - 详情：info-title 标题、海报、主演/地区/状态/电视台、简介
 *         在线播放线路（tabs）+ 网盘/磁力下载（GvodUrls 变量）
 *  - 播放：解析播放页 var now / m3u8 直链 / iframe dm.html 兜底
 *
 * 学习自 66影视.js 风格（纯函数 + cheerio + Fastify T4 注册）。
 * ============================================================================
 */

const axios = require("axios");
const http = require("http");
const https = require("https");
const cheerio = require("cheerio");

// ==================== HTTP 客户端 ====================
const _http = axios.create({
  timeout: 15 * 1000,
  httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
  httpAgent: new http.Agent({ keepAlive: true }),
  responseType: "arraybuffer",
  maxRedirects: 5,
});

// ==================== 站点配置 ====================
const SITE_CONFIG = {
  title: "美剧天堂[纯]",
  host: "https://www.meijutt.cc",
  debug: true,
  searchable: 0,
  quickSearch: 0,
  filterable: 0,
  headers: {
    "User-Agent":
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36",
    Referer: "https://www.meijutt.cc/",
    "Accept-Language": "zh-CN,zh;q=0.9",
  },
  PAGE_LIMIT: 20,
};

const CLASSES = [
  { type_id: "1", type_name: "魔幻科幻" },
  { type_id: "2", type_name: "灵异惊悚" },
  { type_id: "3", type_name: "都市情感" },
  { type_id: "4", type_name: "犯罪历史" },
  { type_id: "5", type_name: "选秀综艺" },
  { type_id: "6", type_name: "动漫卡通" },
];

const DRIVE_ORDER = ["baidu", "tianyi", "quark", "uc", "115", "xunlei", "ali", "123pan"];

// ==================== 日志 ====================
let log = () => {};

// ==================== 工具函数 ====================
const textOf = (res) => Buffer.from(res.data || Buffer.alloc(0)).toString("utf-8");

const safeStr = (v) => (v === undefined || v === null ? "" : String(v).trim());

const clean = (v) => safeStr(v).replace(/\s+/g, " ").trim();

const extractText = (htmlStr) => {
  const text = String(htmlStr || "").replace(/<[^>]+>/g, "").trim();
  try {
    return decodeURIComponent(text.replace(/&#x([0-9a-fA-F]+);/g, (_, h) => "%" + h));
  } catch (_) {
    return text;
  }
};

const fullUrl = (href) => {
  const h = safeStr(href);
  if (!h) return "";
  if (/^https?:\/\//i.test(h)) return h;
  if (h.startsWith("//")) return "https:" + h;
  if (h.startsWith("/")) return SITE_CONFIG.host + h;
  return SITE_CONFIG.host + "/" + h;
};

const normalizeShareUrl = (url) => {
  const value = safeStr(url).replace(/[.,;\]>)}]+$/g, "");
  if (!value) return "";
  try {
    const parsed = new URL(value);
    if (parsed.hostname.includes("pan.baidu.com")) {
      const matched = parsed.pathname.match(/\/s\/([^/?#]+)/);
      const pwd = parsed.searchParams.get("pwd") || parsed.searchParams.get("password") || parsed.searchParams.get("passwd") || "";
      if (matched) return pwd ? `https://pan.baidu.com/s/${matched[1]}?pwd=${pwd}` : `https://pan.baidu.com/s/${matched[1]}`;
    }
    return value;
  } catch (_) {
    return value;
  }
};

const inferDriveType = (value) => {
  const raw = safeStr(value).toLowerCase();
  const original = safeStr(value);
  if (!raw) return "";
  if (original.includes("百度") || raw.includes("pan.baidu.com") || raw === "baidu" || raw === "baiduyun") return "baidu";
  if (original.includes("天翼") || raw.includes("cloud.189.cn") || raw === "tianyi") return "tianyi";
  if (original.includes("夸克") || raw.includes("pan.quark.cn") || raw === "quark") return "quark";
  if (raw === "uc" || raw.includes("drive.uc.cn")) return "uc";
  if (raw.includes("115")) return "115";
  if (original.includes("迅雷") || raw.includes("xunlei")) return "xunlei";
  if (original.includes("阿里") || raw.includes("aliyundrive") || raw.includes("alipan") || raw === "ali" || raw === "aliyun") return "ali";
  if (raw.includes("123")) return "123pan";
  return raw;
};

const driveDisplayName = (type) => {
  const mapping = {
    baidu: "百度网盘",
    tianyi: "天翼网盘",
    quark: "夸克网盘",
    uc: "UC网盘",
    "115": "115网盘",
    xunlei: "迅雷网盘",
    ali: "阿里网盘",
    "123pan": "123网盘",
  };
  return mapping[type] || "网盘";
};

const inferDriveLabel = (url, drive) => {
  const inferred = inferDriveType(url || drive?.key || "");
  if (inferred) return driveDisplayName(inferred);
  if (safeStr(url).startsWith("magnet:")) return "磁力";
  if (safeStr(url).startsWith("ed2k://")) return "ed2k";
  return "资源";
};

const sortSourceGroups = (items) => {
  const order = Object.fromEntries(DRIVE_ORDER.map((name, index) => [name, index]));
  return [...(items || [])].sort((a, b) => {
    const aType = inferDriveType(a?.driveType || a?.name || "");
    const bType = inferDriveType(b?.driveType || b?.name || "");
    return (order[aType] ?? 999) - (order[bType] ?? 999);
  });
};

const parseDriveShare = async (shareUrl, drives) => {
  const drive = (drives || []).find((item) => item.matchShare && item.matchShare(shareUrl));
  if (!drive) return null;
  try {
    const vod = await drive.getVod(shareUrl);
    const playUrl = safeStr(vod?.vod_play_url);
    if (!playUrl) return { drive, vod: null };
    return { drive, vod };
  } catch (e) {
    log("⚠️", "网盘驱动解析失败", shareUrl, e.message);
    return { drive, vod: null };
  }
};

const pageNumber = (v) => {
  const n = parseInt(String(v || "1"), 10);
  return Number.isFinite(n) && n > 0 ? n : 1;
};

// GET 一个页面，返回 UTF-8 文本
const getHtml = async (url, extraHeaders = {}) => {
  const full = fullUrl(url);
  const res = await _http.get(full, {
    headers: { ...SITE_CONFIG.headers, ...extraHeaders },
    validateStatus: () => true,
  });
  if (res.status < 200 || res.status >= 400) throw new Error(`HTTP ${res.status}`);
  return textOf(res);
};

const emptyPage = (page, msg = "") => ({
  list: [],
  page,
  pagecount: 1,
  limit: SITE_CONFIG.PAGE_LIMIT,
  total: 0,
  ...(msg ? { msg } : {}),
});

// ==================== 首页 ====================
const _home = async (filter) => {
  log("🏠", "首页");
  return { class: CLASSES, filters: {} };
};

const _homeVideo = async () => {
  log("🏠", "首页推荐");
  try {
    const html = await getHtml("/");
    return _parseHomeList(html);
  } catch (e) {
    log("❌", "首页请求失败", e.message);
    return { list: [] };
  }
};

const _parseHomeList = (html) => {
  const videos = [];
  const seen = new Set();
  const re = /<a href="(\/meijutt\/(\d+)\.html)"[^>]*title="([^"]*)"/gi;
  for (const m of html.matchAll(re)) {
    const href = m[1];
    const vid = m[2];
    const title = clean(m[3]);
    if (!title || seen.has(vid)) continue;
    seen.add(vid);

    // 在该 a 标签附近找图片
    let pic = "";
    const afterMatch = html.slice(m.index, m.index + 600);
    const picMatch = afterMatch.match(/<img[^>]*src="(https?:\/\/[^"]*)"/i);
    if (picMatch) pic = picMatch[1];

    videos.push({ vod_id: href, vod_name: title, vod_pic: pic });
    if (videos.length >= 20) break;
  }
  return { list: videos };
};

// ==================== 分类列表 ====================
const _category = async (tid, pg) => {
  const typeId = safeStr(tid) || "1";
  const page = pageNumber(pg);
  // 第1页 /mjtt/{tid}.html；第N页 /mjtt/{tid}-{N}.html
  const url =
    page <= 1
      ? `/mjtt/${typeId}.html`
      : `/mjtt/${typeId}-${page}.html`;
  log("📂", "分类", typeId, "第" + page + "页", url);

  let html;
  try {
    html = await getHtml(url);
  } catch (e) {
    log("❌", "分类请求失败", e.message);
    return emptyPage(page);
  }

  return _parseCategoryList(html, page);
};

const _parseCategoryList = (html, pg) => {
  const videos = [];
  // <div class="bor_img3_right"><a href="/meijutt/xxx.html" title="xxx"><img data-original="xxx">...</a><em>评分</em>
  const re =
    /<div class="bor_img3_right">\s*<a href="(\/meijutt\/\d+\.html)"[^>]*title="([^"]*)"[^>]*>\s*<img[^>]*data-original="([^"]*)"[^>]*>[\s\S]*?<\/a>\s*<em>([\d.]+)<\/em>/gi;
  for (const m of html.matchAll(re)) {
    videos.push({
      vod_id: m[1],
      vod_name: clean(m[2]),
      vod_pic: fullUrl(m[3]),
      vod_remarks: `评分 ${m[4]}`,
    });
  }

  // 分页总数：末页链接 或 共N页
  let pagecount = pg;
  let pm = html.match(/href="[^"]*-(\d+)\.html"[^>]*>\s*末页/);
  if (!pm) pm = html.match(/href="[^"]*-(\d+)\.html"[^>]*>\s*>/);
  if (!pm) pm = html.match(/共(\d+)页/);
  if (pm) pagecount = parseInt(pm[1], 10) || pg;

  log("📂", `分类解析 ${videos.length} 条，共 ${pagecount} 页`);
  return {
    list: videos,
    page: pg,
    pagecount,
    limit: SITE_CONFIG.PAGE_LIMIT,
    total: pagecount * SITE_CONFIG.PAGE_LIMIT,
  };
};

// ==================== 详情 ====================
const _detail = async (ids, drives = []) => {
  const vodId = Array.isArray(ids) ? ids[0] : ids;
  const url = fullUrl(vodId);
  log("📄", "详情", url);

  let html;
  try {
    html = await getHtml(url, { Referer: SITE_CONFIG.host });
  } catch (e) {
    log("❌", "详情请求失败", e.message);
    return { list: [] };
  }

  return { list: [await _parseDetail(html, vodId, drives)] };
};

const _parseDetail = async (html, vodId, drives = []) => {
  const vod = { vod_id: vodId };

  // 标题：<div class="info-title"><span>【地区】</span><h1>剧名</h1>(年份)</div>
  const titleRe = /<div class="info-title"><span>(【.*?】)<\/span><h1>([^<]+)<\/h1>\((\d{4})\)<\/div>/i;
  const tm = html.match(titleRe);
  if (tm) {
    vod.vod_name = clean(tm[2]);
    vod.vod_year = tm[3];
    vod.vod_area = clean(tm[1].replace(/[\[\]【】]/g, ""));
  } else {
    const h1m = html.match(/<h1[^>]*>([^<]+)<\/h1>/);
    if (h1m) vod.vod_name = clean(h1m[1]);
  }

  // 海报
  const picMatch = html.match(
    /<img[^>]*(?:data-src|data-original|src)="(https?:\/\/[^"]+\.(?:jpg|jpeg|png|webp))"/i
  );
  if (picMatch) vod.vod_pic = picMatch[1];

  // 信息列表 <li>
  const liItems = [...html.matchAll(/<li>([\s\S]*?)<\/li>/gi)].map((m) => m[1]);
  for (const li of liItems) {
    const text = extractText(li);
    if (text.startsWith("主演：")) {
      const actors = clean(text.replace("主演：", "").replace("更多>>", ""));
      if (actors && actors !== "内详") vod.vod_actor = actors;
    } else if (text.startsWith("小分类：")) {
      vod.vod_type = clean(text.replace("小分类：", ""));
    } else if (text.startsWith("地区：")) {
      const areaText = clean(text.replace("地区：", ""));
      const areaMatch = areaText.match(/([^\s更新]+)/);
      if (areaMatch) vod.vod_area = areaMatch[1];
    } else if (text.startsWith("状态：")) {
      vod.vod_remarks = clean(text.replace("状态：", ""));
    } else if (text.includes("电视台：")) {
      const channel = clean(text.split("电视台：")[1].split("单集")[0]);
      if (channel) {
        const prev = vod.vod_remarks || "";
        vod.vod_remarks = prev ? `${channel} / ${prev}` : channel;
      }
    }
  }

  // 简介 <p>
  const descParts = [...html.matchAll(/<p[^>]*>([\s\S]*?)<\/p>/gi)].map((m) => m[1]);
  for (const part of descParts) {
    const text = extractText(part);
    if (text.length > 30 && !text.includes("下载") && !text.includes("magnet") && !text.includes("gurl")) {
      vod.vod_content = text;
      break;
    }
  }

  // ==================== 播放源解析 ====================
  const streamingSources = {}; // 在线线路：{ 源名: [ "集名$链接", ... ] }
  const driveSourceGroups = []; // 网盘驱动解析后的线路
  const rawDownloadSources = {}; // 磁力/ed2k等无需驱动的下载线路

  // 1) 在线播放线路：tab label + play_{id} 区块
  const tabLabels = [...html.matchAll(/<label[^>]*>\s*([^<]+)\s*<em>\[(\d+)\]<\/em>/gi)].map((m) => clean(m[1]));
  const tabIds = [...html.matchAll(/id="play_(\d+)"/gi)].map((m) => m[1]);
  const tabSplits = html.split(/<div class="tabs-list[^"]*"\s*id="play_\d+"/i);

  for (let i = 0; i < tabIds.length; i++) {
    const tabName = i < tabLabels.length ? tabLabels[i] : `线路${i + 1}`;
    let section = i + 1 < tabSplits.length ? tabSplits[i + 1] : "";
    // 截断到下一个 tabs-list 或 o_list_cn
    const end = section.match(/<div class="tabs-list|<div class="o_list_cn/);
    if (end) section = section.slice(0, end.index);

    const episodes = [...section.matchAll(/href="(\/meijuplay\/[^"]+)"[^>]*>([^<]+)/gi)];
    if (episodes.length) {
      const epList = episodes.map((m) => `${clean(m[2])}$${SITE_CONFIG.host}${m[1]}`);
      streamingSources[tabName] = epList;
    }
  }

  // 2) 下载链接：GvodUrls 变量
  // 网盘分享必须走 server.drives：matchShare -> getVod，不能把分享页原样当播放地址。
  const gvarMatches = [...html.matchAll(/var\s+GvodUrls\d+\s*=\s*"([^"]*)"/gi)].map((m) => m[1]);
  for (const gvar of gvarMatches) {
    const parts = gvar.split("###");
    for (const part of parts) {
      if (!part.includes("$")) continue;
      const idx = part.indexOf("$");
      const name = clean(part.slice(0, idx)) || "下载链接";
      const linkUrl = normalizeShareUrl(part.slice(idx + 1));
      if (!linkUrl) continue;

      let src;
      if (linkUrl.includes("pan.quark.cn")) src = "夸克网盘";
      else if (linkUrl.includes("pan.xunlei.com")) src = "迅雷网盘";
      else if (linkUrl.includes("pan.baidu.com")) src = "百度网盘";
      else if (linkUrl.startsWith("ed2k://")) src = "ed2k";
      else if (linkUrl.startsWith("magnet:")) src = "磁力";
      else src = "其他";

      if (/^(magnet:|ed2k:\/\/)/i.test(linkUrl)) {
        if (!rawDownloadSources[src]) rawDownloadSources[src] = [];
        const ep = `${name}$${linkUrl}`;
        if (!rawDownloadSources[src].includes(ep)) rawDownloadSources[src].push(ep);
        continue;
      }

      const parsed = await parseDriveShare(linkUrl, drives);
      const drive = parsed?.drive || null;
      if (!drive) {
        log("⚠️", "跳过未识别网盘分享", src, linkUrl);
        continue;
      }
      if (!parsed?.vod?.vod_play_url) {
        log("⚠️", "跳过无法解析为可播集数的网盘分享", src, linkUrl);
        continue;
      }

      const driveType = inferDriveType(drive?.key || linkUrl || src);
      const sourceName = safeStr(parsed.vod.vod_play_from) || inferDriveLabel(linkUrl, drive) || src;
      driveSourceGroups.push({
        name: sourceName,
        driveType,
        rawPlayFrom: sourceName,
        rawPlayUrl: safeStr(parsed.vod.vod_play_url),
      });
    }
  }

  const playFrom = [];
  const playUrl = [];

  // 在线播放源保留在前面。
  for (const srcName of Object.keys(streamingSources)) {
    playFrom.push(srcName);
    playUrl.push(streamingSources[srcName].join("#"));
  }

  // 网盘源按人人电影的驱动优先级排序后合并。
  for (const item of sortSourceGroups(driveSourceGroups)) {
    if (!item.rawPlayUrl) continue;
    playFrom.push(item.rawPlayFrom || item.name || "网盘");
    playUrl.push(item.rawPlayUrl);
  }

  // 磁力/ed2k 原样交给客户端。
  const rawOrder = ["ed2k", "磁力", "其他"];
  for (const srcName of rawOrder) {
    if (!rawDownloadSources[srcName] || !rawDownloadSources[srcName].length) continue;
    playFrom.push(srcName);
    playUrl.push(rawDownloadSources[srcName].join("#"));
  }

  vod.vod_play_from = playFrom.length ? playFrom.join("$$$") : "美剧天堂";
  vod.vod_play_url = playUrl.length ? playUrl.join("$$$") : "";

  if (playFrom.length) {
    log("📥", "线路: " + playFrom.join(", "));
  }

  return vod;
};

// ==================== 播放 ====================
const _play = async (flag, id, drives = []) => {
  log("▶️", "播放", flag, id);
  const playUrl = safeStr(id);

  // 网盘驱动返回的 vod_play_url 通常需要按 flag 找回对应 drive.play。
  const flagDrive = (drives || []).find((item) => item.key && new RegExp(`^${item.key}`, "i").test(safeStr(flag)));
  if (flagDrive) {
    try {
      return await flagDrive.play(playUrl, flag || flagDrive.key);
    } catch (e) {
      log("⚠️", "网盘驱动播放失败", flagDrive.key, e.message);
    }
  }

  // 如果点到的是原始网盘分享链接，也尝试直接交给可匹配的驱动。
  const directDrive = (drives || []).find((item) => item.matchShare && item.matchShare(playUrl));
  if (directDrive) {
    try {
      return await directDrive.play(playUrl, flag || directDrive.key);
    } catch (e) {
      log("⚠️", "网盘分享直播失败", directDrive.key, e.message);
    }
  }

  if (playUrl.includes("/meijuplay/")) {
    const m3u8 = await _getM3u8(playUrl);
    if (m3u8) {
      return {
        parse: 0,
        url: m3u8,
        header: {
          "User-Agent": SITE_CONFIG.headers["User-Agent"],
          Referer: SITE_CONFIG.host + "/",
        },
      };
    }
  }

  // 兜底：原样返回（网盘/磁力交给客户端）
  return { parse: 0, url: playUrl, header: {} };
};

const _getM3u8 = async (playUrl) => {
  try {
    const html = await getHtml(playUrl, { Referer: SITE_CONFIG.host });

    // var now = "..." 或 var now = unescape("...")
    let m = html.match(/var\s+now\s*=\s*(?:unescape\()?\s*["']([^"']+)/i);
    if (m) {
      let url = m[1];
      if (url.includes("%")) {
        try {
          url = decodeURIComponent(url);
        } catch (_) {
          // 保留原始
        }
      }
      if (url.includes(".m3u8")) return url;
    }

    // 直接匹配 m3u8
    const m2 = html.match(/(https?:\/\/[^\s"'<>]+\.m3u8[^\s"'<>]*)/i);
    if (m2) return m2[1];

    // iframe dm.html 兜底
    const iframe = html.match(/iframe[^>]*src="([^"]*dm\.html[^"]*)"/i);
    if (iframe) {
      const html2 = await getHtml(iframe[1], { Referer: SITE_CONFIG.host });
      const m3 = html2.match(/var\s+now\s*=\s*(?:unescape\()?\s*["']([^"']+)/i);
      if (m3) {
        let url = m3[1];
        if (url.includes("%")) {
          try {
            url = decodeURIComponent(url);
          } catch (_) {
            // 保留原始
          }
        }
        if (url.includes(".m3u8")) return url;
      }
    }
  } catch (e) {
    log("❌", "m3u8解析失败", e.message);
  }
  return null;
};

// ==================== 路由注册（Fastify T4）====================
const meta = {
  key: "meijutt",
  name: SITE_CONFIG.title,
  type: 4,
  api: "/video/meijutt",
  searchable: SITE_CONFIG.searchable,
  quickSearch: SITE_CONFIG.quickSearch,
  changeable: 0,
  filterable: SITE_CONFIG.filterable,
};

module.exports = async (app, opt) => {
  let drives = [];
  if (app && app.drives) drives = app.drives;
  else if (opt && opt.drives) drives = opt.drives;

  const fastifyLog = app?.log?.info?.bind(app?.log);
  log = SITE_CONFIG.debug
    ? (...args) => {
        const msg = args
          .map((a) => (typeof a === "object" ? JSON.stringify(a) : String(a)))
          .join(" ");
        (fastifyLog || console.log)(`[美剧天堂] ${msg}`);
      }
    : () => {};

  app.get(meta.api, async (req, reply) => {
    const { filter, t, ac, pg, ids, flag, play, wd, quick } = req.query;
    const reqDrives = req.server?.drives || drives;
    try {
      if (play) return await _play(flag || "", play, reqDrives);
      if (wd) return { list: [], page: 1, pagecount: 1, limit: 0, total: 0 };
      // 分类请求：t 参数优先（兼容 ac=detail 和无 ac 两种调用方式）
      if (t) return await _category(t, parseInt(pg || "1", 10));
      // 详情请求
      if (ids)
        return await _detail(ids.split(",").map((s) => s.trim()).filter(Boolean), reqDrives);
      // 首页：返回分类 + 推荐列表
      const home = await _home(filter ?? false);
      const homeVideo = await _homeVideo();
      return { ...home, ...homeVideo };
    } catch (e) {
      log("❌", "API错误", e.message);
      return { error: e.message };
    }
  });

  if (opt && Array.isArray(opt.sites)) opt.sites.push(meta);
  log("🚀", meta.name, "加载完成");
};
