/**
 * 🎬 66影视(6v520) - 磁力下载站 T4 源（不夜版）
 * ============================================================================
 * 站点：https://www.6v520.cc/  （迅雷电影下载 / 66影视，帝国CMS，GBK编码）
 *
 * 功能：
 *  - 首页分类：电影 / 经典高清 / 动漫新番 / 动画电影 / 综艺 / 真人秀
 *  - 分类列表：/{分类}/ 与 /{分类}/index_N.html 翻页（纯文字列表，无封面）
 *  - 详情：解析 <h1> 标题、66tutup 海报、◎ 简介、magnet 磁力下载
 *  - 搜索：POST /e/search/index.php（关键词需 GBK 编码）
 *  - 播放：把 magnet 交给网盘/磁力驱动解析（115/夸克/迅雷离线等）
 *
 * 学习自 routes/影视/ 风格 B（纯函数 + cheerio）+ Fastify 注册（参考滴答影视）。
 * 站点特征：GBK 编码，所有抓取后必须 iconv 转 UTF-8；搜索词需转 GBK URL 编码。
 * ============================================================================
 */

const axios = require("axios");
const http = require("http");
const https = require("https");
const cheerio = require("cheerio");
const iconv = require("iconv-lite");

// ==================== HTTP 客户端 ====================
const _http = axios.create({
  timeout: 20 * 1000,
  httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
  httpAgent: new http.Agent({ keepAlive: true }),
  // 站点是 GBK，统一拿原始字节再手动解码
  responseType: "arraybuffer",
  maxRedirects: 5,
});

// ==================== 站点配置 ====================
const SITE_CONFIG = {
  title: "[纯]66影视",
  host: "https://www.6v520.cc",
  debug: true,
  searchable: 1,
  quickSearch: 0,
  filterable: 0, // 站点无标准筛选接口，关闭
  headers: {
    "User-Agent":
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
    Referer: "https://www.6v520.cc/",
    "Accept-Language": "zh-CN,zh;q=0.9",
  },
  PAGE_LIMIT: 25,
};

// 分类：type_id 用栏目目录名（与 URL 直接对应）
const CLASSES = [
  { type_id: "dy", type_name: "最新电影" },
  { type_id: "gq", type_name: "经典高清" },
  { type_id: "zydy", type_name: "动漫新番" },
  { type_id: "jddy", type_name: "动画电影" },
  { type_id: "zy", type_name: "综艺节目" },
  { type_id: "shoujidianyingmp4", type_name: "真人秀" },
];

// ==================== 日志 ====================
let log = () => {};

// ==================== 工具函数 ====================
const decodeGbk = (buf) => {
  try {
    return iconv.decode(Buffer.from(buf), "gb2312");
  } catch (e) {
    return Buffer.from(buf).toString("utf-8");
  }
};

// 把中文关键词转成 GBK 的 URL 编码（%XX%XX），帝国CMS 搜索必需
const gbkUrlEncode = (str) => {
  const buf = iconv.encode(String(str || ""), "gb2312");
  let out = "";
  for (const b of buf) {
    if (
      (b >= 0x30 && b <= 0x39) || // 0-9
      (b >= 0x41 && b <= 0x5a) || // A-Z
      (b >= 0x61 && b <= 0x7a) // a-z
    ) {
      out += String.fromCharCode(b);
    } else {
      out += "%" + b.toString(16).toUpperCase().padStart(2, "0");
    }
  }
  return out;
};

const safeStr = (v) => (v === undefined || v === null ? "" : String(v).trim());

const fullUrl = (href) => {
  const h = safeStr(href);
  if (!h) return "";
  if (/^https?:\/\//i.test(h)) return h;
  if (h.startsWith("//")) return "https:" + h;
  if (h.startsWith("/")) return SITE_CONFIG.host + h;
  return SITE_CONFIG.host + "/" + h;
};

// 从标题里粗略提取年份/类型做 remarks
const guessRemarks = (title) => {
  const t = safeStr(title);
  const m = t.match(/(4K|2160p|1080p|720p|BD|HD|国语|中字|双字|全集|第[\d一二三四五六七八九十]+季)/gi);
  return m ? [...new Set(m)].slice(0, 3).join(" ") : "";
};

// GET 一个页面，返回 UTF-8 文本
const getHtml = async (url, extraHeaders = {}) => {
  const res = await _http.get(url, {
    headers: { ...SITE_CONFIG.headers, ...extraHeaders },
  });
  return decodeGbk(res.data);
};

// ==================== 封面抓取（列表页无图，进详情页取 66tutup 封面）====================
// 内存缓存：vod_id -> 封面url（同一详情页翻页/复用不重复抓）
const PIC_CACHE = new Map();
const PIC_CACHE_MAX = 800;

// 从详情页 HTML 里提取第一张有效封面图
const extractPicFromHtml = (html) => {
  const $ = cheerio.load(html);
  let pic = "";
  $("img[src]").each((_, img) => {
    if (pic) return;
    const src = $(img).attr("src") || "";
    if (/66tutup|upload|\.(jpg|jpeg|png|webp)/i.test(src)) pic = fullUrl(src);
  });
  return pic;
};

// 抓单个详情页封面（带缓存 + 静默失败）
const fetchOnePic = async (vodId) => {
  if (PIC_CACHE.has(vodId)) return PIC_CACHE.get(vodId);
  let pic = "";
  try {
    const html = await getHtml(fullUrl(vodId), { Referer: SITE_CONFIG.host });
    pic = extractPicFromHtml(html);
  } catch (e) {
    pic = "";
  }
  if (PIC_CACHE.size >= PIC_CACHE_MAX) PIC_CACHE.delete(PIC_CACHE.keys().next().value);
  PIC_CACHE.set(vodId, pic);
  return pic;
};

// 并发给列表项补封面（限制并发数，避免拖慢/被封）
const fillCovers = async (list, concurrency = 8) => {
  const queue = list.filter((it) => it && it.vod_id && !it.vod_pic);
  let idx = 0;
  const worker = async () => {
    while (idx < queue.length) {
      const item = queue[idx++];
      const pic = await fetchOnePic(item.vod_id);
      if (pic) item.vod_pic = pic;
    }
  };
  const workers = [];
  for (let i = 0; i < Math.min(concurrency, queue.length); i++) workers.push(worker());
  await Promise.all(workers);
  return list;
};

// ==================== 首页 ====================
const _home = async (filter) => {
  log("🏠", "首页");
  return { class: CLASSES, filters: {}, list: [] };
};

// ==================== 分类列表 ====================
const _category = async (tid, page) => {
  const typeId = safeStr(tid) || "dy";
  const pg = parseInt(page, 10) || 1;
  // 第1页 /dy/ ；第N页 /dy/index_N.html
  const url =
    pg <= 1
      ? `${SITE_CONFIG.host}/${typeId}/`
      : `${SITE_CONFIG.host}/${typeId}/index_${pg}.html`;
  log("📂", "分类", typeId, "第" + pg + "页", url);

  let html;
  try {
    html = await getHtml(url);
  } catch (e) {
    log("❌", "分类请求失败", e.message);
    return { list: [], page: pg, pagecount: pg, limit: SITE_CONFIG.PAGE_LIMIT, total: 0 };
  }

  const $ = cheerio.load(html);
  const list = [];
  const seen = new Set();

  // 列表条目：<li><span>日期</span><a href="/dy/日期/ID.html">标题</a></li>
  $("li").each((_, li) => {
    const $li = $(li);
    const $a = $li.find("a[href]").first();
    const href = $a.attr("href") || "";
    // 只要详情页链接：/栏目/日期/数字.html
    if (!/^\/[a-z0-9]+\/\d{4}-\d{2}-\d{2}\/\d+\.html$/i.test(href)) return;
    const vod_id = fullUrl(href);
    if (seen.has(vod_id)) return;
    seen.add(vod_id);
    const vod_name = safeStr($a.text());
    if (!vod_name) return;
    const date = safeStr($li.find("span").first().text());
    list.push({
      vod_id,
      vod_name,
      vod_pic: "",
      vod_remarks: guessRemarks(vod_name) || date,
    });
  });

  // 分页总数：尾页 /dy/index_688.html
  let pagecount = pg;
  const tailMatch = html.match(new RegExp(`/${typeId}/index_(\\d+)\\.html['"][^>]*>\\s*尾页`));
  if (tailMatch) pagecount = parseInt(tailMatch[1], 10) || pg;
  else if (/下一页/.test(html)) pagecount = pg + 1;

  log("📂", `分类解析 ${list.length} 条，共 ${pagecount} 页，开始补封面`);
  await fillCovers(list, 8);
  log("📂", `分类完成 ${list.length} 条，已补封面`);
  return { list, page: pg, pagecount, limit: SITE_CONFIG.PAGE_LIMIT, total: pagecount * SITE_CONFIG.PAGE_LIMIT };
};

// ==================== 详情 ====================
const _detail = async (ids) => {
  const vodId = Array.isArray(ids) ? ids[0] : ids;
  const url = fullUrl(vodId);
  log("📄", "详情", url);

  let html;
  try {
    html = await getHtml(url, { Referer: SITE_CONFIG.host });
  } catch (e) {
    log("❌", "详情请求失败", e.message);
    return { list: [] };
  }

  const $ = cheerio.load(html);

  const vod_name =
    safeStr($("h1").first().text()) ||
    safeStr($("title").first().text()).split("-")[0];

  // 海报：优先 66tutup 外链图
  let vod_pic = "";
  $("img[src]").each((_, img) => {
    const src = $(img).attr("src") || "";
    if (/66tutup|upload|\.(jpg|jpeg|png|webp)/i.test(src) && !vod_pic) {
      vod_pic = fullUrl(src);
    }
  });

  // 简介：抓 ◎ 字段块 + ◎简介 正文
  const bodyText = $("body").text();
  const infoLines = [];
  const fieldRe = /◎([^\n◎]{1,40})/g;
  let fm;
  let count = 0;
  while ((fm = fieldRe.exec(bodyText)) !== null && count < 30) {
    const line = safeStr(fm[1]).replace(/\s+/g, " ");
    if (line) infoLines.push("◎" + line);
    count++;
  }
  const vod_content = infoLines.join("\n").slice(0, 1500) || vod_name;

  // 提取字段做展示
  const pick = (label) => {
    const m = bodyText.match(new RegExp("◎\\s*" + label + "[：:　\\s]*([^◎\\n【]{1,60})"));
    return m ? safeStr(m[1]).replace(/\s+/g, " ") : "";
  };
  const vod_year = pick("年\\s*代");
  const vod_area = pick("产\\s*地");
  const vod_type = pick("类\\s*别");
  const vod_actor = pick("主\\s*演");
  const vod_director = pick("导\\s*演");

  // 下载地址：所有 magnet（少量也兼容 ed2k/thunder/ftp），按画质分组成多条线路
  // 画质分组顺序：4K 优先，然后 1080P / 720P / 其他
  const QUALITY_GROUPS = [
    { key: "4K/2160P", re: /(2160p|4k|uhd)/i },
    { key: "1080P", re: /1080p/i },
    { key: "720P", re: /720p/i },
    { key: "其他画质", re: null },
  ];
  const groups = {}; // key -> [ "集标题$链接", ... ]
  let epIndex = {}; // 每组内部计数，用于多集排号
  const seenHash = new Set();

  $("a[href]").each((_, a) => {
    let href = $(a).attr("href") || "";
    if (!/^(magnet:|ed2k:|thunder:|ftp:)/i.test(href)) return;
    href = href.replace(/&amp;/g, "&");
    // magnet 去重（按 btih）
    const hash = (href.match(/btih:([0-9a-z]+)/i) || [])[1];
    if (hash) {
      if (seenHash.has(hash.toLowerCase())) return;
      seenHash.add(hash.toLowerCase());
    }
    // 画质/集标题：优先取所在 <td> 文本（如“磁力：1080p.HD国语中字无水印.mkv”）
    let tdText = safeStr($(a).closest("td").text());
    let label = tdText.replace(/^磁力[：:\s]*/, "").trim();
    if (!label || label.length > 60) label = safeStr($(a).text());
    label = label.replace(/[$#]/g, " ").trim() || "下载";
    // 判画质归组（拿 label + href 一起判）
    const probe = label + " " + href;
    let gk = "其他画质";
    for (const g of QUALITY_GROUPS) {
      if (g.re && g.re.test(probe)) { gk = g.key; break; }
    }
    if (!groups[gk]) { groups[gk] = []; epIndex[gk] = 0; }
    epIndex[gk]++;
    // 同组多条时加序号，避免集名重复导致播放器合并
    const epName = epIndex[gk] > 1 || groups[gk].length
      ? `${label}` // 保留原始画质名
      : label;
    groups[gk].push(`${epName}$${href}`);
  });

  // 按顺序输出有内容的线路
  const fromLines = [];
  const urlLines = [];
  for (const g of QUALITY_GROUPS) {
    const arr = groups[g.key];
    if (arr && arr.length) {
      fromLines.push(g.key);
      urlLines.push(arr.join("#"));
    }
  }

  if (!fromLines.length) {
    log("⚠️", "未找到下载链接");
  } else {
    log("📥", "画质线路: " + fromLines.map((k, i) => `${k}(${groups[k].length})`).join(", "));
  }

  return {
    list: [
      {
        vod_id: vodId,
        vod_name,
        vod_pic,
        vod_year,
        vod_area,
        vod_type,
        vod_actor,
        vod_director,
        vod_content,
        vod_play_from: fromLines.join("$$$") || "磁力下载",
        vod_play_url: urlLines.join("$$$"),
      },
    ],
  };
};

// ==================== 搜索 ====================
const _search = async (page, quick, wd) => {
  const pg = parseInt(page, 10) || 1;
  log("🔍", "搜索", wd, "第" + pg + "页");
  // 帝国CMS 搜索不分页，pg>1 直接返回空
  if (pg > 1) return { list: [], page: pg, pagecount: pg, limit: 0, total: 0 };

  const kw = gbkUrlEncode(wd);
  const body = `keyboard=${kw}&show=title&tempid=1&tbname=article`;

  let html;
  try {
    const res = await _http.post(`${SITE_CONFIG.host}/e/search/index.php`, body, {
      headers: {
        ...SITE_CONFIG.headers,
        "Content-Type": "application/x-www-form-urlencoded",
      },
    });
    html = decodeGbk(res.data);
  } catch (e) {
    log("❌", "搜索请求失败", e.message);
    return { list: [], page: pg, pagecount: 1, limit: 0, total: 0 };
  }

  const $ = cheerio.load(html);
  const list = [];
  const seen = new Set();
  // 6v520 搜索结果条目在 <span> 容器里：<span><a href=详情>标题</a></span>
  // 顶部还有固定导航(公告区/排行榜/帮助)需过滤——它们在 <div> 里，标题无书名号/年份特征
  // 固定导航标题黑名单
  const NAV_BLOCK = /(公告区|排行榜|帮助|教程|新手必看|榜单)/;
  $("span a[href], li a[href]").each((_, a) => {
    const $a = $(a);
    const href = $a.attr("href") || "";
    if (!/^\/[a-z0-9]+\/\d{4}-\d{2}-\d{2}\/\d+\.html$/i.test(href)) return;
    const vod_id = fullUrl(href);
    if (seen.has(vod_id)) return;
    let vod_name = safeStr($a.text());
    if (!vod_name || /^\/?[a-z0-9/.\-]+$/i.test(vod_name)) {
      vod_name = safeStr($a.attr("title")) || vod_name;
    }
    if (!vod_name) return;
    if (NAV_BLOCK.test(vod_name)) return; // 过滤固定导航
    seen.add(vod_id);
    list.push({
      vod_id,
      vod_name,
      vod_pic: "",
      vod_remarks: guessRemarks(vod_name),
    });
  });

  log("🔍", `搜索解析 ${list.length} 条，开始补封面`);
  await fillCovers(list, 8);
  log("🔍", `搜索完成 ${list.length} 条`);
  return { list, page: pg, pagecount: 1, limit: list.length, total: list.length };
};

// ==================== 播放 ====================
// magnet 直接交给客户端/网盘磁力驱动解析（115/迅雷离线等）
const _play = async (flag, id, drives) => {
  log("▶️", "播放", flag, id);
  const playUrl = safeStr(id);

  // 若环境注入了支持磁力的网盘驱动，优先尝试解析成可播放直链
  if (Array.isArray(drives) && drives.length && /^magnet:/i.test(playUrl)) {
    for (const d of drives) {
      try {
        const result = await d.play ? await d.play(playUrl, flag) : null;
        if (result && result.url) {
          log("✅", "驱动解析成功");
          return result;
        }
      } catch (e) {
        /* 继续下一个驱动 */
      }
    }
  }

  // 兜底：把 magnet/直链原样交给客户端
  return { parse: 0, url: playUrl, header: {} };
};

// ==================== 路由注册（Fastify，参考滴答影视）====================
const meta = {
  key: "6v520",
  name: SITE_CONFIG.title,
  type: 4,
  api: "/video/6v520",
  searchable: SITE_CONFIG.searchable,
  quickSearch: SITE_CONFIG.quickSearch,
  changeable: 0,
  filterable: SITE_CONFIG.filterable,
};

module.exports = async (app, opt) => {
  let drives = [];
  if (app && app.drives) drives = app.drives;
  else if (opt && opt.drives) drives = opt.drives;

  const fastifyLog = app?.log?.info?.bind(app?.log);
  log = SITE_CONFIG.debug
    ? (...args) => {
        const msg = args
          .map((a) => (typeof a === "object" ? JSON.stringify(a) : String(a)))
          .join(" ");
        (fastifyLog || console.log)(`[66影视] ${msg}`);
      }
    : () => {};

  app.get(meta.api, async (req, reply) => {
    const { filter, t, ac, pg, ids, flag, play, wd, quick } = req.query;
    const reqDrives = req.server?.drives || drives;
    try {
      if (play) return await _play(flag || "", play, reqDrives);
      if (wd) return await _search(parseInt(pg || "1", 10), quick || false, wd);
      if (!ac) return await _home(filter ?? false);
      if (ac === "detail") {
        if (t) return await _category(t, parseInt(pg || "1", 10));
        if (ids) return await _detail(ids.split(",").map((s) => s.trim()).filter(Boolean));
      }
    } catch (e) {
      log("❌", "API错误", e.message);
      return { error: e.message };
    }
    return req.query;
  });

  if (opt && Array.isArray(opt.sites)) opt.sites.push(meta);
  log("🚀", meta.name, "加载完成");
};
