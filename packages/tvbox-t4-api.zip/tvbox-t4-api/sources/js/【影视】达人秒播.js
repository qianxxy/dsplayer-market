"use strict"; module.exports = require("./appv7-client").createRoute({ key: "appv7zhuijudaren", name: "[影]达人秒播", configKey: "AppV7Zjdr" });
