const axios = require("axios");
const http = require("http");
const https = require("https");
const cheerio = require("cheerio");

const _http = axios.create({
    timeout: 15 * 1000,
    httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
    httpAgent: new http.Agent({ keepAlive: true }),
});

// 两个BT配置
const lianggeBTConfig = {
    host: "https://www.bttwoo.com",
    headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "keep-alive",
        "Referer": "https://www.bttwoo.com/"
    }
};

const PAGE_LIMIT = 20;

// 获取分类数据
const getClasses = async () => {
    return [
        { type_id: "movie_bt_tags/xiju", type_name: "喜剧" },
        { type_id: "movie_bt_tags/aiqing", type_name: "爱情" },
        { type_id: "movie_bt_tags/adt", type_name: "冒险" },
        { type_id: "movie_bt_tags/at", type_name: "动作" },
        { type_id: "movie_bt_tags/donghua", type_name: "动画" },
        { type_id: "movie_bt_tags/qihuan", type_name: "奇幻" },
        { type_id: "movie_bt_tags/xuanni", type_name: "悬疑" },
        { type_id: "movie_bt_tags/kehuan", type_name: "科幻" },
        { type_id: "movie_bt_tags/juqing", type_name: "剧情" },
        { type_id: "movie_bt_tags/kongbu", type_name: "恐怖" },
        { type_id: "meiju", type_name: "美剧" },
        { type_id: "gf", type_name: "高分电影" }
    ];
};

// 获取首页推荐
const getHomeRecommend = async () => {
    try {
        const url = lianggeBTConfig.host + "/";
        const response = await _http.get(url, { headers: lianggeBTConfig.headers });
        const html = response.data;
        
        const list = [];
        const $ = cheerio.load(html);
        
        // 尝试多种选择器获取视频列表
        const selectors = [
            'li:has(a[href*="/movie/"])',
            '.item li:has(a[href*="/movie/"])',
            'li .post'
        ];
        
        let foundElements = [];
        for (const selector of selectors) {
            const elements = $(selector);
            if (elements.length > 0) {
                foundElements = elements;
                break;
            }
        }
        
        const seenIds = new Set();
        
        foundElements.each((i, elem) => {
            const $elem = $(elem);
            
            // 提取链接
            const link = $elem.find('a[href*="/movie/"]').attr('href');
            if (!link) return;
            
            const vodIdMatch = link.match(/\/movie\/(\d+)\.html/);
            if (!vodIdMatch) return;
            
            const vodId = vodIdMatch[1];
            if (seenIds.has(vodId)) return;
            seenIds.add(vodId);
            
            // 提取标题
            let title = '';
            const titleSelectors = [
                'h3 a', 'h3', 'a[title]', '.title', '.name'
            ];
            
            for (const selector of titleSelectors) {
                const titleElem = $elem.find(selector);
                if (titleElem.length > 0) {
                    title = titleElem.text().trim();
                    if (title && title.length > 1) break;
                }
            }
            
            if (!title) return;
            
            // 提取图片
            let pic = '';
            const picSelectors = [
                'img[data-original]', 'img[data-src]', 'img[src]'
            ];
            
            for (const selector of picSelectors) {
                const img = $elem.find(selector);
                if (img.length > 0) {
                    pic = img.attr('data-original') || img.attr('data-src') || img.attr('src');
                    if (pic && !pic.endsWith('blank.gif') && !pic.includes('base64')) {
                        break;
                    }
                }
            }
            
            // 处理图片URL
            if (pic) {
                if (pic.startsWith('//')) {
                    pic = 'https:' + pic;
                } else if (pic.startsWith('/')) {
                    pic = lianggeBTConfig.host + pic;
                }
            }
            
            // 提取备注
            let remarks = '';
            const remarkSelectors = [
                '.rating', '.status', 'span:contains("集")', 
                'span:contains("1080p")', 'span:contains("HD")'
            ];
            
            for (const selector of remarkSelectors) {
                const remarkElem = $elem.find(selector);
                if (remarkElem.length > 0) {
                    remarks = remarkElem.text().trim();
                    if (remarks) break;
                }
            }
            
            list.push({
                vod_id: vodId,
                vod_name: title,
                vod_pic: pic || '',
                vod_remarks: remarks || ''
            });
        });
        
        console.log(`✅ 获取到 ${list.length} 个首页推荐`);
        return list.slice(0, 50); // 限制数量
    } catch (error) {
        console.error('❌ 首页推荐错误:', error.message);
        return [];
    }
};

// 获取筛选配置
const getFilters = () => {
    const baseFilters = [
        {
            key: 'area',
            name: '地区',
            value: [
                { n: '全部', v: '' },
                { n: '中国大陆', v: '中国大陆' },
                { n: '美国', v: '美国' },
                { n: '韩国', v: '韩国' },
                { n: '日本', v: '日本' },
                { n: '英国', v: '英国' },
                { n: '法国', v: '法国' },
                { n: '德国', v: '德国' },
                { n: '其他', v: '其他' }
            ]
        },
        {
            key: 'year',
            name: '年份',
            value: [
                { n: '全部', v: '' },
                { n: '2025', v: '2025' },
                { n: '2024', v: '2024' },
                { n: '2023', v: '2023' },
                { n: '2022', v: '2022' },
                { n: '2021', v: '2021' },
                { n: '2020', v: '2020' },
                { n: '2019', v: '2019' },
                { n: '2018', v: '2018' }
            ]
        }
    ];
    
    // 为每个分类提供筛选配置
    const filters = {};
    const categoryIds = [
        'movie_bt_tags/xiju', 'movie_bt_tags/aiqing', 'movie_bt_tags/adt',
        'movie_bt_tags/at', 'movie_bt_tags/donghua', 'movie_bt_tags/qihuan',
        'movie_bt_tags/xuanni', 'movie_bt_tags/kehuan', 'movie_bt_tags/juqing',
        'movie_bt_tags/kongbu', 'meiju', 'gf'
    ];
    
    for (const categoryId of categoryIds) {
        filters[categoryId] = baseFilters;
    }
    
    return filters;
};

// 构建URL
const buildUrl = (tid, pg, extend = {}) => {
    try {
        let url = lianggeBTConfig.host;
        
        if (tid.startsWith('movie_bt_tags/')) {
            url += '/' + tid;
        } else if (tid === 'meiju') {
            url += '/meiju';
        } else if (tid === 'gf') {
            url += '/gf';
        } else {
            url += '/' + tid;
        }
        
        // 添加分页
        if (pg && pg !== '1') {
            if (url.includes('?')) {
                url += `&paged=${pg}`;
            } else {
                url += `?paged=${pg}`;
            }
        }
        
        // 处理筛选参数（如果需要）
        if (extend.area) {
            if (url.includes('?')) {
                url += `&area=${encodeURIComponent(extend.area)}`;
            } else {
                url += `?area=${encodeURIComponent(extend.area)}`;
            }
        }
        
        if (extend.year) {
            if (url.includes('?')) {
                url += `&year=${encodeURIComponent(extend.year)}`;
            } else {
                url += `?year=${encodeURIComponent(extend.year)}`;
            }
        }
        
        return url;
    } catch (error) {
        console.error('❌ 构建URL错误:', error.message);
        return lianggeBTConfig.host + '/movie_bt_tags/xiju';
    }
};

// 分类列表请求
const getCategoryList = async (type, page = 1, extend = {}) => {
    try {
        const url = buildUrl(type, page, extend);
        console.log(`🔍 分类请求: ${url}`);
        
        const response = await _http.get(url, { headers: lianggeBTConfig.headers });
        const html = response.data;
        const $ = cheerio.load(html);
        
        const list = [];
        const seenIds = new Set();
        
        // 尝试多种选择器
        const selectors = [
            'li:has(a[href*="/movie/"])',
            '.item li:has(a[href*="/movie/"])'
        ];
        
        let foundElements = $();
        for (const selector of selectors) {
            const elements = $(selector);
            if (elements.length > 0) {
                foundElements = elements;
                break;
            }
        }
        
        foundElements.each((i, elem) => {
            const $elem = $(elem);
            
            // 提取链接
            const link = $elem.find('a[href*="/movie/"]').attr('href');
            if (!link) return;
            
            const vodIdMatch = link.match(/\/movie\/(\d+)\.html/);
            if (!vodIdMatch) return;
            
            const vodId = vodIdMatch[1];
            if (seenIds.has(vodId)) return;
            seenIds.add(vodId);
            
            // 提取标题
            let title = '';
            const titleSelectors = [
                'h3 a', 'h3', 'a[title]', '.title', '.name'
            ];
            
            for (const selector of titleSelectors) {
                const titleElem = $elem.find(selector);
                if (titleElem.length > 0) {
                    title = titleElem.text().trim();
                    if (title && title.length > 1) break;
                }
            }
            
            if (!title) return;
            
            // 提取图片
            let pic = '';
            const picSelectors = [
                'img[data-original]', 'img[data-src]', 'img[src]'
            ];
            
            for (const selector of picSelectors) {
                const img = $elem.find(selector);
                if (img.length > 0) {
                    pic = img.attr('data-original') || img.attr('data-src') || img.attr('src');
                    if (pic && !pic.endsWith('blank.gif') && !pic.includes('base64')) {
                        break;
                    }
                }
            }
            
            // 处理图片URL
            if (pic) {
                if (pic.startsWith('//')) {
                    pic = 'https:' + pic;
                } else if (pic.startsWith('/')) {
                    pic = lianggeBTConfig.host + pic;
                }
            }
            
            // 提取备注
            let remarks = '';
            const remarkSelectors = [
                '.rating', '.status', 'span:contains("集")', 
                'span:contains("1080p")', 'span:contains("HD")'
            ];
            
            for (const selector of remarkSelectors) {
                const remarkElem = $elem.find(selector);
                if (remarkElem.length > 0) {
                    remarks = remarkElem.text().trim();
                    if (remarks) break;
                }
            }
            
            list.push({
                vod_id: vodId,
                vod_name: title,
                vod_pic: pic || '',
                vod_remarks: remarks || '',
                vod_year: ''
            });
        });
        
        console.log(`✅ 分类 ${type} 第 ${page} 页获取到 ${list.length} 个项目`);
        return {
            list: list,
            page: parseInt(page),
            pagecount: list.length >= PAGE_LIMIT ? parseInt(page) + 1 : parseInt(page),
            limit: PAGE_LIMIT,
            total: 19980 // 模拟总数量
        };
    } catch (error) {
        console.error('❌ 分类列表错误:', error.message);
        return { list: [], page: parseInt(page), pagecount: 1, limit: PAGE_LIMIT, total: 0 };
    }
};

// 检查搜索结果相关性
const isRelevantSearchResult = (title, searchKey) => {
    if (!title || !searchKey) return false;
    
    const titleLower = title.toLowerCase();
    const searchKeyLower = searchKey.toLowerCase();
    
    // 直接包含搜索关键词
    if (titleLower.includes(searchKeyLower)) {
        return true;
    }
    
    // 字符匹配
    const searchChars = new Set(searchKeyLower.replace(/\s+/g, ''));
    const titleChars = new Set(titleLower.replace(/\s+/g, ''));
    
    if (searchChars.size > 0) {
        const intersection = new Set([...searchChars].filter(x => titleChars.has(x)));
        const matchRatio = intersection.size / searchChars.size;
        if (matchRatio >= 0.6) {
            return true;
        }
    }
    
    // 短搜索词要求严格匹配
    if (searchKeyLower.length <= 2) {
        return titleLower.includes(searchKeyLower);
    }
    
    return false;
};

// 搜索功能
const searchVod = async (keyword, page = 1) => {
    try {
        let searchUrl = `${lianggeBTConfig.host}/xssssearch?q=${encodeURIComponent(keyword)}`;
        if (page && page !== "1") {
            searchUrl += `&p=${page}`;
        }
        
        console.log(`🔍 搜索URL: ${searchUrl}`);
        const response = await _http.get(searchUrl, { headers: lianggeBTConfig.headers });
        const html = response.data;
        const $ = cheerio.load(html);
        
        const list = [];
        const seenIds = new Set();
        
        // 搜索结果选择器
        const elements = $('li:has(a[href*="/movie/"])');
        console.log(`🔍 找到 ${elements.length} 个搜索结果元素`);
        
        elements.each((i, elem) => {
            const $elem = $(elem);
            
            // 提取链接
            const link = $elem.find('a[href*="/movie/"]').attr('href');
            if (!link) return;
            
            const vodIdMatch = link.match(/\/movie\/(\d+)\.html/);
            if (!vodIdMatch) return;
            
            const vodId = vodIdMatch[1];
            if (seenIds.has(vodId)) return;
            
            // 提取标题
            let title = '';
            const titleSelectors = [
                'h3 a', 'h3', 'a[title]'
            ];
            
            for (const selector of titleSelectors) {
                const titleElem = $elem.find(selector);
                if (titleElem.length > 0) {
                    title = titleElem.text().trim();
                    if (title && title.length > 1) break;
                }
            }
            
            if (!title) return;
            
            // 检查相关性
            if (!isRelevantSearchResult(title, keyword)) {
                console.log(`❌ 过滤无关: ${title} (搜索: ${keyword})`);
                return;
            }
            
            seenIds.add(vodId);
            
            // 提取图片
            let pic = '';
            const picSelectors = [
                'img[data-original]', 'img[data-src]', 'img[src]'
            ];
            
            for (const selector of picSelectors) {
                const img = $elem.find(selector);
                if (img.length > 0) {
                    pic = img.attr('data-original') || img.attr('data-src') || img.attr('src');
                    if (pic && !pic.endsWith('blank.gif') && !pic.includes('base64')) {
                        break;
                    }
                }
            }
            
            // 处理图片URL
            if (pic) {
                if (pic.startsWith('//')) {
                    pic = 'https:' + pic;
                } else if (pic.startsWith('/')) {
                    pic = lianggeBTConfig.host + pic;
                }
            }
            
            // 如果没有图片，尝试从详情页获取
            if (!pic) {
                // 这里可以调用一个函数从详情页获取图片，但为了性能，暂时留空
            }
            
            // 提取备注
            let remarks = '';
            const remarkSelectors = [
                '.rating', '.status', 'span:contains("集")'
            ];
            
            for (const selector of remarkSelectors) {
                const remarkElem = $elem.find(selector);
                if (remarkElem.length > 0) {
                    remarks = remarkElem.text().trim();
                    if (remarks) break;
                }
            }
            
            list.push({
                vod_id: vodId,
                vod_name: title,
                vod_pic: pic || '',
                vod_remarks: remarks || '',
                vod_year: ''
            });
            
            console.log(`✅ 相关视频: ${title} (ID: ${vodId})`);
        });
        
        console.log(`✅ 搜索 "${keyword}" 找到 ${list.length} 个结果`);
        return {
            list: list,
            page: parseInt(page),
            pagecount: list.length >= PAGE_LIMIT ? parseInt(page) + 1 : parseInt(page),
            total: list.length
        };
    } catch (error) {
        console.error('❌ 搜索错误:', error.message);
        return { list: [], page: parseInt(page), pagecount: 1, total: 0 };
    }
};

// 解析播放源
const parsePlaySources = ($, vodId) => {
    try {
        const playSources = [];
        
        // 查找播放链接
        const episodeElements = $('a[href*="/v_play/"]');
        const episodes = [];
        
        episodeElements.each((i, elem) => {
            const $elem = $(elem);
            const epTitle = $elem.text().trim();
            const epUrl = $elem.attr('href');
            
            if (epTitle && epUrl) {
                // 提取播放ID
                const playIdMatch = epUrl.match(/\/v_play\/([^.]+)\.html/);
                if (playIdMatch) {
                    episodes.push(`${epTitle}$${playIdMatch[1]}`);
                }
            }
        });
        
        if (episodes.length > 0) {
            playSources.push({
                name: '默认播放',
                episodes: episodes.join('#')
            });
        } else {
            // 默认播放源
            playSources.push({
                name: '默认播放',
                episodes: '第1集$bXZfMTM0NTY4LW5tXzE=' // Base64编码的默认ID
            });
        }
        
        return playSources;
    } catch (error) {
        console.error('❌ 解析播放源错误:', error.message);
        return [{ name: '默认播放', episodes: '第1集$bXZfMTM0NTY4LW5tXzE=' }];
    }
};

// 详情获取
const getDetail = async (id) => {
    try {
        // 确保id是视频ID，不是完整URL
        let detailUrl = id;
        if (!detailUrl.includes('://') && !detailUrl.startsWith('/movie/')) {
            detailUrl = `/movie/${id}.html`;
        }
        
        if (detailUrl.startsWith('/')) {
            detailUrl = lianggeBTConfig.host + detailUrl;
        } else if (!detailUrl.includes('://')) {
            detailUrl = lianggeBTConfig.host + '/movie/' + id + '.html';
        }
        
        console.log('🔍 获取详情:', detailUrl);
        
        const response = await _http.get(detailUrl, { headers: lianggeBTConfig.headers });
        const html = response.data;
        const $ = cheerio.load(html);
        
        // 提取标题
        let title = '';
        const titleSelectors = ['h1', 'h2', 'title'];
        
        for (const selector of titleSelectors) {
            const titleElem = $(selector);
            if (titleElem.length > 0) {
                title = titleElem.text().trim();
                if (title) break;
            }
        }
        
        if (!title) {
            title = '未知标题';
        }
        
        // 提取图片
        let pic = '';
        const picSelectors = [
            'img.poster', '.poster img', 'img[src]'
        ];
        
        for (const selector of picSelectors) {
            const img = $(selector);
            if (img.length > 0) {
                pic = img.attr('src');
                if (pic && !pic.endsWith('blank.gif')) {
                    break;
                }
            }
        }
        
        // 处理图片URL
        if (pic) {
            if (pic.startsWith('//')) {
                pic = 'https:' + pic;
            } else if (pic.startsWith('/')) {
                pic = lianggeBTConfig.host + pic;
            }
        }
        
        // 提取描述
        let desc = '';
        const descSelectors = [
            '.intro', '.description', '.desc'
        ];
        
        for (const selector of descSelectors) {
            const descElem = $(selector);
            if (descElem.length > 0) {
                desc = descElem.text().trim();
                if (desc) break;
            }
        }
        
        // 提取演员
        let actor = '';
        const actorSelectors = [
            'li:contains("主演")',
            'span:contains("主演") + span'
        ];
        
        for (const selector of actorSelectors) {
            const actorElem = $(selector);
            if (actorElem.length > 0) {
                actor = actorElem.text().trim()
                    .replace('主演：', '')
                    .replace('主演', '')
                    .trim();
                if (actor) break;
            }
        }
        
        // 提取导演
        let director = '';
        const directorSelectors = [
            'li:contains("导演")',
            'span:contains("导演") + span'
        ];
        
        for (const selector of directorSelectors) {
            const directorElem = $(selector);
            if (directorElem.length > 0) {
                director = directorElem.text().trim()
                    .replace('导演：', '')
                    .replace('导演', '')
                    .trim();
                if (director) break;
            }
        }
        
        // 提取播放源
        const playSources = parsePlaySources($, id);
        
        const detail = {
            vod_id: id,
            vod_name: title,
            vod_pic: pic || '',
            type_name: '',
            vod_year: '',
            vod_area: '',
            vod_remarks: '',
            vod_actor: actor || '',
            vod_director: director || '',
            vod_content: desc || '',
            vod_play_from: playSources.map(source => source.name).join('$$$'),
            vod_play_url: playSources.map(source => source.episodes).join('$$$')
        };
        
        console.log('✅ 详情获取成功');
        return detail;
    } catch (error) {
        console.error('❌ 详情获取错误:', error.message);
        return null;
    }
};

// 播放请求处理
const getPlayUrl = async (playUrl) => {
    try {
        console.log('🎬 处理播放URL:', playUrl);
        
        // 如果playUrl是Base64编码的播放ID
        if (playUrl && !playUrl.includes('://') && playUrl.length > 10) {
            // 可能是Base64编码的播放ID
            const playId = playUrl;
            const decodedId = Buffer.from(playId, 'base64').toString('utf-8');
            console.log(`🔍 解码播放ID: ${decodedId}`);
            
            playUrl = `${lianggeBTConfig.host}/v_play/${playId}.html`;
        }
        
        // 确保URL格式正确
        if (playUrl && !playUrl.startsWith('http')) {
            playUrl = playUrl.startsWith('/') ? 
                lianggeBTConfig.host + playUrl : 
                lianggeBTConfig.host + '/' + playUrl;
        }
        
        console.log('🔧 处理后的播放URL:', playUrl);
        
        // 检查是否是直接播放链接
        const isDirectPlayable = playUrl.match(/\.(m3u8|mp4|flv|avi|mkv|ts)/i);
        
        if (isDirectPlayable) {
            console.log('✅ 直接播放链接');
            return {
                parse: 0,
                url: playUrl,
                header: {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
                    "Referer": lianggeBTConfig.host + "/",
                    "Origin": lianggeBTConfig.host
                }
            };
        } else {
            console.log('🔍 需要解析播放页');
            // 对于两个BT，通常直接返回播放页URL，让TVBox解析
            return {
                parse: 1,
                url: playUrl,
                header: {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
                    "Referer": lianggeBTConfig.host + "/",
                    "Origin": lianggeBTConfig.host
                }
            };
        }
    } catch (error) {
        console.error('❌ 播放处理错误:', error.message);
        return {
            parse: 1,
            url: playUrl,
            header: lianggeBTConfig.headers
        };
    }
};

// TVBox T4 接口请求处理
const handleT4Request = async (req) => {
    try {
        const { ac, t, pg, wd, ids, play, quick, extend } = req.query;
        const page = parseInt(pg) || 1;

        console.log('📥 请求参数:', { ac, t, pg, wd, ids, play: play ? '***' : null, quick, extend });

        // 1. 搜索请求
        if (wd) {
            console.log('🔍 搜索请求:', wd);
            const result = await searchVod(wd, page);
            if (quick === 'true') {
                result.list = result.list.slice(0, 10);
            }
            return {
                list: result.list,
                page: result.page,
                pagecount: result.pagecount,
                limit: PAGE_LIMIT,
                total: result.total
            };
        }

        // 2. 播放请求 - 最高优先级
        if (play) {
            console.log('🎬 播放请求');
            return await getPlayUrl(play);
        }

        // 3. 详情请求
        if (ids) {
            console.log('📋 详情请求:', ids);
            const detail = await getDetail(ids);
            return {
                list: detail ? [detail] : [],
                page: 1,
                pagecount: 1,
                total: detail ? 1 : 0
            };
        }

        // 4. 分类内容请求
        if (t) {
            console.log('📁 分类请求:', t, '页码:', page);
            const extendParams = {};
            if (extend) {
                try { 
                    Object.assign(extendParams, JSON.parse(extend)); 
                } catch (e) {
                    console.error('❌ extend参数解析错误:', e.message);
                }
            }
            const result = await getCategoryList(t, page, extendParams);
            return {
                list: result.list,
                page: result.page,
                pagecount: result.pagecount,
                limit: PAGE_LIMIT,
                total: result.total
            };
        }

        // 5. 首页请求
        if (!ac || ac === 'class') {
            console.log('🏠 首页请求');
            const classes = await getClasses();
            if (ac === 'class') {
                console.log('📋 分类列表请求');
                return { 
                    class: classes,
                    filters: getFilters()
                };
            }
            
            const homeList = await getHomeRecommend();
            return {
                class: classes,
                filters: getFilters(),
                list: homeList,
                page: 1,
                pagecount: 1,
                total: homeList.length,
                limit: PAGE_LIMIT
            };
        }

        console.log('⚠️ 未知请求类型');
        return { list: [], page: 1, pagecount: 1 };
    } catch (error) {
        console.error('❌ 接口处理错误:', error.message);
        return { 
            list: [], 
            page: 1, 
            pagecount: 1,
            error: error.message 
        };
    }
};

const meta = {
    key: "LiangGeBT",
    name: "[纯]两个BT",
    type: 4,
    api: "/video/LiangGeBT",
};

module.exports = async (app, opt) => {
    app.get(meta.api, async (req, reply) => {
        const result = await handleT4Request(req);
        return result;
    });
    opt.sites.push(meta);
};