const axios = require("axios");
const http = require("http");
const https = require("https");
const crypto = require("crypto");
const querystring = require("querystring");

const _http = axios.create({
    timeout: 15 * 1000,
    httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
    httpAgent: new http.Agent({ keepAlive: true }),
});

// 独播库配置
const dubokuConfig = {
    host: "https://api.dbokutv.com",
    refererHost: "https://www.duboku.tv",
    headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        "Content-Type": "application/json",
        "Referer": "https://www.duboku.tv/",
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "keep-alive"
    }
};

const PAGE_LIMIT = 20;

// 辅助函数：base64解码（用于解码图片和视频地址）
const decodeDubokuData = (data) => {
    if (!data || typeof data !== 'string') return '';
    
    const strippedStr = data.trim().replace(/['"]/g, '');
    if (!strippedStr) return '';
    
    const segmentLength = 10;
    try {
        // 分段反转
        let processedBase64 = '';
        for (let i = 0; i < strippedStr.length; i += segmentLength) {
            const segment = strippedStr.slice(i, i + segmentLength);
            processedBase64 += segment.split('').reverse().join('');
        }
        
        // 替换点号为等号
        processedBase64 = processedBase64.replace(/\./g, '=');
        
        // Base64解码
        const paddingNeeded = 4 - (processedBase64.length % 4);
        if (paddingNeeded !== 4) {
            processedBase64 += '='.repeat(paddingNeeded);
        }
        
        const decodedBytes = Buffer.from(processedBase64, 'base64');
        return decodedBytes.toString('utf-8');
    } catch (error) {
        console.error('❌ 解码错误:', error.message);
        return '';
    }
};

// 辅助函数：生成随机字符串
const generateRandomString = (length) => {
    const characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * characters.length);
        result += characters[randomIndex];
    }
    return result;
};

// 辅助函数：交错字符串
const interleaveStrings = (str1, str2) => {
    const result = [];
    const minLength = Math.min(str1.length, str2.length);
    
    for (let i = 0; i < minLength; i++) {
        result.push(str1[i]);
        result.push(str2[i]);
    }
    
    result.push(str1.slice(minLength));
    result.push(str2.slice(minLength));
    return result.join('');
};

// 辅助函数：生成签名
const generateSignature = (url) => {
    const timestamp = Math.floor(Date.now() / 1000);
    const randomNumber = Math.floor(Math.random() * 800000000);
    const valueA = randomNumber + 100000000;
    const valueB = 900000000 - randomNumber;
    
    // 交错字符串
    const interleaved = interleaveStrings(
        `${valueA}${valueB}`,
        timestamp.toString()
    );
    
    // Base64编码并替换等号为点号
    const ssid = Buffer.from(interleaved).toString('base64').replace(/=/g, '.');
    const sign = generateRandomString(60);
    const token = generateRandomString(38);
    
    const separator = url.includes('?') ? '&' : '?';
    return `${url}${separator}sign=${sign}&token=${token}&ssid=${ssid}`;
};

// 获取分类数据
const getClasses = async () => {
    return [
        { type_id: "2", type_name: "连续剧" },
        { type_id: "3", type_name: "综艺" },
        { type_id: "1", type_name: "电影" },
        { type_id: "4", type_name: "动漫" }
    ];
};

// 获取首页推荐
const getHomeRecommend = async () => {
    try {
        const url = generateSignature(`${dubokuConfig.host}/home`);
        console.log('🔍 获取首页推荐:', url);
        
        const response = await _http.get(url, {
            headers: {
                ...dubokuConfig.headers,
                "Referer": dubokuConfig.refererHost + "/"
            },
            timeout: 10000
        });
        
        const data = response.data;
        const list = [];
        
        if (Array.isArray(data)) {
            data.forEach(category => {
                const vodList = category.VodList || [];
                vodList.forEach(vod => {
                    const vodId = vod.DId || vod.DuId || '';
                    const vodPic = vod.TnId || '';
                    
                    list.push({
                        vod_id: decodeDubokuData(vodId),
                        vod_name: vod.Name || '',
                        vod_pic: decodeDubokuData(vodPic),
                        vod_remarks: vod.Tag || ''
                    });
                });
            });
        }
        
        console.log(`✅ 获取到 ${list.length} 个首页推荐`);
        return list.slice(0, 20); // 限制首页显示数量
    } catch (error) {
        console.error('❌ 首页推荐错误:', error.message);
        return [];
    }
};

// 分类列表请求
const getCategoryList = async (type, page = 1, extend = {}) => {
    try {
        // 构建分类URL路径
        const pageStr = page === 1 ? '' : page.toString();
        const path = `/vodshow/${type}--------${pageStr}---`;
        const url = generateSignature(dubokuConfig.host + path);
        
        console.log(`🔍 获取分类列表: ${type} 第 ${page} 页`, url);
        
        const response = await _http.get(url, {
            headers: {
                ...dubokuConfig.headers,
                "Referer": dubokuConfig.refererHost + "/"
            },
            timeout: 10000
        });
        
        const data = response.data;
        const list = [];
        let pageCount = 1;
        
        // 解析视频列表
        if (data && data.VodList && Array.isArray(data.VodList)) {
            data.VodList.forEach(vod => {
                const vodId = vod.DId || vod.DuId || '';
                const vodPic = vod.TnId || '';
                
                list.push({
                    vod_id: decodeDubokuData(vodId),
                    vod_name: vod.Name || '',
                    vod_pic: decodeDubokuData(vodPic),
                    vod_remarks: vod.Tag || ''
                });
            });
            
            // 计算总页数
            if (data.PaginationList && Array.isArray(data.PaginationList)) {
                for (const pagination of data.PaginationList) {
                    if (pagination.Type === 'StartEnd') {
                        const pageInfo = decodeDubokuData(pagination.PId || pagination.PuId);
                        if (pageInfo) {
                            const parts = pageInfo.split('-');
                            if (parts.length >= 9) {
                                pageCount = parseInt(parts[8]) || 1;
                            }
                        }
                    } else if (pagination.Type === 'ShortPage') {
                        const pageStr = pagination.Name || '';
                        const match = pageStr.match(/\/(\d+)/);
                        if (match && match[1]) {
                            pageCount = parseInt(match[1]) || 1;
                        }
                    }
                }
            }
        }
        
        console.log(`✅ 分类 ${type} 第 ${page} 页获取到 ${list.length} 个项目，总页数: ${pageCount}`);
        return {
            list: list,
            page: parseInt(page),
            pagecount: pageCount,
            total: list.length * pageCount
        };
    } catch (error) {
        console.error('❌ 分类列表错误:', error.message);
        return { list: [], page: parseInt(page), pagecount: 1, total: 0 };
    }
};

// 搜索功能
const searchVod = async (keyword, page = 1) => {
    try {
        const baseUrl = generateSignature(`${dubokuConfig.host}/vodsearch`);
        const url = `${baseUrl}&wd=${encodeURIComponent(keyword)}`;
        
        console.log(`🔍 搜索 "${keyword}" 第 ${page} 页`, url);
        
        const response = await _http.get(url, {
            headers: {
                ...dubokuConfig.headers,
                "Referer": dubokuConfig.refererHost + "/"
            },
            timeout: 10000
        });
        
        const data = response.data;
        const list = [];
        
        if (Array.isArray(data)) {
            data.forEach(vod => {
                const vodId = vod.DId || vod.DuId || '';
                const vodPic = vod.TnId || '';
                
                list.push({
                    vod_id: decodeDubokuData(vodId),
                    vod_name: vod.Name || '',
                    vod_pic: decodeDubokuData(vodPic),
                    vod_remarks: vod.Tag || '',
                    vod_actor: vod.Actor || '',
                    vod_score: vod.Rating || ''
                });
            });
        }
        
        console.log(`✅ 搜索 "${keyword}" 找到 ${list.length} 个结果`);
        return {
            list: list,
            page: parseInt(page),
            pagecount: 1, // 搜索通常只有一页
            total: list.length
        };
    } catch (error) {
        console.error('❌ 搜索错误:', error.message);
        return { list: [], page: parseInt(page), pagecount: 1, total: 0 };
    }
};

// 详情获取
const getDetail = async (id) => {
    try {
        // 确保id是完整路径
        let detailPath = id.startsWith('/') ? id : '/' + id;
        const url = generateSignature(dubokuConfig.host + detailPath);
        
        console.log('🔍 获取详情:', url);
        
        const response = await _http.get(url, {
            headers: {
                ...dubokuConfig.headers,
                "Referer": dubokuConfig.refererHost + "/"
            },
            timeout: 10000
        });
        
        const data = response.data;
        
        if (!data) {
            console.log('❌ 详情数据为空');
            return null;
        }
        
        // 处理播放列表
        let vod_play_url = '';
        const playList = [];
        
        if (data.Playlist && Array.isArray(data.Playlist)) {
            data.Playlist.forEach(episode => {
                const episodeName = episode.EpisodeName || `第${playList.length + 1}集`;
                const videoId = decodeDubokuData(episode.VId || '');
                if (videoId) {
                    playList.push(`${episodeName}$${videoId}`);
                }
            });
            
            vod_play_url = playList.join('#');
        }
        
        // 构建详情信息
        const vod_pic = decodeDubokuData(data.TnId || '');
        const vod_id = decodeDubokuData(data.DId || data.DuId || '') || id;
        
        const detail = {
            vod_id: vod_id,
            vod_name: data.Name || '',
            vod_pic: vod_pic || '',
            vod_remarks: data.Tag ? `评分：${data.Rating || '暂无'}` : '',
            vod_year: data.ReleaseYear || '',
            vod_area: data.Region || '',
            vod_actor: Array.isArray(data.Actor) ? data.Actor.join(',') : data.Actor || '',
            vod_director: data.Director || '',
            vod_content: data.Description || '',
            vod_play_from: '独播库',
            vod_play_url: vod_play_url,
            type_name: `${data.Genre || ''},${data.Scenario || ''},${data.Language || ''}`
        };
        
        console.log(`✅ 详情获取成功，找到 ${playList.length} 个剧集`);
        return detail;
    } catch (error) {
        console.error('❌ 详情获取错误:', error.message);
        return null;
    }
};

// 播放请求处理
const getPlayUrl = async (playUrl) => {
    try {
        console.log('🎬 处理播放URL:', playUrl);
        
        // 确保URL格式正确
        let finalUrl = playUrl;
        if (!playUrl.startsWith('http')) {
            if (playUrl.startsWith('/')) {
                finalUrl = dubokuConfig.host + playUrl;
            } else {
                finalUrl = dubokuConfig.host + '/' + playUrl;
            }
        }
        
        // 生成签名
        const signedUrl = generateSignature(finalUrl);
        console.log('🔧 签名后的播放URL:', signedUrl);
        
        const response = await _http.get(signedUrl, {
            headers: {
                ...dubokuConfig.headers,
                "Referer": dubokuConfig.refererHost + "/"
            },
            timeout: 10000
        });
        
        const data = response.data;
        
        if (!data || !data.HId) {
            console.log('❌ 未找到播放地址');
            return {
                parse: 1,
                url: playUrl,
                header: {
                    "User-Agent": dubokuConfig.headers["User-Agent"],
                    "Referer": dubokuConfig.refererHost + "/",
                    "Origin": dubokuConfig.refererHost
                }
            };
        }
        
        // 解码视频地址
        const videoUrl = decodeDubokuData(data.HId);
        console.log('✅ 解码后的视频地址:', videoUrl);
        
        if (!videoUrl) {
            console.log('⚠️ 视频地址解码失败');
            return {
                parse: 1,
                url: playUrl,
                header: {
                    "User-Agent": dubokuConfig.headers["User-Agent"],
                    "Referer": dubokuConfig.refererHost + "/",
                    "Origin": dubokuConfig.refererHost
                }
            };
        }
        
        return {
            parse: 0,
            url: videoUrl,
            header: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
                "Accept-Encoding": "gzip, deflate",
                "origin": "https://w.duboku.io",
                "referer": "https://w.duboku.io/",
                "priority": "u=1, i"
            }
        };
    } catch (error) {
        console.error('❌ 播放处理错误:', error.message);
        return {
            parse: 1,
            url: playUrl,
            header: {
                "User-Agent": dubokuConfig.headers["User-Agent"],
                "Referer": dubokuConfig.refererHost + "/",
                "Origin": dubokuConfig.refererHost
            }
        };
    }
};

// TVBox T4 接口请求处理
const handleT4Request = async (req) => {
    try {
        const { ac, t, pg, wd, ids, play, quick, extend } = req.query;
        const page = parseInt(pg) || 1;

        console.log('📥 请求参数:', { ac, t, pg, wd, ids, play: play ? '***' : null, quick, extend });

        // 1. 搜索请求
        if (wd) {
            console.log('🔍 搜索请求:', wd);
            const result = await searchVod(wd, page);
            if (quick === 'true') {
                result.list = result.list.slice(0, 10);
            }
            return {
                list: result.list,
                page: result.page,
                pagecount: result.pagecount,
                limit: PAGE_LIMIT,
                total: result.total
            };
        }

        // 2. 播放请求 - 最高优先级
        if (play) {
            console.log('🎬 播放请求');
            return await getPlayUrl(play);
        }

        // 3. 详情请求
        if (ids) {
            console.log('📋 详情请求:', ids);
            const detail = await getDetail(ids);
            return {
                list: detail ? [detail] : [],
                page: 1,
                pagecount: 1,
                total: detail ? 1 : 0
            };
        }

        // 4. 分类内容请求
        if (t) {
            console.log('📁 分类请求:', t, '页码:', page);
            const extendParams = {};
            if (extend) {
                try { 
                    Object.assign(extendParams, JSON.parse(extend)); 
                } catch (e) {
                    console.error('❌ extend参数解析错误:', e.message);
                }
            }
            const result = await getCategoryList(t, page, extendParams);
            return {
                list: result.list,
                page: result.page,
                pagecount: result.pagecount,
                limit: PAGE_LIMIT,
                total: result.total
            };
        }

        // 5. 首页请求
        if (!ac || ac === 'class') {
            console.log('🏠 首页请求');
            const classes = await getClasses();
            if (ac === 'class') {
                console.log('📋 分类列表请求');
                return { class: classes };
            }
            
            const homeList = await getHomeRecommend();
            return {
                class: classes,
                list: homeList,
                page: 1,
                pagecount: 1,
                total: homeList.length
            };
        }

        console.log('⚠️ 未知请求类型');
        return { list: [], page: 1, pagecount: 1 };
    } catch (error) {
        console.error('❌ 接口处理错误:', error.message);
        return { 
            list: [], 
            page: 1, 
            pagecount: 1,
            error: error.message 
        };
    }
};

const meta = {
    key: "DuBoKu",
    name: "[纯]独播库",
    type: 4,
    api: "/video/DuBoKu",
};

module.exports = async (app, opt) => {
    app.get(meta.api, async (req, reply) => {
        const result = await handleT4Request(req);
        return result;
    });
    opt.sites.push(meta);
};