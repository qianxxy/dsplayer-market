/**
 * 韩小圈 - Fastify T4 JS 源
 * 由同名 Python Spider 迁移：首页、分类分页、详情、搜索、播放。
 */

const axios = require("axios");
const http = require("http");
const https = require("https");
const cheerio = require("cheerio");

const SITE_CONFIG = {
  key: "hanxiaoquan",
  title: "韩小圈[纯]",
  host: "https://www.jennyhow.com",
  api: "/video/hanxiaoquan",
  searchable: 1,
  quickSearch: 0,
  filterable: 0,
  PAGE_LIMIT: 24,
  headers: {
    "User-Agent":
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    Referer: "https://www.jennyhow.com",
  },
};

const CLASS_MAP = {
  "/hxq/1.html": "最新韩剧",
  "/hxq/2.html": "韩国电影",
  "/hxq/3.html": "韩国综艺",
  "/hxq/4.html": "韩国动漫",
};

const TID_ALIAS = {
  20: "/hxq/1.html",
  1: "/hxq/1.html",
  21: "/hxq/2.html",
  2: "/hxq/2.html",
  22: "/hxq/3.html",
  3: "/hxq/3.html",
  23: "/hxq/4.html",
  4: "/hxq/4.html",
};

const _http = axios.create({
  timeout: 10 * 1000,
  httpAgent: new http.Agent({ keepAlive: true }),
  httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
  responseType: "arraybuffer",
  maxRedirects: 5,
});

let log = () => {};

const textOf = (res) => Buffer.from(res.data || Buffer.alloc(0)).toString("utf-8");
const clean = (v) => String(v ?? "").replace(/\s+/g, " ").trim();
const stripLabel = (text, re) => clean(String(text || "").replace(re, ""));
const pageNumber = (v) => {
  const n = parseInt(String(v || "1"), 10);
  return Number.isFinite(n) && n > 0 ? n : 1;
};
const fixUrl = (url) => {
  const u = String(url || "").trim();
  if (!u) return "";
  if (u.startsWith("//")) return "https:" + u;
  if (/^https?:\/\//i.test(u)) return u;
  if (u.startsWith("/")) return SITE_CONFIG.host + u;
  return SITE_CONFIG.host + "/" + u;
};
const getText = async (url) => {
  const res = await _http.get(url, { headers: SITE_CONFIG.headers, validateStatus: () => true });
  if (res.status < 200 || res.status >= 400) throw new Error(`HTTP ${res.status}`);
  return textOf(res);
};
const emptyPage = (page, msg = "") => ({ list: [], page, pagecount: page, limit: SITE_CONFIG.PAGE_LIMIT, total: 0, ...(msg ? { msg } : {}) });

const parseModuleItems = (html, searchMode = false) => {
  const $ = cheerio.load(html || "");
  const videos = [];
  const selector = searchMode ? "div.module-search-item, div.module-item" : "div.module-item";
  $(selector).each((_, item) => {
    const $item = $(item);
    const $a = searchMode
      ? $item.find("a").first()
      : $item.find("a.module-item-pic").first().length
        ? $item.find("a.module-item-pic").first()
        : $item.find("a.module-item-title").first().length
          ? $item.find("a.module-item-title").first()
          : $item.find("a").first();
    if (!$a.length) return;
    const $img = $item.find("img").first();
    const name = clean($a.attr("title") || $img.attr("alt") || $a.text());
    const href = $a.attr("href") || "";
    const pic = $img.attr("data-src") || $img.attr("data-original") || $img.attr("src") || "";
    const remarks = clean($item.find(".module-item-text,.module-item-note").first().text());
    if (href && name) videos.push({ vod_id: href, vod_name: name, vod_pic: fixUrl(pic), vod_remarks: remarks });
  });
  return videos;
};

const home = async () => ({ class: Object.entries(CLASS_MAP).map(([type_id, type_name]) => ({ type_id, type_name })) });

const homeVideo = async () => {
  try {
    const html = await getText(SITE_CONFIG.host);
    return { list: parseModuleItems(html) };
  } catch (e) {
    return { list: [], msg: `首页读取失败: ${e.message}` };
  }
};

const category = async (tid, pg) => {
  const page = pageNumber(pg);
  let path = TID_ALIAS[String(tid)] || String(tid || "/hxq/1.html");
  // Python 原规则：分类第2页起把 /hxq/N.html 改为 /hxq/N-{page}.html。
  if (page > 1 && path.endsWith(".html")) path = path.replace(".html", `-${page}.html`);
  const url = /^https?:\/\//i.test(path) ? path : SITE_CONFIG.host + path;
  try {
    const html = await getText(url);
    const list = parseModuleItems(html);
    return { list, page, pagecount: list.length > 0 ? page + 1 : page, limit: SITE_CONFIG.PAGE_LIMIT, total: 0 };
  } catch (e) {
    return emptyPage(page, `分类读取失败: ${e.message}`);
  }
};

const detail = async (ids) => {
  const id = Array.isArray(ids) ? ids[0] : ids;
  const detailUrl = /^https?:\/\//i.test(String(id || "")) ? String(id) : SITE_CONFIG.host + id;
  try {
    const html = await getText(detailUrl);
    const $ = cheerio.load(html || "");
    const title = clean($("h1").first().text()) || "未知名称";
    const $pic = $("img.lazyload,img.lazy").first();
    const pic = fixUrl($pic.attr("data-src") || $pic.attr("data-original") || $pic.attr("src") || "");
    let vod_director = "", vod_actor = "", vod_year = "", vod_content = "";
    $("body *").each((_, el) => {
      const tag = (el.tagName || "").toLowerCase();
      if (["title", "meta", "script", "style"].includes(tag)) return;
      const text = clean($(el).text());
      if (!text || text.length > 300) return;
      if (!vod_director && /导演/.test(text)) vod_director = stripLabel(text, /^.*?导演[：:]?\s*/);
      else if (!vod_actor && /主演/.test(text)) vod_actor = stripLabel(text, /^.*?主演[：:]?\s*/);
      else if (!vod_year && /(上映|年份)/.test(text)) vod_year = stripLabel(text, /^.*?(上映|年份)[：:]?\s*/);
      else if (!vod_content && /(剧情|简介)/.test(text)) vod_content = stripLabel(text, /^.*?(剧情|简介)[：:]?\s*/);
    });
    if (!vod_content) vod_content = clean($(".module-info-introduction-content,.module-info-introduction").first().text());
    const playFrom = [];
    const playUrl = [];
    const tabs = $("ul.nav-tabs li a").toArray();
    tabs.forEach((a) => {
      const $a = $(a);
      const lineName = clean($a.text());
      const targetId = ($a.attr("href") || "").replace("#", "");
      if (!targetId) return;
      const eps = [];
      $(`div#${targetId}`).find("a").each((_, ep) => {
        const $ep = $(ep);
        const name = clean($ep.attr("title") || $ep.text());
        const href = $ep.attr("href") || "";
        if (href) eps.push(`${name || "播放"}$${href}`);
      });
      if (eps.length) {
        playFrom.push(lineName || `线路${playFrom.length + 1}`);
        playUrl.push(eps.join("#"));
      }
    });
    return {
      list: [{
        vod_id: id,
        vod_name: title,
        vod_pic: pic,
        vod_director,
        vod_actor,
        vod_year,
        vod_content,
        vod_play_from: playFrom.join("$$$"),
        vod_play_url: playUrl.join("$$$"),
      }],
    };
  } catch (e) {
    return { list: [], msg: `详情读取失败: ${e.message}` };
  }
};

const play = async (flag, id) => {
  const playUrl = /^https?:\/\//i.test(String(id || "")) ? String(id) : SITE_CONFIG.host + id;
  try {
    const html = await getText(playUrl);
    const now = (html.match(/var now=["'](.*?)["'];/i) || [])[1];
    if (now) return { parse: 0, playUrl: "", url: now, header: { "User-Agent": SITE_CONFIG.headers["User-Agent"] } };
    const m = html.match(/player_aaaa\s*=\s*(\{[^}]+\})/i);
    if (m) {
      try {
        const data = JSON.parse(m[1]);
        return { parse: 0, playUrl: "", url: data.url || "", header: { "User-Agent": SITE_CONFIG.headers["User-Agent"] } };
      } catch (_) {}
    }
    return { parse: 1, playUrl: "", url: "", header: { "User-Agent": SITE_CONFIG.headers["User-Agent"] } };
  } catch (e) {
    return { parse: 1, playUrl: "", url: "", header: { "User-Agent": SITE_CONFIG.headers["User-Agent"] }, msg: `播放解析失败: ${e.message}` };
  }
};

const search = async (wd, pg) => {
  const page = pageNumber(pg);
  try {
    const url = `${SITE_CONFIG.host}/vodsearch/${encodeURIComponent(String(wd || ""))}----------${page}---.html`;
    const html = await getText(url);
    return { list: parseModuleItems(html, true), page };
  } catch (e) {
    return { list: [], page, msg: `搜索失败: ${e.message}` };
  }
};

const meta = { key: SITE_CONFIG.key, name: SITE_CONFIG.title, type: 4, api: SITE_CONFIG.api, searchable: 1, quickSearch: 0, changeable: 0, filterable: 0 };

const handleT4Request = async (req) => {
  const { filter, ac, t, pg, ids, flag, play: playId, wd } = req.query || {};
  if (playId) return play(flag || "", playId);
  if (wd) return search(wd, pg || "1");
  if (ids) return detail(ids.split(",").map((s) => s.trim()).filter(Boolean));
  if (t) return category(t, pg || "1");
  if (ac === "class") return home(filter ?? false);
  return { ...(await home(filter ?? false)), ...(await homeVideo()) };
};

module.exports = async (app, opt = {}) => {
  log = (...args) => (app?.log?.info || console.log)(`[韩小圈] ${args.join(" ")}`);
  app.get(meta.api, async (req, reply) => handleT4Request(req));
  if (opt && Array.isArray(opt.sites)) opt.sites.push(meta);
  log("加载完成");
};
