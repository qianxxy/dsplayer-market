/**
 * ============================================================================
 * 农民影视 - TVBox T4 接口插件
 * ============================================================================
 * 
 * 功能说明：
 * - 提供农民影视视频源的 TVBox T4 格式接口
 * - 支持分类浏览、搜索、详情、播放等功能
 * - 集成筛选系统（类型、地区、年代、排序）
 * - 自动屏蔽失效线路（线路②、线路2、线路二）
 * - 支持播放页深度解析，自动提取真实视频地址
 * 
 * 主要特性：
 * 1. 分类支持：电影、电视剧、综艺、动漫、短剧
 * 2. 筛选功能：支持类型、地区、年份、排序等筛选条件
 *    - 电影：动作片、喜剧片、爱情片、科幻片、恐怖片、剧情片、战争片、惊悚片、奇幻片
 *    - 电视剧：国产剧、港台泰、日韩剧、欧美剧
 *    - 动漫：动漫剧、动漫片
 *    - 综艺/短剧：地区、年代、排序筛选
 * 3. 线路过滤：自动过滤包含"线路②"、"线路2"、"线路二"的线路
 * 4. 智能解析：支持iframe嵌套、m3u8嗅探、JS变量提取等多种解析方式
 * 5. 播放优化：参考原生APP解析逻辑，支持mac_url/mac_from提取
 * 
 * 接口路径：/video/YingBao
 * 
 * 日期：2026-02-07
 * ============================================================================
 */
const axios = require("axios");
const http = require("http");
const https = require("https");
const cheerio = require("cheerio");

const _http = axios.create({
    timeout: 15 * 1000,
    httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
    httpAgent: new http.Agent({ keepAlive: true }),
});

// 农民影视配置 - 去除URL尾部空格
const farmerConfig = {
    host: "https://vip.wwgz.cn:5200",
    searchHost: "https://v.emsdn.cn",
    headers: {
        "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1",
        "Referer": "https://vip.wwgz.cn:5200",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        "Accept-Encoding": "gzip, deflate, br"
    },
    blockedLines: ['线路②', '线路2', '线路二'],
    PAGE_LIMIT: 24
};

// 日志工具函数
const logger = {
    info: (msg, data) => {
        const timestamp = new Date().toISOString();
        console.log(`[${timestamp}] [INFO] ${msg}`, data ? JSON.stringify(data) : '');
    },
    error: (msg, error) => {
        const timestamp = new Date().toISOString();
        console.error(`[${timestamp}] [ERROR] ${msg}`, error ? (error.message || error) : '');
    },
    debug: (msg, data) => {
        const timestamp = new Date().toISOString();
        if (process.env.DEBUG) {
            console.log(`[${timestamp}] [DEBUG] ${msg}`, data ? JSON.stringify(data) : '');
        }
    },
    warn: (msg, data) => {
        const timestamp = new Date().toISOString();
        console.warn(`[${timestamp}] [WARN] ${msg}`, data ? JSON.stringify(data) : '');
    }
};

// 解析农民影视播放页，提取真实视频地址
const parseFarmerPlayPage = async (playUrl) => {
    try {
        logger.info('🔍 解析农民影视播放页', { url: playUrl });
        
        const response = await _http.get(playUrl, {
            headers: {
                ...farmerConfig.headers,
                "Referer": farmerConfig.host + "/"
            }
        });
        
        const html = response.data;
        const $ = cheerio.load(html);
        
        // 方法1：查找iframe中的播放地址
        const iframeSrc = $('iframe').attr('src');
        if (iframeSrc) {
            logger.info('🔍 找到iframe', { src: iframeSrc });
            let iframeUrl = iframeSrc;
            if (iframeUrl.startsWith('//')) {
                iframeUrl = 'https:' + iframeUrl;
            } else if (iframeUrl.startsWith('/')) {
                iframeUrl = farmerConfig.host + iframeUrl;
            }
            
            if (iframeUrl.includes('.m3u8') || iframeUrl.includes('.mp4')) {
                return iframeUrl;
            }
            
            return await parseFarmerPlayPage(iframeUrl);
        }
        
        // 方法2：查找m3u8地址
        const m3u8Patterns = [
            /['"]((?:https?:)?\/\/[^'"]+\.m3u8[^'"]*)['"]/gi,
            /source\s*:\s*['"]([^'"]+\.m3u8[^'"]*)['"]/i,
            /url\s*:\s*['"]([^'"]+\.m3u8[^'"]*)['"]/i,
            /videoUrl\s*:\s*['"]([^'"]+)['"]/i
        ];
        
        for (const pattern of m3u8Patterns) {
            const matches = html.match(pattern);
            if (matches) {
                for (const match of matches) {
                    const urlMatch = match.match(/['"](https?:\/\/[^'"]+\.m3u8[^'"]*)['"]/i);
                    if (urlMatch && urlMatch[1]) {
                        let m3u8Url = urlMatch[1];
                        if (m3u8Url.startsWith('//')) {
                            m3u8Url = 'https:' + m3u8Url;
                        } else if (m3u8Url.startsWith('/')) {
                            m3u8Url = farmerConfig.host + m3u8Url;
                        }
                        
                        logger.info('✅ 找到m3u8地址', { url: m3u8Url });
                        return m3u8Url;
                    }
                }
            }
        }
        
        // 方法3：手动嗅探视频链接
        const videoKeywords = ['.mp4', '.m3u8', 'item/video', 'video_mp4', 'video/tos'];
        const filterKeywords = ['.html', '=http'];
        
        for (const keyword of videoKeywords) {
            const regex = new RegExp(`https?://[^"'\s]*${keyword}[^"'\s]*`, 'gi');
            const matches = html.match(regex);
            
            if (matches) {
                for (const match of matches) {
                    let isValid = true;
                    for (const filter of filterKeywords) {
                        if (match.includes(filter)) {
                            isValid = false;
                            break;
                        }
                    }
                    
                    if (isValid) {
                        logger.info('✅ 手动嗅探到视频地址', { url: match });
                        return match;
                    }
                }
            }
        }
        
        // 方法4：查找JavaScript变量中的视频地址
        const scriptContents = $('script:not([src])').html();
        if (scriptContents) {
            const jsPatterns = [
                /(?:url|src|source)\s*[=:]\s*['"]([^'"]+\.(?:m3u8|mp4|flv)[^'"]*)['"]/gi,
                /http[^'"]*\.(?:m3u8|mp4|flv)[^'"]*/gi
            ];
            
            for (const pattern of jsPatterns) {
                const matches = scriptContents.match(pattern);
                if (matches) {
                    for (const match of matches) {
                        if (match.includes('://')) {
                            let videoUrl = match.replace(/['"]/g, '');
                            if (videoUrl.startsWith('//')) {
                                videoUrl = 'https:' + videoUrl;
                            }
                            logger.info('✅ 从JS中找到视频地址', { url: videoUrl });
                            return videoUrl;
                        }
                    }
                }
            }
        }
        
        logger.warn('❌ 未找到可播放的视频地址，尝试让TVBox解析');
        return null;
    } catch (error) {
        logger.error('❌ 解析播放页错误', error);
        return null;
    }
};

// 获取分类数据
const getClasses = async () => {
    return [
        { type_id: "2", type_name: "剧集" },
        { type_id: "1", type_name: "电影" },
        { type_id: "3", type_name: "综艺" },
        { type_id: "4", type_name: "动漫" },
        { type_id: "26", type_name: "短剧" }
    ];
};

// 获取筛选数据 - 修正：cateId对应id参数，class始终为0
const getFilter = async () => {
    logger.info('📦 开始构建筛选数据');

    const yearValues = [
        { "n": "全部", "v": "" }, { "n": "2025", "v": "2025" }, { "n": "2024", "v": "2024" },
        { "n": "2023", "v": "2023" }, { "n": "2022", "v": "2022" }, { "n": "2021", "v": "2021" },
        { "n": "2020", "v": "2020" }, { "n": "2019", "v": "2019" }, { "n": "2018", "v": "2018" },
        { "n": "2017", "v": "2017" }, { "n": "2016", "v": "2016" }, { "n": "2015", "v": "2015" },
        { "n": "2014", "v": "2014" }, { "n": "2013", "v": "2013" }, { "n": "2012", "v": "2012" },
        { "n": "2011", "v": "2011" }, { "n": "2010", "v": "2010" }, { "n": "2009", "v": "2009" },
        { "n": "2008", "v": "2008" }, { "n": "2007", "v": "2007" }, { "n": "2006", "v": "2006" },
        { "n": "2005", "v": "2005" }, { "n": "2004", "v": "2004" }, { "n": "2003", "v": "2003" },
        { "n": "2002", "v": "2002" }, { "n": "2001", "v": "2001" }, { "n": "2000", "v": "2000" },
        { "n": "1999", "v": "1999" }, { "n": "1998", "v": "1998" }, { "n": "1997", "v": "1997" },
        { "n": "1996", "v": "1996" }, { "n": "1995", "v": "1995" }, { "n": "1994", "v": "1994" },
        { "n": "1993", "v": "1993" }, { "n": "1992", "v": "1992" }, { "n": "1991", "v": "1991" },
        { "n": "1990", "v": "1990" }, { "n": "1989", "v": "1989" }, { "n": "1988", "v": "1988" },
        { "n": "1987", "v": "1987" }, { "n": "1986", "v": "1986" }, { "n": "1985", "v": "1985" },
        { "n": "1984", "v": "1984" }, { "n": "1983", "v": "1983" }, { "n": "1982", "v": "1982" },
        { "n": "1981", "v": "1981" }, { "n": "1980", "v": "1980" }, { "n": "1979", "v": "1979" },
        { "n": "1978", "v": "1978" }, { "n": "1977", "v": "1977" }, { "n": "1976", "v": "1976" },
        { "n": "1975", "v": "1975" }, { "n": "1974", "v": "1974" }, { "n": "1973", "v": "1973" },
        { "n": "1972", "v": "1972" }, { "n": "1971", "v": "1971" }, { "n": "1970", "v": "1970" },
        { "n": "1969", "v": "1969" }, { "n": "1968", "v": "1968" }, { "n": "1967", "v": "1967" },
        { "n": "1966", "v": "1966" }, { "n": "1965", "v": "1965" }, { "n": "1964", "v": "1964" },
        { "n": "1963", "v": "1963" }, { "n": "1962", "v": "1962" }, { "n": "1961", "v": "1961" },
        { "n": "1960", "v": "1960" }
    ];

    const areaValues = [
        { "n": "全部", "v": "" }, { "n": "大陆", "v": "大陆" }, { "n": "香港", "v": "香港" },
        { "n": "台湾", "v": "台湾" }, { "n": "美国", "v": "美国" }, { "n": "韩国", "v": "韩国" },
        { "n": "日本", "v": "日本" }, { "n": "泰国", "v": "泰国" }, { "n": "新加坡", "v": "新加坡" },
        { "n": "马来西亚", "v": "马来西亚" }, { "n": "印度", "v": "印度" }, { "n": "英国", "v": "英国" },
        { "n": "法国", "v": "法国" }, { "n": "加拿大", "v": "加拿大" }, { "n": "西班牙", "v": "西班牙" },
        { "n": "俄罗斯", "v": "俄罗斯" }, { "n": "其它", "v": "其它" }
    ];

    const byValues = [
        { "n": "时间", "v": "time" }, { "n": "人气", "v": "hits" }, { "n": "评分", "v": "score" }
    ];

    // 修正：type_id对应大类，cateId对应具体的子类型id（vod-list-id-X中的X）
    const filterData = {
        "1": [  // 电影大类
            { 
                "key": "cateId",  // 这个对应URL中的id参数
                "name": "类型", 
                "value": [
                    { "n": "全部", "v": "0" },    // id=0表示全部
                    { "n": "动作片", "v": "5" },
                    { "n": "喜剧片", "v": "6" },
                    { "n": "爱情片", "v": "7" },
                    { "n": "科幻片", "v": "8" },
                    { "n": "恐怖片", "v": "9" },
                    { "n": "剧情片", "v": "10" },
                    { "n": "战争片", "v": "11" },
                    { "n": "惊悚片", "v": "16" },
                    { "n": "奇幻片", "v": "17" }
                ]
            },
            { "key": "area", "name": "地区", "value": areaValues },
            { "key": "year", "name": "年代", "value": yearValues },
            { "key": "by", "name": "排序", "value": byValues }
        ],
        "2": [  // 电视剧大类
            { 
                "key": "cateId", 
                "name": "类型", 
                "value": [
                    { "n": "全部", "v": "0" },
                    { "n": "国产剧", "v": "12" },
                    { "n": "港台泰", "v": "13" },
                    { "n": "日韩剧", "v": "14" },
                    { "n": "欧美剧", "v": "15" }
                ]
            },
            { "key": "area", "name": "地区", "value": areaValues },
            { "key": "year", "name": "年代", "value": yearValues },
            { "key": "by", "name": "排序", "value": byValues }
        ],
        "3": [  // 综艺大类 - 只有地区、年代、排序，没有子类型
            { "key": "area", "name": "地区", "value": areaValues },
            { "key": "year", "name": "年代", "value": yearValues },
            { "key": "by", "name": "排序", "value": byValues }
        ],
        "4": [  // 动漫大类
            { 
                "key": "cateId", 
                "name": "类型", 
                "value": [
                    { "n": "全部", "v": "0" },
                    { "n": "动漫剧", "v": "18" },
                    { "n": "动漫片", "v": "19" }
                ]
            },
            { "key": "area", "name": "地区", "value": areaValues },
            { "key": "year", "name": "年代", "value": yearValues },
            { "key": "by", "name": "排序", "value": byValues }
        ],
        "26": [  // 短剧大类 - 只有地区、年代、排序
            { "key": "area", "name": "地区", "value": areaValues },
            { "key": "year", "name": "年代", "value": yearValues },
            { "key": "by", "name": "排序", "value": byValues }
        ]
    };
    
    logger.info('✅ 筛选数据构建完成', { 
        types: Object.keys(filterData)
    });
    
    return filterData;
};

// 分类列表请求 - 修正URL构建逻辑
const getCategoryList = async (type, page = 1, extend = {}) => {
    try {
        const by = extend.by || "time";
        const year = extend.year || "";
        const area = extend.area || "";
        // 修正：cateId对应id参数，不是class参数
        // 如果cateId有值且不为0，用cateId作为id；否则用type作为id
        const id = (extend.cateId && extend.cateId !== "0") ? extend.cateId : type;
        
        // 构建分类链接 - class始终为0
        let url = `${farmerConfig.host}/vod-list-id-${id}-pg-${page}-order--by-${by}-class-0-year-${year}-letter--area-${area}-lang-.html`;
        
        logger.info('📥 分类请求', { type, id, page, extend, url });
        
        const response = await _http.get(url, { 
            headers: farmerConfig.headers 
        });
        
        const html = response.data;
        const $ = cheerio.load(html);
        
        const list = [];
        $('.resize_list li, .globalPicList li').each((i, it) => {
            const $it = $(it);
            const title = $it.find('a').attr('title') || $it.find('a').text().trim();
            const pic = $it.find('img').attr('data-src') || $it.find('img').attr('src');
            const desc = $it.find('.sBottom').text().trim();
            const href = $it.find('a').attr('href');
            
            if (title) {
                let vodId = href;
                if (vodId && vodId.startsWith('/')) {
                    vodId = vodId.substring(1);
                }
                
                list.push({
                    vod_id: vodId || '',
                    vod_name: title,
                    vod_pic: pic ? (pic.startsWith('http') ? pic : farmerConfig.host + pic) : '',
                    vod_remarks: desc || ''
                });
            }
        });
        
        logger.info(`✅ 分类 ${type}(id=${id}) 第 ${page} 页获取到 ${list.length} 个项目`);
        
        // 翻页判断逻辑...
        let pagecount = page;
        let hasNext = false;
        
        const pageLinks = $('.page a, .pagination a, .page-num');
        if (pageLinks.length > 0) {
            let maxPage = page;
            pageLinks.each((i, elem) => {
                const text = $(elem).text().trim();
                const href = $(elem).attr('href') || '';
                const pageNum = parseInt(text);
                
                if (!isNaN(pageNum) && pageNum > maxPage) {
                    maxPage = pageNum;
                }
                
                const match = href.match(/pg-(\d+)/);
                if (match) {
                    const linkPage = parseInt(match[1]);
                    if (linkPage > maxPage) {
                        maxPage = linkPage;
                    }
                }
            });
            
            if (maxPage > page) {
                pagecount = maxPage;
                hasNext = true;
            }
        }
        
        if (!hasNext) {
            const nextBtn = $('.page-next, .next, .pagination .next, a:contains("下一页")');
            hasNext = nextBtn.length > 0 && !nextBtn.hasClass('disabled');
            if (hasNext) {
                pagecount = page + 10;
            }
        }
        
        if (list.length >= farmerConfig.PAGE_LIMIT && !hasNext) {
            hasNext = true;
            pagecount = page + 1;
        }
        
        return {
            list: list,
            page: parseInt(page),
            pagecount: pagecount,
            total: list.length * pagecount
        };
    } catch (error) {
        logger.error('❌ 分类列表错误', error);
        return { list: [], page: parseInt(page), pagecount: 1, total: 0 };
    }
};

// 获取首页推荐 - 合并多个分类（今日更新+电视剧+综艺+动漫），不取电影，去重
const getHomeRecommend = async () => {
    try {
        const url = farmerConfig.host;
        logger.info('🏠 获取首页推荐', { url });
        
        const response = await _http.get(url, { headers: farmerConfig.headers });
        const html = response.data;
        
        const list = [];
        const seenIds = new Set();
        const $ = cheerio.load(html);
        
        // 获取页面标题，用于识别分类
        const modTitles = [];
        $('.mod-hd .item-title').each((i, el) => {
            modTitles.push($(el).text().trim());
        });
        logger.info('📋 页面分类标题', { titles: modTitles });
        
        // 遍历所有globalPicList，跳过电影分类
        const lists = $('.globalPicList');
        lists.each((listIdx, listEl) => {
            const $list = $(listEl);
            const parentSection = $list.closest('.mod');
            const sectionTitle = parentSection.find('.mod-hd .item-title').text().trim();
            
            // 跳过电影分类
            if (sectionTitle.includes('电影')) {
                logger.info(`⏭️ 跳过电影分类（列表${listIdx + 1}）`);
                return;
            }
            
            $list.find('li').each((i, it) => {
                const $it = $(it);
                const title = $it.find('a').attr('title') || $it.find('a').text().trim();
                const pic = $it.find('img').data('src') || $it.find('img').attr('src');
                const desc = $it.find('.sBottom').text().trim();
                const href = $it.find('a').attr('href');
                
                if (title && href) {
                    let vodId = href;
                    if (vodId && vodId.startsWith('/')) {
                        vodId = vodId.substring(1);
                    }
                    
                    // 去重：同一个视频只取一次
                    if (!seenIds.has(vodId)) {
                        seenIds.add(vodId);
                        list.push({
                            vod_id: vodId || '',
                            vod_name: title,
                            vod_pic: pic ? (pic.startsWith('http') ? pic : farmerConfig.host + pic) : '',
                            vod_remarks: desc || ''
                        });
                    }
                }
            });
        });
        
        logger.info(`✅ 获取到 ${list.length} 个首页推荐（去重后，跳过电影）`);
        return list;
    } catch (error) {
        logger.error('❌ 首页推荐错误', error);
        return [];
    }
};

// 修复搜索功能
const searchVod = async (wd, page = 1) => {
    try {
        const url = `${farmerConfig.host}/index.php?m=vod-search`;
        const data = new URLSearchParams();
        data.append("wd", wd);

        console.log('🔍 搜索请求:', url, '关键词:', wd);

        const response = await _http.post(url, data, {
            headers: farmerConfig.headers
        });

        const $ = cheerio.load(response.data);
        const list = [];

        // 参考颖宝旺旺的解析逻辑 [2]
        $("ul#data_list > li").each((i, item) => {
            const $item = $(item);
            const href = $item.find("div.pic > a").attr("href");
            const pic = $item.find("div.pic > a > img").attr("data-src");
            
            // 处理 ID 格式，保持与 getDetail 兼容
            let vodId = href;
            if (vodId && vodId.startsWith('/')) {
                vodId = vodId.substring(1);
            }

            const vod = {
                vod_id: vodId || "",
                vod_name: $item.find("div.txt > span.sTit").text().trim(),
                vod_pic: pic ? (pic.startsWith('http') ? pic : farmerConfig.host + pic) : '',
                vod_remarks: $item.find("div.pic > a > span.sStyle").text().trim(),
            };

            // 获取评分作为备注
            $item.find("div.txt > span.sDes").each((j, uu) => {
                let tmp = $(uu).text().trim();
                if (/^评分:/.test(tmp)) {
                    tmp = tmp.replace("评分:", "");
                    if (tmp !== "暂无") {
                        vod.vod_remarks = tmp;
                    }
                }
            });

            list.push(vod);
        });

        logger.info(`✅ 搜索到 ${list.length} 个结果`);
        return {
            list: list,
            page: parseInt(page),
            pagecount: 1,
            total: list.length
        };
    } catch (error) {
        logger.info('❌ 搜索错误:', error.message);
        return { list: [], page: 1, pagecount: 1, total: 0 };
    }
};

// 详情获取
const getDetail = async (id) => {
    try {
        let detailUrl = id.startsWith('http') ? id : farmerConfig.host + '/' + id;
        logger.info('🔍 获取详情', { id, url: detailUrl });
        
        const response = await _http.get(detailUrl, { headers: farmerConfig.headers });
        const html = response.data;
        const $ = cheerio.load(html);
        
        // 基本信息 - 修正选择器优先级：.type-title是分类名（如"国产剧"），不是剧名！
        const vod_name = $('.title').text().trim() ||
                        $('.page-hd a').attr('title') ||
                        ($('title').text().match(/《([^》]+)》/) || [])[1] ||
                        $('h1').not('.type-title').text().trim() ||
                        $('.type-title').text().trim();
        
        const vod_content = $('.detail-con p').text().trim() || 
                           $('.vod_content').text().trim() ||
                           $('.detail-content').text().trim();
        
        const vod_pic = $('.lazyload').data('src') || 
                       $('.page-hd img').attr('src') ||
                       $('.vodlist_thumb').attr('src') || 
                       $('img.lazy').attr('src');
        
        // 演员信息 - 参考第二个文件的desc选择器
        let vod_actor = '';
        $('.desc_item:contains(主演:), .desc_item:eq(1)').each((i, elem) => {
            const actorText = $(elem).text().replace('主演:', '').replace('演员:', '').trim();
            if (actorText) vod_actor += (i > 0 ? ',' : '') + actorText;
        });
        
        // 导演信息
        let vod_director = '';
        $('.desc_item:contains(导演:)').each((i, elem) => {
            const directorText = $(elem).text().replace('导演:', '').trim();
            if (directorText) vod_director += (i > 0 ? ',' : '') + directorText;
        });
        
        // 年份、地区、类型信息
        let vod_year = '';
        let vod_area = '';
        let vod_type = '';
        
        $('.desc_item').each((i, elem) => {
            const text = $(elem).text();
            if (text.includes('年份:') || text.includes('年代:')) {
                vod_year = text.replace('年份:', '').replace('年代:', '').trim();
            }
            if (text.includes('地区:')) {
                vod_area = text.replace('地区:', '').trim();
            }
            if (text.includes('类型:')) {
                vod_type = text.replace('类型:', '').trim();
            }
        });
        
        // 播放列表提取 - 参考第二个文件的二级选择器
        const playmap = {};
        const playLines = [];
        
        // 处理播放线路 - 参考第二个文件的tabs: ".hd li"
        $('.numlistBox .hd li, .hd li, .play-tab li').each((tabIndex, tabItem) => {
            const form = $(tabItem).text().trim();
            const formattedForm = form === '默认' ? '农民专线' : form;
            
            if (farmerConfig.blockedLines && farmerConfig.blockedLines.some(blocked => formattedForm.includes(blocked))) {
                logger.info(`🚫 屏蔽线路: ${formattedForm}`);
                return;
            }
            
            if (!formattedForm) return;
            
            // 获取对应的播放列表 - 参考第二个文件的lists: ".numList:eq(#id) li"
            const playlist = $('.numList').eq(tabIndex);
            
            if (playlist.length > 0) {
                playmap[formattedForm] = [];
                playlist.find('li').each((i, playItem) => {
                    const title = $(playItem).find('a').text().trim();
                    let urls = $(playItem).find('a').attr('href');
                    
                    if (title && urls) {
                        if (urls.startsWith('/')) {
                            urls = farmerConfig.host + urls;
                        } else if (!urls.startsWith('http')) {
                            urls = farmerConfig.host + '/' + urls;
                        }
                        playmap[formattedForm].push(title + "$" + urls);
                    }
                });
                
                if (playmap[formattedForm].length > 0) {
                    playmap[formattedForm].reverse(); // 反转选集序列
                    playLines.push(formattedForm);
                    logger.info(`✅ 播放线路 ${formattedForm} 找到 ${playmap[formattedForm].length} 个剧集`);
                } else {
                    delete playmap[formattedForm];
                }
            }
        });
        
        // 如果没有找到线路，尝试直接查找
        if (Object.keys(playmap).length === 0) {
            logger.info('🔍 未找到线路选项卡，尝试直接查找播放列表');
            $('.numList li, .play-list li, .playlist li').each((i, playItem) => {
                const title = $(playItem).find('a').text().trim();
                let urls = $(playItem).find('a').attr('href');
                
                if (title && urls) {
                    if (urls.startsWith('/')) {
                        urls = farmerConfig.host + urls;
                    } else if (!urls.startsWith('http')) {
                        urls = farmerConfig.host + '/' + urls;
                    }
                    if (!playmap['农民专线']) {
                        playmap['农民专线'] = [];
                        playLines.push('农民专线');
                    }
                    playmap['农民专线'].push(title + "$" + urls);
                }
            });
            
            if (playmap['农民专线']) {
                playmap['农民专线'].reverse();
                logger.info(`✅ 直接查找找到 ${playmap['农民专线'].length} 个剧集`);
            }
        }
        
        // 如果还是没有找到，创建默认播放线路
        if (Object.keys(playmap).length === 0) {
            logger.warn('⚠️ 未找到播放列表，创建默认线路');
            playmap['农民专线'] = [`第1集$${detailUrl}`];
            playLines.push('农民专线');
        }
        
        // 合并播放线路
        const vod_play_from = playLines.join('$$$');
        const playUrls = playLines.map(line => playmap[line].join("#"));
        const vod_play_url = playUrls.join('$$$');
        
        const detail = {
            vod_id: id,
            vod_name: vod_name,
            vod_pic: vod_pic ? (vod_pic.startsWith('http') ? vod_pic : farmerConfig.host + vod_pic) : '',
            vod_content: '💃颖宝为您介绍剧情并提醒您勿信广告📢📢📢\n' + vod_content,
            vod_actor: vod_actor,
            vod_director: vod_director,
            vod_year: vod_year,
            vod_area: vod_area,
            vod_type: vod_type,
            vod_play_from: '💃颖宝' + vod_play_from || '农民专线',
            vod_play_url: vod_play_url || ''
        };
        
        logger.info('✅ 详情获取成功', { 
            name: vod_name, 
            lines: vod_play_from,
            episodes: playLines.map(line => ({ line, count: playmap[line].length }))
        });
        
        return detail;
    } catch (error) {
        logger.error('❌ 详情获取错误', error);
        return null;
    }
};

// 播放请求处理 - 参考第二个文件的lazy函数
const getPlayUrl = async (playUrl) => {
    try {
        logger.info('🎬 处理播放URL', { url: playUrl });
        
        // 确保URL格式正确
        if (playUrl && !playUrl.startsWith('http')) {
            playUrl = playUrl.startsWith('/') ? 
                farmerConfig.host + playUrl : 
                farmerConfig.host + '/' + playUrl;
        }
        
        logger.info('🔧 处理后的播放URL', { url: playUrl });
        
        // 检查是否是直接播放链接
        const isDirectPlayable = playUrl.match(/\.(m3u8|mp4|flv|avi|mkv|ts)/i);
        
        if (isDirectPlayable) {
            logger.info('✅ 直接播放链接');
            return {
                parse: 0,
                url: playUrl,
                header: {
                    "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1",
                    "Referer": farmerConfig.host + "/",
                    "Origin": farmerConfig.host
                }
            };
        } else {
            logger.info('🔍 需要解析播放页');
            
            // 参考第二个文件的lazy函数逻辑
            const html = await _http.get(playUrl, { 
                headers: {
                    ...farmerConfig.headers,
                    "Referer": farmerConfig.host + "/"
                }
            }).then(res => res.data);
            
            // 提取mac_url和mac_from
            const macUrlMatch = html.match(/mac_url='([^']+)'/);
            const macFromMatch = html.match(/mac_from='([^']+)'/);
            
            if (macUrlMatch && macFromMatch) {
                const macUrl = macUrlMatch[1];
                const macFrom = macFromMatch[1];
                
                logger.info('📋 提取到mac参数', { macFrom });
                
                // 解析集数索引
                const numMatch = playUrl.match(/num-(\d+)/);
                const srcMatch = playUrl.match(/src-(\d+)/);
                const index = numMatch ? parseInt(numMatch[1]) - 1 : 0;
                const srcIndex = srcMatch ? parseInt(srcMatch[1]) - 1 : 0;
                
                // 分割播放线路
                const lines = macUrl.split('$$$');
                if (lines[srcIndex]) {
                    const playUrls = lines[srcIndex].split('#');
                    if (playUrls[index]) {
                        const playUrlPart = playUrls[index].split('$')[1];
                        
                        if (playUrlPart) {
                            // 请求播放器API - 参考第二个文件
                            const playerUrl = `https://api.wwgz.cn:520/player/?url=${encodeURIComponent(playUrlPart)}`;
                            logger.info('🎮 请求播放器', { url: playerUrl });
                            
                            const playerHtml = await _http.get(playerUrl, {
                                headers: {
                                    "Referer": farmerConfig.host + "/",
                                    "User-Agent": farmerConfig.headers["User-Agent"]
                                }
                            }).then(res => res.data);
                            
                            // 提取真实m3u8地址
                            const m3u8Match = playerHtml.match(/"url":\s*"([^"]+)"/) || 
                                             playerHtml.match(/url['"]?\s*[:=]\s*['"]([^'"]+)['"]/i) ||
                                             playerHtml.match(/(https?:\/\/[^\s"']+\.m3u8[^\s"']*)/i);
                            
                            if (m3u8Match) {
                                let realUrl = m3u8Match[1].replace(/\\/g, '');
                                logger.info('✅ 解析成功，真实视频地址', { url: realUrl });
                                return {
                                    parse: 0,
                                    url: realUrl,
                                    header: {
                                        "User-Agent": farmerConfig.headers["User-Agent"],
                                        "Referer": playerUrl,
                                        "Origin": farmerConfig.host
                                    }
                                };
                            }
                        }
                    }
                }
            }
            
            // 备用解析方法
            const realVideoUrl = await parseFarmerPlayPage(playUrl);
            
            if (realVideoUrl) {
                logger.info('✅ 备用解析成功', { url: realVideoUrl });
                return {
                    parse: 0,
                    url: realVideoUrl,
                    header: {
                        "User-Agent": farmerConfig.headers["User-Agent"],
                        "Referer": playUrl,
                        "Origin": farmerConfig.host
                    }
                };
            }
            
            logger.warn('⚠️ 未解析出真实地址，让TVBox尝试解析');
            return {
                parse: 1,
                url: playUrl,
                header: {
                    "User-Agent": farmerConfig.headers["User-Agent"],
                    "Referer": farmerConfig.host + "/",
                    "Origin": farmerConfig.host
                }
            };
        }
    } catch (error) {
        logger.error('❌ 播放处理错误', error);
        return {
            parse: 1,
            url: playUrl,
            header: farmerConfig.headers
        };
    }
};

// TVBox T4 接口请求处理
const handleT4Request = async (req) => {
    const startTime = Date.now();
    const requestId = Math.random().toString(36).substring(7);
    // 详细记录所有请求参数
    const query = req.query || req.body || {};
    logger.info(`[${requestId}] 📥 原始请求参数`, { 
        query: JSON.stringify(query),
        keys: Object.keys(query)
    });
    try {
        const { ac, t, pg, wd, ids, play, quick, ext } = req.query || req.body || {};
        const page = parseInt(pg) || 1;

        logger.info(`[${requestId}] 📥 T4请求参数`, { ac, t, pg, wd: wd ? '***' : null, ids: ids ? '***' : null, play: play ? '***' : null, quick });

        // 1. 播放请求 
        if (play) {
            logger.info(`[${requestId}] 🎬 播放请求`);
            const result = await getPlayUrl(play);
            logger.info(`[${requestId}] ✅ 播放请求完成`, { duration: Date.now() - startTime });
            return result;
        }
        // 2. 搜索请求
        if (wd) {
            // 1. 解码
            const keyword = decodeURIComponent(wd || '').trim();
            logger.info(`[${requestId}] 🔍 搜索请求`, { keyword });

            let result = await searchVod(keyword, page);   // 2. 用解码后的 keyword
            if (quick === 'true') {
                result.list = result.list.slice(0, 10);
            }
            logger.info(`[${requestId}] ✅ 搜索请求完成`, {
                duration: Date.now() - startTime,
                results: result.list.length
            });
            return {
                list: result.list,
                page: result.page,
                pagecount: result.pagecount,
                limit: farmerConfig.PAGE_LIMIT,
                total: result.total
            };
        }


        // 3. 详情请求
        if (ids) {
            logger.info(`[${requestId}] 📋 详情请求`, { id: ids });
            const detail = await getDetail(ids);
            logger.info(`[${requestId}] ✅ 详情请求完成`, { duration: Date.now() - startTime });
            return {
                list: detail ? [detail] : [],
                page: 1,
                pagecount: 1,
                total: detail ? 1 : 0
            };
        }

        // 4. 分类内容请求（包含筛选）
        if (t && (ac === 'detail' || ac === 'list' || !ac)) {
            logger.info(`[${requestId}] 📁 分类列表请求`, { type: t, page, ext });
            
            const extendParams = {};
            
            if (ext) {
                try {
                    const decodedExt = Buffer.from(ext, 'base64').toString('utf-8');
                    const parsedExt = JSON.parse(decodedExt);
                    Object.assign(extendParams, parsedExt);
                    logger.info(`[${requestId}] 📋 解析筛选参数成功`, { parsed: parsedExt });
                } catch (e) {
                    logger.error(`[${requestId}] ❌ ext参数解析错误`, e);
                    try {
                        const parsedExt = JSON.parse(ext);
                        Object.assign(extendParams, parsedExt);
                    } catch (e2) {
                        logger.error(`[${requestId}] ❌ ext直接解析也失败`, e2);
                    }
                }
            }
            
            const result = await getCategoryList(t, page, extendParams);
            
            logger.info(`[${requestId}] ✅ 分类请求完成`, { 
                duration: Date.now() - startTime,
                listCount: result.list.length 
            });
            
            return {
                list: result.list,
                page: result.page,
                pagecount: result.pagecount,
                limit: farmerConfig.PAGE_LIMIT,
                total: result.total
            };
        }
        // 5. 首页/分类列表请求
        if (!ac || ac === 'class') {
            logger.info(`[${requestId}] 🏠 首页/分类列表请求`);
            const [classes, filters] = await Promise.all([
                getClasses(),      // 原始分类数组
                getFilter()        // 返回的是 { "1": [...], "2": [...] }
            ]);

            // 直接使用 getFilter 返回的对象格式作为 filters
            // TVBox T4 标准格式: filters: { type_id: [filter_items] }
            const filtersObj = filters || {};

            // 分类列表接口只返回 class + filters
            if (ac === 'class') {
                logger.info(`[${requestId}] ✅ 分类列表请求完成`, { duration: Date.now() - startTime });
                return { class: classes, filters: filtersObj };
            }

            // 首页接口
            const homeList = await getHomeRecommend();
            logger.info(`[${requestId}] ✅ 首页请求完成`, { duration: Date.now() - startTime });
            return {
                class: classes,
                filters: filtersObj,   // 关键字段，直接使用 getFilter 的结果
                list: homeList.slice(0, 24),
                page: 1,
                pagecount: 1,
                total: homeList.length
            };
        }


        logger.warn(`[${requestId}] ⚠️ 未知T4请求类型`);
        return { list: [], page: 1, pagecount: 1 };
    } catch (error) {
        logger.error(`[${requestId}] ❌ T4请求处理错误`, error);
        return { 
            list: [], 
            page: 1, 
            pagecount: 1,
            error: error.message 
        };
    }
};

const meta = {
    key: "YingBao",
    name: "[纯]颖宝",
    type: 4,
    api: "/video/YingBao",
    searchable: 1,
    quickSearch: 1,
    changeable: 1,
    filterable: 1
};

module.exports = async (app, opt) => {

    // 接入日志系统
    if (app && app.log) {
        logger.info = (msg, data) => app.log.info({ ...data, msg });
        logger.error = (msg, error) => app.log.error({ err: error, msg });
        logger.warn = (msg, data) => app.log.warn({ ...data, msg });
        logger.debug = (msg, data) => app.log.debug({ ...data, msg });
    }
    // 支持自定义host配置
    if (opt?.farmerHost) {
        farmerConfig.host = opt.farmerHost.replace(/\/$/, '');
        logger.info('📝 使用自定义host', { host: farmerConfig.host });
    }
    
    // 注册GET接口（TVBox T4默认GET）
    app.get(meta.api, async (req, reply) => {
        const result = await handleT4Request(req);
        return result;
    });
    
    // 兼容POST请求
    app.post(meta.api, async (req, reply) => {
        const result = await handleT4Request({ query: req.body });
        return result;
    });
    
    opt.sites.push(meta);
    logger.info('✅ 农民影视插件已注册', { api: meta.api });
};