/* 落雪 Music — 洛雪音乐 T4 桥接源
 * 将 lx-music-sync-server 的音乐能力接入 TVBox。
 * 用户名密码在此文件顶部配置，修改后重启服务生效。
 * 惰性播放：_detail 不调 /api/music/url，改为打包 play token，
 * _play 收到 token 后才惰性解析播放地址。
 * 支持通过 flag 参数选择音质（如 “高品音质”、“无损音质” 等）。
 */
const axios = require('axios');

/* ── 用户配置（按需修改） ────────────────────── */
const LX_SERVER = 'http://127.0.0.1:9527';   // lxserver 地址
const LX_USERNAME = 'admin';                  // lxserver 用户名
const LX_PASSWORD = '123456';                 // lxserver 密码（见 config.js）

/* ── 常量 ────────────────────────────────────── */

// 最近歌曲列表缓存：key=source → songs[]
// 用于 _detail 构建连续播放列表
const listCache = new Map();
const LIST_CACHE_TTL = 5 * 60 * 1000; // 5 分钟
const API = '/video/luoyu_bridge';
const UA = 'Mozilla/5.0 (Linux; Android 12; TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36';
const PAGE_SIZE = 30;

const SOURCE_NAMES = Object.freeze({
  kw: '酷我音乐', kg: '酷狗音乐', tx: 'QQ音乐', wy: '网易云音乐', mg: '咪咕音乐',
});
const QUALITY_MAP = Object.freeze({
  '128k': '标准音质',
  '320k': '高品音质',
  flac: '无损音质',
  flac24bit: 'Hi-Res',
});
const QUALITY_LIST = ['320k', '128k', 'flac', 'flac24bit'];

// 反向映射：显示名称 -> 音质代码
const QUALITY_NAME_REVERSE = {};
Object.keys(QUALITY_MAP).forEach(k => {
  QUALITY_NAME_REVERSE[QUALITY_MAP[k]] = k;
});

const meta = {
  key: 'luoyu_bridge',
  name: '[听]落雪Music',
  type: 4,
  api: API,
  searchable: 1,
  quickSearch: 1,
  filterable: 0,
  changeable: 0,
};

/* ── 分类 ────────────────────────────────────── */
const classes = [
  { type_id: 'kw', type_name: '酷我音乐' },
  { type_id: 'kg', type_name: '酷狗音乐' },
  { type_id: 'tx', type_name: 'QQ音乐' },
  { type_id: 'wy', type_name: '网易云音乐' },
  { type_id: 'mg', type_name: '咪咕音乐' },
];

/* ── HTTP 客户端 ─────────────────────────────── */
const http = axios.create({
  timeout: 25000,
  proxy: false,
  maxRedirects: 5,
  headers: { 'User-Agent': UA, 'Accept-Language': 'zh-CN,zh;q=0.9' },
  validateStatus: s => s >= 200 && s < 500,
});

/* ── 工具函数 ────────────────────────────────── */
function cleanText(v) {
  return String(v || '')
    .replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();
}

function lxUrl(path, params) {
  const base = String(LX_SERVER).replace(/\/+$/, '');
  const parts = [];
  if (params && typeof params === 'object') {
    Object.keys(params).forEach(k => {
      const v = params[k];
      if (v !== undefined && v !== null && v !== '') parts.push(encodeURIComponent(k) + '=' + encodeURIComponent(String(v)));
    });
  }
  return base + '/' + (path || '').replace(/^\//, '') + (parts.length ? '?' + parts.join('&') : '');
}

/* ── 缓存清理（避免内存泄漏） ────────────────── */
function cleanListCache() {
  const now = Date.now();
  for (const [key, entry] of listCache) {
    if (now - entry.t > LIST_CACHE_TTL) {
      listCache.delete(key);
    }
  }
}

let cacheTimerStarted = false;
function startCacheTimer() {
  if (cacheTimerStarted) return;
  cacheTimerStarted = true;
  setInterval(cleanListCache, LIST_CACHE_TTL);
}

function getListCache(key) {
  cleanListCache();
  const entry = listCache.get(key);
  if (!entry) return null;
  if (Date.now() - entry.t > LIST_CACHE_TTL) {
    listCache.delete(key);
    return null;
  }
  return entry;
}

/* ── 认证管理（对齐 Python 逻辑） ────────────── */
const authState = { token: '', expires: 0 };
let loginPromise = null;

async function lxLogin(force) {
  if (!force && authState.token && Date.now() < authState.expires) {
    return authState.token;
  }
  if (loginPromise) {
    return loginPromise;
  }
  loginPromise = (async () => {
    try {
      if (!LX_USERNAME || !LX_PASSWORD) throw new Error('请先在落雪Music.js中配置用户名与密码');
      const res = await http.post(lxUrl('/api/user/login'), { username: LX_USERNAME, password: LX_PASSWORD }, {
        headers: { 'Content-Type': 'application/json' },
        responseType: 'text', timeout: 10000,
      });
      if (res.status < 200 || res.status >= 300) throw new Error('登录失败: HTTP ' + res.status);
      const body = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
      if (!body || !body.success || !body.token) throw new Error('lxserver 登录失败: ' + JSON.stringify(body).slice(0, 100));
      authState.token = String(body.token);
      authState.expires = Date.now() + 60 * 60 * 1000;
      return authState.token;
    } finally {
      loginPromise = null;
    }
  })();
  return loginPromise;
}

function shouldUseAuth() {
  const username = String(LX_USERNAME || '').trim();
  return !(!username || ['default', 'open', '_open'].includes(username));
}

/* ── API 请求 ────────────────────────────────── */
async function lxGet(path, params) {
  const url = lxUrl(path, params);
  const res = await http.get(url, { responseType: 'text' });
  if (res.status < 200 || res.status >= 300) throw new Error('HTTP ' + res.status + ': ' + url);
  return typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
}

async function lxPostAuth(path, body, retried) {
  const url = lxUrl(path);
  const headers = { 'Content-Type': 'application/json' };
  if (shouldUseAuth()) {
    const token = await lxLogin(false);
    headers['X-User-Token'] = token;
    headers['X-User-Name'] = LX_USERNAME;
  }
  const res = await http.post(url, body || {}, { headers, responseType: 'text', timeout: 15000 });
  const data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
  if (res.status === 401 && !retried && shouldUseAuth()) {
    await lxLogin(true);
    return lxPostAuth(path, body, true);
  }
  if (res.status < 200 || res.status >= 300) throw new Error('HTTP ' + res.status + ': ' + url);
  return data;
}

/* ── 数据映射 ────────────────────────────────── */
function listOf(value) {
  if (Array.isArray(value)) return value;
  if (!value || typeof value !== 'object') return [];
  for (const key of ['list', 'items', 'songs', 'tracks', 'data', 'result']) {
    if (Array.isArray(value[key])) return value[key];
    if (value[key] && typeof value[key] === 'object') {
      const nested = listOf(value[key]);
      if (nested.length) return nested;
    }
  }
  return [];
}

function first(item, paths, fallback) {
  for (const p of paths) {
    const parts = p.split('.');
    let v = item;
    for (const part of parts) {
      if (!v || typeof v !== 'object') { v = undefined; break; }
      v = v[part];
    }
    if (v !== undefined && v !== null && v !== '') return v;
  }
  return fallback;
}

function normalizeSong(raw, source) {
  const item = Object.assign({}, raw || {});
  if (item.meta && typeof item.meta === 'object') {
    Object.keys(item.meta).forEach(k => {
      if (item[k] === undefined || item[k] === null || item[k] === '') item[k] = item.meta[k];
    });
  }
  return {
    source: source || first(item, ['source'], '') || '',
    songmid: String(first(item, ['songmid', 'songId', 'id', 'copyrightId', 'hash'], '') || ''),
    hash: String(first(item, ['hash'], '') || ''),
    name: cleanText(first(item, ['name', 'songName', 'title'], '') || ''),
    singer: cleanText(first(item, ['singer', 'artist', 'author'], '') || ''),
    album: cleanText(first(item, ['albumName', 'album.name', 'album'], '') || ''),
    img: first(item, ['img', 'pic', 'picUrl', 'cover', 'coverUrl'], '') || '',
    interval: String(first(item, ['interval', 'duration'], '') || ''),
    types: Array.isArray(item.types) ? item.types : [],
    _types: item._types && typeof item._types === 'object' ? item._types : {},
    songId: String(first(item, ['songId', 'id'], '') || ''),
    strMediaMid: String(first(item, ['strMediaMid'], '') || ''),
    copyrightId: String(first(item, ['copyrightId'], '') || ''),
    lrcUrl: String(first(item, ['lrcUrl'], '') || ''),
    albumId: String(first(item, ['albumId'], '') || ''),
    typeUrl: item.typeUrl && typeof item.typeUrl === 'object' ? item.typeUrl : {},
  };
}

/* ── ID 编码/解码 ───────────────────────────── */
function encodeSongId(song) {
  const payload = {
    s: song.source, m: song.songmid, n: song.name,
    a: song.singer, h: song.hash,
    i: song.img ? song.img.slice(0, 200) : '',
    t: song.types, _t: song._types,
    sm: song.strMediaMid, c: song.copyrightId,
    l: song.lrcUrl, al: song.albumId, si: song.songId,
  };
  return 'lx_' + Buffer.from(JSON.stringify(payload)).toString('base64url');
}

function decodeSongId(encoded) {
  try {
    const raw = String(encoded || '').replace(/^lx_/, '');
    const json = JSON.parse(Buffer.from(raw, 'base64url').toString('utf8'));
    return normalizeSong({
      source: json.s, songmid: json.m, name: json.n, singer: json.a,
      hash: json.h, img: json.i, types: json.t, _types: json._t,
      strMediaMid: json.sm, copyrightId: json.c, lrcUrl: json.l, albumId: json.al,
      songId: json.si || '',
    }, json.s);
  } catch (_) { return null; }
}

function encodePlayToken(quality, song) {
  const payload = {
    q: quality,
    s: {
      source: song.source, songmid: song.songmid, hash: song.hash, songId: song.songId,
      name: song.name, singer: song.singer,
      types: song.types, _types: song._types,
      strMediaMid: song.strMediaMid, copyrightId: song.copyrightId,
      lrcUrl: song.lrcUrl, albumId: song.albumId,
      img: song.img ? song.img.slice(0, 200) : '',
    },
  };
  return 'pl_' + Buffer.from(JSON.stringify(payload)).toString('base64url');
}

function decodePlayToken(token) {
  try {
    const raw = String(token || '').replace(/^pl_/, '');
    const json = JSON.parse(Buffer.from(raw, 'base64url').toString('utf8'));
    return {
      quality: json.q,
      song: normalizeSong(json.s, json.s ? json.s.source : ''),
    };
  } catch (_) { return null; }
}

/* ── 工具函数 ────────────────────────────────── */
function songToVod(song, source) {
  const n = normalizeSong(song, source);
  return {
    vod_id: encodeSongId(n),
    vod_name: n.name || '未知歌曲',
    vod_pic: n.img || '',
    vod_remarks: [n.singer, n.interval].filter(Boolean).join(' · '),
    vod_content: [n.singer, n.album].filter(Boolean).join(' · '),
    vod_play_from: SOURCE_NAMES[n.source] || n.source || 'Lx音乐',
    vod_play_url: (n.name || '未知') + '$' + encodeSongId(n),
  };
}

function pageResult(list, pg, total) {
  const page = Math.max(parseInt(pg || '1', 10) || 1, 1);
  const tc = Number(total || list.length || 0);
  return { list, page, pagecount: Math.max(1, tc ? Math.ceil(tc / PAGE_SIZE) : (list.length >= PAGE_SIZE ? page + 1 : page)), limit: PAGE_SIZE, total: tc };
}

function availableQualities(song) {
  const set = new Set();
  (song.types || []).forEach(t => {
    const type = typeof t === 'string' ? t : (t && t.type);
    if (type) set.add(String(type));
  });
  Object.keys(song._types || {}).forEach(k => { if (k) set.add(String(k)); });
  if (!set.size) return ['320k'];
  const match = QUALITY_LIST.filter(q => set.has(q));
  return match.length ? match : Array.from(set);
}

// 根据用户传入的 flag（音质名称或代码）构建优先尝试的音质队列
function buildQualityQueue(requestedQuality, preferredQuality) {
  // 默认降级顺序
  const base = ['320k', '128k', 'flac', 'flac24bit'];
  // 解析 preferredQuality 为音质代码
  let preferredCode = '';
  if (preferredQuality) {
    // 直接匹配代码
    if (QUALITY_MAP[preferredQuality]) {
      preferredCode = preferredQuality;
    } else {
      // 尝试反向映射名称 -> 代码
      preferredCode = QUALITY_NAME_REVERSE[preferredQuality] || '';
    }
  }
  // 如果 specified 有效，把它放到队列最前面
  if (preferredCode) {
    const queue = [preferredCode];
    base.forEach(q => {
      if (q !== preferredCode) queue.push(q);
    });
    return queue;
  }
  // 否则用 requestedQuality 作为首选
  if (requestedQuality && QUALITY_MAP[requestedQuality]) {
    const queue = [requestedQuality];
    base.forEach(q => {
      if (q !== requestedQuality) queue.push(q);
    });
    return queue;
  }
  return base;
}

async function resolveSongUrl(song, quality) {
  const q = quality || '320k';
  // 直接传整个 song 对象
  const result = await lxPostAuth('/api/music/url', {
    songInfo: song,
    quality: q,
    enableAutoSwitchApiSource: true,
  });
  if (!result || !result.url) throw new Error('音源没有返回播放地址');
  return {
    url: String(result.url).replace(/^(?:music|mp3):\/\//i, ''),
    headers: result.header || result.headers || {},
    quality: result.quality || q,
  };
}

/* ── TVBox 接口 ─────────────────────────────── */
async function _home() {
  let list = [];
  try {
    const boards = await lxGet('/api/music/leaderboard/boards', { source: 'kw' });
    const bl = listOf(boards);
    if (bl.length) {
      const bid = first(bl[0], ['bangid', 'id', 'sourceId'], 'hot');
      const songs = await lxGet('/api/music/leaderboard/list', { source: 'kw', bangid: bid, page: 1 });
      const allSongs = listOf(songs);
      const rawSongs = allSongs.map(s => normalizeSong(s, 'kw')).filter(s => s.songmid);
      if (rawSongs.length) listCache.set('kw', { songs: rawSongs, t: Date.now() });
      list = allSongs.slice(0, 30).map(s => songToVod(s, 'kw')).filter(v => v.vod_id && v.vod_name);
    }
  } catch (_) {}
  return { class: classes, list, page: 1, pagecount: 1, total: list.length };
}

async function _category({ id, page }) {
  const pg = Math.max(parseInt(page || '1', 10) || 1, 1);
  const source = String(id || 'kw').trim();
  try {
    const boards = await lxGet('/api/music/leaderboard/boards', { source });
    const bl = listOf(boards);
    if (!bl.length) return { list: [], page: pg, pagecount: 1, total: 0 };
    let allVods = [];
    let allRaw = [];
    for (let i = 0; i < Math.min(3, bl.length); i++) {
      const bid = first(bl[i], ['bangid', 'id', 'sourceId'], '');
      if (!bid) continue;
      try {
        const songs = await lxGet('/api/music/leaderboard/list', { source, bangid: bid, page: 1 });
        const rawList = listOf(songs);
        allVods.push(...rawList.map(s => songToVod(s, source)).filter(v => v.vod_id && v.vod_name));
        allRaw.push(...rawList.map(s => normalizeSong(s, source)).filter(s => s.songmid));
      } catch (_) {}
    }
    if (allRaw.length) listCache.set(source, { songs: allRaw, t: Date.now() });
    return pageResult(allVods.slice((pg - 1) * PAGE_SIZE, pg * PAGE_SIZE), pg, allVods.length);
  } catch (e) {
    return { code: 500, msg: e.message || String(e), list: [], page: pg, pagecount: 1, total: 0 };
  }
}

/* ── _detail：惰性打包 ── */
async function _detail({ ids }) {
  const result = [];
  for (const rawId of (ids || []).map(v => String(v || '').trim()).filter(Boolean)) {
    try {
      const song = decodeSongId(rawId);
      if (!song || !song.songmid) { result.push({ vod_id: rawId, vod_name: '落雪Music', vod_play_from: 'Lx音乐', vod_play_url: '' }); continue; }
      const qs = availableQualities(song);
      if (!qs.length) qs.push('320k');
      let playlistSongs = [song];
      const cached = getListCache(song.source);
      if (cached && cached.songs.length > 1) {
        playlistSongs = cached.songs.slice();
        const idx = playlistSongs.findIndex(s => s.songmid === song.songmid);
        if (idx > 0) {
          const [clicked] = playlistSongs.splice(idx, 1);
          playlistSongs.unshift(clicked);
        }
      }
      const playLines = [];
      const playFrom = [];
      for (const q of qs) {
        const episodes = playlistSongs.map(s =>
          (s.name || '未知') + '$' + encodePlayToken(q, s)
        );
        playLines.push(episodes.join('#'));
        playFrom.push(QUALITY_MAP[q] || q);
      }
      result.push({
        vod_id: rawId,
        vod_name: song.name || '未知歌曲',
        vod_pic: song.img || '',
        type_name: song.singer || '',
        vod_remarks: [song.singer, playlistSongs.length > 1 ? (song.singer + ' · 共' + playlistSongs.length + '首') : ''].filter(Boolean).join(' · '),
        vod_content: [song.singer, song.album].filter(Boolean).join(' · '),
        vod_play_from: playFrom.join('$$$'),
        vod_play_url: playLines.join('$$$'),
      });
    } catch (e) { result.push({ vod_id: rawId, vod_name: '落雪Music', vod_play_from: 'Lx音乐', vod_play_url: '' }); }
  }
  return { list: result };
}

/* ── _search ─────────────────────────────────── */
async function _search({ wd, page }) {
  const pg = Math.max(parseInt(page || '1', 10) || 1, 1);
  const keyword = cleanText(String(wd || ''));
  if (!keyword) return { list: [], page: pg, pagecount: 1, total: 0 };
  try {
    const allSongs = []; const seen = new Set();
    for (const src of ['kw', 'kg', 'tx', 'wy']) {
      try {
        const result = await lxGet('/api/music/search', { source: src, type: 'song', name: keyword, page: 1, limit: 20 });
        (listOf(result) || []).forEach(raw => {
          const n = normalizeSong(raw, src);
          const k = n.source + ':' + n.songmid;
          if (!n.songmid || seen.has(k)) return;
          seen.add(k); allSongs.push(songToVod(n, n.source));
        });
      } catch (_) {}
    }
    return pageResult(allSongs.slice((pg - 1) * PAGE_SIZE, pg * PAGE_SIZE).filter(v => v.vod_id && v.vod_name), pg, allSongs.length);
  } catch (e) {
    return { code: 500, msg: e.message || String(e), list: [], page: pg, pagecount: 1, total: 0 };
  }
}

/* ── 歌词 ────────────────────────────────────── */
async function fetchLyrics(song, retried = false) {
  try {
    const token = authState.token || (shouldUseAuth() ? await lxLogin(false).catch(() => '') : '');
    const params = {
      source: song.source || '', songmid: song.songmid || '',
      songId: song.songId || '', name: song.name || '',
      singer: song.singer || '', hash: song.hash || '',
      interval: song.interval || '', copyrightId: song.copyrightId || '',
      albumId: song.albumId || '', lrcUrl: song.lrcUrl || '',
    };
    const headers = { 'User-Agent': UA };
    if (token) { headers['X-User-Token'] = token; headers['X-User-Name'] = LX_USERNAME; }
    const res = await http.get(lxUrl('/api/music/lyric', params), { headers, responseType: 'text', timeout: 8000 });
    if (res.status === 401 && !retried && shouldUseAuth()) {
      await lxLogin(true);
      return fetchLyrics(song, true);
    }
    if (res.status < 200 || res.status >= 300) return '';
    const raw = typeof res.data === 'string' ? res.data : String(res.data || '');
    try {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') {
        for (const key of ['lyric', 'lrc', 'rawLrc']) {
          if (typeof parsed[key] === 'string') return parsed[key];
        }
      }
    } catch (_) {}
    return raw;
  } catch (_) {}
  return '';
}

/* ── _play：惰性解析（支持 flag 音质选择） ── */
async function _play({ id, flag }) {
  const rawId = String(id || '').trim();
  if (/^https?:\/\//i.test(rawId)) {
    return { parse: 0, jx: 0, playUrl: '', url: rawId, header: { 'User-Agent': UA, Referer: LX_SERVER + '/' } };
  }

  // 尝试 play token（pl_ 前缀）
  const decoded = decodePlayToken(rawId);
  if (decoded && decoded.song && decoded.song.songmid) {
    const song = decoded.song;
    // 构建音质尝试队列（优先使用 flag 指定的音质）
    const qualities = buildQualityQueue(decoded.quality, flag);
    for (const q of qualities) {
      try {
        const r = await resolveSongUrl(song, q);
        const lrc = await fetchLyrics(song);
        return {
          parse: 0, jx: 0, playUrl: '', url: r.url,
          header: Object.assign({ 'User-Agent': UA, Referer: LX_SERVER + '/' }, r.headers || {}),
          lrc: lrc,
          artwork: song.img || '',
        };
      } catch (_) {}
    }
    return { parse: 0, jx: 0, url: '', msg: '获取播放地址失败', header: { 'User-Agent': UA } };
  }

  // 回退：旧版 song ID（lx_ 前缀）
  const song = decodeSongId(rawId);
  if (song && song.songmid) {
    const qualities = buildQualityQueue('', flag).filter(q => availableQualities(song).includes(q));
    for (const q of qualities) {
      try {
        const r = await resolveSongUrl(song, q);
        const lrc = await fetchLyrics(song);
        return {
          parse: 0, jx: 0, playUrl: '', url: r.url,
          header: Object.assign({ 'User-Agent': UA, Referer: LX_SERVER + '/' }, r.headers || {}),
          lrc: lrc,
          artwork: song.img || '',
        };
      } catch (_) {}
    }
  }

  return { parse: 0, jx: 0, url: '', header: { 'User-Agent': UA } };
}

/* ── 注册路由 ────────────────────────────────── */
module.exports = async (app, opt) => {
  startCacheTimer();
  app.get(meta.api, async (req) => {
    const { t, ac, pg, ids, play, wd, quick, flag } = req.query || {};
    try {
      if (play) return await _play({ id: play, flag });
      if (wd) return await _search({ wd, page: pg || 1, quick });
      if (!ac) return await _home();
      if (ac === 'detail') {
        if (ids) return await _detail({ ids: String(ids).split(',').map(v => v.trim()).filter(Boolean) });
        if (t) return await _category({ id: t, page: pg || 1 });
      }
      return req.query;
    } catch (e) {
      return { code: 500, msg: e.message || String(e), list: [] };
    }
  });
  opt.sites.push(meta);
};