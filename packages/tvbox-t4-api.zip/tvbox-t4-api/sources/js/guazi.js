const axios = require("axios");
const crypto = require("crypto");
const fs = require("fs");
const http = require("http");
const https = require("https");
const path = require("path");

// 对齐最新 Guazi Java 源（2026-07）：动态 token + 新 AES/headers
const API_HOSTS = [
  "https://api.6a7nnf7.com",
  "https://api.umygrx3.com",
  "https://api.rmedphk.com",
  "https://api.w32z7vtd.com",
  "https://apinew.uozvr.com",
];

const AES_KEY = "OITxa5OqAYjhswxx";
const AES_IV = "rCMNwZASNBKZ8mXV";
const DEVICE_OLD_KEY = "aLFBMWpxBrIDAD1Si/KVvm41";
const RSA_PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDUM5+/y8sPsWkd1/RQS64X259E
UwxFXFE5HlA65MqrxnPs0JqoSRojSDy5QhwvROlaD6TwRQHKMY2OAZ6SnQeUJsCh
TEFIR9qUkwrs3/MVUMxjsv6JS6Oe/juclyJGTgVmDhB55EafXsD0SQYVj/QXXsxR
6ewR5E2kL52yAAD4yQIDAQAB
-----END PUBLIC KEY-----`;
const RSA_PRIVATE_KEY = `-----BEGIN PRIVATE KEY-----
MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGAe6hKrWLi1zQmjTT1
ozbE4QdFeJGNxubxld6GrFGximxfMsMB6BpJhpcTouAqywAFppiKetUBBbXwYsYU
1wNr648XVmPmCMCy4rY8vdliFnbMUj086DU6Z+/oXBdWU3/b1G0DN3E9wULRSwcK
ZT3wj/cCI1vsCm3gj2R5SqkA9Y0CAwEAAQKBgAJH+4CxV0/zBVcLiBCHvSANm0l7
HetybTh/j2p0Y1sTXro4ALwAaCTUeqdBjWiLSo9lNwDHFyq8zX90+gNxa7c5EqcW
V9FmlVXr8VhfBzcZo1nXeNdXFT7tQ2yah/odtdcx+vRMSGJd1t/5k5bDd9wAvYdI
DblMAg+wiKKZ5KcdAkEA1cCakEN4NexkF5tHPRrR6XOY/XHfkqXxEhMqmNbB9U34
saTJnLWIHC8IXys6Qmzz30TtzCjuOqKRRy+FMM4TdwJBAJQZFPjsGC+RqcG5UvVM
iMPhnwe/bXEehShK86yJK/g/UiKrO87h3aEu5gcJqBygTq3BBBoH2md3pr/W+hUM
WBsCQQChfhTIrdDinKi6lRxrdBnn0Ohjg2cwuqK5zzU9p/N+S9x7Ck8wUI53DKm8
jUJE8WAG7WLj/oCOWEh+ic6NIwTdAkEAj0X8nhx6AXsgCYRql1klbqtVmL8+95KZ
K7PnLWG/IfjQUy3pPGoSaZ7fdquG8bq8oyf5+dzjE/oTXcByS+6XRQJAP/5ciy1b
L3NhUhsaOVy55MHXnPjdcTX0FaLi+ybXZIfIQ2P4rb19mVq1feMbCXhz+L1rG8oa
t5lYKfpe8k83ZA==
-----END PRIVATE KEY-----`;

const LIMIT = 30;
const PLAY_UA = "Lavf/57.83.100";
const PLAY_REFERER = "http://WJiZxLXA2.com/";
const AUTH_FILE = process.env.GUAZI_AUTH_FILE || path.join("/tmp", "guazi_auth.json");

const meta = {
  key: "guazi",
  name: "[纯]瓜子",
  type: 4,
  api: "/video/guazi",
  searchable: 1,
  quickSearch: 1,
  filterable: 1,
  changeable: 0,
};

const CLASSES = [
  { type_id: "1", type_name: "电影" },
  { type_id: "2", type_name: "国产剧" },
  { type_id: "4", type_name: "动漫" },
  { type_id: "64", type_name: "短剧" },
  { type_id: "3", type_name: "综艺" },
  { type_id: "5", type_name: "海外剧" },
];

// Java SUB_MAP
const SUB_MAP = {
  "1": "5",
  "2": "12",
  "3": "30",
  "4": "22",
  "64": "",
  "5": "0",
};

const AREA_FILTER = {
  key: "area",
  name: "地区",
  value: [
    { n: "全部", v: "0" },
    { n: "大陆", v: "大陆" },
    { n: "香港", v: "香港" },
    { n: "台湾", v: "台湾" },
    { n: "美国", v: "美国" },
    { n: "韩国", v: "韩国" },
    { n: "日本", v: "日本" },
    { n: "英国", v: "英国" },
    { n: "法国", v: "法国" },
    { n: "泰国", v: "泰国" },
    { n: "印度", v: "印度" },
    { n: "其他", v: "其他" },
  ],
};
const YEAR_FILTER = {
  key: "year",
  name: "年份",
  value: [
    { n: "全部", v: "0" },
    ...Array.from({ length: 22 }, (_, index) => {
      const year = String(2026 - index);
      return { n: year, v: year };
    }),
    { n: "更早", v: "2004" },
  ],
};
const SORT_FILTER = {
  key: "sort",
  name: "排序",
  value: [
    { n: "最新", v: "d_id" },
    { n: "最热", v: "d_hits" },
    { n: "推荐", v: "d_score" },
  ],
};
const FILTERS = Object.fromEntries(CLASSES.map((item) => [item.type_id, [AREA_FILTER, YEAR_FILTER, SORT_FILTER]]));

const state = {
  apiHost: API_HOSTS[0],
  token: "",
  tokenId: "",
  deviceId: "",
  deviceKey: "",
  registered: false,
  tokenReady: false,
  hostReady: false,
};

const cache = {
  api: new Map(),
  detail: new Map(),
  ttl: {
    api: 3 * 60 * 1000,
    detail: 20 * 60 * 1000,
  },
};

function cacheGet(map, key, ttl) {
  const hit = map.get(key);
  if (!hit) return null;
  if (Date.now() - hit.ts > ttl) {
    map.delete(key);
    return null;
  }
  return hit.value;
}

function cacheSet(map, key, value) {
  map.set(key, { ts: Date.now(), value });
  if (map.size > 500) map.clear();
  return value;
}

function cleanText(value = "") {
  return String(value || "")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}

function sanitizeValue(value = "") {
  return cleanText(value).replace(/[$#]/g, " ").slice(0, 240);
}

function pageOf(value) {
  return Math.max(1, parseInt(value || "1", 10) || 1);
}

function decodeExt(raw) {
  if (!raw) return {};
  if (typeof raw === "object") return raw;
  const attempts = [String(raw)];
  try { attempts.push(decodeURIComponent(String(raw))); } catch {}
  try { attempts.push(Buffer.from(String(raw), "base64").toString("utf8")); } catch {}
  try { attempts.push(Buffer.from(String(raw), "base64url").toString("utf8")); } catch {}
  for (const item of attempts) {
    try {
      const parsed = JSON.parse(item);
      return parsed && typeof parsed === "object" ? parsed : {};
    } catch {}
  }
  return {};
}

function encodePlay(data) {
  return Buffer.from(JSON.stringify(data), "utf8").toString("base64url");
}

function decodePlay(id) {
  const raw = String(id || "");
  try {
    const parsed = JSON.parse(Buffer.from(raw, "base64url").toString("utf8"));
    return parsed && typeof parsed === "object" ? parsed : null;
  } catch {}
  const parts = raw.split("||");
  if (parts.length >= 2) {
    return { param: parts[0], resolution: parts[1] };
  }
  return raw ? { param: raw, resolution: "" } : null;
}

function stableStringify(value) {
  if (Array.isArray(value)) return `[${value.map((item) => stableStringify(item)).join(",")}]`;
  if (!value || typeof value !== "object") return JSON.stringify(value);
  return `{${Object.keys(value)
    .sort()
    .map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`)
    .join(",")}}`;
}

function apiJsonStringify(value) {
  return JSON.stringify(value).replace(/[^\x00-\x7F]/g, (char) => {
    return `\\u${char.charCodeAt(0).toString(16).padStart(4, "0")}`;
  });
}

function md5Upper(value) {
  return crypto.createHash("md5").update(String(value)).digest("hex").toUpperCase();
}

function bytesToHex(buf) {
  return Buffer.from(buf).toString("hex").toUpperCase();
}

function aesEncryptHex(text, key = AES_KEY, iv = AES_IV) {
  const cipher = crypto.createCipheriv("aes-128-cbc", Buffer.from(key, "utf8"), Buffer.from(iv, "utf8"));
  cipher.setAutoPadding(true);
  return Buffer.concat([cipher.update(String(text), "utf8"), cipher.final()]).toString("hex").toUpperCase();
}

function aesDecryptHex(hexText, key, iv) {
  const decipher = crypto.createDecipheriv("aes-128-cbc", Buffer.from(key, "utf8"), Buffer.from(iv, "utf8"));
  decipher.setAutoPadding(true);
  return Buffer.concat([
    decipher.update(Buffer.from(String(hexText || ""), "hex")),
    decipher.final(),
  ]).toString("utf8");
}

function rsaEncrypt(data) {
  return crypto
    .publicEncrypt(
      { key: RSA_PUBLIC_KEY, padding: crypto.constants.RSA_PKCS1_PADDING },
      Buffer.from(String(data), "utf8")
    )
    .toString("base64");
}

function rsaDecrypt(encryptedText) {
  const encrypted = Buffer.from(String(encryptedText || ""), "base64");
  try {
    return crypto
      .privateDecrypt({ key: RSA_PRIVATE_KEY, padding: crypto.constants.RSA_PKCS1_PADDING }, encrypted)
      .toString("utf8");
  } catch (error) {
    if (!crypto.constants.RSA_NO_PADDING) throw error;
  }
  const raw = crypto.privateDecrypt({ key: RSA_PRIVATE_KEY, padding: crypto.constants.RSA_NO_PADDING }, encrypted);
  if (raw[0] !== 0x00 || raw[1] !== 0x02) throw new Error("响应密钥 RSA padding 不匹配");
  const split = raw.indexOf(0x00, 2);
  if (split < 10) throw new Error("响应密钥 RSA padding 无效");
  return raw.slice(split + 1).toString("utf8");
}

function loadAuth() {
  try {
    if (fs.existsSync(AUTH_FILE)) {
      const data = JSON.parse(fs.readFileSync(AUTH_FILE, "utf8"));
      state.token = String(data.token || "");
      state.tokenId = String(data.tokenId || data.token_id || "");
      state.deviceId = String(data.deviceId || data.device_id || "");
      state.deviceKey = String(data.deviceKey || data.device_key || "");
      state.registered = !!data.registered || !!state.token;
    }
  } catch {}

  if (state.deviceId && state.deviceKey) return;

  state.deviceId = String(864150060000000 + Math.floor(Math.random() * 10000));
  state.deviceKey = crypto.randomBytes(20).toString("hex").toUpperCase();
  state.token = "";
  state.tokenId = "";
  state.registered = false;
  saveAuth();
}

function saveAuth() {
  try {
    fs.writeFileSync(
      AUTH_FILE,
      JSON.stringify(
        {
          token: state.token,
          tokenId: state.tokenId,
          deviceId: state.deviceId,
          deviceKey: state.deviceKey,
          registered: state.registered,
        },
        null,
        2
      )
    );
  } catch {}
}

function getHeaders() {
  return {
    "User-Agent": PLAY_UA,
    code: "GZ0369",
    deviceId: state.deviceId || "",
    lang: "zh_cn",
    "Cache-Control": "no-cache",
    "Content-Type": "application/x-www-form-urlencoded",
    Version: "2604028",
    PackageName: "com.ae06aebdbb.y286327f5a.ofe849883320260517",
    Ver: "3.0.3.2",
    "api-ver": "3.0.3.2",
  };
}

const client = axios.create({
  timeout: 22000,
  maxRedirects: 3,
  httpAgent: new http.Agent({ keepAlive: true }),
  httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
  validateStatus: () => true,
});

async function findAvailableHost() {
  for (const host of API_HOSTS) {
    try {
      const res = await axios.head(host, {
        timeout: 3000,
        httpsAgent: new https.Agent({ rejectUnauthorized: false }),
        validateStatus: () => true,
        headers: { "User-Agent": "Mozilla/5.0" },
      });
      if (res.status >= 200 && res.status < 500) {
        state.apiHost = host;
        state.hostReady = true;
        return host;
      }
    } catch {}
  }
  state.apiHost = API_HOSTS[0];
  state.hostReady = true;
  return state.apiHost;
}

async function ensureHost() {
  if (!state.hostReady) await findAvailableHost();
  return state.apiHost;
}

function applyAuth(result = {}) {
  const newToken = String(result.token || "");
  if (!newToken) throw new Error(`Token 获取失败: ${JSON.stringify(result)}`);
  state.token = newToken;
  const newTokenId = String(result.app_user_id || result.token_id || "");
  if (newTokenId) state.tokenId = newTokenId;
  saveAuth();
}

async function rawApiRequest(path, params = {}, retry = 0, options = {}) {
  const authPath = String(path).startsWith("/App/Authentication/");
  if (!authPath) await ensureToken();

  const host = await ensureHost();
  const requestParams = { ...(params || {}) };
  if (Object.prototype.hasOwnProperty.call(requestParams, "token")) requestParams.token = state.token;
  if (Object.prototype.hasOwnProperty.call(requestParams, "token_id")) requestParams.token_id = state.tokenId;

  const useCache = options.useCache === true && !authPath;
  const cacheKey = `${host}|${path}|${stableStringify(requestParams)}|${state.tokenId}`;
  if (useCache) {
    const cached = cacheGet(cache.api, cacheKey, cache.ttl.api);
    if (cached) return cached;
  }

  const jsonParams = apiJsonStringify(requestParams);
  const requestKey = aesEncryptHex(jsonParams);
  const time = String(Math.floor(Date.now() / 1000));
  const keys = rsaEncrypt(JSON.stringify({ iv: AES_IV, key: AES_KEY }));
  const tokenForSign = state.token || "";
  const signStr =
    `token_id=,token=${tokenForSign},phone_type=1,request_key=${requestKey}` +
    `,app_id=1,time=${time},keys=${keys}*&zvdvdvddbfikkkumtmdwqppp?|4Y!s!2br`;
  const signature = md5Upper(signStr);

  const body = new URLSearchParams({
    token: tokenForSign,
    token_id: "",
    phone_type: "1",
    time,
    phone_model: "xiaomi-25031",
    keys,
    request_key: requestKey,
    signature,
    app_id: "1",
    ad_version: "1",
  }).toString();

  const res = await client.post(`${host}${path}`, body, { headers: getHeaders() });
  if (res.status < 200 || res.status >= 400) {
    throw new Error(`HTTP ${res.status} ${path}`);
  }

  const response = typeof res.data === "string" ? JSON.parse(res.data) : res.data;
  if (!response || typeof response !== "object") throw new Error(`空响应 ${path}`);

  if (response.code != null && Number(response.code) !== 200) {
    if (retry < 1 && !authPath) {
      state.tokenReady = false;
      await ensureToken(true);
      return rawApiRequest(path, params, retry + 1, options);
    }
    throw new Error(`请求失败: ${JSON.stringify(response)}`);
  }

  const encryptedData = response.data || {};
  if (!encryptedData.keys || !encryptedData.response_key) {
    throw new Error(`API 返回缺少加密数据: ${path}`);
  }
  const keyInfo = JSON.parse(rsaDecrypt(encryptedData.keys));
  const decrypted = aesDecryptHex(encryptedData.response_key, keyInfo.key, keyInfo.iv);
  const result = JSON.parse(decrypted);
  if (useCache) cacheSet(cache.api, cacheKey, result);
  return result;
}

async function signUp() {
  const result = await rawApiRequest("/App/Authentication/Device/signUp", {
    new_key: state.deviceKey,
    old_key: DEVICE_OLD_KEY,
    phone_type: 1,
    code: "",
  });
  applyAuth(result);
  state.registered = true;
  saveAuth();
}

async function signIn() {
  const result = await rawApiRequest("/App/Authentication/Device/signIn", {
    new_key: state.deviceKey,
    old_key: DEVICE_OLD_KEY,
  });
  applyAuth(result);
}

async function ensureToken(force = false) {
  if (!force && state.tokenReady && state.token) return;
  loadAuth();
  if (!state.token) {
    if (state.registered) await signIn();
    else await signUp();
  }
  try {
    applyAuth(await rawApiRequest("/App/Authentication/Authenticator/refresh", {}));
  } catch (error) {
    if (!state.registered) throw error;
    await signIn();
  }
  state.tokenReady = true;
}

function vodRemarks(item = {}) {
  const continu = String(item.vod_continu ?? "0");
  const total = String(item.d_total ?? "0");
  if (total !== "0" && continu !== "0") {
    if (continu === total) return `全${total}集`;
    return `更新至${continu}集`;
  }
  if (continu !== "0" && continu !== "") return `更新至${continu}集`;
  return String(item.vod_year || item.vod_scroe || "电影");
}

function listItem(item = {}) {
  const vodId = String(item.vod_id ?? item.id ?? "");
  if (!vodId) return null;
  return {
    vod_id: vodId,
    vod_name: sanitizeValue(item.vod_name || item.name || ""),
    vod_pic: `${String(item.vod_pic || item.pic || "")}@User-Agent=Dalvik/2.1.0`,
    vod_remarks: vodRemarks(item),
  };
}

function listResult(list, page) {
  return {
    list: (Array.isArray(list) ? list : []).map(listItem).filter((item) => item && item.vod_name),
    page: pageOf(page),
    pagecount: 9999,
    limit: LIMIT,
    total: 999999,
  };
}

function resolutionScore(value) {
  const text = String(value || "").toUpperCase();
  if (text.includes("4K") || text.includes("2160")) return 2160;
  if (text.includes("1080")) return 1080;
  if (text.includes("720")) return 720;
  if (text.includes("480")) return 480;
  if (text.includes("360")) return 360;
  const num = parseInt(text.replace(/[^0-9]/g, ""), 10);
  return Number.isFinite(num) ? num : 0;
}

function parseParamString(value) {
  const text = String(value || "").replace(/&amp;/g, "&").replace(/^\?/, "");
  const params = {};
  for (const [key, val] of new URLSearchParams(text)) {
    params[key === "vod_d_id" ? "vod_id" : key] = val;
  }
  return params;
}

async function homeContent() {
  return {
    class: CLASSES,
    filters: FILTERS,
    list: [],
  };
}

async function categoryContent({ id, page, ext }) {
  const pg = pageOf(page);
  const decodedExt = decodeExt(ext);
  const tid = String(id || "1");
  const data = await rawApiRequest(
    "/App/IndexList/indexList",
    {
      tid,
      page: String(pg),
      pageSize: String(LIMIT),
      area: decodedExt.area || "0",
      year: decodedExt.year || "0",
      sort: decodedExt.sort || "d_id",
      sub: decodedExt.sub != null ? String(decodedExt.sub) : (SUB_MAP[tid] != null ? SUB_MAP[tid] : "0"),
    },
    0,
    { useCache: true }
  );
  return listResult(data?.list || [], pg);
}

async function searchContent({ wd, page }) {
  const keyword = cleanText(wd);
  const pg = pageOf(page);
  if (!keyword) return listResult([], pg);
  const data = await rawApiRequest(
    "/App/Index/findMoreVod",
    {
      keywords: keyword,
      order_val: "1",
    },
    0,
    { useCache: false }
  );
  return listResult(data?.list || [], pg);
}

async function detailContent({ ids }) {
  await ensureToken();
  const vodId = String(Array.isArray(ids) ? ids[0] : String(ids || "").split(",")[0]).split("|")[0];
  if (!vodId) return { list: [] };

  const cacheKey = `detail:${vodId}`;
  const cached = cacheGet(cache.detail, cacheKey, cache.ttl.detail);
  if (cached) return cached;

  const playInfo = await rawApiRequest("/App/IndexPlay/playInfo", {
    token_id: state.tokenId,
    vod_id: vodId,
    mobile_time: String(Math.floor(Date.now() / 1000)),
    token: state.token,
  });
  const vurlInfo = await rawApiRequest("/App/Resource/Vurl/show", {
    vurl_cloud_id: "2",
    vod_d_id: vodId,
  });

  const vod = playInfo?.vodInfo || {};
  const vodName = sanitizeValue(vod.vod_name || "");
  const qualityEpisodes = new Map();
  const qualityOrder = [];
  const episodes = Array.isArray(vurlInfo?.list) ? vurlInfo.list : [];

  episodes.forEach((item, index) => {
    const playObj = item?.play || {};
    const epName = episodes.length === 1 ? vodName || "正片" : String(index + 1);
    for (const [quality, ep] of Object.entries(playObj)) {
      const param = String(ep?.param || "");
      if (!param) continue;
      if (!qualityEpisodes.has(quality)) {
        qualityEpisodes.set(quality, []);
        qualityOrder.push(quality);
      }
      // 与 Java 一致：param||画质
      const playId = encodePlay({ param, resolution: quality });
      qualityEpisodes.get(quality).push(`${sanitizeValue(epName)}$${playId}`);
    }
  });

  qualityOrder.sort((a, b) => resolutionScore(b) - resolutionScore(a));
  const playFromList = [];
  const playUrlList = [];
  for (const quality of qualityOrder) {
    playFromList.push(sanitizeValue(quality) || "默认");
    playUrlList.push(qualityEpisodes.get(quality).join("#"));
  }

  const result = {
    list: [
      {
        vod_id: vodId,
        vod_name: vodName,
        vod_pic: `${String(vod.vod_pic || "")}@User-Agent=Dalvik/2.1.0`,
        vod_remarks: vodRemarks(vod),
        vod_year: String(vod.vod_year || ""),
        vod_area: sanitizeValue(vod.vod_area || ""),
        vod_actor: sanitizeValue(vod.vod_actor || ""),
        vod_director: sanitizeValue(vod.vod_director || ""),
        vod_content: cleanText(String(vod.vod_use_content || "").replace(/\u3000/g, "\n")),
        vod_play_from: playFromList.join("$$$") || "瓜子",
        vod_play_url: playUrlList.join("$$$"),
      },
    ],
  };
  return cacheSet(cache.detail, cacheKey, result);
}

async function playContent({ id, flag }) {
  const decoded = decodePlay(id);
  if (!decoded?.param) return { parse: 0, jx: 0, playUrl: "", url: "" };

  const params = parseParamString(decoded.param);
  const resolution = String(decoded.resolution || flag || "").trim();
  if (resolution) params.resolution = resolution;

  const data = await rawApiRequest("/App/Resource/VurlDetail/showOne", params, 0, { useCache: false });
  const url = String(data?.url || "");
  return {
    parse: 0,
    jx: 0,
    playUrl: "",
    url,
    header: {
      "User-Agent": PLAY_UA,
      Referer: PLAY_REFERER,
    },
  };
}

module.exports = async function guazi(app, opt) {
  loadAuth();
  app.get(meta.api, async (req) => {
    try {
      const q = req.query || {};
      // 播放
      if (q.play || q.ac === "play") return await playContent({ id: q.play || q.id, flag: q.flag });
      // 搜索
      if (q.wd) return await searchContent({ wd: q.wd, page: q.pg || q.page });
      // 详情：明确有 ids，或 ac=detail 且 id 不是分类请求
      if (q.ids || (q.ac === "detail" && q.id && !q.t)) {
        return await detailContent({ ids: q.ids || q.id });
      }
      // 分类：t=分类ID；部分壳会带 ac=detail&t=
      if (q.t) return await categoryContent({ id: q.t, page: q.pg || q.page, ext: q.ext || q.extend || q.f });
      // 兜底：单独 id 当详情
      if (q.id) return await detailContent({ ids: q.id });
      return await homeContent();
    } catch (error) {
      return {
        list: [],
        msg: error?.message || String(error),
      };
    }
  });

  if (opt && Array.isArray(opt.sites)) {
    opt.sites.push(meta);
  }
};

module.exports.meta = meta;
