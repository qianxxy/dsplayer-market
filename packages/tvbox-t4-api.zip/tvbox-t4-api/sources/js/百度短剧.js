/**
 * 百度短剧 - T4 插件 (从 cat 源迁移)
 */
"use strict";
const axios = require("axios");
const crypto = require("crypto");

// ==================== 常量配置 ====================
const UA = "Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.91 Mobile Safari/537.36";
const clarity_order = { '蓝光': 1, '超清': 2, '标清': 3 };

const rule = {
    host: 'https://mbd.baidu.com',
    detailHost: 'https://sv.baidu.com',
    listUrl: '/feedapi/v1/videoserver/playlets/list?service=bdbox',
    searchUrl: '/feedapi/v1/videoserver/playlets/search?service=bdbox',
    detailUrl: '/haokan/ui-video/playlet/rec/detail?log=vhk&tn=1020970b&ctn=1008350n&blur=1',
    playUrl: '/appui/api?cmd=video/relate&log=vhk&tn=1020970b&ctn=1008350n&blur=1',
};

const headers = {
    'User-Agent': UA,
    'Content-Type': 'application/x-www-form-urlencoded',
    'Accept': 'application/json'
};

// ==================== 工具函数 ====================
function safeJSONParse(str, defaultValue = {}) {
    if (!str || typeof str === 'object') return str || defaultValue;
    try { return JSON.parse(str); } catch { return defaultValue; }
}

function md5(str) {
    return crypto.createHash('md5').update(str).digest('hex').toLowerCase();
}

// ==================== 网络请求 ====================
async function request(url, options = {}) {
    const reqHeaders = { ...headers, ...options.headers };
    let data = options.data;
    const method = options.method || 'GET';

    if (data && typeof data === 'object') {
        const contentType = reqHeaders['Content-Type'] || '';
        if (contentType.includes('json')) {
            data = JSON.stringify(data);
        } else if (contentType.includes('form')) {
            const params = new URLSearchParams();
            for (const [k, v] of Object.entries(data)) {
                params.set(k, v);
            }
            data = params.toString();
        }
    }

    try {
        const response = await axios({
            url,
            method,
            headers: reqHeaders,
            data,
            timeout: options.timeout || 15000,
        });
        return response.data;
    } catch (e) {
        console.error('[百度短剧] 请求失败:', e.message);
        return null;
    }
}

// ==================== 核心业务函数 ====================

// 1. 获取分类（同步）
function home() {
    const he = ["全部", "新剧", "限时免费", "精选", "独播"];
    const ticailist = [
        "神医", "连续剧", "都市", "现代言情", "异能", "逆袭", "甜宠", "总裁", "萌宝", "战神", "宫斗宅斗", "神豪",
        "虐恋", "闪婚", "玄幻", "穿越重生", "年代", "家庭伦理", "古代言情", "武侠武打", "赘婿", "单元剧", "青春校园",
        "历史架空", "王妃", "鉴宝", "科幻", "军旅战争", "种田"
    ];

    const classes = he.map(name => ({ type_id: name, type_name: name }));
    classes.push(...ticailist.map(name => ({
        type_id: name === "全部" ? "全部题材" : name,
        type_name: name
    })));

    return { class: classes, filters: {} };
}

// 2. 首页推荐列表
async function homeVod() {
    const result = await category('新剧', 1, {}, {});
    return { list: (result.list || []).slice(0, 12) };
}

// 3. 分类列表
async function category(tid, pg, filter, extend) {
    pg = pg <= 0 ? 1 : pg;
    const sub = ["新剧", "限时免费", "精选", "独播"].includes(tid) ? tid : "新剧";
    const tcsub = (tid === "全部" || tid === "全部题材") ? "" : tid;
    const t = Math.floor(Date.now() / 1000);
    const version = md5(t + "v2");

    const postData = {
        data: JSON.stringify({
            data: {
                extRequest: { flow_tabid: "13" },
                from: "feed",
                page: "channel_video_landing",
                pd: "feed",
                refreshIndex: pg,
                cursor: "",
                theme: "",
                timestamp: t,
                version: version,
                themes: [
                    { kind: "综合", names: [sub] },
                    { kind: "题材", names: [tcsub] }
                ]
            }
        })
    };

    const res = await request(`${rule.host}${rule.listUrl}`, { method: 'POST', data: postData });
    const videos = (res?.data?.items || []).map(it => ({
        vod_id: it.collId || '',
        vod_name: it.title || '未知标题',
        vod_pic: it.img || '',
        vod_remarks: it.updateStatus || '',
        vod_content: it.description || ''
    }));

    return {
        page: pg,
        pagecount: pg + 1,
        limit: videos.length,
        total: videos.length * (pg + 1),
        list: videos
    };
}

// 4. 详情
async function detail(id) {
    const res = await request(`${rule.detailHost}${rule.detailUrl}`, {
        method: 'POST',
        data: { playlet_id: id, vid: "undefined" }
    });
    const dthtml = res?.data;
    const vids = dthtml?.vid_list || [];
    if (!vids.length) return { list: [] };

    const playArr = vids.map((vid, index) => `第${index + 1}集$${vid}`);
    const vod = {
        vod_id: id,
        vod_name: dthtml.playlet_title || '未知剧名',
        vod_pic: dthtml.playlet_poster || '',
        vod_content: dthtml.description || '',
        vod_remarks: `共${vids.length}集 热度值:${dthtml.hot_value || 0}`,
        vod_director: dthtml.tag_text || '',
        vod_year: dthtml.create_time || '',
        vod_play_from: "百度短剧",
        vod_play_url: playArr.join('#')
    };

    return { list: [vod] };
}

// 5. 播放地址
async function play(id) {
    const res = await request(`${rule.detailHost}${rule.playUrl}`, {
        method: 'POST',
        data: { method: "post", vid: id }
    });
    const video = res?.["video/relate"]?.data?.cur_video;
    if (!video?.clarityUrl) return { parse: 0, url: '', msg: '获取播放链接失败' };

    const urls = video.clarityUrl
        .filter(item => item?.url)
        .map(item => ({
            title: item.title,
            url: item.url,
            order: clarity_order[item.title] || 999
        }))
        .sort((a, b) => a.order - b.order);

    if (!urls.length) return { parse: 0, url: '', msg: '暂无可用播放地址' };

    const flat = urls.flatMap(item => [item.title, item.url]);
    return {
        parse: 0,
        url: flat,
        header: { 'User-Agent': UA, 'Referer': rule.host }
    };
}

// 6. 搜索
async function search(wd, pg) {
    pg = pg <= 0 ? 1 : pg;
    const postData = {
        data: JSON.stringify({
            query: wd,
            page: pg,
            attribute: ["title"],
            fe_page_type: "search",
            extra: {
                tab_id: "216",
                flow_tabid: "13",
                shortplay_source: "feed",
                from: "feed",
                tab_type: "搜索",
                sub_template: "playlet_search_result"
            }
        })
    };

    const res = await request(`${rule.host}${rule.searchUrl}`, {
        method: 'POST',
        data: postData
    });
    const videos = (res?.data?.itemList || []).map(it => ({
        vod_id: it.nid?.split("_")[1] || '',
        vod_name: it.title || '未知标题',
        vod_pic: it.img || '',
        vod_remarks: (it.collNum || '0') + '集',
        vod_content: it.description || ''
    }));

    return {
        page: pg,
        pagecount: pg + 1,
        limit: videos.length,
        total: videos.length * (pg + 1),
        list: videos
    };
}

// ==================== T4 插件适配 ====================
const meta = {
    key: "baiduduanju",
    name: "[短]百度短剧",
    type: 4,
    api: "/video/baiduduanju",
    searchable: 1,
    quickSearch: 1,
    filterable: 1,
    changeable: 0,
};

function decodeExt(ext) {
    if (!ext) return {};
    try {
        return JSON.parse(Buffer.from(String(ext), "base64").toString("utf8")) || {};
    } catch { return {}; }
}

module.exports = async (app, opt) => {
    app.get(meta.api, async (req) => {
        const q = req.query || {};
        const { ac, t, pg, wd, play: playId, ids, ext } = q;
        const filters = decodeExt(ext);

        try {
            // 分发请求
            if (playId) {
                return await play(playId);
            }
            if (wd) {
                return await search(wd, pg || 1);
            }
            if (ids) {
                const idList = Array.isArray(ids) ? ids : [String(ids)];
                return await detail(idList[0]); // 只取第一个
            }
            if (t) {
                return await category(t, pg || 1, filters, {});
            }
            // 默认首页：返回分类 + 推荐列表
            const homeData = home();
            const vodData = await homeVod();
            return {
                ...homeData,
                list: vodData.list || []
            };
        } catch (e) {
            app.log?.error?.(`[百度短剧] ${e?.message || e}`);
            return { list: [] };
        }
    });

    opt.sites.push(meta);
};