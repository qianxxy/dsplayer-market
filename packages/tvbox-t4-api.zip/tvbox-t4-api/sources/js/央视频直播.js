/** 央视频直播（T4 直链版）
 *  由 /docker/vod/test/央视频T4.py 转写为 vod 容器路由格式
 *  - 普通频道: JCE 时移协议直链 (jacc.ysp.cctv.cn)
 *  - 强制 BK 频道: bkliveinfo cKey 直链 (bkliveinfo.ysp.cctv.cn)
 *  - playerContent 现场解析直链，播放器直连央视 CDN，服务器零视频流量
 */
const axios = require("axios");
const crypto = require("crypto");
const zlib = require("zlib");

const UA =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36";
const PLAY_HEADERS = { "User-Agent": UA, Referer: "https://live.cctv.cn/" };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------------- 频道表 ----------------
const CHANNELS = [
  ["cctv1", "CCTV-1", "2024078201", "600001859", "fhd"],
  ["cctv2", "CCTV-2", "2024075401", "600001800", "fhd"],
  ["cctv3", "CCTV-3", "2024068501", "600001801", "fhd"],
  ["cctv4", "CCTV-4", "2029797101", "600001814", "fhd"],
  ["cctv5", "CCTV-5", "2024078401", "600001818", "fhd"],
  ["cctv5p", "CCTV-5+", "2024078001", "600001817", "fhd"],
  ["cctv6", "CCTV-6", "2013693901", "600108442", "fhd"],
  ["cctv7", "CCTV-7", "2024072001", "600004092", "fhd"],
  ["cctv8", "CCTV-8", "2029793001", "600001803", "fhd"],
  ["cctv9", "CCTV-9", "2024078601", "600004078", "fhd"],
  ["cctv10", "CCTV-10", "2024078701", "600001805", "fhd"],
  ["cctv11", "CCTV-11", "2027248701", "600001806", "fhd"],
  ["cctv12", "CCTV-12", "2027248801", "600001807", "fhd"],
  ["cctv13", "CCTV-13", "2029797201", "600001811", "fhd"],
  ["cctv14", "CCTV-14", "2027248901", "600001809", "fhd"],
  ["cctv15", "CCTV-15", "2027249001", "600001815", "fhd"],
  ["cctv16", "CCTV-16", "2027249101", "600098637", "fhd"],
  ["cctv164k", "CCTV-16 4K", "2027249301", "600099502", "fhd"],
  ["cctv17", "CCTV-17", "2027249401", "600001810", "fhd"],
  ["cctv4k", "CCTV-4K", "2029810301", "600002264", "fhd"],
  ["cctv8k", "CCTV-8K", "2026774101", "600156816", "fhd"],
  ["cgtn", "CGTN", "2024181701", "600014550", "fhd"],
  ["cgtnfr", "CGTN法语", "2024181801", "600084704", "fhd"],
  ["cgtnru", "CGTN俄语", "2024181901", "600084758", "fhd"],
  ["cgtnar", "CGTN阿拉伯语", "2024182001", "600084782", "fhd"],
  ["cgtnes", "CGTN西班牙语", "2024182101", "600084744", "fhd"],
  ["cgtndoc", "CGTN 纪录", "2024182301", "600084781", "fhd"],
  ["cctvfyjc", "CCTV 风云剧场", "2025637103", "600099658", "shd"],
  ["cctvdyjc", "CCTV 第一剧场", "2026874203", "600099655", "shd"],
  ["cctvhjjc", "CCTV 怀旧剧场", "2026874303", "600099620", "shd"],
  ["bjws", "北京卫视", "2024052703", "600002309", "fhd"],
  ["jsws", "江苏卫视", "2024171103", "600002521", "fhd"],
  ["dfws", "东方卫视", "2024054503", "600002483", "fhd"],
  ["zjws", "浙江卫视", "2024054703", "600002520", "fhd"],
  ["hnws", "湖南卫视", "2024054803", "600002475", "fhd"],
  ["hbws", "湖北卫视", "2024171203", "600002508", "fhd"],
  ["gdws", "广东卫视", "2024060903", "600002485", "fhd"],
  ["gxws", "广西卫视", "2024060703", "600002509", "fhd"],
  ["hljws", "黑龙江卫视", "2029797003", "600002498", "fhd"],
  ["hainanws", "海南卫视", "2024055603", "600002506", "fhd"],
  ["cqws", "重庆卫视", "2024061103", "600002531", "fhd"],
  ["szws", "深圳卫视", "2024061303", "600002481", "fhd"],
  ["scws", "四川卫视", "2024061403", "600002516", "fhd"],
  ["henanws", "河南卫视", "2029797303", "600002525", "fhd"],
  ["dnws", "东南卫视", "2024061503", "600002484", "fhd"],
  ["gzws", "贵州卫视", "2024061603", "600002490", "fhd"],
  ["jxws", "江西卫视", "2024061703", "600002503", "fhd"],
  ["lnws", "辽宁卫视", "2024171303", "600002505", "fhd"],
  ["ahws", "安徽卫视", "2024171403", "600002532", "fhd"],
  ["hebws", "河北卫视", "2024171503", "600002493", "fhd"],
  ["sdws", "山东卫视", "2029787903", "600002513", "fhd"],
  ["tjws", "天津卫视", "2019927003", "600152137", "fhd"],
  ["jlws", "吉林卫视", "2025561503", "600190405", "fhd"],
  ["saxws", "陕西卫视", "2029795103", "600190400", "fhd"],
  ["nxws", "宁夏卫视", "2025608503", "600190737", "fhd"],
  ["nmgws", "内蒙古卫视", "2025561203", "600190401", "fhd"],
  ["ynws", "云南卫视", "2025561303", "600190402", "fhd"],
  ["shanxiws", "山西卫视", "2025560803", "600190407", "fhd"],
  ["qhws", "青海卫视", "2025559103", "600190406", "fhd"],
  ["xizangws", "西藏卫视", "2025558003", "600190403", "fhd"],
  ["xjws", "新疆卫视", "2019927403", "600152138", "fhd"],
  ["cetv1", "CETV-1", "2022823801", "600171827", "fhd"],
  ["guoxue", "国学频道", "2029360403", "600213139", "fhd"],
];

const CHANNEL_MAP = new Map(
  CHANNELS.map((c) => [c[0], { slug: c[0], name: c[1], sid: c[2], pid: c[3], defn: c[4] }])
);

const FORCE_BK = new Set([
  "cctv11", "cctv12", "cctv14", "cctv15", "cctv16", "cctv164k",
  "cctv17", "cctv4k", "cctvfyjc", "cctvdyjc", "cctvhjjc",
]);

const BACKEND_CHANNELS = new Set([
  "cctv1", "cctv2", "cctv3", "cctv4", "cctv5", "cctv5p",
  "cctv7", "cctv8", "cctv9", "cctv10", "cctv11", "cctv12",
  "cctv13", "cctv14", "cctv15", "cctv16", "cctv17",
  "cctv4k", "cctv8k", "cctv164k",
  "cgtn", "cgtnfr", "cgtnru", "cgtnar", "cgtnes", "cgtndoc",
]);

const TRUE_4K = new Set(["cctv4k", "cctv8k", "cctv164k"]);

const CLASSES = [
  { type_name: "央视频道", type_id: "cctv" },
  { type_name: "卫视频道", type_id: "satellite" },
  { type_name: "CGTN", type_id: "cgtn" },
  { type_name: "4K超清", type_id: "4k" },
  { type_name: "付费剧场", type_id: "premium" },
  { type_name: "其他", type_id: "other" },
];

// ---------------- 台标 ----------------
const LOGO_MIRRORS = [
  "https://cdn.jsdmirror.com/gh/fanmingming/live@main/tv/",
  "https://jsd.onmicrosoft.cn/gh/fanmingming/live@main/tv/",
  "https://gcore.jsdelivr.net/gh/fanmingming/live@main/tv/",
  "https://cdn.jsdelivr.net/gh/fanmingming/live@main/tv/",
  "https://ghproxy.net/https://raw.githubusercontent.com/fanmingming/live/main/tv/",
  "https://live.fanmingming.com/tv/",
];

const LOGO_OVERRIDE = {
  cctv5p: "CCTV5+.png",
  cctv4k: "CCTV4K.png",
  cctv8k: "CCTV8K.png",
  cctv164k: "CCTV16.png",
  cgtn: "CGTN.png",
  cgtnfr: "CGTN法语.png",
  cgtnru: "CGTN俄语.png",
  cgtnar: "CGTN阿语.png",
  cgtnes: "CGTN西语.png",
  cgtndoc: "CGTN纪录.png",
  cctvfyjc: "风云剧场.png",
  cctvdyjc: "第一剧场.png",
  cctvhjjc: "怀旧剧场.png",
  cetv1: "CETV1.png",
  guoxue: "国学.png",
};

let LOGO_BASE = LOGO_MIRRORS[0];
(async () => {
  for (const base of LOGO_MIRRORS) {
    try {
      const r = await axios.get(base + "CCTV1.png", {
        headers: PLAY_HEADERS, timeout: 5000, responseType: "arraybuffer",
      });
      const b = Buffer.from(r.data);
      if (b.length >= 4 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) {
        LOGO_BASE = base;
        return;
      }
    } catch {}
  }
})();

function logoFile(slug, name = "") {
  if (LOGO_OVERRIDE[slug]) return LOGO_OVERRIDE[slug];
  const m = /^cctv(\d+)$/.exec(slug);
  if (m) return "CCTV" + m[1] + ".png";
  if (name && slug.endsWith("ws")) return name + ".png";
  return "";
}

function logoUrl(slug, name = "") {
  const fn = logoFile(slug, name);
  return fn ? LOGO_BASE + encodeURIComponent(fn) : "";
}

// ---------------- JCE 二进制协议 ----------------
class JW {
  constructor() { this.parts = []; }
  push(b) { this.parts.push(b); }
  out() { return Buffer.concat(this.parts); }
  head(typ, tag) {
    if (tag < 15) this.push(Buffer.from([((tag & 0xf) << 4) | (typ & 0xf)]));
    else this.push(Buffer.from([0xf0 | (typ & 0xf), tag]));
  }
  byte(v, tag) {
    v = Math.trunc(Number(v) || 0);
    if (v === 0) { this.head(12, tag); return; }
    this.head(0, tag);
    this.push(Buffer.from([v & 0xff]));
  }
  short(v, tag) {
    v = Math.trunc(Number(v) || 0);
    if (v >= -128 && v <= 127) { this.byte(v, tag); return; }
    this.head(1, tag);
    const b = Buffer.alloc(2); b.writeInt16BE(v); this.push(b);
  }
  int(v, tag) {
    v = Math.trunc(Number(v) || 0);
    if (v >= -32768 && v <= 32767) { this.short(v, tag); return; }
    this.head(2, tag);
    const b = Buffer.alloc(4); b.writeInt32BE(v); this.push(b);
  }
  long(v, tag) {
    v = Math.trunc(Number(v) || 0);
    if (v >= -2147483648 && v <= 2147483647) { this.int(v, tag); return; }
    this.head(3, tag);
    const b = Buffer.alloc(8); b.writeBigInt64BE(BigInt(v)); this.push(b);
  }
  float(v, tag) { this.head(4, tag); const b = Buffer.alloc(4); b.writeFloatBE(v); this.push(b); }
  double(v, tag) { this.head(5, tag); const b = Buffer.alloc(8); b.writeDoubleBE(v); this.push(b); }
  string(s, tag) {
    if (s === null || s === undefined) return;
    const data = Buffer.from(String(s), "utf8");
    if (data.length > 255) {
      this.head(7, tag);
      const b = Buffer.alloc(4); b.writeInt32BE(data.length);
      this.push(b); this.push(data);
    } else {
      this.head(6, tag);
      this.push(Buffer.from([data.length])); this.push(data);
    }
  }
  bytes(data, tag) {
    const buf = Buffer.isBuffer(data) ? data : Buffer.from(data);
    this.head(13, tag); this.head(0, 0); this.int(buf.length, 0); this.push(buf);
  }
  struct(fn, tag) { this.head(10, tag); fn(this); this.head(11, 0); }
  list(items, tag) { this.head(9, tag); this.int(items.length, 0); }
}

class JR {
  constructor(d) { this.d = d; this.p = 0; }
  rem() { return this.d.length - this.p; }
  get(n) {
    if (this.p + n > this.d.length) throw new Error("EOF");
    const b = this.d.subarray(this.p, this.p + n); this.p += n; return b;
  }
  u8() { return this.get(1)[0]; }
  head() {
    const b = this.u8();
    let typ = b & 0xf, tag = (b >> 4) & 0xf;
    if (tag === 15) tag = this.u8();
    return [typ, tag];
  }
  value(typ) {
    switch (typ) {
      case 0: return this.get(1).readInt8(0);
      case 1: return this.get(2).readInt16BE(0);
      case 2: return this.get(4).readInt32BE(0);
      case 3: return this.get(8).readBigInt64BE(0);
      case 4: return this.get(4).readFloatBE(0);
      case 5: return this.get(8).readDoubleBE(0);
      case 6: { const n = this.u8(); return this.get(n).toString("utf8"); }
      case 7: { const n = this.get(4).readInt32BE(0); return this.get(n).toString("utf8"); }
      case 8: {
        const n = this._int(); const m = {};
        for (let i = 0; i < n; i++) { const k = this._fv(); m[k] = this._fv(); }
        return m;
      }
      case 9: {
        const n = this._int(); const a = [];
        for (let i = 0; i < n; i++) a.push(this._fv());
        return a;
      }
      case 10: return this.struct();
      case 11: return null;
      case 12: return 0;
      case 13: { this.head(); const n = this._int(); return this.get(n); }
      default: throw new Error("type " + typ);
    }
  }
  _fv() { const [t] = this.head(); return this.value(t); }
  _int() { const [t] = this.head(); return Number(this.value(t)); }
  struct() {
    const m = new Map();
    while (this.rem() > 0) {
      const [t, tag] = this.head();
      if (t === 11) break;
      m.set(tag, this.value(t));
    }
    return m;
  }
}

const VER_NAME = "3.2.7.26212", VER_CODE = "302070";
const APP_ID = "1200013", QMF_APP_ID = 10012, QMF_PLATFORM = 1, BIZ_ID = 0;
const CHAN_ID = "10070";
const GUID = crypto.randomBytes(16).toString("hex");

const i32be = (v) => { const b = Buffer.alloc(4); b.writeInt32BE(v); return b; };
const u16be = (v) => { const b = Buffer.alloc(2); b.writeUInt16BE(v); return b; };
const i64be = (v) => { const b = Buffer.alloc(8); b.writeBigInt64BE(BigInt(v)); return b; };

function quaWrite(w) {
  w.string(VER_NAME, 0); w.string(VER_CODE, 1);
  w.int(1080, 2); w.int(2400, 3); w.int(3, 4); w.string("12", 5);
  w.int(1, 6); w.int(1, 7); w.int(420, 8); w.string(CHAN_ID, 9);
  for (let i = 10; i < 15; i++) w.string("", i);
  w.struct((ww) => { ww.int(0, 0); ww.byte(0, 1); ww.string("", 2); }, 15);
  w.string("", 16); w.string("", 17); w.string("", 18);
  w.struct((ww) => { ww.int(0, 0); ww.float(0, 1); ww.float(0, 2); ww.double(0, 3); }, 19);
  w.string(GUID.slice(0, 16), 20); w.string("Pixel 6", 21);
  w.int(1, 22);
  for (let i = 23; i < 27; i++) w.int(0, i);
  w.string("", 27); w.string("", 28); w.string(GUID, 29);
}

function headWrite(w, cmd, reqid) {
  w.int(reqid, 0); w.int(cmd, 1);
  w.struct((ww) => quaWrite(ww), 2);
  w.string(APP_ID, 3); w.string(GUID, 4);
  w.list([], 5); w.struct(() => {}, 6);
  w.list([], 7);
  w.int(0, 8); w.int(0, 9); w.int(0, 10);
}

function wrapPacket(cmd, body, reqid) {
  const w = new JW();
  w.struct((ww) => headWrite(ww, cmd, reqid), 0);
  w.bytes(body, 1);
  const reqcmd = w.out();
  const inner = Buffer.concat([
    Buffer.from([38]), i32be(reqcmd.length + 17), Buffer.from([1]),
    Buffer.alloc(10), reqcmd, Buffer.from([40]),
  ]);
  const comp = zlib.gzipSync(inner);
  let out = Buffer.concat([
    Buffer.from([19]), i32be(0), u16be(2), u16be(0xff01), u16be(cmd), u16be(0), i64be(reqid),
    i32be(531), i32be(QMF_APP_ID), i64be(BIZ_ID),
  ]);
  const g = Buffer.from(GUID, "ascii").subarray(0, 32);
  out = Buffer.concat([out, g, Buffer.alloc(32 - g.length)]);
  out = Buffer.concat([out, Buffer.from([QMF_PLATFORM & 0xff]), i32be(parseInt(VER_CODE, 10)), Buffer.alloc(6)]);
  out = Buffer.concat([out, Buffer.from([0]), u16be(0), u16be(0)]);
  out = Buffer.concat([out, i32be(inner.length), comp, Buffer.from([3])]);
  out.writeInt32BE(out.length, 1);
  return out;
}

function unwrapPacket(data) {
  if (!data || data.length < 90 || data[0] !== 0x13) return null;
  const flags = data.readUInt32BE(21);
  let payload = data.subarray(89, data.length - 1);
  if (flags & 2) payload = zlib.gunzipSync(payload);
  if (payload[0] !== 0x26 || payload[payload.length - 1] !== 0x28) return null;
  const rc = new JR(payload.subarray(16, payload.length - 1)).struct();
  const v = rc.get(1);
  return v || Buffer.alloc(0);
}

async function jceTimeshiftUrl(pid, sid, start, end, stream = "fhd") {
  const w = new JW();
  w.string(pid, 0); w.string(sid, 1); w.long(start, 2); w.long(end, 3); w.string(stream, 4);
  const packet = wrapPacket(25312, w.out(), Date.now() & 0x7fffffff);
  const resp = await axios.post("https://jacc.ysp.cctv.cn", packet, {
    headers: { "Content-Type": "application/octet-stream" },
    timeout: 15000, responseType: "arraybuffer",
  });
  const respBody = unwrapPacket(Buffer.from(resp.data));
  if (!respBody || !respBody.length) throw new Error("bad response");
  const m = new JR(respBody).struct();
  const err = m.has(0) ? Number(m.get(0)) : 0;
  if (err !== 0) throw new Error(String(m.get(1) || "errCode=" + err));
  const url = m.has(2) ? String(m.get(2) || "") : "";
  if (!url) throw new Error("empty m3u8");
  if (url.includes("liverecord.video.cloud.cctv.com")) throw new Error("dead cdn host");
  return url;
}

// ---------------- BK cKey (TEA) ----------------
const CK_PLATFORM = 4330403;
const CK_APPVER = "V8.22.1035.3031";
const CK_TEA = Buffer.from("59b2f7cf725ef43c34fdd7c123411ed3", "hex");
const CK_GTEA = Buffer.from("110DBEC10C23E7D2E56A1CAD6914EF1B", "hex");
const CK_XOR = Buffer.from([0x84, 0x2e, 0xed, 0x08, 0xf0, 0x66, 0xe6, 0xea, 0x48, 0xb4, 0xca, 0xa9, 0x91, 0xed, 0x6f, 0xf3]);
const CK_GXOR = Buffer.from([0xb3, 0xc9, 0x53, 0xa0, 0x69, 0x13, 0xad, 0x4d]);

const u32 = (v) => v >>> 0;

function teaBlk(blk, key) {
  let y = blk.readUInt32BE(0), z = blk.readUInt32BE(4);
  const k = [key.readUInt32BE(0), key.readUInt32BE(4), key.readUInt32BE(8), key.readUInt32BE(12)];
  let s = 0;
  for (let i = 0; i < 16; i++) {
    s = u32(s + 0x9e3779b9);
    y = u32(y + u32(u32(u32(z << 4) + k[0]) ^ u32(z + s) ^ u32((z >>> 5) + k[1])));
    z = u32(z + u32(u32(u32(y << 4) + k[2]) ^ u32(y + s) ^ u32((y >>> 5) + k[3])));
  }
  const out = Buffer.alloc(8);
  out.writeUInt32BE(y, 0); out.writeUInt32BE(z, 4);
  return out;
}

function cksum(buf) {
  let v = 0;
  for (const b of buf) v = (0x83 * v + b) % 0x80000000;
  return v >>> 0;
}

function teaPkt(data, key) {
  const pad = (8 - ((data.length + 10) % 8)) % 8;
  const plain = Buffer.concat([
    Buffer.from([(crypto.randomBytes(1)[0] & 0xf8) | pad]),
    crypto.randomBytes(pad),
    crypto.randomBytes(2),
    data,
    Buffer.alloc(7),
  ]);
  let out = Buffer.alloc(0);
  let pp = Buffer.alloc(8), pc = Buffer.alloc(8);
  for (let off = 0; off < plain.length; off += 8) {
    const mixed = Buffer.from(plain.subarray(off, off + 8));
    for (let i = 0; i < 8; i++) mixed[i] ^= pc[i];
    const cipher = Buffer.from(teaBlk(mixed, key));
    for (let i = 0; i < 8; i++) cipher[i] ^= pp[i];
    out = Buffer.concat([out, cipher]);
    pp = mixed; pc = cipher;
  }
  return out;
}

function lp(s) {
  const d = Buffer.isBuffer(s) ? s : Buffer.from(String(s), "utf8");
  return Buffer.concat([u16be(d.length), d]);
}

function ckGuard(ts, guid) {
  const tail = (v) => { const t = String(v); return t.length >= 5 ? t.slice(-5) : ""; };
  const body = Buffer.concat([
    i32be(ts), lp(tail(guid)), lp(tail("null")), lp(tail("null")), lp("-1"),
  ]);
  const plain = lp(body);
  const enc = Buffer.concat([teaPkt(plain, CK_GTEA), i32be(cksum(plain))]);
  for (let i = 0; i < enc.length; i++) enc[i] ^= CK_GXOR[i & 7];
  return enc.toString("hex").toUpperCase();
}

function ckey(channelId) {
  const ts = Math.floor(Date.now() / 1000);
  const guid = crypto.randomBytes(16).toString("hex");
  const guard = ckGuard(ts, guid);
  const uid = crypto.randomBytes(4).toString("hex").toUpperCase();
  const body = Buffer.concat([
    Buffer.from([0x00, 0x00, 0x00, 0x42, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x04, 0xd2]),
    i32be(CK_PLATFORM), i32be(0), i32be(ts),
    lp("dcgh"), lp("_zj1A5Gh6QYcxWjIUGos2w=="), lp(CK_APPVER), lp(String(channelId)),
    lp(guid), i32be(1), i32be(1), lp(uid), lp("nil"),
    lp("57eab0c4-2c58-44c6-8ae9-dd2757525dc5"), lp("nil"), lp("v0.1.000"),
    lp("com.cctv.yangshipin.app.iphone"), lp(String(CK_PLATFORM)),
    lp("ex_json_bus"), lp("ex_json_vs"), lp(guard),
  ]);
  const pkt = Buffer.concat([u16be(body.length), body]);
  pkt.writeUInt32BE(cksum(pkt), 18);
  const enc = Buffer.concat([teaPkt(pkt, CK_TEA), i32be(cksum(pkt))]);
  for (let i = 0; i < enc.length; i++) enc[i] ^= CK_XOR[i & 15];
  const b64 = enc.toString("base64").replace(/\+/g, "_").replace(/\//g, "-").replace(/=+$/, "");
  return {
    cKey: "--01" + b64,
    guid,
    ts,
    flowId: crypto.randomBytes(16).toString("hex").toUpperCase() + "_" + CK_PLATFORM,
  };
}

const BK_H264 = Buffer.from("H(30:1080,60:1080|30:1080,60:1080)").toString("base64");

async function bkPlayurls(channelId, livePid, defn = "fhd") {
  const t = ckey(channelId);
  const q = new URLSearchParams({
    atime: "120", livepid: String(livePid), cnlid: String(channelId),
    appVer: CK_APPVER, app_version: "300090", caplv: "1", cmd: "2",
    defn, device: "iPhone", encryptVer: "4.2", getpreviewinfo: "0",
    hevclv: "0", lang: "zh-Hans_CN", livequeue: "0", logintype: "1",
    nettype: "1", newnettype: "1", newplatform: String(CK_PLATFORM),
    platform: String(CK_PLATFORM), sdtfrom: "v3021", spacode: "23",
    spaudio: "1", spdemuxer: "6", spdrm: "2", spdynamicrange: "1",
    spflv: "1", spflvaudio: "1", sphdrfps: "60", sphttps: "1",
    spvcode: BK_H264, spvideo: "4", stream: "1", system: "1",
    sysver: "ios18.2.1", uhd_flag: "0", cKey: t.cKey, guid: t.guid,
    fntick: String(t.ts), flowid: t.flowId, playbacktime: "0",
  });
  const r = await axios.get("https://bkliveinfo.ysp.cctv.cn/?" + q.toString(), {
    headers: { "User-Agent": "qqlive", Accept: "application/json" },
    timeout: 15000, responseType: "arraybuffer",
  });
  const p = JSON.parse(Buffer.from(r.data).toString("utf8"));
  if (parseInt(p.iretcode != null ? p.iretcode : -1, 10) !== 0) {
    throw new Error("iretcode=" + p.iretcode + " " + (p.errinfo || ""));
  }
  const urls = [];
  if (p.playurl) urls.push(p.playurl);
  const bu = p.backurl_list || p.backurlList || p.backurl;
  if (Array.isArray(bu)) {
    for (const it of bu) urls.push(typeof it === "string" ? it : (it.url || it.playurl || ""));
  } else if (typeof bu === "string") {
    urls.push(...bu.split(/[;,]/).filter((x) => x.trim()));
  }
  const uniq = [...new Set(urls)].filter((u) => u && u.includes(".cctv."));
  if (!uniq.length) throw new Error("no playurl");
  uniq.sort((a, b) => (a.includes("bklive-") ? 0 : 1) - (b.includes("bklive-") ? 0 : 1) || (a < b ? -1 : a > b ? 1 : 0));
  return uniq;
}

// ---------------- 直链探测 ----------------
async function fetchText(u) {
  const r = await axios.get(u, { headers: PLAY_HEADERS, timeout: 15000, responseType: "arraybuffer" });
  return Buffer.from(r.data).toString("utf8");
}

async function usable(u, liveOnly = true, gap = 1.2) {
  try {
    let t = await fetchText(u);
    if (t.includes("#EXT-X-STREAM-INF")) {
      for (const ln of t.split(/\r?\n/)) {
        const s = ln.trim();
        if (s && !s.startsWith("#")) {
          u = new URL(s, u).href;
          t = await fetchText(u);
          break;
        }
      }
    }
    if (!t.startsWith("#EXTM3U") || !t.includes("#EXTINF")) return "";
    await sleep(gap * 1000);
    const t2 = await fetchText(u);
    if (!t2.startsWith("#EXTM3U") || !t2.includes("#EXTINF")) return "";
    if (liveOnly && t2 === t) return "";
    return u;
  } catch {
    return "";
  }
}

async function resolveChannel(slug) {
  const info = CHANNEL_MAP.get(slug);
  if (!info) return "";
  const modes = FORCE_BK.has(slug) ? ["bk", "jce"] : ["jce", "bk"];
  for (const [liveOnly, gap] of [[true, 5], [false, 5], [false, 0]]) {
    for (const mode of modes) {
      let cands = [];
      try {
        if (mode === "jce") {
          const now = Math.floor(Date.now() / 1000);
          cands = [await jceTimeshiftUrl(info.pid, info.sid, now - 300, now, info.defn)];
        } else {
          cands = await bkPlayurls(info.sid, info.pid, info.defn);
          cands.sort((a, b) => (a.includes("ali") ? 1 : 0) - (b.includes("ali") ? 1 : 0));
        }
      } catch {
        continue;
      }
      for (const u of cands) {
        const u2 = await usable(u, liveOnly, mode === "bk" ? gap : 1.2);
        if (u2) return u2;
      }
    }
  }
  return "";
}

// ---------------- 内容接口 ----------------
function formatRemarks(brand = "央视频", meta = "") {
  const clean = String(meta || "").replace(/[\r\n\t]+/g, " ").trim();
  return clean ? brand + " | " + clean : brand;
}

function classify(slug) {
  const cats = [];
  if ((/^cctv\d/.test(slug) || slug === "cctv5p") && !TRUE_4K.has(slug)) cats.push("cctv");
  if (TRUE_4K.has(slug)) cats.push("4k");
  if (slug === "cctvfyjc" || slug === "cctvdyjc" || slug === "cctvhjjc") cats.push("premium");
  if (slug.endsWith("ws") || slug === "cetv1") cats.push("satellite");
  if (slug.startsWith("cgtn")) cats.push("cgtn");
  if (slug === "guoxue") cats.push("other");
  return cats;
}

function card(slug, name) {
  const tag = TRUE_4K.has(slug) ? "真4K" : BACKEND_CHANNELS.has(slug) ? "高码率" : "";
  return {
    vod_id: slug,
    vod_name: name,
    vod_pic: logoUrl(slug, name),
    vod_remarks: formatRemarks("央视频", tag),
    style: { type: "rect", ratio: 1.78 },
  };
}

function homeContent() {
  return { class: CLASSES, filters: {}, list: [] };
}

function categoryContent(tid) {
  const cards = [];
  for (const [slug, name] of CHANNELS.map((c) => [c[0], c[1]])) {
    if (classify(slug).includes(tid)) cards.push(card(slug, name));
  }
  return { page: 1, pagecount: 1, limit: cards.length, total: cards.length, list: cards };
}

function detailContent(id) {
  const slug = Array.isArray(id) ? String(id[0]) : String(id);
  const info = CHANNEL_MAP.get(slug);
  if (!info) return { list: [] };
  let desc = "【📺 央视频直播】\n频道: " + info.name + "\nHLS 直播，解析直链直连央视 CDN。";
  desc = desc.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  return {
    list: [{
      vod_id: slug,
      vod_name: info.name,
      vod_pic: logoUrl(slug, info.name),
      vod_remarks: formatRemarks("央视频", "直播"),
      vod_content: desc,
      vod_play_from: "央视频",
      vod_play_url: "超清$" + slug,
    }],
  };
}

function searchContent(wd) {
  const key = String(wd || "").trim().toLowerCase();
  const cards = [];
  for (const [slug, name] of CHANNELS.map((c) => [c[0], c[1]])) {
    if (key && (name.toLowerCase().includes(key) || slug.includes(key))) cards.push(card(slug, name));
  }
  return { page: 1, pagecount: 1, limit: cards.length, total: cards.length, list: cards };
}

async function playContent(id) {
  const slug = String(id).trim();
  if (slug.startsWith("http://") || slug.startsWith("https://")) {
    return { parse: 0, url: slug, header: { ...PLAY_HEADERS } };
  }
  if (!CHANNEL_MAP.has(slug)) return { parse: 0, url: "", header: {} };
  const url = await resolveChannel(slug);
  return { parse: 0, url, header: { ...PLAY_HEADERS } };
}

// ---------------- 路由注册 ----------------
const meta = {
  key: "yangshipin",
  name: "央视频直播",
  type: 4,
  api: "/video/yangshipin",
  searchable: 1,
  quickSearch: 1,
  changeable: 0,
};

module.exports = async (app, opt) => {
  app.get(meta.api, async (req, reply) => {
    const { t, ac, pg, ids, play, wd } = req.query || {};
    try {
      if (play) return await playContent(play);
      if (wd) return await searchContent(wd);
      if (ac === "class") return { class: CLASSES };
      if (ac === "detail") {
        if (t) return await categoryContent(t);
        if (ids) return await detailContent(String(ids).split(",").map((x) => x.trim()).filter(Boolean));
      }
      if (!ac) return homeContent();
      return { list: [], page: 1, pagecount: 1, total: 0 };
    } catch (e) {
      req.server?.log?.error?.("[央视频直播] " + ((e && e.stack) || e));
      return { list: [], page: 1, pagecount: 1, total: 0, error: String((e && e.message) || e) };
    }
  });
  opt.sites.push(meta);
};
