// 云朵影视 猫源 (buyue/vodspider 框架, routes 自动加载, 苹果CMS/catvod 协议)
// 站点: https://he22ello3as.top  (SPA, 数据走 /api.php/web/* JSON 接口)
// play 解码: 对 /api.php/web/decode/url 发送带签名的 protobuf 请求, 返回 m3u8 直链
const axios = require("axios");
const crypto = require("crypto");
const http = require("http");
const https = require("https");

const HOST = "https://he22ello3as.top";
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.54 Safari/537.36";

const API_HOME = HOST + "/api.php/web/index/home";
const API_RANKING = HOST + "/api.php/web/ranking/list";
const API_FILTER = HOST + "/api.php/web/filter/vod";
const API_DETAIL = HOST + "/api.php/web/vod/get_detail";
const API_SEARCH = HOST + "/api.php/web/search/index";
const API_DECODE = HOST + "/api.php/web/decode/url";

// ---- 核心机密参数 (用于计算签名, 与原始 Python 一致, 站点改版时同步更新) ----
const REAL_FINGER =
  "WF-9e14d752872961ca1f5f125a6607c2712535b8d8b5c1294423c2da8436a41000";
const REAL_SK =
  "WEB-df5526941b0e3165d0a8485119ca3628b45f2b4a5c4b888bf01645a7060e1638";
const REAL_ID = "com.web.player.6c3b998c";

const JSON_HEADERS = {
  "User-Agent": UA,
  "Referer": HOST + "/",
  "Accept": "application/json",
  "X-Client": "8f3d2a1c7b6e5d4c9a0b1f2e3d4c5b6a",
  "web-sign": "yda81x6d9ad3c4s",
};
const PB_HEADERS = {
  "User-Agent": UA,
  "Referer": HOST + "/play/0",
  "Content-Type": "application/x-protobuf",
  "Accept": "application/x-protobuf",
  "web-sign": "yda81x6d9ad3c4s",
  "X-Client": "8f3d2a1c7b6e5d4c9a0b1f2e3d4c5b6a",
};

const _http = axios.create({
  timeout: 15 * 1000,
  httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
  httpAgent: new http.Agent({ keepAlive: true }),
});

// ============ 排行榜缓存 (5分钟过期, 避免重复请求) ============
let _rankingCache = null;
let _rankingTs = 0;
const RANKING_TTL = 5 * 60 * 1000;

async function getRankings() {
  const now = Date.now();
  if (_rankingCache && now - _rankingTs < RANKING_TTL) {
    return _rankingCache;
  }
  const j = (await _http.get(API_RANKING, { headers: JSON_HEADERS })).data;
  _rankingCache = (j.data && j.data.rankings) || [];
  _rankingTs = now;
  return _rankingCache;
}

// ============ protobuf 手工编解码 (schema 已知, 无需第三方库) ============
function varint(n) {
  const out = [];
  while (true) {
    const b = n & 0x7f;
    n = Math.floor(n / 128);
    if (n) out.push(b | 0x80);
    else {
      out.push(b);
      break;
    }
  }
  return Buffer.from(out);
}
function pbBytes(field, data) {
  const b = Buffer.isBuffer(data) ? data : Buffer.from(data, "utf-8");
  return Buffer.concat([Buffer.from([(field << 3) | 2]), varint(b.length), b]);
}
function pbVarint(field, n) {
  return Buffer.concat([Buffer.from([(field << 3) | 0]), varint(n)]);
}
// 对应 Python generate_payload: 构造签名 + protobuf 请求体
function generatePayload(tokenVal, vodFrom) {
  const t = Math.floor(Date.now() / 1000);
  const nonce = crypto.randomBytes(16).toString("hex");
  const v = 1;
  const sig = `finger=${REAL_FINGER}&id=${REAL_ID}&nonce=${nonce}&sk=${REAL_SK}&time=${t}&v=${v}`;
  const sign = crypto
    .createHash("sha256")
    .update(sig)
    .digest("hex")
    .toUpperCase();
  return Buffer.concat([
    pbBytes(1, tokenVal),
    pbBytes(2, vodFrom),
    pbVarint(3, t),
    pbBytes(4, nonce),
    pbBytes(5, sign),
    pbBytes(6, REAL_ID),
    pbVarint(7, v),
  ]);
}
function readVarint(buf, pos) {
  let result = 0,
    shift = 0,
    i = pos;
  while (i < buf.length) {
    const b = buf[i++];
    result |= (b & 0x7f) << shift;
    if (!(b & 0x80)) break;
    shift += 7;
  }
  return [result, i];
}
// 通用 protobuf 解析: 自动识别 varint(数字) / length-delimited(字符串)
function parsePb(buf) {
  const out = {};
  let i = 0;
  while (i < buf.length) {
    const [key, ni] = readVarint(buf, i);
    i = ni;
    const fld = key >> 3;
    const wire = key & 7;
    if (wire === 0) {
      const [val, vi] = readVarint(buf, i);
      i = vi;
      (out[fld] = out[fld] || []).push(val);
    } else if (wire === 2) {
      const [len, li] = readVarint(buf, i);
      i = li;
      const data = buf.subarray(i, i + len);
      i += len;
      let s;
      try {
        s = data.toString("utf-8");
      } catch (e) {
        s = data;
      }
      (out[fld] = out[fld] || []).push(s);
    } else break;
  }
  return out;
}

function stripHtml(s) {
  return String(s || "")
    .replace(/<[^>]+>/g, "")
    .replace(/&.{1,5};/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

// 统一列表字段格式 (catvod 协议)
function pickItem(v) {
  return {
    vod_id: String(v.vod_id),
    vod_name: v.vod_name,
    vod_pic: v.vod_pic,
    vod_remarks: v.vod_remarks || "",
  };
}
function pickList(arr) {
  return (arr || []).map(pickItem);
}

// ============ 接口实现 ============

// 首页分类列表 (不返回 list, 让 CatVod 按标签独立请求)
async function home() {
  const j = (await _http.get(API_HOME, { headers: JSON_HEADERS })).data;
  const cats = (j.data && j.data.categories) || [];
  const classes = cats.map((c) => ({
    type_id: String(c.type_id),
    type_name: c.type_name,
  }));
  // 关键: 不返回 list 字段! 否则 CatVod 会把首页推荐缓存用于所有标签
  return { class: classes, filters: {} };
}

// 分类内容 (使用 ranking/list 接口, 每个分类返回不同数据)
async function category(tid, pg) {
  // 第一页用排行榜 (分类精准)
  if (!pg || pg <= 1) {
    const rankings = await getRankings();
    const cat = rankings.find((r) => String(r.type_id) === String(tid));
    if (cat && cat.videos && cat.videos.length) {
      return {
        page: 1,
        pagecount: 1,
        list: pickList(cat.videos),
        total: cat.videos.length,
        limit: cat.videos.length,
      };
    }
  }

  // 第二页起用 filter 接口兜底 (该接口不分类型但可翻页)
  const j = (
    await _http.get(API_FILTER, {
      params: { type_id: tid, page: pg || 1, sort: "time" },
      headers: JSON_HEADERS,
    })
  ).data;
  return {
    page: j.page || pg || 1,
    pagecount: j.pageCount || 1,
    list: pickList(j.data),
    total: j.total || (j.data ? j.data.length : 0),
    limit: (j.data && j.data.length) || 0,
  };
}

async function detail(ids) {
  const list = [];
  for (const id of ids) {
    const j = (
      await _http.get(API_DETAIL, {
        params: { vod_id: id },
        headers: JSON_HEADERS,
      })
    ).data;
    const v = j.data && j.data[0];
    if (!v) continue;
    const froms = String(v.vod_play_from || "")
      .split("$$$")
      .map((s) => s.trim())
      .filter(Boolean);
    const urls = String(v.vod_play_url || "")
      .split("$$$")
      .map((s) => s.trim())
      .filter(Boolean);
    list.push({
      vod_id: String(v.vod_id),
      vod_name: v.vod_name,
      vod_pic: v.vod_pic,
      vod_content: stripHtml(v.vod_content),
      vod_remarks: v.vod_remarks || "",
      vod_year: v.vod_year || "",
      vod_area: v.vod_area || "",
      vod_actor: v.vod_actor || "",
      vod_director: v.vod_director || "",
      vod_play_from: froms.join("$$$"),
      vod_play_url: urls.join("$$$"),
    });
  }
  return { list };
}

async function search(wd, pg) {
  const j = (
    await _http.get(API_SEARCH, {
      params: { wd: wd, page: pg, limit: 15 },
      headers: JSON_HEADERS,
    })
  ).data;
  return {
    list: pickList(j.data),
    page: j.page || pg,
    pagecount: j.pageCount || 1,
    total: j.total || (j.data ? j.data.length : 0),
    limit: (j.data && j.data.length) || 0,
  };
}

// 解码播放令牌 -> m3u8 直链
async function playDecode(token, flag) {
  // 已是网页/视频地址 (如 qq 源) -> 交给客户端解析器
  if (/^https?:\/\//i.test(token)) {
    if (
      /\.(m3u8|mp4|rmvb|avi|wmv|flv|mkv|webm|mov|m3u)(?!\w)/i.test(token)
    ) {
      return { url: token, parse: 0, jx: 0, header: { "User-Agent": UA, Referer: HOST + "/" } };
    }
    return { url: token, parse: 1, jx: 0 };
  }
  // token 可能被 URL 编码过 (如 CO4K 的 %2B), 先解码
  let decodedToken;
  try { decodedToken = decodeURIComponent(token); } catch (e) { decodedToken = token; }
  try {
    const payload = generatePayload(decodedToken, flag || "");
    const resp = await _http.post(API_DECODE, payload, {
      headers: PB_HEADERS,
      responseType: "arraybuffer",
      timeout: 10000,
    });
    const buf = Buffer.isBuffer(resp.data)
      ? resp.data
      : Buffer.from(resp.data);
    const pb = parsePb(buf);
    const code = pb[1] && pb[1][0];
    const url = pb[3] && pb[3][0];
    if (code === 1 && url) {
      return {
        url: url,
        parse: 0,
        jx: 0,
        header: { "User-Agent": UA, Referer: HOST + "/" },
      };
    }
    // 解码返回非成功码 -> 返回提示信息让前端展示
    return { url: "", parse: 0, jx: 0, msg: (pb[2] && pb[2][0]) || ("解码失败(code=" + code + ")") };
  } catch (err) {
    // 网络超时/异常 -> 返回错误信息而非抛异常(避免 500)
    return { url: "", parse: 0, jx: 0, msg: "播放解析失败: " + (err.message || "未知错误").slice(0, 80) };
  }
}

// ============ 站点信息 ============
const meta = {
  key: "yunduo",
  name: "[纯]云朵影视",
  type: 4,
  api: "/video/yunduo",
  searchable: 1,
  quickSearch: 1,
  filterable: 0,
};

// ============ 路由 (单 GET, 按 req.query 分发) ============
module.exports = async (app, opt) => {
  app.get(meta.api, async (req, reply) => {
    delete req.query.token;
    const q = req.query;
    const { play, ac, t, pg, wd, ids, flag } = q;

    // ===== 播放直链 & 中转 =====
    if (play) {
      return await playDecode(play, flag || "");
    }
    if (ac === "play" || ac === "videourl") {
      const pid = q.id || q.url || q.play;
      if (pid) return await playDecode(pid, flag || "");
    }

    // ===== 搜索 =====
    if (wd || ac === "search") {
      return await search(wd || q.keyword || "", parseInt(pg) || 1);
    }

    // ===== 详情 (按 ids) =====
    if (ids || ac === "detail") {
      const idList = String(ids || q.id || "")
        .split(",")
        .filter(Boolean);
      if (idList.length) return await detail(idList);
    }

    // ===== 分类首页 (只返回 class 列表, 不带 list!) =====
    if (!ac || (ac === "list" && !t)) {
      return await home();
    }

    // ===== 分类内容 (按 type_id 从排行榜取对应分类数据) =====
    if (t) {
      return await category(t, parseInt(pg) || 1);
    }

    return { list: [] };
  });

  opt.sites.push(meta);
};
