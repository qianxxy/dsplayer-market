const axios = require("axios");
const cheerio = require("cheerio");
const http = require("http");
const https = require("https");

const _http = axios.create({
    timeout: 15 * 1000,
    httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
    httpAgent: new http.Agent({ keepAlive: true }),
});

// 奇优影院配置
const qiyouConfig = {
    host: "http://qiyoudy5.com",
    headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Referer": "http://qiyoudy5.com/",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        "Accept-Encoding": "gzip, deflate"
    }
};

const PAGE_LIMIT = 90;

// 辅助函数：获取第一个元素或默认值
const getFirst = (array, defaultValue = "") => {
    return array && array.length > 0 ? array[0] : defaultValue;
};

// 解析HTML内容
const parseHtml = (content) => {
    try {
        return cheerio.load(content);
    } catch (error) {
        console.error('解析HTML错误:', error.message);
        return null;
    }
};

// 清理HTML特殊字符
const cleanHtml = (html) => {
    if (!html) return '';
    return html
        .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '')
        .replace(/&nbsp;/g, ' ')
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"');
};

// 获取分类
const getClasses = async () => {
    return [
        { type_id: "1", type_name: "电影" },
        { type_id: "2", type_name: "电视剧" },
        { type_id: "3", type_name: "动漫" },
        { type_id: "4", type_name: "综艺" },
        { type_id: "6", type_name: "午夜" }
    ];
};

// 获取筛选器
const getFilters = async () => {
    return {
        "1": [{ "key": "by", "name": "排序", "value": [{ "n": "按时间", "v": "time" }, { "n": "按人气", "v": "hit" }] }],
        "2": [{ "key": "by", "name": "排序", "value": [{ "n": "按时间", "v": "time" }, { "n": "按人气", "v": "hit" }] }],
        "3": [{ "key": "by", "name": "排序", "value": [{ "n": "按时间", "v": "time" }, { "n": "按人气", "v": "hit" }] }],
        "4": [{ "key": "by", "name": "排序", "value": [{ "n": "按时间", "v": "time" }, { "n": "按人气", "v": "hit" }] }],
        "6": [{ "key": "by", "name": "排序", "value": [{ "n": "按时间", "v": "time" }, { "n": "按人气", "v": "hit" }] }]
    };
};

// 获取首页推荐视频
const getHomeRecommend = async () => {
    try {
        const response = await _http.get(qiyouConfig.host + "/", {
            headers: qiyouConfig.headers
        });
        
        const $ = parseHtml(response.data);
        if (!$) return [];
        
        const videos = [];
        
        // 轮播图
        $("div.carousel a.stui-vodlist__thumb").each((i, elem) => {
            try {
                const $elem = $(elem);
                const name = $elem.find("span.pic-text.text-center").text().trim() || 
                            $elem.attr("title") || "未知";
                
                const style = $elem.attr("style") || "";
                const picMatch = style.match(/background:\s*url\((.*?)\)/);
                const pic = picMatch ? picMatch[1] : "";
                
                const sid = $elem.attr("href") || "";
                
                if (name && sid) {
                    videos.push({
                        vod_id: sid,
                        vod_name: name,
                        vod_pic: pic,
                        vod_remarks: "推荐"
                    });
                }
            } catch (e) {
                console.log('轮播图解析失败:', e.message);
            }
        });
        
        // 视频列表
        $("ul.stui-vodlist a.stui-vodlist__thumb").each((i, elem) => {
            try {
                const $elem = $(elem);
                const name = $elem.attr("title") || "未知";
                const pic = $elem.attr("data-original") || "";
                const sid = $elem.attr("href") || "";
                const remark = $elem.find("span.pic-text.text-right").text().trim() || "";
                
                if (name && sid) {
                    videos.push({
                        vod_id: sid,
                        vod_name: name,
                        vod_pic: pic,
                        vod_remarks: remark
                    });
                }
            } catch (e) {
                console.log('视频列表解析失败:', e.message);
            }
        });
        
        console.log(`✅ 获取到 ${videos.length} 个首页推荐`);
        return videos;
    } catch (error) {
        console.error('❌ 首页推荐错误:', error.message);
        return [];
    }
};

// 获取分类内容
const getCategoryList = async (type, page = 1, extend = {}) => {
    try {
        const order = extend.by || 'time';
        const url = `${qiyouConfig.host}/list/${type}_${page}.html?order=${order}`;
        
        console.log(`📁 分类请求: ${url}`);
        
        const response = await _http.get(url, {
            headers: qiyouConfig.headers
        });
        
        const $ = parseHtml(response.data);
        if (!$) return { list: [], page, pagecount: 1 };
        
        const videos = [];
        
        $("a.stui-vodlist__thumb").each((i, elem) => {
            try {
                const $elem = $(elem);
                const name = $elem.attr("title") || "未知";
                const pic = $elem.attr("data-original") || "";
                const sid = $elem.attr("href") || "";
                const remark = $elem.find("span.pic-text.text-right").text().trim() || "";
                
                if (name && sid) {
                    videos.push({
                        vod_id: sid,
                        vod_name: name,
                        vod_pic: pic,
                        vod_remarks: remark
                    });
                }
            } catch (e) {
                console.log('分类项解析失败:', e.message);
            }
        });
        
        // 获取分页信息
        let currentPage = page;
        let totalPage = 1;
        
        const activePage = $("ul.stui-page a.active").text();
        if (activePage) {
            currentPage = parseInt(activePage) || page;
        }
        
        // 提取所有页面链接中的页码
        const pageNumbers = [];
        $("ul.stui-page a[href*='list']").each((i, elem) => {
            const href = $(elem).attr("href");
            if (href) {
                const match = href.match(/list\/\d+_(\d+)\.html/);
                if (match) {
                    pageNumbers.push(parseInt(match[1]));
                }
            }
        });
        
        if (pageNumbers.length > 0) {
            totalPage = Math.max(...pageNumbers);
        }
        
        console.log(`✅ 分类 ${type} 第 ${currentPage}/${totalPage} 页获取到 ${videos.length} 个项目`);
        
        return {
            list: videos,
            page: currentPage,
            pagecount: totalPage > 0 ? totalPage : 9999,
            limit: PAGE_LIMIT,
            total: 999999
        };
    } catch (error) {
        console.error('❌ 分类列表错误:', error.message);
        return { list: [], page, pagecount: 1, limit: PAGE_LIMIT, total: 0 };
    }
};

// 获取详情
const getDetail = async (id) => {
    try {
        const url = qiyouConfig.host + id;
        console.log('🔍 获取详情:', url);
        
        const response = await _http.get(url, {
            headers: qiyouConfig.headers
        });
        
        const $ = parseHtml(response.data);
        if (!$) return null;
        
        // 基本信息
        const detailNode = $("div.stui-content__detail, div.stui-player__detail").first();
        
        let pic = $("meta[property='og:image']").attr("content") || 
                 detailNode.find("img").attr("data-original") || "";
        
        let title = detailNode.find("h1").text().trim();
        if (!title) {
            const pageTitle = $("title").text();
            const match = pageTitle.match(/《(.*?)》/);
            title = match ? match[1] : pageTitle;
        }
        
        const area = $("meta[property='og:video:area']").attr("content") || "";
        const director = $("meta[property='og:video:director']").attr("content") || "";
        const actor = $("meta[property='og:video:actor']").attr("content") || "";
        const desc = $("meta[property='og:description']").attr("content") || "";
        
        // 年份
        let year = "";
        const yearText = $("p.data").text();
        if (yearText) {
            const match = yearText.match(/年份：(\d{4})/);
            year = match ? match[1] : "";
        }
        
        // 播放列表
        const playFrom = [];
        const playUrl = [];
        
        $("ul.nav-tabs li").each((i, elem) => {
            const $elem = $(elem);
            const tabName = $elem.find("a").text().trim();
            const tabId = ($elem.find("a").attr("href") || "").replace("#", "");
            
            if (tabName && tabId) {
                const episodes = [];
                $(`#${tabId} ul.stui-content__playlist a`).each((j, epElem) => {
                    const $ep = $(epElem);
                    const epName = $ep.text().trim() || "播放";
                    let epUrl = $ep.attr("href") || "";
                    
                    if (epUrl) {
                        episodes.push(`${epName}$${epUrl}`);
                    }
                });
                
                if (episodes.length > 0) {
                    playFrom.push(tabName);
                    playUrl.push(episodes.join("#"));
                }
            }
        });
        
        // 如果没有找到播放列表，尝试其他选择器
        if (playFrom.length === 0) {
            $("ul.stui-content__playlist a").each((i, elem) => {
                const $elem = $(elem);
                const epName = $elem.text().trim() || "播放";
                let epUrl = $elem.attr("href") || "";
                
                if (epUrl) {
                    if (!playFrom.includes("播放列表")) {
                        playFrom.push("播放列表");
                    }
                    if (!playUrl[0]) {
                        playUrl[0] = "";
                    }
                    playUrl[0] += (playUrl[0] ? "#" : "") + `${epName}$${epUrl}`;
                }
            });
        }
        
        const detail = {
            vod_id: id,
            vod_name: title,
            vod_pic: pic,
            vod_year: year,
            vod_area: area,
            vod_actor: actor,
            vod_director: director,
            vod_content: desc
        };
        
        if (playFrom.length > 0 && playUrl.length > 0) {
            detail.vod_play_from = playFrom.join("$$$");
            detail.vod_play_url = playUrl.join("$$$");
        }
        
        console.log('✅ 详情获取成功:', title);
        return detail;
    } catch (error) {
        console.error('❌ 详情获取错误:', error.message);
        return null;
    }
};

// 搜索功能
const searchVod = async (keyword, page = 1) => {
    try {
        console.log(`🔍 搜索: "${keyword}" 第 ${page} 页`);
        
        const url = qiyouConfig.host + "/search.php";
        const postData = new URLSearchParams({
            searchword: keyword
        }).toString();
        
        const response = await _http.post(url, postData, {
            headers: {
                ...qiyouConfig.headers,
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                "Origin": qiyouConfig.host,
                "Referer": qiyouConfig.host + "/"
            }
        });
        
        const $ = parseHtml(response.data);
        if (!$) return { list: [], page, pagecount: 1, total: 0 };
        
        const videos = [];
        
        // 多种选择器尝试
        const selectors = [
            "ul.stui-vodlist__media li",
            "ul.stui-vodlist li", 
            "a.stui-vodlist__thumb"
        ];
        
        let foundItems = [];
        
        for (const selector of selectors) {
            foundItems = $(selector);
            if (foundItems.length > 0) break;
        }
        
        foundItems.each((i, elem) => {
            try {
                const $elem = $(elem);
                let href, title, pic, remark;
                
                if ($elem.is('a')) {
                    href = $elem.attr("href") || "";
                    title = $elem.attr("title") || "";
                    pic = $elem.attr("data-original") || "";
                    remark = $elem.find("span.pic-text").text().trim() || "";
                } else {
                    const link = $elem.find("a.stui-vodlist__thumb").first() || $elem.find("a").first();
                    if (link.length > 0) {
                        href = link.attr("href") || "";
                        title = link.attr("title") || "";
                        pic = link.attr("data-original") || "";
                        
                        // 尝试从style中获取图片
                        if (!pic) {
                            const style = link.attr("style") || "";
                            const match = style.match(/background-image:\s*url\(['"]?(.*?)['"]?\)/);
                            if (match) pic = match[1];
                        }
                        
                        remark = $elem.find("span.pic-text").text().trim() || "";
                    }
                }
                
                if (href && title) {
                    videos.push({
                        vod_id: href,
                        vod_name: title.trim(),
                        vod_pic: pic,
                        vod_remarks: remark
                    });
                }
            } catch (e) {
                console.log('搜索项解析失败:', e.message);
            }
        });
        
        // 备用方案
        if (videos.length === 0) {
            $("a[href*='/vod/']").each((i, elem) => {
                const $elem = $(elem);
                const href = $elem.attr("href") || "";
                const title = $elem.attr("title") || $elem.text().trim();
                const pic = $elem.attr("data-original") || "";
                const remark = $elem.find("span.pic-text").text().trim() || "";
                
                if (href && title) {
                    videos.push({
                        vod_id: href,
                        vod_name: title.trim(),
                        vod_pic: pic,
                        vod_remarks: remark
                    });
                }
            });
        }
        
        // 去重
        const seen = new Set();
        const uniqueVideos = [];
        
        videos.forEach(video => {
            const identifier = video.vod_id + video.vod_name;
            if (!seen.has(identifier)) {
                seen.add(identifier);
                uniqueVideos.push(video);
            }
        });
        
        console.log(`✅ 搜索 "${keyword}" 找到 ${uniqueVideos.length} 个结果`);
        
        return {
            list: uniqueVideos,
            page: parseInt(page),
            pagecount: uniqueVideos.length >= PAGE_LIMIT ? parseInt(page) + 1 : parseInt(page),
            total: uniqueVideos.length
        };
    } catch (error) {
        console.error('❌ 搜索错误:', error.message);
        return { list: [], page: parseInt(page), pagecount: 1, total: 0 };
    }
};

// 获取播放地址
const getPlayUrl = async (playUrl) => {
    try {
        console.log('🎬 处理播放URL:', playUrl);
        
        const url = qiyouConfig.host + playUrl;
        const response = await _http.get(url, {
            headers: qiyouConfig.headers
        });
        
        const html = response.data;
        
        // 1. 查找API链接
        const apiPatterns = [
            /http:\/\/api\.yongfan99\.com:81\/content\.php\?[^'"]+/,
            /content\.php\?vid=[^&]+&type=[^'"]+/
        ];
        
        for (const pattern of apiPatterns) {
            const match = html.match(pattern);
            if (match) {
                let apiUrl = match[0];
                if (!apiUrl.startsWith('http')) {
                    apiUrl = "http://api.yongfan99.com:81/" + apiUrl;
                }
                
                try {
                    const apiResponse = await _http.get(apiUrl, {
                        headers: {
                            ...qiyouConfig.headers,
                            "Referer": url
                        }
                    });
                    
                    const m3u8Match = apiResponse.data.match(/http[s]?:\/\/[^\s"']+\.m3u8[^\s"']*/);
                    if (m3u8Match) {
                        console.log('✅ 从API找到m3u8地址');
                        return {
                            parse: 0,
                            url: m3u8Match[0],
                            header: {
                                "User-Agent": qiyouConfig.headers["User-Agent"],
                                "Referer": url
                            }
                        };
                    }
                } catch (apiError) {
                    console.log('API请求失败:', apiError.message);
                }
            }
        }
        
        // 2. 查找iframe
        const iframePattern = /<iframe[^>]*src=['"]([^'"]+)['"][^>]*>/g;
        let iframeMatch;
        
        while ((iframeMatch = iframePattern.exec(html)) !== null) {
            let iframeUrl = iframeMatch[1];
            if (iframeUrl.startsWith('//')) {
                iframeUrl = 'https:' + iframeUrl;
            } else if (iframeUrl.startsWith('/')) {
                iframeUrl = qiyouConfig.host + iframeUrl;
            } else if (!iframeUrl.startsWith('http')) {
                iframeUrl = qiyouConfig.host + '/' + iframeUrl;
            }
            
            try {
                const iframeResponse = await _http.get(iframeUrl, {
                    headers: {
                        ...qiyouConfig.headers,
                        "Referer": url
                    }
                });
                
                const m3u8Match = iframeResponse.data.match(/http[s]?:\/\/[^\s"']+\.m3u8[^\s"']*/);
                if (m3u8Match) {
                    console.log('✅ 从iframe找到m3u8地址');
                    return {
                        parse: 0,
                        url: m3u8Match[0],
                        header: {
                            "User-Agent": qiyouConfig.headers["User-Agent"],
                            "Referer": iframeUrl
                        }
                    };
                }
            } catch (iframeError) {
                console.log('iframe请求失败:', iframeError.message);
            }
        }
        
        // 3. 直接搜索m3u8
        const directM3u8Match = html.match(/http[s]?:\/\/[^\s"']+\.m3u8[^\s"']*/);
        if (directM3u8Match) {
            console.log('✅ 直接找到m3u8地址');
            return {
                parse: 0,
                url: directM3u8Match[0],
                header: {
                    "User-Agent": qiyouConfig.headers["User-Agent"],
                    "Referer": url
                }
            };
        }
        
        // 4. 返回原始URL进行外部解析
        console.log('⚠️ 未找到m3u8地址，返回原始URL');
        return {
            parse: 1,
            url: url,
            header: qiyouConfig.headers
        };
        
    } catch (error) {
        console.error('❌ 播放处理错误:', error.message);
        return {
            parse: 1,
            url: qiyouConfig.host + playUrl,
            header: qiyouConfig.headers
        };
    }
};

// TVBox T4 接口请求处理
const handleT4Request = async (req) => {
    try {
        const { ac, t, pg, wd, ids, play, quick, extend } = req.query;
        const page = parseInt(pg) || 1;

        console.log('📥 请求参数:', { 
            ac: ac || 'home', 
            t: t || 'none', 
            pg: page, 
            wd: wd || 'none', 
            ids: ids || 'none', 
            play: play ? '***' : 'none', 
            quick: quick || 'false',
            extend: extend || 'none'
        });

        // 1. 播放请求 - 最高优先级
        if (play) {
            console.log('🎬 播放请求');
            return await getPlayUrl(play);
        }

        // 2. 搜索请求
        if (wd && wd !== 'none') {
            console.log('🔍 搜索请求:', wd);
            const result = await searchVod(wd, page);
            if (quick === 'true') {
                result.list = result.list.slice(0, 10);
            }
            return {
                list: result.list,
                page: result.page,
                pagecount: result.pagecount,
                limit: PAGE_LIMIT,
                total: result.total
            };
        }

        // 3. 详情请求
        if (ids && ids !== 'none') {
            console.log('📋 详情请求:', ids);
            const detail = await getDetail(ids);
            return {
                list: detail ? [detail] : [],
                page: 1,
                pagecount: 1,
                total: detail ? 1 : 0
            };
        }

        // 4. 分类内容请求
        if (t && t !== 'none') {
            console.log('📁 分类请求:', t, '页码:', page);
            let extendParams = {};
            if (extend && extend !== 'none') {
                try {
                    extendParams = JSON.parse(extend);
                } catch (e) {
                    console.log('extend参数解析失败，使用默认值');
                }
            }
            const result = await getCategoryList(t, page, extendParams);
            return {
                list: result.list,
                page: result.page,
                pagecount: result.pagecount,
                limit: result.limit,
                total: result.total
            };
        }

        // 5. 首页请求
        console.log('🏠 首页请求');
        const classes = await getClasses();
        const filters = await getFilters();
        
        if (ac === 'class') {
            console.log('📋 分类列表请求');
            return { 
                class: classes,
                filters: filters
            };
        }
        
        const homeList = await getHomeRecommend();
        return {
            class: classes,
            filters: filters,
            list: homeList.slice(0, 20),
            page: 1,
            pagecount: 1,
            total: homeList.length
        };

    } catch (error) {
        console.error('❌ 接口处理错误:', error.message);
        return { 
            list: [], 
            page: 1, 
            pagecount: 1,
            error: error.message 
        };
    }
};

const meta = {
    key: "QiYou",
    name: "[纯]奇优影院",
    type: 4, // 影视类型
    api: "/video/QiYou",
};

module.exports = async (app, opt) => {
    app.get(meta.api, async (req, reply) => {
        const result = await handleT4Request(req);
        return result;
    });
    opt.sites.push(meta);
};