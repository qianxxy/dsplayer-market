/**
 * 【直播】央视直播
 * 央视频（yangshipin）+ 央视官网（tv.cctv.com）直播转点播 T4 源
 * - 频道目录：在线抓取，失败回落到 data/ 下的快照
 * - 播放地址：播放时实时鉴权换取 m3u8，多 CDN 线路
 * - 节目单：api.cntv.cn EPG，列表显示「正在播出」，详情展示当日节目表
 */

const axios = require('axios');
const crypto = require('crypto');
const https = require('https');
const fs = require('fs');
const os = require('os');
const path = require('path');

// ========== 元数据 ==========
const META = {
  key: 'cctvlive1',
  name: '[直播]央视直播',
  type: 4,
  api: '/video/cctvlive1',
  searchable: 1,
  quickSearch: 1,
  filterable: 1,
  changeable: 0,
  style: { type: 'rect', ratio: 1.33 }
};

const API_PATH = META.api;

// ========== 常量 ==========
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36';
const LOGO_URL = 'https://epg.112114.xyz/logo/{}.png';
const DEFAULT_PIC = 'https://ghproxy.net/https://raw.githubusercontent.com/hjdhnx/hipy-server/master/app/static/img/lives.jpg';

const CCTV_HOST = 'https://tv.cctv.com';
const CCTV_CATALOG_URL = CCTV_HOST + '/live/';
const CCTV_PLAY_URL = 'https://vdnx.live.cntv.cn/api/v3/vdn/live';
const CCTV_PLAY_SECRET = 'a4220a71b31746908fa3e7fdd7a6852a';
const CCTV_MIN_CHANNELS = 18;
const CCTV_ID_RE = /^cctv(?:\d+|5plus|jilu|child|europe|america)$/;
const CCTV_LINK_RE = /tv\.cctv\.com\/live\/(cctv(?:\d+|5plus|jilu|child|europe|america))\//gi;
const CCTV_LOGO_NAMES = {
  cctv5plus: 'CCTV5+',
  cctvjilu: 'CCTV9',
  cctvchild: 'CCTV14',
  cctveurope: 'CCTV4欧洲',
  cctvamerica: 'CCTV4美洲'
};

const YSP_HOST = 'https://www.yangshipin.cn';
const YSP_NAVIGATION_URL = 'https://capi.yangshipin.cn/api/oms/pc/navigation/home_top_nav';
const YSP_PAGE_URL = 'https://capi.yangshipin.cn/api/oms/pc/page/{}';
const YSP_PLAYER_URL = 'https://player-api.yangshipin.cn/v1/player/';
const YSP_OPEN_TOKEN_URL = 'https://h5access.yangshipin.cn/web/open/token';
const YSP_KEYGEN_URL = 'https://s.yangshipin.cn/CCTVVideo/cctvh5-openapicore/keygen_bg.wasm';
const YSP_APP_ID = '519748109';
const YSP_APP_VERSION = 'V1.0.0';
const YSP_PLATFORM = '5910204';
const YSP_AUTH_SALT = 'n@7QKk%YeSjfw%22';
const YSP_REQUEST_SALT = '0f$IVHi9Qno?G';
const YSP_OPEN_VAPP_ID = '59306155';
const YSP_OPEN_VSECRET = 'b42702bf7309a179d102f3d51b1add2fda0bc7ada64cb801';
const YSP_TICKET_KEYSTREAM = Buffer.from(
  '6a70e9ac007ccc384c28a88dfd2211decb66494bca83bd6178f85732b2eacc959' +
  '4e4e5ab720ec3a43e87b3c72b86192ff0dfea8fa8f47794d8792668438c',
  'hex'
);
const YSP_TICKET_SUFFIX = 'bSCz8SqH8T';
const YSP_CKEY_KEY = Buffer.from('48e5918a74ae21c972b90cce8af6c8be', 'hex');
const YSP_CKEY_IV = Buffer.from('9a7e7d23610266b1d9fbf98581384d92', 'hex');
const YSP_MIN_CHANNELS = 50;
const YSP_WASM_MIN = 20000;
const YSP_WASM_MAX = 100000;

const EPG_URL = 'https://api.cntv.cn/epg/getEpgInfoByChannelNew';

const GROUP_YANGSHI = '央视频道';
const GROUP_WEISHI = '卫视频道';
const GROUP_OTHER = '其他频道';
const GROUP_CCTV = '央视官网';
const YSP_GROUPS = { yangshi: GROUP_YANGSHI, weishi: GROUP_WEISHI };

const CLASS_ORDER = [
  { type_id: 'ysp_yangshi', type_name: GROUP_YANGSHI },
  { type_id: 'ysp_weishi', type_name: GROUP_WEISHI },
  { type_id: 'ysp_other', type_name: GROUP_OTHER },
  { type_id: 'cctv', type_name: GROUP_CCTV }
];

const XMLTV_NAMES = {
  CCTV1: 'CCTV-1 综合',
  CCTV2: 'CCTV-2 财经',
  CCTV3: 'CCTV-3 综艺',
  CCTV4: 'CCTV-4 中文国际',
  CCTV5: 'CCTV-5 体育',
  'CCTV5+': 'CCTV-5+ 体育赛事',
  CCTV6: 'CCTV-6 电影',
  CCTV7: 'CCTV-7 国防军事',
  CCTV8: 'CCTV-8 电视剧',
  CCTV9: 'CCTV-9 纪录',
  CCTV10: 'CCTV-10 科教',
  CCTV11: 'CCTV-11 戏曲',
  CCTV12: 'CCTV-12 社会与法',
  CCTV13: 'CCTV-13 新闻',
  CCTV14: 'CCTV-14 少儿',
  CCTV15: 'CCTV-15 音乐',
  'CCTV16-HD': 'CCTV-16 奥林匹克',
  'CCTV16(4K）': 'CCTV-16 奥林匹克',
  CCTV17: 'CCTV-17 农业农村',
  CCTV4K: 'CCTV-4K',
  CCTV8K: 'CCTV-8K',
  CGTN: 'CGTN 英语',
  CGTN法语频道: 'CGTN 法语',
  CGTN俄语频道: 'CGTN 俄语',
  CGTN阿拉伯语频道: 'CGTN 阿拉伯语',
  CGTN西班牙语频道: 'CGTN 西班牙语',
  CGTN外语纪录频道: 'CGTN 英文纪录'
};

const YSP_LOGO_NAMES = {
  'CCTV16-HD': 'CCTV16',
  'CCTV16(4K）': 'CCTV16-4K',
  CGTN阿拉伯语频道: 'CGTN阿拉伯语',
  CGTN西班牙语频道: 'CGTN西班牙语',
  CGTN外语纪录频道: 'CGTN纪录',
  'CCTV高尔夫·网球频道': 'CCTV高尔夫网球'
};

const CATALOG_TTL = 30 * 60 * 1000;
const EPG_TTL = 60 * 60 * 1000;
const PLAY_TTL = 50 * 1000;
const CATALOG_TIMEOUT = 8000;
const PLAYER_TIMEOUT = 15000;

const DATA_DIR = path.join(__dirname, 'data');
const CONFIG_PATH = path.join(DATA_DIR, 'cctvlive_config.json');
const CCTV_SNAPSHOT_PATH = path.join(DATA_DIR, 'cctv_channels.json');
const YSP_SNAPSHOT_PATH = path.join(DATA_DIR, 'yangshipin_channels.json');
const KEYGEN_CACHE_PATH = path.join(os.tmpdir(), 'ysp-keygen-v1.wasm');

// ========== 基础设施 ==========
let log = console;

// vdnx.live.cntv.cn 只支持 legacy renegotiation，需放宽 TLS 选项
const agent = new https.Agent({
  secureOptions: crypto.constants.SSL_OP_LEGACY_SERVER_CONNECT,
  keepAlive: true
});

const http = axios.create({ httpsAgent: agent, timeout: CATALOG_TIMEOUT });

const catalogCache = { time: 0, data: null };
const epgCache = new Map();
const playCache = new Map();
let keygenInstance = null;

function text(value = '') {
  return String(value === undefined || value === null ? '' : value).trim();
}

function pad2(value) {
  return String(value).padStart(2, '0');
}

function md5(value) {
  return crypto.createHash('md5').update(String(value), 'utf8').digest('hex');
}

function canonicalQuery(params) {
  return Object.keys(params).sort().map((key) => `${key}=${params[key]}`).join('&');
}

function signature(params, salt) {
  return md5(canonicalQuery(params) + salt);
}

function randomText(length = 10) {
  const alphabet = 'ABCDEFGHIJKlMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let index = 0; index < length; index += 1) {
    result += alphabet[crypto.randomInt(alphabet.length)];
  }
  return result;
}

function logoUrl(name, fallback = '') {
  const clean = text(name);
  if (!clean) return fallback;
  return LOGO_URL.replace('{}', encodeURIComponent(clean));
}

function shanghaiClock(seconds) {
  const stamp = Number(seconds);
  if (!Number.isFinite(stamp)) return '';
  const date = new Date((stamp + 8 * 3600) * 1000);
  return `${pad2(date.getUTCHours())}:${pad2(date.getUTCMinutes())}`;
}

function shanghaiToday() {
  const date = new Date(Date.now() + 8 * 3600 * 1000);
  return `${date.getUTCFullYear()}-${pad2(date.getUTCMonth() + 1)}-${pad2(date.getUTCDate())}`;
}

async function mapLimit(items, limit, worker) {
  const results = new Array(items.length);
  let cursor = 0;
  const runners = new Array(Math.min(limit, items.length)).fill(0).map(async () => {
    while (cursor < items.length) {
      const index = cursor;
      cursor += 1;
      try {
        results[index] = await worker(items[index], index);
      } catch {
        results[index] = null;
      }
    }
  });
  await Promise.all(runners);
  return results;
}

function readJsonFile(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return fallback;
  }
}

// ========== 配置 ==========
function readConfig() {
  const data = readJsonFile(CONFIG_PATH, {}) || {};
  return {
    showEpg: data.showEpg === undefined ? true : Boolean(data.showEpg),
    hideVip: Boolean(data.hideVip),
    def_pic: text(data.def_pic) || DEFAULT_PIC
  };
}

function writeConfig(data) {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(data, null, 2));
}

// ========== protobuf 极简解析（央视频目录接口） ==========
function readVarint(buffer, position) {
  let value = 0;
  let shift = 0;
  let cursor = position;
  while (cursor < buffer.length && shift < 70) {
    const byte = buffer[cursor];
    cursor += 1;
    value += (byte & 0x7f) * Math.pow(2, shift);
    if (byte < 0x80) return [value, cursor];
    shift += 7;
  }
  throw new Error('invalid protobuf varint');
}

function* protoFields(buffer) {
  let position = 0;
  while (position < buffer.length) {
    let key;
    [key, position] = readVarint(buffer, position);
    const field = Math.floor(key / 8);
    const wire = key & 7;
    if (!field) throw new Error('invalid protobuf field');
    let value;
    if (wire === 0) {
      [value, position] = readVarint(buffer, position);
    } else if (wire === 2) {
      let length;
      [length, position] = readVarint(buffer, position);
      value = buffer.subarray(position, position + length);
      position += length;
    } else if (wire === 1) {
      value = buffer.subarray(position, position + 8);
      position += 8;
    } else if (wire === 5) {
      value = buffer.subarray(position, position + 4);
      position += 4;
    } else {
      throw new Error('unsupported protobuf wire type');
    }
    if (position > buffer.length) throw new Error('truncated protobuf response');
    yield [field, wire, value];
  }
}

function protoMessage(buffer, repeated = new Set()) {
  const result = {};
  for (const [field, , value] of protoFields(buffer)) {
    if (repeated.has(field)) {
      if (!result[field]) result[field] = [];
      result[field].push(value);
    } else {
      result[field] = value;
    }
  }
  return result;
}

function protoText(value) {
  return Buffer.isBuffer(value) ? value.toString('utf8') : '';
}

function protoResponse(buffer) {
  const message = protoMessage(buffer);
  if (!Buffer.isBuffer(message[2])) throw new Error('invalid protobuf response');
  return [message[1] || 0, message[2]];
}

// ========== 央视频 wasm 签名 ==========
class Keygen {
  constructor(bytes) {
    this.state = {};
    this.heap = new Map();
    this.handle = 132;
    const imports = {
      wbg: {
        __wbg_get_9c1840f7ecd81363: (pointer, length) => {
          const key = this.readText(pointer, length);
          const prefix = 'cctvh5openapi.state.';
          let value = '';
          if (key.startsWith(prefix)) {
            value = this.state[key.slice(prefix.length)] || '';
          } else if (key === 'window.location.host') {
            value = 'www.yangshipin.cn';
          } else if (key === 'window.location.protocol') {
            value = 'https:';
          }
          const handle = this.handle;
          this.handle += 1;
          this.heap.set(handle, String(value));
          return handle;
        },
        __wbindgen_string_get: (output, handle) => {
          const payload = Buffer.from(this.heap.get(handle) || '', 'utf8');
          const pointer = this.exports.__wbindgen_malloc(payload.length, 1);
          Buffer.from(this.exports.memory.buffer).set(payload, pointer);
          const view = new DataView(this.exports.memory.buffer);
          view.setInt32(output, pointer, true);
          view.setInt32(output + 4, payload.length, true);
        },
        __wbindgen_object_drop_ref: (handle) => {
          this.heap.delete(handle);
        }
      }
    };
    const instance = new WebAssembly.Instance(new WebAssembly.Module(bytes), imports);
    this.exports = instance.exports;
    if (!this.exports.memory) throw new Error('missing keygen memory');
  }

  readText(pointer, length) {
    return Buffer.from(this.exports.memory.buffer, pointer, length).toString('utf8');
  }

  call(name) {
    const output = this.exports.__wbindgen_add_to_stack_pointer(-16);
    let pointer = 0;
    let length = 0;
    try {
      this.exports[name](output);
      const view = new DataView(this.exports.memory.buffer);
      pointer = view.getInt32(output, true);
      length = view.getInt32(output + 4, true);
      return this.readText(pointer, length);
    } finally {
      if (pointer) this.exports.__wbindgen_free(pointer, length, 1);
      this.exports.__wbindgen_add_to_stack_pointer(16);
    }
  }

  tokenRandom(state) {
    this.state = state;
    return this.call('get_token_rnd');
  }

  signature(state) {
    this.state = state;
    return this.call('get_signature');
  }
}

function validWasm(bytes) {
  return Buffer.isBuffer(bytes)
    && bytes.length >= YSP_WASM_MIN
    && bytes.length <= YSP_WASM_MAX
    && bytes.subarray(0, 4).toString('binary') === '\u0000asm';
}

async function loadKeygen() {
  if (keygenInstance) return keygenInstance;
  let bytes = null;
  try {
    const cached = fs.readFileSync(KEYGEN_CACHE_PATH);
    if (validWasm(cached)) bytes = cached;
  } catch {
    bytes = null;
  }
  if (!bytes) {
    const response = await http.get(YSP_KEYGEN_URL, {
      responseType: 'arraybuffer',
      timeout: PLAYER_TIMEOUT,
      headers: { 'User-Agent': UA }
    });
    const payload = Buffer.from(response.data);
    if (!validWasm(payload)) throw new Error('无效的央视频签名模块');
    bytes = payload;
    try {
      fs.writeFileSync(KEYGEN_CACHE_PATH, payload);
    } catch (error) {
      log?.warn?.(`[央视直播] 缓存签名模块失败: ${error.message}`);
    }
  }
  keygenInstance = new Keygen(bytes);
  return keygenInstance;
}

// ========== 央视频播放地址 ==========
function yspTicket(pid, timestamp, guid) {
  const payload = Buffer.from(`${pid}&${timestamp}&${guid}&${YSP_APP_ID}&${YSP_TICKET_SUFFIX}`, 'utf8');
  if (payload.length > YSP_TICKET_KEYSTREAM.length) throw new Error('invalid ticket payload');
  const output = Buffer.alloc(payload.length);
  for (let index = 0; index < payload.length; index += 1) {
    output[index] = payload[index] ^ YSP_TICKET_KEYSTREAM[index];
  }
  return output.toString('hex');
}

function yspCkey(cnlid, timestamp, guid) {
  const raw = `|${cnlid}|${timestamp}|mg3c3b04ba|${YSP_APP_VERSION}|${guid}|${YSP_PLATFORM}`
    + '|https://www.yangshipin.c|mozilla/5.0 (windows nt ||Mozilla|Netscape|Win32|';
  let hash = 0;
  for (const character of raw) {
    hash = ((hash << 5) - hash + character.codePointAt(0)) | 0;
  }
  const source = Buffer.from(`|${hash}${raw}`, 'utf8');
  const cipher = crypto.createCipheriv('aes-128-cbc', YSP_CKEY_KEY, YSP_CKEY_IV);
  const encrypted = Buffer.concat([cipher.update(source), cipher.final()]);
  return '--01' + encrypted.toString('hex').toUpperCase();
}

function yspGuid() {
  return `${Date.now().toString(36)}_${randomText(11)}`;
}

function yspPlayerHeaders(guid) {
  return {
    Origin: YSP_HOST,
    Referer: YSP_HOST + '/',
    'User-Agent': UA,
    'sec-ch-ua': '"Chromium";v="148", "Not=A?Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    yspappid: YSP_APP_ID,
    Cookie: [
      `guid=${guid}`,
      'versionName=99.99.99',
      'versionCode=999999',
      'vplatform=109',
      'platformVersion=Chrome',
      'deviceModel=148',
      'newLogin=1',
      'nseqId=1'
    ].join('; ')
  };
}

async function yspAuth(pid, guid, headers) {
  const params = { pid, guid, appid: 'ysp_pc', rand_str: randomText() };
  params.signature = signature(params, YSP_AUTH_SALT);
  const response = await http.post(
    YSP_PLAYER_URL + 'auth',
    new URLSearchParams(params).toString(),
    {
      timeout: PLAYER_TIMEOUT,
      headers: { ...headers, 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' }
    }
  );
  const data = response.data?.data || {};
  if (response.data?.code !== 0 || !data.token || !data.ts) {
    throw new Error(response.data?.msg || '央视频鉴权失败');
  }
  return data;
}

async function yspSdkHeaders(guid, params, headers) {
  const keygen = await loadKeygen();
  const sdkInput = md5(canonicalQuery(params));
  const sequence = '1';
  const requestId = `999999${randomText()}${Date.now()}`;
  const composite = `${sdkInput}-${guid}-${sequence}-${requestId}`;
  const state = {
    guid,
    token: '',
    yspappid: YSP_APP_ID,
    input: '',
    ts: String(Date.now()),
    version: 'v1',
    query: 'object'
  };
  const tokenRandom = keygen.tokenRandom(state);
  const response = await http.get(YSP_OPEN_TOKEN_URL, {
    timeout: PLAYER_TIMEOUT,
    headers,
    params: {
      yspappid: YSP_APP_ID,
      guid,
      vappid: YSP_OPEN_VAPP_ID,
      vsecret: YSP_OPEN_VSECRET,
      raw: 1,
      version: 'v1',
      ts: state.ts,
      rnd: tokenRandom
    }
  });
  const token = response.data?.data?.token;
  if (!token) throw new Error(response.data?.msg || '央视频令牌获取失败');
  state.token = token;
  state.input = composite;
  const sdkSignature = keygen.signature(state) + '-' + composite;
  return {
    'Content-Type': 'application/json;charset=UTF-8',
    yspsdkinput: sdkInput,
    yspsdksign: sdkSignature,
    seqId: sequence,
    'request-id': requestId,
    yspappid: YSP_APP_ID
  };
}

async function resolveYsp(pid, cnlid) {
  const guid = yspGuid();
  const baseHeaders = yspPlayerHeaders(guid);
  const auth = await yspAuth(pid, guid, baseHeaders);
  const timestamp = String(Math.round(Date.now() / 1000));
  const params = {
    cnlid,
    livepid: pid,
    stream: '2',
    guid,
    cKey: yspCkey(cnlid, timestamp, guid),
    adjust: 1,
    sphttps: '1',
    platform: YSP_PLATFORM,
    cmd: '2',
    encryptVer: '8.1',
    dtype: '1',
    devid: 'devid',
    otype: 'ojson',
    appVer: YSP_APP_VERSION,
    app_version: YSP_APP_VERSION,
    channel: 'ysp_tx',
    defn: 'fhd'
  };
  const sdkHeaders = await yspSdkHeaders(guid, params, baseHeaders);
  params.rand_str = randomText();
  params.signature = signature(params, YSP_REQUEST_SALT);
  const response = await http.post(YSP_PLAYER_URL + 'get_live_info', params, {
    timeout: PLAYER_TIMEOUT,
    headers: {
      ...baseHeaders,
      ...sdkHeaders,
      yspPlayerToken: String(auth.token),
      yspticket: yspTicket(pid, String(auth.ts), guid)
    }
  });
  if (response.data?.code !== 0) throw new Error(response.data?.msg || '央视频拒绝该频道');
  const data = response.data?.data || {};
  if (data.iretcode !== undefined && data.iretcode !== null && data.iretcode !== 0) {
    throw new Error(data.errinfo || '该频道当前不可播放');
  }
  const candidates = [];
  for (const item of data.backurl_list || []) {
    if (item && typeof item.url === 'string') candidates.push(item.url);
  }
  if (typeof data.playurl === 'string') candidates.push(data.playurl);
  const urls = candidates.filter((item) => item.startsWith('https://'));
  if (!urls.length) throw new Error('未获取到播放地址');
  return { urls: Array.from(new Set(urls)), referer: YSP_HOST + '/' };
}

// ========== 央视官网播放地址 ==========
async function resolveCctv(channelId) {
  const timestamp = Date.now();
  const nonce = crypto.randomInt(100, 1001);
  const digest = md5(`${channelId}${timestamp}${nonce}${CCTV_PLAY_SECRET}`);
  const response = await http.get(CCTV_PLAY_URL, {
    timeout: PLAYER_TIMEOUT,
    params: {
      channel: channelId,
      vn: '1',
      pdrm: '1',
      uid: crypto.randomBytes(18).toString('base64'),
      hbss: String(timestamp)
    },
    headers: {
      'auth-key': `${timestamp}-${nonce}-${digest}`,
      Origin: CCTV_HOST,
      Referer: CCTV_HOST + '/',
      'User-Agent': UA,
      'X-Requested-With': 'XMLHttpRequest'
    }
  });
  const result = response.data || {};
  if (result.ack !== 'yes') throw new Error('央视官网拒绝该频道');
  const urls = [result.manifest?.hls_cdrm, result.backup?.hls_cdrm]
    .filter((item) => typeof item === 'string' && item.startsWith('http'));
  if (!urls.length) throw new Error('未获取到播放地址');
  return { urls: Array.from(new Set(urls)), referer: CCTV_HOST + '/' };
}

// ========== 播放 id ==========
function parsePlayId(value) {
  const parts = text(value).split('~~');
  if (parts[0] === 'cctv' && CCTV_ID_RE.test(parts[1] || '')) {
    return { provider: 'cctv', channelId: parts[1] };
  }
  if (parts[0] === 'ysp' && /^\d+$/.test(parts[1] || '') && /^\d*$/.test(parts[2] || '')) {
    return { provider: 'ysp', pid: parts[1], cnlid: parts[2] || '' };
  }
  return null;
}

async function resolvePlay(playId) {
  const parsed = parsePlayId(playId);
  if (!parsed) throw new Error('无效的频道标识');
  const key = text(playId);
  const hit = playCache.get(key);
  if (hit && Date.now() < hit.expire) return hit.data;
  const data = parsed.provider === 'cctv'
    ? await resolveCctv(parsed.channelId)
    : await resolveYsp(parsed.pid, parsed.cnlid);
  playCache.set(key, { expire: Date.now() + PLAY_TTL, data });
  return data;
}

// ========== EPG ==========
function cntvEpgId(name) {
  const clean = text(name);
  const special = {
    'CCTV5+': 'cctv5plus',
    'CCTV16-HD': 'cctv16',
    'CCTV16(4K）': 'cctv16',
    CCTV4K: 'cctv4k',
    CCTV8K: 'cctv8k',
    CCTV第一剧场频道: 'diyijuchang',
    CCTV世界地理频道: 'shijiedili'
  };
  if (special[clean]) return special[clean];
  const match = /^CCTV(\d{1,2})$/.exec(clean);
  if (!match) return '';
  const number = Number(match[1]);
  if (number < 1 || number > 17) return '';
  if (number === 9) return 'cctvjilu';
  if (number === 14) return 'cctvchild';
  return 'cctv' + number;
}

async function fetchEpg(epgId, date) {
  const id = text(epgId);
  const day = text(date);
  if (!/^[a-z0-9]+$/.test(id) || !/^\d{4}-\d{2}-\d{2}$/.test(day)) {
    throw new Error('无效的节目单参数');
  }
  const key = `${id}|${day}`;
  const hit = epgCache.get(key);
  if (hit && Date.now() < hit.expire) return hit.data;
  const response = await http.get(EPG_URL, {
    timeout: CATALOG_TIMEOUT,
    params: { c: id, serviceId: 'tvcctv', d: day.replace(/-/g, '') },
    headers: { Referer: CCTV_HOST + '/', 'User-Agent': UA }
  });
  const rows = response.data?.data?.[id]?.list;
  if (!Array.isArray(rows)) throw new Error('节目单返回异常');
  const items = [];
  for (const row of rows) {
    const title = text(row?.title);
    const start = Number(row?.startTime);
    const end = Number(row?.endTime);
    if (!title || !Number.isFinite(start) || !Number.isFinite(end)) continue;
    items.push({ title, start, end, startText: shanghaiClock(start), endText: shanghaiClock(end) });
  }
  epgCache.set(key, { expire: Date.now() + EPG_TTL, data: items });
  return items;
}

async function safeEpg(epgId, date) {
  if (!epgId) return [];
  try {
    return await fetchEpg(epgId, date);
  } catch (error) {
    log?.warn?.(`[央视直播] 节目单获取失败 ${epgId}: ${error.message}`);
    return [];
  }
}

function currentProgram(items) {
  const now = Math.floor(Date.now() / 1000);
  return items.find((item) => item.start <= now && now < item.end) || null;
}

// ========== 频道目录 ==========
function cctvSnapshot() {
  const data = readJsonFile(CCTV_SNAPSHOT_PATH, null);
  const channels = Array.isArray(data?.channels) ? data.channels : [];
  return channels.filter((item) => item && CCTV_ID_RE.test(text(item.id)));
}

function yspSnapshot() {
  const data = readJsonFile(YSP_SNAPSHOT_PATH, null);
  const channels = Array.isArray(data?.channels) ? data.channels : [];
  return channels.filter((item) => item && text(item.pid) && text(item.name));
}

async function fetchCctvChannels() {
  const snapshot = cctvSnapshot();
  const names = new Map(snapshot.map((item) => [text(item.id), text(item.name)]));
  const response = await http.get(CCTV_CATALOG_URL, {
    timeout: CATALOG_TIMEOUT,
    responseType: 'text',
    transformResponse: [(value) => value],
    headers: { Referer: CCTV_HOST + '/', 'User-Agent': UA }
  });
  const found = [];
  const seen = new Set();
  for (const match of String(response.data || '').matchAll(CCTV_LINK_RE)) {
    const id = match[1].toLowerCase();
    if (seen.has(id)) continue;
    seen.add(id);
    found.push({ id, name: names.get(id) || id.toUpperCase() });
  }
  if (found.length < CCTV_MIN_CHANNELS) throw new Error('频道列表不完整');
  return found;
}

async function fetchYspChannels() {
  const cacheBuster = String(Math.floor(Date.now() / 5000));
  const headers = {
    Accept: 'application/octet-stream',
    Referer: YSP_HOST + '/',
    'User-Agent': UA,
    'app-platform': 'pc',
    'app-version': '1.0.0',
    platform: '109',
    yspappid: YSP_APP_ID
  };
  const navigation = await http.get(`${YSP_NAVIGATION_URL}?${cacheBuster}`, {
    timeout: CATALOG_TIMEOUT,
    responseType: 'arraybuffer',
    headers
  });
  const [navCode, navData] = protoResponse(Buffer.from(navigation.data));
  if (navCode !== 200) throw new Error(`导航接口返回 ${navCode}`);
  let feedId = '';
  for (const [field, wire, value] of protoFields(navData)) {
    if (field !== 2 || wire !== 2) continue;
    const entry = protoMessage(value);
    const id = protoText(entry[4]);
    const name = protoText(entry[1]);
    if (id && (name === '电视' || name === '電視' || entry[10] === 2)) {
      feedId = id;
      break;
    }
  }
  if (!feedId) throw new Error('未找到电视栏目');
  const page = await http.get(
    `${YSP_PAGE_URL.replace('{}', encodeURIComponent(feedId))}?${cacheBuster}`,
    { timeout: CATALOG_TIMEOUT, responseType: 'arraybuffer', headers }
  );
  const [pageCode, pageData] = protoResponse(Buffer.from(page.data));
  if (pageCode !== 200) throw new Error(`栏目接口返回 ${pageCode}`);
  const channels = [];
  const seen = new Set();
  for (const [field, wire, moduleBytes] of protoFields(pageData)) {
    if (field !== 2 || wire !== 2) continue;
    const moduleData = protoMessage(moduleBytes, new Set([15]));
    if (protoText(moduleData[2]) !== 'tvChannel') continue;
    for (const channelBytes of moduleData[15] || []) {
      const entry = protoMessage(channelBytes);
      const pid = protoText(entry[4]);
      const name = protoText(entry[2]);
      if (!pid || !name || seen.has(pid)) continue;
      seen.add(pid);
      channels.push({
        name,
        pid,
        cnlid: protoText(entry[6]),
        logo: protoText(entry[5]),
        type: protoText(entry[11]),
        vip: Boolean(entry[7])
      });
    }
  }
  if (channels.length < YSP_MIN_CHANNELS) throw new Error('频道列表不完整');
  return channels;
}

function normalizeCctv(raw) {
  const id = text(raw.id);
  const name = text(raw.name);
  return {
    vodId: `cctv~~${id}`,
    playId: `cctv~~${id}`,
    provider: 'cctv',
    providerName: GROUP_CCTV,
    classId: 'cctv',
    group: GROUP_CCTV,
    name,
    alias: name,
    logo: logoUrl(CCTV_LOGO_NAMES[id] || id.toUpperCase()),
    epgId: id,
    vip: false
  };
}

function normalizeYsp(raw) {
  const name = text(raw.name);
  const pid = text(raw.pid);
  const cnlid = text(raw.cnlid);
  const type = text(raw.type);
  const group = YSP_GROUPS[type] || GROUP_OTHER;
  const logoName = YSP_LOGO_NAMES[name] || (name.endsWith('频道') ? name.slice(0, -2) : name);
  return {
    vodId: `ysp~~${pid}`,
    playId: `ysp~~${pid}~~${cnlid}`,
    provider: 'ysp',
    providerName: '央视频',
    classId: group === GROUP_YANGSHI ? 'ysp_yangshi' : group === GROUP_WEISHI ? 'ysp_weishi' : 'ysp_other',
    group,
    name: XMLTV_NAMES[name] || name,
    alias: name,
    logo: logoUrl(logoName, text(raw.logo)),
    epgId: cntvEpgId(name),
    vip: Boolean(raw.vip)
  };
}

async function loadCatalog(force = false) {
  if (!force && catalogCache.data && Date.now() - catalogCache.time < CATALOG_TTL) {
    return catalogCache.data;
  }
  const [yspResult, cctvResult] = await Promise.all([
    fetchYspChannels().catch((error) => {
      log?.warn?.(`[央视直播] 央视频目录回落快照: ${error.message}`);
      return yspSnapshot();
    }),
    fetchCctvChannels().catch((error) => {
      log?.warn?.(`[央视直播] 央视官网目录回落快照: ${error.message}`);
      return cctvSnapshot();
    })
  ]);
  const channels = [
    ...yspResult.map(normalizeYsp),
    ...cctvResult.map(normalizeCctv)
  ].filter((item) => item.name && item.playId);

  const byVodId = new Map();
  const byEpgId = new Map();
  for (const channel of channels) {
    byVodId.set(channel.vodId, channel);
    if (channel.epgId) {
      if (!byEpgId.has(channel.epgId)) byEpgId.set(channel.epgId, []);
      byEpgId.get(channel.epgId).push(channel);
    }
  }
  const classes = CLASS_ORDER.filter((item) => channels.some((channel) => channel.classId === item.type_id));
  const data = { channels, byVodId, byEpgId, classes };
  catalogCache.time = Date.now();
  catalogCache.data = data;
  return data;
}

// ========== T4 接口 ==========
function vipFilter() {
  return [{
    key: 'vip',
    name: '权限',
    init: '',
    value: [{ n: '全部', v: '' }, { n: '免费', v: 'free' }, { n: '会员', v: 'vip' }]
  }];
}

async function home() {
  const catalog = await loadCatalog();
  const filters = {};
  for (const item of catalog.classes) {
    filters[item.type_id] = item.type_id.startsWith('ysp_') ? vipFilter() : [];
  }
  return { class: catalog.classes, filters };
}

function channelRemarks(channel, program) {
  const parts = [];
  if (program) parts.push(`正在播出 ${program.title}`);
  else parts.push(channel.providerName);
  if (channel.vip) parts.push('会员');
  return parts.join(' · ');
}

async function category({ id, page, filters }) {
  const catalog = await loadCatalog();
  const config = readConfig();
  const current = Math.max(1, Number.parseInt(page, 10) || 1);
  const classId = text(id);
  const vip = text(filters?.vip);

  let channels = catalog.channels.filter((item) => item.classId === classId);
  if (vip === 'free') channels = channels.filter((item) => !item.vip);
  if (vip === 'vip') channels = channels.filter((item) => item.vip);
  if (config.hideVip) channels = channels.filter((item) => !item.vip);
  if (current > 1) {
    return { page: current, pagecount: 1, limit: channels.length, total: channels.length, list: [] };
  }

  let programs = new Map();
  if (config.showEpg) {
    const targets = channels.filter((item) => item.epgId);
    const today = shanghaiToday();
    const results = await mapLimit(targets, 6, async (item) => ({
      epgId: item.epgId,
      program: currentProgram(await safeEpg(item.epgId, today))
    }));
    programs = new Map(results.filter(Boolean).map((item) => [item.epgId, item.program]));
  }

  const list = channels.map((channel) => ({
    vod_id: channel.vodId,
    vod_name: channel.name,
    vod_pic: channel.logo || config.def_pic,
    vod_remarks: channelRemarks(channel, programs.get(channel.epgId))
  }));

  return { page: 1, pagecount: 1, limit: list.length, total: list.length, list };
}

function buildPlayLines(channel, catalog) {
  const lines = [{ from: channel.providerName, playId: channel.playId }];
  if (channel.epgId) {
    for (const other of catalog.byEpgId.get(channel.epgId) || []) {
      if (other.provider === channel.provider) continue;
      lines.push({ from: other.providerName, playId: other.playId });
    }
  }
  return lines;
}

function buildContent(channel, items, program) {
  const lines = [`频道：${channel.name}`, `分组：${channel.group}`, `来源：${channel.providerName}`];
  if (channel.vip) lines.push('提示：央视频标记为会员频道，可能需要登录');
  if (program) lines.push(`正在播出：${program.startText} ${program.title}`);
  if (items.length) {
    const now = Math.floor(Date.now() / 1000);
    const upcoming = items.filter((item) => item.end > now).slice(0, 8);
    const preview = (upcoming.length ? upcoming : items.slice(0, 8))
      .map((item) => `${item.startText} ${item.title}`);
    lines.push('', '今日节目：', ...preview);
  }
  return lines.join('\n');
}

async function detail({ id }) {
  const catalog = await loadCatalog();
  const config = readConfig();
  const ids = Array.isArray(id) ? id : [id];
  const list = [];

  for (const rawId of ids) {
    const channel = catalog.byVodId.get(text(rawId));
    if (!channel) continue;
    const items = config.showEpg ? await safeEpg(channel.epgId, shanghaiToday()) : [];
    const program = currentProgram(items);
    const lines = buildPlayLines(channel, catalog);
    list.push({
      vod_id: channel.vodId,
      vod_name: channel.name,
      vod_pic: channel.logo || config.def_pic,
      type_name: channel.group,
      vod_area: '中国大陆',
      vod_remarks: program ? `正在播出 ${program.title}` : '直播',
      vod_content: buildContent(channel, items, program),
      vod_play_from: lines.map((line) => line.from).join('$$$'),
      vod_play_url: lines.map((line) => `直播$${line.playId}`).join('$$$')
    });
  }

  return { list };
}

async function play({ id }) {
  const playId = text(id);
  try {
    const resolved = await resolvePlay(playId);
    const header = { 'User-Agent': UA, Referer: resolved.referer };
    if (resolved.urls.length === 1) {
      return { parse: 0, url: resolved.urls[0], header };
    }
    const urls = [];
    resolved.urls.forEach((url, index) => {
      urls.push(index === 0 ? '主线' : `备线${index}`);
      urls.push(url);
    });
    return { parse: 0, url: urls, header };
  } catch (error) {
    log?.warn?.(`[央视直播] 播放解析失败 ${playId}: ${error.message}`);
    return { parse: 0, url: '', msg: error.message };
  }
}

async function search({ wd }) {
  const keyword = text(wd);
  if (!keyword) return { page: 1, pagecount: 1, limit: 0, total: 0, list: [] };
  const catalog = await loadCatalog();
  const config = readConfig();
  const needle = keyword.toLowerCase();
  const list = catalog.channels
    .filter((channel) => `${channel.name} ${channel.alias}`.toLowerCase().includes(needle))
    .map((channel) => ({
      vod_id: channel.vodId,
      vod_name: channel.name,
      vod_pic: channel.logo || config.def_pic,
      vod_remarks: `${channel.providerName} · ${channel.group}`
    }));
  return { page: 1, pagecount: 1, limit: list.length, total: list.length, list };
}

async function handle(query) {
  const q = query || {};
  if (q.play) return play({ id: q.play });
  if (q.wd) return search({ wd: q.wd });
  if (q.ids) {
    const ids = String(q.ids).split(',').map((item) => item.trim()).filter(Boolean);
    return detail({ id: ids });
  }
  if (q.t) {
    let filters = {};
    if (q.ext) {
      try {
        filters = JSON.parse(Buffer.from(String(q.ext), 'base64').toString('utf8')) || {};
      } catch {
        filters = {};
      }
    } else if (q.vip !== undefined) {
      filters = { vip: q.vip };
    }
    return category({ id: q.t, page: q.pg || q.page || 1, filters });
  }
  return home();
}

// ========== 直播播放列表（可直接作为直播源使用） ==========
function baseUrl(req) {
  const proto = text(req.headers['x-forwarded-proto']) || req.protocol || 'http';
  const host = text(req.headers['x-forwarded-host']) || text(req.headers.host);
  return `${proto}://${host}`;
}

async function buildPlaylist(req, format) {
  const catalog = await loadCatalog();
  const config = readConfig();
  const root = `${baseUrl(req)}/cctvlive/play`;
  const channels = config.hideVip ? catalog.channels.filter((item) => !item.vip) : catalog.channels;

  if (format === 'txt') {
    const groups = new Map();
    for (const channel of channels) {
      if (!groups.has(channel.group)) groups.set(channel.group, []);
      groups.get(channel.group).push(channel);
    }
    const lines = [];
    for (const [group, items] of groups) {
      lines.push(`${group},#genre#`);
      for (const channel of items) {
        lines.push(`${channel.name},${root}?id=${encodeURIComponent(channel.playId)}`);
      }
      lines.push('');
    }
    return lines.join('\n');
  }

  const lines = ['#EXTM3U'];
  channels.forEach((channel, index) => {
    const attrs = [
      `tvg-id="${channel.epgId || channel.alias}"`,
      `tvg-name="${channel.name}"`,
      `tvg-chno="${index + 1}"`,
      `tvg-logo="${channel.logo || config.def_pic}"`,
      `group-title="${channel.group}"`
    ].join(' ');
    lines.push(`#EXTINF:-1 ${attrs},${channel.name}`);
    lines.push(`${root}?id=${encodeURIComponent(channel.playId)}`);
  });
  return lines.join('\n');
}

// ========== 路由 ==========
async function init(app) {
  log = app?.log || console;
  catalogCache.time = 0;
  catalogCache.data = null;
  playCache.clear();
  return {};
}

module.exports = async (app, opt = {}) => {
  log = app?.log || console;

  app.get(API_PATH, async (req) => {
    try {
      return await handle(req.query);
    } catch (error) {
      log?.error?.(`[央视直播] 接口异常: ${error.message}`);
      return { class: [], list: [], page: 1, pagecount: 1, total: 0, error: error.message };
    }
  });

  // 直播播放：302 跳转到实时 m3u8，供播放列表 / 外部播放器使用
  app.get('/cctvlive/play', async (req, reply) => {
    try {
      const resolved = await resolvePlay(req.query?.id);
      return reply.redirect(resolved.urls[0], 302);
    } catch (error) {
      return reply.code(502).type('text/plain').send(`央视直播: ${error.message}`);
    }
  });

  // 节目单：{date, epg_data:[{title,start,end}]}
  app.get('/cctvlive/epg', async (req, reply) => {
    try {
      const date = text(req.query?.date) || shanghaiToday();
      const items = await fetchEpg(req.query?.id, date);
      return reply.send({
        date,
        epg_data: items.map((item) => ({
          title: item.title,
          start: item.startText,
          end: item.endText
        }))
      });
    } catch (error) {
      return reply.code(400).send({ error: error.message });
    }
  });

  app.get('/cctvlive/m3u', async (req, reply) => {
    try {
      const format = text(req.query?.format).toLowerCase() === 'txt' ? 'txt' : 'm3u';
      const body = await buildPlaylist(req, format);
      return reply.type('text/plain; charset=utf-8').send(body);
    } catch (error) {
      return reply.code(500).type('text/plain').send(`央视直播: ${error.message}`);
    }
  });

  app.get('/cctvlive/config', async (_req, reply) => reply.send({ code: 0, data: readConfig() }));

  app.put('/cctvlive/config', async (req, reply) => {
    const body = req.body || {};
    const next = {
      showEpg: body.showEpg === undefined ? true : Boolean(body.showEpg),
      hideVip: Boolean(body.hideVip),
      def_pic: text(body.def_pic) || DEFAULT_PIC
    };
    writeConfig(next);
    return reply.send({ code: 0, data: next });
  });

  app.delete('/cctvlive/config', async (_req, reply) => {
    try {
      if (fs.existsSync(CONFIG_PATH)) fs.unlinkSync(CONFIG_PATH);
    } catch (error) {
      log?.warn?.(`[央视直播] 删除配置失败: ${error.message}`);
    }
    return reply.send({ code: 0, data: readConfig() });
  });

  app.get('/cctvlive/refresh', async (_req, reply) => {
    try {
      const catalog = await loadCatalog(true);
      playCache.clear();
      return reply.send({ code: 0, data: { channels: catalog.channels.length } });
    } catch (error) {
      return reply.code(500).send({ code: -1, error: error.message });
    }
  });

  if (Array.isArray(opt?.sites)) opt.sites.push(META);
};

module.exports.META = META;
module.exports.init = init;
