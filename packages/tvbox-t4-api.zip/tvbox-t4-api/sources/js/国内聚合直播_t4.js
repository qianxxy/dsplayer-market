/**
 * ============================================================================
 * 国内聚合直播 - TVBox T4 接口插件
 * ============================================================================
 * 
 * 功能说明：
 * - 基于本地 127.0.0.1:3332 的国内全量聚合直播后台
 * - 130+直播平台（龙珠、映客、卡哇伊、番茄社区等）
 * - 支持分类浏览、主播详情、直链播放
 * 
 * 接口路径：/video/guoneijvhe
 * 
 * 日期：2026-07-31
 * ============================================================================
 */
const axios = require("axios");
const http = require("http");
const https = require("https");

const API_HOST = "http://127.0.0.1:3332";

const axiosInstance = axios.create({
    timeout: 10000,
    httpAgent: new http.Agent({ keepAlive: true }),
    headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'application/json, text/plain, */*'
    }
});

const cache = {
    data: new Map(),
    ttl: {
        home: 60000,
        category: 30000,
        detail: 30000,
        play: 10000
    },
    get: (key) => {
        const item = cache.data.get(key);
        if (!item) return null;
        if (Date.now() > item.expire) {
            cache.data.delete(key);
            return null;
        }
        return item.data;
    },
    set: (key, data, type = 'category') => {
        cache.data.set(key, { data, expire: Date.now() + (cache.ttl[type] || 60000) });
        if (cache.data.size > 500) cache.data.clear();
    }
};

const _home = async ({ filter }) => {
    const cacheKey = 'guonei_home';
    const cached = cache.get(cacheKey);
    if (cached) return cached;
    try {
        const res = await axiosInstance.get(`${API_HOST}/`);
        const data = res.data;
        if (!data || !data.class) return { class: [] };
        // 过滤掉 Number=0 的平台（无主播）
        const valid = data.class.filter(c => {
            const num = parseInt(c.type_name.match(/\d+/)?.[0] || '0');
            return num > 0 || !c.type_name.includes('Number');
        });
        const result = { class: valid.length > 0 ? valid : data.class };
        cache.set(cacheKey, result, 'home');
        return result;
    } catch (e) {
        console.error('获取首页分类失败:', e.message);
        return { class: [{ type_id: 'jsonfanjiashequ.txt', type_name: '番茄社区' }] };
    }
};

const _category = async ({ id, page }) => {
    const pg = parseInt(page || 1);
    const cacheKey = `guonei_cat_${id}_${pg}`;
    const cached = cache.get(cacheKey);
    if (cached) return cached;
    try {
        const res = await axiosInstance.get(`${API_HOST}/?tid=${id}`);
        const data = res.data;
        let list = [];
        if (data && data.list) {
            list = data.list.map(item => ({
                vod_id: item.vod_id || item.id || '',
                vod_name: item.vod_name || item.name || '',
                vod_pic: item.vod_pic || item.pic || '',
                vod_remarks: item.vod_remarks || item.remarks || ''
            }));
        }
        const result = { page: pg, pagecount: 99, limit: 20, total: 999, list };
        cache.set(cacheKey, result, 'category');
        return result;
    } catch (e) {
        console.error('获取分类列表失败:', e.message);
        return { list: [], page: pg, pagecount: 0 };
    }
};

const _detail = async ({ id }) => {
    const ids = Array.isArray(id) ? id.join(',') : id;
    const cacheKey = `guonei_detail_${ids}`;
    const cached = cache.get(cacheKey);
    if (cached) return cached;
    try {
        const res = await axiosInstance.get(`${API_HOST}/?ac=detail&ids=${ids}`);
        const data = res.data;
        const result = { list: (data && data.list) || [] };
        cache.set(cacheKey, result, 'detail');
        return result;
    } catch (e) {
        console.error('获取详情失败:', e.message);
        return { list: [] };
    }
};

const _play = async ({ id }) => {
    const cacheKey = `guonei_play_${id}`;
    const cached = cache.get(cacheKey);
    if (cached) return cached;
    try {
        const res = await axiosInstance.get(`${API_HOST}/?ac=play&id=${encodeURIComponent(id)}`);
        const data = res.data;
        const result = { parse: 0, url: (data && data.url) || id };
        cache.set(cacheKey, result, 'play');
        return result;
    } catch (e) {
        console.error('获取播放地址失败:', e.message);
        return { parse: 0, url: id };
    }
};

const meta = {
    key: "GuoNeiJuHe",
    name: "📺国内情色聚合直播[+]",
    type: 4,
    api: "/video/GuoNeiJuHe",
    searchable: 0,
    quickSearch: 0,
    playable: 1,
    changeable: 0
};

module.exports = async (app, opt) => {
    app.get(meta.api, async (req, reply) => {
        const { t, ac, pg, ids, play, wd, quick, filter } = req.query;
        if (play) {
            return await _play({ id: play });
        } else if (wd) {
            return { list: [] };
        } else if (!ac) {
            return await _home({ filter: filter ?? false });
        } else if (ac === "detail") {
            if (t) {
                return await _category({ id: t, page: parseInt(pg || "1") });
            } else if (ids) {
                return await _detail({ id: ids });
            }
        }
        return { code: 400, msg: "参数错误" };
    });
    opt.sites.push(meta);
};
