const axios = require('axios')
const http = require('http')
const https = require('https')
const cheerio = require('cheerio')

const HOST = 'https://ysttv.com'
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
const LIMIT = 32
const BADIMG = ['poster_loading', 'logo', 'thumb.png', 'playing.gif', 'favicon', 'doubanio', 'discord']
const PAGEFMTS = ['%s/p/%s', '%s?page=%s', '%s/page/%s', '%s/%s']
const SEARCHFMTS = ['/search/%s', '/vod/search/%s', '/search/index/wd/%s', '/index.php/vod/search/wd/%s', '/search?wd=%s']

let cachedPageFmt = ''
let cachedSearchFmt = ''

const meta = {
  key: 'ysttv',
  name: '[纯]影视天堂 ✈️',
  type: 4,
  api: '/video/ysttv',
  searchable: 1,
  quickSearch: 1,
  filterable: 1,
  changeable: 0,
}

const classes = [
  { type_id: 'movie', type_name: '电影' },
  { type_id: 'teleplay', type_name: '剧集' },
  { type_id: 'variety', type_name: '综艺' },
  { type_id: 'anime', type_name: '动漫' },
  { type_id: 'playlet', type_name: '短剧' },
]

const genres = [
  ['全部', ''], ['动作', 'action'], ['喜剧', 'comedy'], ['科幻', 'sci-fi'],
  ['悬疑', 'mystery'], ['爱情', 'romance'], ['犯罪', 'crime'], ['恐怖', 'horror'],
  ['剧情', 'drama'], ['奇幻', 'fantasy'], ['惊悚', 'thriller'], ['冒险', 'adventure'],
  ['动画', 'animation'], ['历史', 'history'], ['同性', 'lgbt'], ['纪录片', 'documentary'],
  ['古装', 'costume'], ['武侠', 'wuxia'], ['音乐', 'music'], ['歌舞', 'musical'],
  ['运动', 'sports'], ['灾难', 'disaster'], ['传记', 'biography'], ['儿童', 'kids'],
]

const years = [['全部', '']].concat(
  Array.from({ length: 11 }, (_, i) => [String(2025 - i), `year${2025 - i}`])
)

const areas = [
  ['全部', ''], ['大陆', 'area-china'], ['台湾', 'area-taiwan'], ['香港', 'area-hong-kong'],
  ['美国', 'area-usa'], ['韩国', 'area-korea'], ['日本', 'area-japan'], ['英国', 'area-uk'],
  ['法国', 'area-france'], ['泰国', 'area-thailand'], ['印度', 'area-india'], ['加拿大', 'area-canada'],
]

const sorts = [['最新', ''], ['人气', 'hot'], ['评分', 'rating']]

const filterItems = [
  { key: 'genre', name: '类型', value: genres.map(g => ({ n: g[0], v: g[1] })) },
  { key: 'year', name: '年份', value: years.map(y => ({ n: y[0], v: y[1] })) },
  { key: 'area', name: '地区', value: areas.map(a => ({ n: a[0], v: a[1] })) },
  { key: 'sort', name: '排序', value: sorts.map(s => ({ n: s[0], v: s[1] })) },
]

const filters = Object.fromEntries(classes.map(c => [c.type_id, filterItems]))

const httpClient = axios.create({
  timeout: 15000,
  httpAgent: new http.Agent({ keepAlive: true }),
  httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
  headers: { 'User-Agent': UA, 'Referer': `${HOST}/`, 'Accept-Language': 'zh-CN,zh;q=0.9' },
})

const cleanText = (s = '') => String(s).replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim()
const absUrl = (u = '') => !u ? '' : /^https?:\/\//i.test(u) ? u : u.startsWith('//') ? 'https:' + u : u.startsWith('/') ? HOST + u : u
const safePage = (page) => Math.max(1, parseInt(page || '1', 10) || 1)
const decodeExt = (ext) => {
  if (!ext) return {}
  try { return JSON.parse(Buffer.from(String(ext), 'base64').toString('utf8')) || {} } catch (_) {}
  try { return JSON.parse(String(ext)) || {} } catch (_) { return {} }
}

async function fetchHtml(url, options = {}) {
  try {
    const { data } = await httpClient.request({ url: absUrl(url), method: 'GET', ...options })
    return String(data || '')
  } catch (e) {
    console.error('[ERROR] 请求失败:', url, e.message)
    return ''
  }
}

function parseList($) {
  const list = []
  const seen = new Set()
  $('a[href*="/detail/"]').each((_, el) => {
    const $el = $(el)
    const href = $el.attr('href') || ''
    const m = href.match(/\/detail\/(\d+)/)
    if (!m || seen.has(m[1])) return
    const vid = m[1]
    const name = cleanText($el.attr('title') || $el.find('img').attr('alt') || '')
    if (!name) return
    seen.add(vid)
    const pic = $el.attr('data-original') || $el.attr('data-src') || $el.find('img').attr('data-original') || $el.find('img').attr('data-src') || $el.find('img').attr('src') || ''
    const goodPic = pic && !BADIMG.some(b => pic.includes(b)) ? pic : ''
    const remarks = $el.find('span, em, i').toArray().map(el => cleanText($(el).text())).filter(Boolean).join(' ').slice(0, 30)
    list.push({ vod_id: vid, vod_name: name, vod_pic: absUrl(goodPic), vod_remarks: remarks })
  })
  return list
}

function fieldFromText(text, label) {
  const re = new RegExp(`${label}\\s*[:：]\\s*([^\\n]{1,200})`, 'i')
  const m = text.match(re)
  return m ? m[1].replace(/[　|/]/g, '').trim() : ''
}

async function pagedHtml(base, pg) {
  if (pg === 1) return await fetchHtml(base)
  if (cachedPageFmt) return await fetchHtml(cachedPageFmt % (base, pg))
  const firstHtml = await fetchHtml(base)
  if (!firstHtml) return ''
  const $1 = cheerio.load(firstHtml)
  const firstId = parseList($1)[0]?.vod_id || ''
  for (const fmt of PAGEFMTS) {
    const html = await fetchHtml(fmt % (base, pg))
    if (!html) continue
    const $t = cheerio.load(html)
    const got = parseList($t)
    if (got.length && got[0].vod_id !== firstId) {
      cachedPageFmt = fmt
      console.log('[INFO] 分页格式确定:', fmt)
      return html
    }
  }
  console.log('[WARN] 未能确定分页格式，仅返回首页')
  return ''
}

async function homeContent() {
  const html = await fetchHtml('/')
  const $ = cheerio.load(html || '')
  const list = parseList($).slice(0, LIMIT)
  return { class: classes, list, filters, page: 1, pagecount: 1, limit: LIMIT, total: list.length }
}

async function categoryContent({ id, page, ext }) {
  const pg = safePage(page)
  const ex = decodeExt(ext)
  const facet = ex.genre || ex.year || ex.area || ex.sort || ''
  const base = `/vod/${id}` + (facet ? `/${facet}` : '')
  const html = await pagedHtml(base, pg)
  const $ = cheerio.load(html || '')
  const list = parseList($)
  return { list, page: pg, pagecount: list.length ? pg + 1 : pg, limit: LIMIT, total: 999999 }
}

async function searchContent({ wd, page, quick }) {
  const pg = safePage(page)
  const kw = encodeURIComponent(String(wd || '').trim())
  const formats = cachedSearchFmt ? [cachedSearchFmt] : SEARCHFMTS
  for (const fmt of formats) {
    const html = await fetchHtml(fmt.replace('%s', kw))
    if (!html) continue
    const $ = cheerio.load(html)
    const list = parseList($)
    if (list.length) {
      cachedSearchFmt = fmt
      console.log('[INFO] 搜索格式确定:', fmt)
      return { list: quick ? list.slice(0, 10) : list, page: pg }
    }
  }
  console.log('[WARN] 未能确定搜索接口')
  return { list: [], page: pg }
}

async function detailContent({ ids }) {
  const vid = String(ids || '').replace(/\D/g, '')
  if (!vid) return { list: [] }
  const html = await fetchHtml(`/detail/${vid}/`)
  if (!html) return { list: [] }
  const $ = cheerio.load(html)
  const allText = cleanText($('body').text())

  const vodName = cleanText($('h1').first().text()) || fieldFromText(allText, 'og:title')

  let pic = ''
  $('img').each((_, el) => {
    const src = $(el).attr('src') || $(el).attr('data-original') || $(el).attr('data-src') || ''
    if (src && !BADIMG.some(b => src.includes(b)) && /\/cover\/|\/upload\/|jinyingimage/.test(src)) {
      pic = src
      return false
    }
  })

  const vodYear = $('a[href*="/year"]').first().text().trim()
  const vodArea = $('a[href*="/area-"]').first().text().trim()

  const typeNames = []
  $('a[href*="/vod/"]').each((_, el) => {
    const href = $(el).attr('href') || ''
    if (!href.includes('/year') && !href.includes('/area-')) {
      const t = cleanText($(el).text())
      if (t) typeNames.push(t)
    }
  })

  const vodDirector = fieldFromText(allText, '导演')
  const vodActor = fieldFromText(allText, '主演')
  const epCount = fieldFromText(allText, '集数')
  const score = fieldFromText(allText, '评分')
  let vodRemarks = score || epCount || ''
  if (epCount && /^\d+$/.test(epCount) && epCount !== '1') vodRemarks = `共${epCount}集`
  const vodContent = fieldFromText(allText, '剧情') || fieldFromText(allText, '简介')

  const vod = {
    vod_id: vid,
    vod_name: vodName.replace(/[《》]/g, ''),
    vod_pic: absUrl(pic),
    vod_year: vodYear,
    vod_area: vodArea,
    type_name: typeNames.slice(0, 3).join(' '),
    vod_director: vodDirector,
    vod_actor: vodActor,
    vod_remarks: vodRemarks,
    vod_content: vodContent,
  }

  // Fetch episode list from player page
  const ph = await fetchHtml(`/player/${vid}/`)
  const eps = []
  if (ph) {
    const $p = cheerio.load(ph)
    $p(`a[href*="/player/${vid}/"]`).each((_, el) => {
      const lk = $p(el).attr('href') || ''
      const nm = cleanText($p(el).text()) || $p(el).attr('title') || ''
      if (!lk || !nm || lk.replace(/\/+$/, '').endsWith(`/${vid}`)) return
      const item = nm.replace(/[$#]/g, '') + '$' + absUrl(lk)
      if (!eps.includes(item)) eps.push(item)
    })
  }

  vod.vod_play_from = '影视天堂'
  vod.vod_play_url = eps.length ? eps.join('#') : `正片$${HOST}/player/${vid}/`
  return { list: [vod] }
}

async function playContent({ play, flag }) {
  const pid = absUrl(play)
  const html = await fetchHtml(pid)
  if (!html) return { parse: 1, url: pid, header: { 'User-Agent': UA, Referer: `${HOST}/` } }

  let url = ''
  const htmlNorm = html.replace(/\\\//g, '/')

  const patterns = [
    /var\s+now\s*=\s*["']([^"']+)["']/,
    /var\s+player_\w+\s*=\s*(\{.*?\})\s*[;<]/,
    /"(?:url|video_url|playUrl)"\s*:\s*"([^"]+\.(?:m3u8|mp4)[^"]*)"/,
    /url:\s*["']([^"']+\.(?:m3u8|mp4)[^"']*)["']/,
    /(https?:\/\/[^\s"'\\<>]+\.(?:m3u8|mp4)[^\s"'\\<>]*)/,
  ]

  for (const p of patterns) {
    const m = htmlNorm.match(p)
    if (!m) continue
    let val = m[1]
    if (val.startsWith('{')) {
      try {
        const parsed = JSON.parse(val)
        val = parsed.url || ''
      } catch (_) {
        const m2 = val.match(/"https?:\/\/[^"]+\.(?:m3u8|mp4)[^"]*"/)
        val = m2 ? m2[0].replace(/"/g, '') : ''
      }
    }
    if (val) { url = absUrl(val); break }
  }

  if (!url) return { parse: 1, url: pid, header: { 'User-Agent': UA, Referer: `${HOST}/`, 'Accept-Language': 'zh-CN,zh;q=0.9' } }
  return { parse: 0, url, header: { 'User-Agent': UA, Referer: `${HOST}/` } }
}

module.exports = async (app, opt = {}) => {
  app.get(meta.api, async (req) => {
    const { ac, t, pg, ids, id, wd, play, flag, quick, ext, extend } = req.query || {}
    try {
      if (play) return await playContent({ play, flag })
      if (ids || id) return await detailContent({ ids: ids || id })
      if (wd) return await searchContent({ wd, page: safePage(pg), quick: quick === '1' || quick === 'true' })
      if (t || ac === 'detail') return await categoryContent({ id: t, page: safePage(pg), ext: ext || extend })
      return await homeContent()
    } catch (e) {
      console.error('[ERROR]', e.message)
      return { list: [], page: 1, pagecount: 1, limit: LIMIT, total: 0, error: e.message }
    }
  })
  opt.sites.push(meta)
}
