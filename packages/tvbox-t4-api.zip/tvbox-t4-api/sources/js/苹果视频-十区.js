const axios = require('axios')
const http = require('http')
const https = require('https')

const HOST = 'https://6181016.xyz'
const UA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36'
const LIMIT = 20

const meta = {
  key: 'pgsp_10',
  name: '[秀]苹果视频-十区',
  type: 4,
  api: '/video/pgsp10',
  searchable: 1,
  quickSearch: 0,
  filterable: 0,
  changeable: 0,
}

const classes = [
  { type_id: '1', type_name: '一区' },
  { type_id: '66', type_name: '全部' },
  { type_id: '63', type_name: '日欧' },
  { type_id: '64', type_name: '动漫' },
  { type_id: '65', type_name: '无码' },
  { type_id: '69', type_name: '字幕' },
  { type_id: '70', type_name: 'P站' },
  { type_id: '68', type_name: '厂牌' },
  { type_id: '71', type_name: '网黄' },
  { type_id: '67', type_name: 'JK' },
  { type_id: '72', type_name: '国产' },
  { type_id: '73', type_name: '热门' },
]

const filters = {}

// ---------- helpers ----------
const cleanText = (s = '') => String(s).replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim()
const absUrl = (u = '') => !u ? '' : /^https?:\/\//i.test(u) ? u : u.startsWith('//') ? 'https:' + u : u.startsWith('/') ? HOST + u : u
const safePage = (page) => Math.max(1, parseInt(page || '1', 10) || 1)

// XOR 128 decrypt
function dec(t) {
  try { return [...String(t)].map(c => String.fromCharCode(c.charCodeAt(0) ^ 128)).join('') } catch (_) { return t }
}

const httpClient = axios.create({
  timeout: 15000,
  httpAgent: new http.Agent({ keepAlive: true }),
  httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
  headers: { 'User-Agent': UA, Referer: `${HOST}/`, 'Accept-Language': 'zh-CN,zh;q=0.9' },
})

async function fetchHtml(url) {
  try {
    const { data } = await httpClient.get(absUrl(url))
    return String(data || '')
  } catch (e) {
    console.error('[ERROR] 请求失败:', url, e.message)
    return ''
  }
}

// CDN domains that need Referer header
const PROXY_CDNS = ['sssydim.qdwywj.cn', 'imsgrs.qdwywj.cn']

function needProxy(picUrl) {
  if (!picUrl) return false
  try {
    const u = new URL(picUrl)
    return PROXY_CDNS.some(cdn => u.hostname.includes(cdn))
  } catch (_) { return false }
}

// ---------- parse list ----------
function parseList(html, proxyPrefix = '') {
  const list = []
  const seen = new Set()
  const itemRe = /<a[^>]*class="[^"]*vodbox[^"]*"[^>]*href="([^"]+)"[^>]*>(.*?)<\/a>/gs
  let m
  while ((m = itemRe.exec(html)) !== null) {
    const href = m[1]
    const block = m[2]
    const vod_id = /^https?:\/\//i.test(href) ? href : HOST + href
    if (seen.has(vod_id)) continue
    seen.add(vod_id)

    // Decrypt name from <p class="km-script">
    const te = /<p[^>]*class="km-script"[^>]*>([^<]+)<\/p>/s.exec(block)
    const vod_name = te ? dec(te[1].trim()) : '未知'

    // Poster: data-original
    const pic = /data-original=["']([^"']+)["']/.exec(block)
    let vod_pic = pic ? pic[1] : ''
    if (vod_pic.startsWith('//')) vod_pic = 'https:' + vod_pic

    // Proxy image if from a CDN that blocks hotlinking
    if (needProxy(vod_pic) && proxyPrefix) {
      vod_pic = proxyPrefix + encodeURIComponent(vod_pic)
    }

    list.push({ vod_id, vod_name, vod_pic })
  }
  return list
}

// ---------- 图片代理 ----------
const imgAgent = new https.Agent({ keepAlive: true, rejectUnauthorized: false })

async function proxyImage(url) {
  try {
    const resp = await axios.get(url, {
      responseType: 'arraybuffer',
      timeout: 15000,
      httpAgent: new http.Agent({ keepAlive: true }),
      httpsAgent: imgAgent,
      headers: {
        'User-Agent': UA,
        Referer: `${HOST}/`,
        'Accept': 'image/webp,image/apng,image/*,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.9',
      },
    })
    const contentType = resp.headers['content-type'] || 'image/jpeg'
    const data = Buffer.from(resp.data).toString('base64')
    return { contentType, data }
  } catch (e) {
    console.error('[IMG_PROXY] 失败:', url, e.message)
    return null
  }
}

// ---------- API handlers ----------
async function homeContent() {
  const html = await fetchHtml('/index.php/vod/type/id/66.html')
  const list = html ? parseList(html, '/video/pgsp10/img?url=').slice(0, LIMIT) : []
  return { class: classes, list, filters, page: 1, pagecount: 1, limit: LIMIT, total: list.length }
}

async function categoryContent({ id, page }) {
  const pg = safePage(page)
  const url = pg > 1
    ? `/index.php/vod/type/id/${id}/page/${pg}.html`
    : `/index.php/vod/type/id/${id}.html`
  const html = await fetchHtml(url)
  const list = html ? parseList(html, '/video/pgsp10/img?url=') : []

  let pagecount = pg + 1
  if (html) {
    const tpM = /totalPages\s*=\s*["'](\d+)["']/.exec(html)
    if (tpM) {
      const tp = parseInt(tpM[1], 10)
      pagecount = Math.floor((tp + 30) / 16) + 5
    }
  }

  return { list, page: pg, pagecount, limit: LIMIT, total: 9999 }
}

async function searchContent({ wd, page, quick }) {
  const pg = safePage(page)
  const kw = encodeURIComponent(String(wd || '').trim())
  const html = await fetchHtml(`/index.php/vod/search/page/${pg}/wd/${kw}.html`)
  const list = html ? parseList(html, '/video/pgsp10/img?url=') : []
  const pagecount = list.length ? pg + 1 : pg
  return { list: quick ? list.slice(0, 10) : list, page: pg, pagecount, limit: LIMIT, total: list.length }
}

async function detailContent({ ids }) {
  const vod_id = String(ids || '')
  if (!vod_id) return { list: [] }

  // Extract name from URL path
  let vod_name = '视频'
  const scscM = vod_id.match(/\/html\/(?:scsc|acac)\/([^.]+)/)
  if (scscM) {
    const pp = scscM[1]
    if (pp) vod_name = dec(decodeURIComponent(pp))
  }

  return {
    list: [{
      vod_id,
      vod_name,
      vod_pic: '',
      vod_play_from: '主线路',
      vod_play_url: `1$${vod_id}`,
    }]
  }
}

async function playContent({ play }) {
  const play_url = String(play || '')

  // --- Case 1: ?v= parameter (direct m3u8 URL) ---
  const vMatch = play_url.match(/[?&]v=([^&]+)/)
  if (vMatch) {
    let m3u8_url = decodeURIComponent(vMatch[1])
    // Replace CDN domain
    m3u8_url = m3u8_url.replace('d2wexzpo1hxhi0', 'd2m0k739byzwun')
    // Append token
    const TOKEN = '?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0aW1lc3RhbXAiOjE3ODE3MDg0MDQzNjUzMDM2MDAsInR5cGUiOjAsInVpZCI6NTUzNDcxNDN9.LiIcl5qe1yhUX6fj5iCke9-S-ULHxxGK5hibHY_qcxc&c=https://zzzsts.lkkwip.cn'
    return { parse: 0, url: m3u8_url + TOKEN, header: { 'User-Agent': UA, Referer: `${HOST}/` } }
  }

  // --- Case 2: ?url=kk8- format ---
  const kk8Match = play_url.match(/[?&]url=(kk8-[^&]+)/)
  if (kk8Match) {
    const kk8id = kk8Match[1].slice(4)
    const m3u8_url = `https://m2cdn.playergo.top/${kk8id}/18343ef90a2825a74ad0dafbaed3fd8e765fcf90fe3f3bdb02/playlist.m3u8`
    return { parse: 0, url: m3u8_url, header: { 'User-Agent': UA, Referer: `${HOST}/` } }
  }

  // --- Case 3: Direct m3u8/mp4/flv URL ---
  if (/\.(m3u8|mp4|flv)(\?|$)/i.test(play_url)) {
    return { parse: 0, url: play_url, header: { 'User-Agent': UA, Referer: `${HOST}/` } }
  }

  // --- Fallback ---
  return { parse: 1, url: play_url, header: { 'User-Agent': UA, Referer: `${HOST}/` } }
}

// ---------- express app ----------
module.exports = async (app, opt = {}) => {
  // 图片代理路由
  app.get('/video/pgsp10/img', async (req, res) => {
    const imgUrl = req.query.url
    if (!imgUrl) {
      res.status(400).send('Missing url parameter')
      return
    }
    const result = await proxyImage(imgUrl)
    if (!result) {
      res.status(502).send('Failed to fetch image')
      return
    }
    res.setHeader('Content-Type', result.contentType)
    res.setHeader('Cache-Control', 'public, max-age=86400')
    res.send(Buffer.from(result.data, 'base64'))
  })

  app.get(meta.api, async (req) => {
    const { ac, t, pg, ids, id, wd, play, flag, quick } = req.query || {}
    try {
      if (play) return await playContent({ play, flag })
      if (ids || id) return await detailContent({ ids: ids || id })
      if (wd) return await searchContent({ wd, page: safePage(pg), quick: quick === '1' || quick === 'true' })
      if (t || ac === 'detail') return await categoryContent({ id: t, page: safePage(pg) })
      return await homeContent()
    } catch (e) {
      console.error('[ERROR]', e.message)
      return { list: [], page: 1, pagecount: 1, limit: LIMIT, total: 0, error: e.message }
    }
  })
  opt.sites.push(meta)
}
