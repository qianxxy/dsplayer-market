/**
 * 🎵 酷我音乐 - 歌手 T4 源（小心儿悠悠版）
 * ============================================================================
 * 站点：酷我音乐（kuwo.cn）
 *
 * 功能：
 *  - 首页分类：华语男/女/组合、日韩男/女/组合、欧美男/女/组合、其他
 *  - 分类列表：wapi.kuwo.cn artistInfo → 歌手列表（30条/页）
 *  - 详情：歌手信息 + 歌曲列表（循环最多 10 页，300 首上限）
 *  - 搜索：search.kuwo.cn ft=artist 搜索歌手
 *  - 播放：3 音质（无损FLAC/320K/128K）走 nmobi.kuwo.cn convert_url_with_sign
 *          拿真实 URL（返回 [音质名, url, 音质名, url...] 数组）
 *          歌词 getlyric 转 SSA 5行字幕（subs data URL）
 *
 * 路由格式对齐 routes/guazi.js（命名函数导出 + 独立 Content 函数 + meta 显式导出）。
 * ============================================================================
 */

const axios = require("axios");
const http = require("http");
const https = require("https");

// ==================== HTTP 客户端 ====================
const _http = axios.create({
  timeout: 15 * 1000,
  httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
  httpAgent: new http.Agent({ keepAlive: true }),
  maxRedirects: 5,
});

// ==================== 站点配置 ====================
const LIMIT = 30;
const MAX_SONGS = 300;
const MAX_SONG_PAGES = 10;

const meta = {
  key: "kuwo",
  name: "[听]酷我音乐",
  type: 4,
  api: "/video/kuwo",
  searchable: 1,
  quickSearch: 1,
  filterable: 0,
  changeable: 0,
};

const CLASSES = [
  { type_id: "1", type_name: "华语男" },
  { type_id: "2", type_name: "华语女" },
  { type_id: "3", type_name: "华语组合" },
  { type_id: "4", type_name: "日韩男" },
  { type_id: "5", type_name: "日韩女" },
  { type_id: "6", type_name: "日韩组合" },
  { type_id: "7", type_name: "欧美男" },
  { type_id: "8", type_name: "欧美女" },
  { type_id: "9", type_name: "欧美组合" },
  { type_id: "0", type_name: "其他" },
];

const HEADERS = {
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
  Referer: "http://www.kuwo.cn/",
};

const MOBILE_HEADERS = {
  "User-Agent": "Mozilla/5.0 (Linux; Android 10)",
  Referer: "https://www.kuwo.cn/",
};

// ==================== 工具函数 ====================
function pageOf(value) {
  return Math.max(1, parseInt(value || "1", 10) || 1);
}

function clean(value) {
  return String(value || "").replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ").trim();
}

function formatTime(seconds) {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return (m < 10 ? "0" + m : "" + m) + ":" + (s < 10 ? "0" + s.toFixed(2) : s.toFixed(2));
}

// ==================== 列表项 & 列表结果（对齐 guazi.js）====================
function listItem(item = {}) {
  const vodId = String(item.vod_id ?? item.id ?? "");
  if (!vodId) return null;
  return {
    vod_id: vodId,
    vod_name: clean(item.vod_name || item.name || ""),
    vod_pic: String(item.vod_pic || item.pic || ""),
    vod_remarks: item.vod_remarks || "",
  };
}

function listResult(list, page) {
  return {
    list: (Array.isArray(list) ? list : []).map(listItem).filter((item) => item && item.vod_name),
    page: pageOf(page),
    pagecount: 9999,
    limit: LIMIT,
    total: 999999,
  };
}

// ==================== 首页 ====================
async function homeContent() {
  return {
    class: CLASSES,
    filters: {},
    list: [],
  };
}

// ==================== 分类列表（歌手） ====================
async function categoryContent({ id, page, ext }) {
  const tid = String(id || "1");
  const pg = pageOf(page);
  try {
    const url = "http://wapi.kuwo.cn/api/www/artist/artistInfo" +
      "?category=" + encodeURIComponent(tid) +
      "&prefix=&pn=" + pg + "&rn=30";
    const resp = await _http.get(url, { headers: HEADERS, timeout: 10000 });
    const data = resp.data;
    const list = [];
    const artistList = (data.data && data.data.artistList) || [];
    for (const item of artistList) {
      list.push({
        vod_id: String(item.id || ""),
        vod_name: String(item.name || ""),
        vod_pic: String(item.pic300 || item.pic || item.pic120 || ""),
        vod_remarks: "",
      });
    }
    return {
      list,
      page: pg,
      pagecount: 9999,
      limit: 90,
      total: 999999,
    };
  } catch (e) {
    console.error("[酷我音乐] 分类错误:", e.message);
    return { list: [], page: pg, pagecount: 9999, limit: 90, total: 0 };
  }
}

// ==================== 歌手歌曲（循环翻页） ====================
async function getArtistSongs(rid) {
  const songs = [];
  for (let page = 1; page <= MAX_SONG_PAGES; page++) {
    try {
      const url = "http://wapi.kuwo.cn/api/www/artist/artistMusic" +
        "?artistid=" + encodeURIComponent(rid) + "&pn=" + page + "&rn=30";
      const resp = await _http.get(url, { headers: HEADERS, timeout: 10000 });
      const data = resp.data;
      if (data.code === 200) {
        const songList = (data.data && data.data.list) || [];
        if (!songList.length) break;
        for (const song of songList) {
          const songName = String(song.name || "").trim();
          if (songName) {
            songs.push({
              name: songName,
              rid: String(song.rid || ""),
              album: String(song.album || ""),
            });
          }
        }
        if (songs.length >= MAX_SONGS) {
          songs.length = MAX_SONGS;
          break;
        }
      } else {
        break;
      }
    } catch (e) {
      continue;
    }
  }
  return songs;
}

// ==================== 详情（歌手 + 歌曲列表） ====================
async function detailContent({ ids }) {
  const rid = String(Array.isArray(ids) ? ids[0] : String(ids || "").split(",")[0]).trim();
  try {
    const infoUrl = "http://wapi.kuwo.cn/api/www/artist/artist?artistid=" + encodeURIComponent(rid);
    const infoResp = await _http.get(infoUrl, { headers: HEADERS, timeout: 10000 });
    const infoData = infoResp.data.data || {};
    const artistName = String(infoData.name || "");

    const allSongs = await getArtistSongs(rid);
    if (allSongs.length > MAX_SONGS) allSongs.length = MAX_SONGS;

    const playArr = [];
    for (const song of allSongs) {
      const name = String(song.name || "").replace(/[$#]/g, "").trim();
      const songId = song.rid;
      const album = song.album;
      playArr.push(album ? (name + " - " + album + "$" + songId) : (name + "$" + songId));
    }

    let artistInfo = String(infoData.info || "");
    artistInfo = clean(artistInfo.replace(/\r\n/g, "\n").replace(/\r/g, "\n"));

    return {
      list: [
        {
          vod_id: rid,
          vod_name: artistName,
          vod_pic: String(infoData.pic300 || infoData.pic || ""),
          vod_content: artistInfo || "暂无歌手简介",
          vod_remarks: "歌曲 :  " + allSongs.length + "首",
          vod_actor: artistName,
          vod_play_from: "酷我音乐",
          vod_play_url: playArr.join("#"),
        },
      ],
    };
  } catch (e) {
    console.error("[酷我音乐] 详情错误:", e.message);
    return {
      list: [
        {
          vod_id: rid,
          vod_name: "加载失败",
          vod_content: "加载歌手信息失败: " + e.message,
          vod_remarks: "加载失败",
          vod_actor: "未知",
          vod_play_from: "酷我音乐",
          vod_play_url: "",
        },
      ],
    };
  }
}

// ==================== SSA 字幕 ====================
function createSsaSubtitle(lrcText) {
  const pattern = /\[(\d{2}):(\d{2})\.(\d{2})\](.*)/;
  const lines = [];
  for (const line of String(lrcText || "").split("\n")) {
    const m = line.match(pattern);
    if (m) {
      const minutes = parseInt(m[1], 10);
      const seconds = parseInt(m[2], 10);
      const hundredths = parseInt(m[3], 10);
      const text = m[4].trim();
      const totalSeconds = minutes * 60 + seconds + hundredths / 100.0;
      if (text) {
        lines.push({ start: totalSeconds, text });
      }
    }
  }
  if (!lines.length) return "";

  const ssaHeader = `[Script Info]
ScriptType: v4.00+
Collisions: Normal
PlayResX: 1280
PlayResY: 720
Timer: 100.0000
WrapStyle: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: WAITING_TOP2,Roboto,55,&H0000FFFF,&H00808080,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,1,1,2,0,0,180,1
Style: WAITING_TOP1,Roboto,55,&H0000FFFF,&H00808080,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,1,1,2,0,0,260,1
Style: PLAYING_CENTER,Roboto,60,&H0000FF00,&H00808080,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,2,2,2,0,0,340,1
Style: PLAYED_BOTTOM1,Roboto,55,&H0000FFFF,&H00808080,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,1,1,2,0,0,420,1
Style: PLAYED_BOTTOM2,Roboto,55,&H0000FFFF,&H00808080,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,1,1,2,0,0,500,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
`;

  function formatSsaTime(seconds) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    const cs = Math.floor((seconds * 100) % 100);
    return h + ":" + (m < 10 ? "0" + m : "" + m) + ":" + (s < 10 ? "0" + s : "" + s) + "." + (cs < 10 ? "0" + cs : "" + cs);
  }

  const events = [];
  for (let i = 0; i < lines.length; i++) {
    const current = lines[i];
    const currentEnd = i + 1 < lines.length ? lines[i + 1].start : current.start + 5.0;
    const wait2 = i + 2 < lines.length ? lines[i + 2] : null;
    const wait1 = i + 1 < lines.length ? lines[i + 1] : null;
    const played1 = i - 1 >= 0 ? lines[i - 1] : null;
    const played2 = i - 2 >= 0 ? lines[i - 2] : null;

    const startStr = formatSsaTime(current.start);
    const endStr = formatSsaTime(currentEnd);

    if (wait2) events.push("Dialogue: 1," + startStr + "," + endStr + ",WAITING_TOP2,,0,0,0,," + wait2.text);
    if (wait1) events.push("Dialogue: 2," + startStr + "," + endStr + ",WAITING_TOP1,,0,0,0,," + wait1.text);
    events.push("Dialogue: 3," + startStr + "," + endStr + ",PLAYING_CENTER,,0,0,0,," + current.text);
    if (played1) events.push("Dialogue: 4," + startStr + "," + endStr + ",PLAYED_BOTTOM1,,0,0,0,," + played1.text);
    if (played2) events.push("Dialogue: 5," + startStr + "," + endStr + ",PLAYED_BOTTOM2,,0,0,0,," + played2.text);
  }

  return ssaHeader + events.join("\n");
}

// ==================== 播放 ====================
async function playContent({ id, flag }) {
  const rid = String(id || "");
  const qualities = [];
  const qualityList = [
    { name: "无损FLAC", bitrate: 2000, format: "flac" },
    { name: "高品质320K", bitrate: 320, format: "mp3" },
    { name: "标准128K", bitrate: 128, format: "mp3" },
  ];

  for (const q of qualityList) {
    try {
      const apiUrl = "https://nmobi.kuwo.cn/mobi.s" +
        "?f=web&user=0&source=kwplayer_ar_4.4.2.7_B_nuoweida_vh.apk" +
        "&type=convert_url_with_sign&rid=" + encodeURIComponent(rid) +
        "&bitrate=" + q.bitrate + "&format=" + q.format;
      const r = await _http.get(apiUrl, { headers: MOBILE_HEADERS, timeout: 5000 });
      const data = r.data;
      if (data.code === 200 && data.data && data.data.url) {
        qualities.push([q.name, data.data.url]);
      }
    } catch (e) { /* 单音质失败继续 */ }
  }

  if (!qualities.length) {
    return { parse: 0, jx: 0, playUrl: "", url: "", header: {} };
  }

  const urls = [];
  for (const [name, u] of qualities) {
    urls.push(name);
    urls.push(u);
  }

  let lrc = "";
  let pic = "";
  const picUrl = "http://artistpicserver.kuwo.cn/pic.web?type=rid_pic&pictype=url&size=500&rid=" + encodeURIComponent(rid);

  try {
    const lrcResp = await _http.get("https://kuwo.cn/openapi/v1/www/lyric/getlyric?musicId=" + encodeURIComponent(rid), { timeout: 5000 });
    const lj = lrcResp.data;
    if (lj.data && lj.data.lrclist) {
      lrc = lj.data.lrclist
        .map((item) => "[" + formatTime(parseFloat(item.time || 0)) + "]" + (item.lineLyric || ""))
        .join("\n");
    }
  } catch (e) { /* 歌词失败不致命 */ }

  try {
    const pr = await _http.get(picUrl, { timeout: 5000 });
    pic = String(pr.data || "").trim();
    if (!/^https?:\/\//i.test(pic)) pic = "";
  } catch (e) { /* 封面失败用默认 */ }

  const result = {
    parse: 0,
    jx: 0,
    playUrl: "",
    url: urls,
    header: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      Referer: "https://www.kuwo.cn/",
    },
  };

  if (pic) {
    result.pic = pic;
    result.artwork = pic; // VodPlus 壳子 YS 播放器认 artwork 显示封面
  }

  if (lrc) {
    result.lrc = lrc; // VodPlus 壳子 YS 播放器认 lrc 纯 LRC 文本显示歌词
    try {
      const ssaLrc = createSsaSubtitle(lrc);
      if (ssaLrc) {
        const ssaBase64 = Buffer.from(ssaLrc, "utf-8").toString("base64");
        const ssaUrl = "data:text/x-ssa;base64," + ssaBase64;
        result.subs = [
          {
            name: "5行歌词",
            url: ssaUrl,
            format: "text/x-ssa",
            selected: true,
          },
        ];
      }
    } catch (e) { /* 字幕失败不致命 */ }
  }

  return result;
}

// ==================== 搜索（歌手） ====================
async function searchContent({ wd, page }) {
  const keyword = clean(wd);
  const pg = pageOf(page);
  if (!keyword) return listResult([], pg);
  try {
    const pageNum = (pg - 1) * 30;
    const url = "https://search.kuwo.cn/r.s" +
      "?client=kt&pn=" + pageNum + "&rn=30&all=" + encodeURIComponent(keyword) +
      "&vipver=1&ft=artist&encoding=utf8&rformat=json&mobi=1";
    const resp = await _http.get(url, { headers: HEADERS, timeout: 10000 });
    const data = resp.data;
    const list = [];
    if (data.abslist) {
      const basePath = data.BASEPICPATH || "http://img1.kuwo.cn/star/starheads/";
      for (const item of data.abslist) {
        const aid = String(item.ARTISTID || item.DC_TARGETID || "");
        if (!aid) continue;
        let pic = String(item.hts_PICPATH || "");
        if (!pic && item.PICPATH) pic = basePath + item.PICPATH;
        list.push({
          vod_id: aid,
          vod_name: String(item.ARTIST || ""),
          vod_pic: pic,
          vod_remarks: "歌曲 :  " + (item.SONGNUM || 0) + "首",
        });
      }
    }
    return {
      list,
      page: pg,
      pagecount: 9999,
      limit: LIMIT,
      total: 999999,
    };
  } catch (e) {
    console.error("[酷我音乐] 搜索错误:", e.message);
    return listResult([], pg);
  }
}

// ==================== 路由注册（对齐 guazi.js）====================
module.exports = async function kuwoMusic(app, opt) {
  app.get(meta.api, async (req) => {
    try {
      const q = req.query || {};
      // 播放
      if (q.play || q.ac === "play") return await playContent({ id: q.play || q.id, flag: q.flag });
      // 搜索
      if (q.wd) return await searchContent({ wd: q.wd, page: q.pg || q.page });
      // 详情：明确有 ids，或 ac=detail 且 id 不是分类请求
      if (q.ids || (q.ac === "detail" && q.id && !q.t)) {
        return await detailContent({ ids: q.ids || q.id });
      }
      // 分类：t=分类ID；部分壳会带 ac=detail&t=
      if (q.t) return await categoryContent({ id: q.t, page: q.pg || q.page, ext: q.ext || q.extend || q.f });
      // 兜底：单独 id 当详情
      if (q.id) return await detailContent({ ids: q.id });
      return await homeContent();
    } catch (error) {
      return {
        list: [],
        msg: error?.message || String(error),
      };
    }
  });

  if (opt && Array.isArray(opt.sites)) {
    opt.sites.push(meta);
  }
};

module.exports.meta = meta;
