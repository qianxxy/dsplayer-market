"use strict";

const axios = require("axios");

const API_BASE = "https://sv.baidu.com";
const UA = "Mozilla/5.0 (Linux; Android 11; M2012K10C Build/RP1A.200720.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/87.0.4280.141 Mobile Safari/537.36 haokan/7.80.0.18 (Baidu; P1 11)/imoaiX_03_11_C01K2102M/1043677m/5ACDB023CFB9D64743B08E51953F7C76%7CVSAJ32AVA/1/7.80.0.18/780001/1/immersiveMode/modeV4PlusWhite/isFirstInstall/bbqMode/bbqModeV2/blackStyle/isPlaylet Talos/1.8.7";

const meta = { key: "baiduduanju", name: "[短]好看短剧", type: 4, api: "/video/baiduduanju", searchable: 1, quickSearch: 1, filterable: 1, changeable: 0 };

function headers() {
  return { "User-Agent": UA, "Content-Type": "application/x-www-form-urlencoded; charset=utf-8", Cookie: "BAIDUCUID=giHCu0azv80G8SfQ0avU8gaaH8jfiv86ju2MugiR2i8-k3a35avAa1_mA", "Talos-Module-Version": "1.0.71.1", "Talos-Module-Name": "shortDrama" };
}

async function api(path, params) {
  const res = await axios.post(`${API_BASE}${path}`, new URLSearchParams(params).toString(), { headers: headers(), timeout: 15000, responseType: "json" });
  return res.data || {};
}

function pageNo(v) { const n = Number.parseInt(v, 10); return Number.isFinite(n) && n > 0 ? n : 1; }
function decodeExt(ext) { if (!ext) return {}; try { return JSON.parse(Buffer.from(String(ext), "base64").toString("utf8")) || {}; } catch { return {}; } }

async function home() {
  const data = await api("/haokan/ui-feed/playletShelfFeed?osbranch=a0", { from: "feed" });
  const classes = [];
  for (const panel of data.data && data.data.playlet_shelf_filter_panel || []) for (const tag of panel.tag_list || []) if (tag.tag_id) classes.push({ type_id: String(tag.tag_id), type_name: String(tag.name || "") });
  return { class: classes, filters: {} };
}

async function category(id, pg, ext) {
  const page = pageNo(pg);
  const data = await api("/haokan/ui-feed/playletTagsFeed?osbranch=a0", { tag_id: ext.cateId || id, rn: "9", pn: String(page) });
  const list = (data.data && data.data.list || []).map((v) => ({ vod_id: v.progress_vid ? `${v.playlet_id}|||${v.progress_vid}` : String(v.playlet_id || ""), vod_name: String(v.playlet_title || ""), vod_pic: String(v.playlet_poster || ""), vod_remarks: String(v.episodes_num_text || "") })).filter((v) => v.vod_id && v.vod_name);
  return { page, pagecount: list.length >= 9 ? page + 1 : page, limit: 9, total: 0, list };
}

async function findVid(playletId) {
  const value = `enable_enter_playlet=0&seek_time=0&hotspot=0&auto_show_hot_point_panel=0&type=playlet&commonlist_id=${Date.now()}&scene=&vid=&enable_atlas=0&mark_pn=&uk=&ctime=0&from=playlet_new&id=${playletId}&rn=10&pn=1&direction=3`;
  const data = await api("/appui/api?osbranch=a0", { "video/commonlist": value });
  return data["video/commonlist"] && data["video/commonlist"].data && data["video/commonlist"].data.results && data["video/commonlist"].data.results[0] && data["video/commonlist"].data.results[0].content && data["video/commonlist"].data.results[0].content.vid || "";
}

async function detail(rawId) {
  const [id, suppliedVid] = String(rawId).split("|||");
  const vid = suppliedVid || await findVid(id);
  if (!vid) throw new Error("详情缺少视频参数");
  const data = await api("/haokan/ui-video/playlet/rec/detail?osbranch=a0", { vid, playlet_id: id });
  const v = data.data || {};
  const urls = (v.vid_list || []).map((item, i) => `第${i + 1}集$${item}|||${id}`);
  return { list: [{ vod_id: id, vod_name: String(v.playlet_title || ""), vod_pic: String(v.playlet_poster || ""), vod_content: String(v.description || ""), vod_play_from: "好看", vod_play_url: urls.join("#") }] };
}

async function play(rawId) {
  const [vid, setId] = String(rawId).split("|||");
  if (!vid || !setId) throw new Error("播放参数错误");
  const value = `method=post&vid=${vid}&immersive_mode=v4_5&tplname=feed_small_video&tag=playlet_talos&tab=detail&external_from=&is_dp_video=0&immersive_square_type=3&video_set_id=${setId}&play_screen_type=1&play_volume_type=2&play_external_device_type=1`;
  const data = await api("/appui/api?osbranch=a0", { "video/relate": value });
  const rows = data["video/relate"] && data["video/relate"].data && data["video/relate"].data.cur_video && data["video/relate"].data.cur_video.clarityUrl || [];
  const url = rows.find((v) => v.key === "1080p")?.url || rows.find((v) => v.key === "sc")?.url || rows[0]?.url || "";
  if (!url) throw new Error("播放地址为空");
  return { parse: 0, url, header: { "User-Agent": UA }, extra: { nodanmu: true } };
}

async function search(wd) {
  const data = await api("/haokan/ui-interact/playlet/search/sugs?osbranch=a0", { search_word: String(wd || "").trim() });
  return { list: (Array.isArray(data.data) ? data.data : []).map((v) => ({ vod_id: String(v.id || ""), vod_name: String(v.title || ""), vod_pic: String(v.cover_url || ""), vod_remarks: String(v.tag || "") })).filter((v) => v.vod_id && v.vod_name) };
}

module.exports = async (app, opt) => {
  app.get(meta.api, async (req) => {
    const q = req.query || {};
    try {
      if (q.play) return await play(q.play);
      if (q.wd) return await search(q.wd);
      if (q.ids) return await detail(q.ids);
      if (q.t) return await category(q.t, q.pg, decodeExt(q.ext));
      return await home();
    } catch (e) { app.log && app.log.error && app.log.error(`[好看短剧] ${e.message || e}`); return { list: [] }; }
  });
  opt.sites.push(meta);
};
