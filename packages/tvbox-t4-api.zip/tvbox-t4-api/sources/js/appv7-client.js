"use strict";

const axios = require("axios");
const crypto = require("node:crypto");
const zlib = require("node:zlib");

const CRYPTO_URL = process.env.APPV7_CRYPTO_URL || "http://103.36.222.35:9595/wexfnwshinidie/appv7/crypto.php";
const PLAY_KEY = Buffer.from("0123456789abcdef", "utf8");

function text(v) { const s = String(v ?? "").trim(); return s.toLowerCase() === "null" ? "" : s; }
function number(v, fallback = 1) { const n = Number.parseInt(v, 10); return Number.isFinite(n) ? n : fallback; }
function json(v, fallback = {}) { try { const s = String(v ?? "").trim(); return s.startsWith("{") ? JSON.parse(s) : fallback; } catch { return fallback; } }
function decodeExt(ext) { if (!ext) return {}; try { return JSON.parse(Buffer.from(String(ext), "base64").toString("utf8")) || {}; } catch { return {}; } }
function hostOf(url) { try { return new URL(url).host; } catch { return ""; } }

function encodePlay(data) {
  const cipher = crypto.createCipheriv("aes-128-ecb", PLAY_KEY, null);
  cipher.setAutoPadding(true);
  return Buffer.concat([cipher.update(JSON.stringify(data), "utf8"), cipher.final()]).toString("base64");
}
function decodePlay(data) {
  try { const decipher = crypto.createDecipheriv("aes-128-ecb", PLAY_KEY, null); decipher.setAutoPadding(true); return JSON.parse(Buffer.concat([decipher.update(Buffer.from(String(data), "base64")), decipher.final()]).toString("utf8")); } catch { return null; }
}

class AppV7Client {
  constructor(configKey) { this.configKey = configKey; this.config = null; }
  async init() {
    if (this.config) return;
    const sep = CRYPTO_URL.includes("?") ? "&" : "?";
    const res = await axios.get(`${CRYPTO_URL}${sep}action=config&key=${encodeURIComponent(this.configKey)}`, { timeout: 15000, responseType: "json", validateStatus: () => true });
    if (res.status < 200 || res.status >= 300 || res.data?.error || !res.data?.data?.host) throw new Error(`AppV7 config failed: ${res.status} ${res.data?.error || "empty"}`);
    const c = res.data.data;
    this.config = { key: text(c.key), name: text(c.name), host: text(c.host), version: text(c.version), versionNumber: text(c.version_number), pkId: text(c.pk_id), buildTime: text(c.build_time), signMd5: text(c.sign_md5), apkLength: text(c.apk_length), parseKey: text(c.parse_key), platform: text(c.platform) || "android", platformVersion: text(c.platform_version) || "TP1A.220624.014", userAgent: text(c.user_agent) || "Dart/3.11 (dart:io)" };
  }
  logsUrl() { return `${this.config.host.replace(/\/+$/g, "")}/v7/logs`; }
  headers(length) { const c = this.config, url = this.logsUrl(); return { host: hostOf(url), "content-length": String(length), "user-agent": c.userAgent, version: c.version, "accept-encoding": "gzip", "version-number": c.versionNumber, "content-type": "text/plain", "pk-id": c.pkId, "build-time": c.buildTime, platform: c.platform, "platform-version": c.platformVersion }; }
  async crypto(action, raw) {
    const sep = CRYPTO_URL.includes("?") ? "&" : "?";
    const res = await axios.post(`${CRYPTO_URL}${sep}action=${encodeURIComponent(action)}`, { key: this.configKey, raw: raw == null ? "" : String(raw) }, { headers: { "content-type": "application/json", accept: "application/json" }, timeout: 20000, responseType: "json", validateStatus: () => true });
    if (res.status < 200 || res.status >= 300 || res.data?.error) throw new Error(`AppV7 crypto ${action}: ${res.data?.error || res.status}`);
    return res.data || {};
  }
  async request(method, data = { token: "" }) {
    await this.init();
    const encrypted = text((await this.crypto("encrypt", JSON.stringify({ method, data, csrf: Date.now() }))).body);
    if (!encrypted) throw new Error(`${this.configKey} encrypt empty`);
    const res = await axios.post(this.logsUrl(), encrypted, { headers: this.headers(encrypted.length), timeout: 20000, responseType: "arraybuffer", maxRedirects: 0, validateStatus: (s) => s >= 200 && s < 400, transformRequest: [(v) => v], transformResponse: [(v) => v] });
    let body = Buffer.from(res.data || []); const encoding = String(res.headers?.["content-encoding"] || "").toLowerCase();
    if (encoding.includes("gzip") || (body[0] === 31 && body[1] === 139)) body = zlib.gunzipSync(body); else if (encoding.includes("deflate")) body = zlib.inflateSync(body); else if (encoding.includes("br")) body = zlib.brotliDecompressSync(body);
    const raw = body.toString("utf8"), direct = json(raw, null); if (direct) return direct;
    const decoded = await this.crypto("decrypt", raw); if (decoded.data && typeof decoded.data === "object") return decoded.data; const parsed = json(decoded.text, null); if (parsed) return parsed;
    throw new Error(`${this.configKey} ${method} decrypt empty`);
  }
  async parseUrl(url) {
    try {
      const res = await axios.get(url, { headers: { "user-agent": this.config.userAgent, "accept-encoding": "gzip", connection: "Keep-Alive", host: hostOf(url) }, responseType: "arraybuffer", timeout: 20000, maxRedirects: 0, validateStatus: (s) => s >= 200 && s < 400 });
      let body = Buffer.from(res.data || []); const encoding = String(res.headers?.["content-encoding"] || "").toLowerCase(); if (encoding.includes("gzip") || (body[0] === 31 && body[1] === 139)) body = zlib.gunzipSync(body); else if (encoding.includes("deflate")) body = zlib.inflateSync(body); else if (encoding.includes("br")) body = zlib.brotliDecompressSync(body);
      const raw = body.toString("utf8").trim(); if (raw.startsWith("{") || raw.startsWith("[") || raw.startsWith("http")) return raw; return text((await this.crypto("parse_decrypt", raw)).text) || raw;
    } catch { return ""; }
  }
  nav() { return this.request("nav", { token: "" }); }
  list(page, tid, ext) { return this.request("video_list", { token: "", pg: number(page), tid: number(tid), class: text(ext.class), area: text(ext.area), lang: text(ext.lang), year: text(ext.year), order: text(ext.order) || "最新" }); }
  search(wd, page) { return this.request("search", { token: "", pg: number(page), text: text(wd) }); }
  detail(id) { return this.request("video_detail", { token: "", id: number(id, 0), sign_md5: this.config.signMd5, apk_path: `/data/app/~~mLGfF_Nezy4R4TqUevJVlg==/${this.config.pkId}-NlNuzFF6p4657CBJv-ue4Q==/base.apk`, apk_length: number(this.config.apkLength, 0) }); }
  async secretUrl(url, code) { const r = await this.request("secret_parse_api_url", { token: "", url, player_code: code }); return text(r?.data); }
}

function playerCode(url, fallback) { const s = text(url), p = s.indexOf("-"); if (p > 0 && !s.slice(0, p).includes("://")) return s.slice(0, p); const l = s.toLowerCase(); return l.includes("qq.com") ? "qq" : l.includes("iqiyi.com") || l.includes("qiyi.com") ? "qiyi" : l.includes("youku.com") ? "youku" : l.includes("mgtv.com") ? "mgtv" : l.includes("bilibili.com") || l.includes("b23.tv") ? "bilibili" : fallback; }
function finalUrl(raw) { const o = json(raw, {}); return text(o.url) || (String(raw || "").trim().startsWith("http") ? String(raw).trim() : ""); }
function card(v) { return { vod_id: String(v?.vod_id || ""), vod_name: text(v?.vod_name), vod_pic: text(v?.vod_pic), vod_remarks: text(v?.vod_remarks) }; }

function createRoute({ key, name, configKey }) {
  const client = new AppV7Client(configKey); const parseApis = new Map(), extraApis = new Map();
  const meta = { key, name, type: 4, api: `/video/${key}`, searchable: 1, quickSearch: 1, filterable: 1, changeable: 0 };
  async function home() { const r = await client.nav(); const classes = [], filters = {}; for (const row of Array.isArray(r?.data) ? r.data : []) { const id = text(row.type_id), n = text(row.type_name); if (!id || !n) continue; classes.push({ type_id: id, type_name: n }); const ext = row.type_extend || {}, values = []; for (const [k, title] of [["class", "类型"], ["area", "地区"], ["lang", "语言"], ["year", "年份"]]) { const list = String(ext[k] || "").split(",").map((v) => v.trim()).filter(Boolean); if (list.length) values.push({ key: k, name: title, value: [{ n: "全部", v: "" }, ...list.map((v) => ({ n: v, v }))] }); } values.push({ key: "order", name: "排序", value: ["最新", "最热", "评分"].map((v) => ({ n: v, v })) }); filters[id] = values; } return { class: classes, filters, list: [] }; }
  async function category(id, page, ext) { const pg = number(page); const r = await client.list(pg, id, ext); const list = (Array.isArray(r?.data) ? r.data : []).map(card).filter((v) => v.vod_id && v.vod_name); return { page: pg, pagecount: number(r?.pagecount, 999999), limit: 21, total: 999999, list }; }
  async function detail(id) { const info = (await client.detail(id))?.data?.vod_info || {}; parseApis.clear(); extraApis.clear(); const from = [], urls = []; for (const line of Array.isArray(info.vod_url_with_player) ? info.vod_url_with_player : []) { const n = text(line.name); if (!n) continue; from.push(n); parseApis.set(n, text(line.parse_api)); extraApis.set(n, text(line.extra_parse_api)); const eps = []; for (const item of String(line.url || "").split("#")) { if (!item) continue; const parts = item.split("$"), title = parts.length > 1 ? parts.shift() : "", url = parts.length ? parts.join("$") : item; eps.push(`${title}$${encodePlay({ name: line.name, code: line.code, url, parseApi: line.parse_api, extraParseApi: line.extra_parse_api, parseSecret: !!line.parse_secret, headers: line.headers, linkFeatures: line.link_features, unLinkFeatures: line.un_link_features, coreParams: Array.isArray(line.core_params) ? line.core_params : [] })}`); } urls.push(eps.join("#")); }
    return { list: [{ vod_id: String(info.vod_id || id), vod_name: text(info.vod_name), vod_pic: text(info.vod_pic), vod_remarks: text(info.vod_remarks), vod_year: text(info.vod_year), vod_area: text(info.vod_area), vod_actor: text(info.vod_actor), vod_director: text(info.vod_director), vod_content: text(info.vod_content), vod_play_from: from.join("$$$"), vod_play_url: urls.join("$$$") }] }; }
  async function search(wd, page) { const pg = number(page), r = await client.search(wd, pg), list = (Array.isArray(r?.data) ? r.data : []).map(card).filter((v) => v.vod_id && v.vod_name); return { page: pg, pagecount: number(r?.pagecount, 999999), limit: 21, total: 999999, list }; }
  async function play(id, flag) { const packed = decodePlay(id), raw = packed ? text(packed.url) : text(id), code = packed?.code || flag, primary = packed ? text(packed.parseApi) : text(parseApis.get(flag)), extra = packed ? text(packed.extraParseApi) : text(extraApis.get(flag)); if (!primary && !extra) return raw.startsWith("http") ? { parse: 0, url: raw } : { msg: "缺少 parse_api" }; let target = await client.secretUrl(raw, playerCode(raw, code)).catch(() => raw) || raw;
    for (const api of [primary, extra].filter(Boolean)) { let result = await client.parseUrl(`${api}${target}`), url = finalUrl(result); if (url) return { parse: 0, url }; const nested = text(json(result, {}).data); if (nested.includes("%")) try { result = decodeURIComponent(nested.replace(/\+/g, "%2B")); } catch {} if (result.startsWith("http")) { result = await client.parseUrl(result); url = finalUrl(result); if (url) return { parse: 0, url }; } } return { msg: "解析失败" }; }
  return async (app, opt) => { app.get(meta.api, async (req) => { const q = req.query || {}; try { await client.init(); if (q.play) return await play(q.play, q.flag || ""); if (q.wd) return await search(q.wd, q.pg); if (q.ids) return await detail(q.ids); if (q.t) return await category(q.t, q.pg, decodeExt(q.ext)); return await home(); } catch (e) { app.log?.error?.(`[${name}] ${e.message || e}`); return { list: [] }; } }); opt.sites.push(meta); };
}

module.exports = { createRoute, CRYPTO_URL };
