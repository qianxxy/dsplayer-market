"use strict"; module.exports = require("./appv7-client").createRoute({ key: "appv7linglingqi", name: "[影]零七秒播", configKey: "AppV7Llq" });
