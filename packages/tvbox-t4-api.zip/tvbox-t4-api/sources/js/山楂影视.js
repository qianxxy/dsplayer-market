const axios = require('axios');
const http = require('http');
const crypto = require('crypto');

const HOST = 'http://qkys.qukanwh.com';
const DEVICE_ID = '2d590b9842d064a1';
const APP_SIGN_SHA1 = '09a8dc51639a31801af5f6418caebfabc695eb24';
const UA = 'okhttp/4.12.0';
const PAGE_SIZE = 40;

const PUB_KEY_B64 = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCoYt0BP77U+DM08BiI/QbSRIfxijXo85BTPqIM1Ow8BNwhLETzRIZ+dEwdWDbydG/PspgBAfRpGaYVdJYtvaC2JnoO8+Ik6qMWojfEJxSFLa0Pb0A892tun4gsxoEMjcreZ+YGyaBxAfqX0BSMfdrOgIYaZQjYrw9TRLlUT31QoQIDAQAB';
const PRIV_KEY_B64 = `MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCquQQ5r6+yJI8CDFkXRp8vUsdD45ov8EP12ooLs56ca2DQXaSNGS9910bAPVA9chkp0mKIvKqjAsHz5Tl9EeNPblarGEeJUIxpxZtiSqNTpvtiD/TjhpzuHYic7RAfQ/h7p/ypE8ymU42pYjsB5t26Mv6XgkLV+jzrSf73HlCuS0iMyLmt6zz3Mw9izM13EpB8iFLtfbbYymycKTx4RAmPQLwhNGex/AlUIYxXP4R2yyaa4W6mEtc6aME2QuzJFxPgP3HJ9NBx/LWVn4skxWjZ7zg+VRQRHnjyVaSLu3Z5gN5ITWCyE32qaHJa6WBahZj5jWhRyAG1bQ+xKJa8lBL5AgMBAAECggEAUwv9SjJ0PSwbhNuM2w23kcWquROWhYtTA91zGY4esehqB/IFgb2mpIh8Gje5OKqwIu/8jpd4SiOlRYdUF8sD0DfUYRZGdj2AkFNX6tBz8tVfo6wvbB6naA1lzzBij1L5JO3qsjS3cJFkb+kg2yP66AC2Z+0tpfk8eRhdtshAZwfcd1DEGt1uAvYL1eaUK9HRvpt9lPeGcHERDl2hBd4uyaF0K1O+zF9y59nYbTySWPxRZq3sFEE85xRMlstD7YZi7W2gKvMFRD4/FKmrZ3m7aKJRITtyKOyyPcYmepNv3Qv7kk59Pg38n2WWQ0Ra/bCH3E48YNCnQvZMpitkTfJhoQKBgQDbnROOYTP8OTJ6f/qhoGjxeO3x1VOaOp8l0x7b0SCfoqNGS0Cyiqj72BmJtPMPqSTjn6MmNzqbg1KOdhXyzNozs+i5ccW1M56j96mr5I/Z0FpE3oyIHNfDDBlf9M8YQqEF9oYxniYYft9oapO7cRQkHER6qpvnHTavwlv4m78CXwKBgQDHAjs2YlpKDdI1lcbZJCc7TwtH+Pd2bUki8YXafWNcPhITQHbOZjr310eK1QJC6GJncjkOqbX7yv3ivvTO35FZTQhuA1xEG1P00FG8bE0tHYPIwQHi9y0eA5cieMdo8E6XYria1mw/3fqSQEsfZyJlR32JQIoGAipM8iO1X2nZpwKBgDkMFIhnt5lNQk+P7wsNIDWZtDWdtJnboHuy29E+Abt2A/O+mI/IdRz2hau/1WO8DFkUnszOi+rZshhPlGP90rCbi1igtTrcrdjp/KkqNjPea5R4OwkgdOu1uOG0NheXNzzVTQaWjk7Opjn5dWa7eP/oV+GFb/oZHJuLYVizHGsBAoGADA7rjZEKDYCm4w5PPSr+oY5ZjaPdQrS+gLqHtMRyN82fBMGcMUdqfUfzEstzVqCEDeaS5HuOBlK3bXzKkppjUTjksN3NQmcxgBz7RuJ9DqXCLXDcb2cwuafYCYOt+YLOEEgwDVm+t2P44dG5e46hO+fICH/7nP+WlpD5buz4GfMCgYB57r3g/6hi9WUDnfc7ZAzWMqR0EhJVYKYy+KFEtdIPzhkkIHq5RASe88E9kzoGoZFdb3tIjvGZWcHerirrqWkMsuQtP/Qi0zjieid5tAPj+r4kbiCVTw0E0jnmPBzGInQi7lpeTTKnG1fbyS5lBS+WmHfIuzpECgCkxhaT+LJJkg==`;

const pubKey = crypto.createPublicKey({ key: Buffer.from(PUB_KEY_B64, 'base64'), format: 'der', type: 'spki' });
const privKey = crypto.createPrivateKey({ key: Buffer.from(PRIV_KEY_B64, 'base64'), format: 'der', type: 'pkcs8' });

const client = axios.create({
  timeout: 18000,
  proxy: false,
  httpAgent: new http.Agent({ keepAlive: true }),
  validateStatus: s => s >= 200 && s < 500,
});

const store = { userId: '', token: '', tokenAt: 0 };

function md5(s) { return crypto.createHash('md5').update(String(s)).digest('hex').toUpperCase(); }
function b64u(v) { return Buffer.from(JSON.stringify(v), 'utf8').toString('base64url'); }
function ub64u(v) { return JSON.parse(Buffer.from(String(v || ''), 'base64url').toString('utf8')); }
function clean(v) { return String(v ?? '').trim(); }
function asArr(v) { return Array.isArray(v) ? v : []; }

function rsaEncrypt(str) {
  return crypto.publicEncrypt({ key: pubKey, padding: crypto.constants.RSA_PKCS1_PADDING }, Buffer.from(String(str), 'utf8')).toString('base64');
}

function unpadPkcs1V15(block) {
  // Node 22+ 禁止 RSA_PKCS1_PADDING 私钥解密，这里用 RSA_NO_PADDING 后手动剥离 00 02 ... 00 数据。
  let i = 0;
  while (i < block.length && block[i] === 0) i++;
  if (block[i] === 2) {
    const sep = block.indexOf(0, i + 1);
    if (sep >= 0) return block.subarray(sep + 1);
  }
  return block;
}

function rsaDecrypt(encryptedB64) {
  const buf = Buffer.from(String(encryptedB64 || ''), 'base64');
  const parts = [];
  for (let i = 0; i < buf.length; i += 256) {
    const raw = crypto.privateDecrypt({ key: privKey, padding: crypto.constants.RSA_NO_PADDING }, buf.subarray(i, i + 256));
    parts.push(unpadPkcs1V15(raw));
  }
  return Buffer.concat(parts).toString('utf8');
}

function baseHeaders(extra = {}) {
  return {
    'User-Agent': UA,
    'Connection': 'Keep-Alive',
    'Accept-Encoding': 'gzip',
    'Content-Type': 'application/json;charset=UTF-8',
    'Cache-Control': 'no-cache',
    'token': store.token || '',
    'deviceId': DEVICE_ID,
    'client': 'app',
    'deviceType': 'Android',
    ...extra,
  };
}

function paramsString({ episodeId = '', episodeIndex = '', id = '', playerId = '', typeId = '', userId = '' }) {
  return `episodeId${episodeId}episodeIndex${episodeIndex}id${id}playerId${playerId}source0typeId${typeId}userId${userId}`;
}

function makeSign(timestamp, paramsStr) {
  const raw = `SaltLSFBTimestamp${timestamp}Params${paramsStr}ClientappDeviceId${DEVICE_ID}`;
  return md5(Buffer.from(raw, 'utf8').toString('base64'));
}

function encryptedHeadersAndBody(body, paramsStr) {
  const bodyJson = JSON.stringify(body, null, 0);
  const ts = String(Math.floor(Date.now() / 1000));
  return [{
    ...baseHeaders(),
    snjm: rsaEncrypt('113'),
    appsign: rsaEncrypt(APP_SIGN_SHA1),
    timestamp: ts,
    sign: makeSign(ts, paramsStr),
  }, { key: rsaEncrypt(bodyJson) }];
}

async function ensureLogin(force = false) {
  if (!force && store.token && Date.now() - store.tokenAt < 30 * 60 * 1000) return;
  const res = await client.get(`${HOST}/api/v1/app/user/visitorInfo`, { headers: baseHeaders({ token: '' }) });
  const data = res.data && res.data.data;
  if (!data || !data.id || !data.token) throw new Error('山楂游客登录失败');
  store.userId = String(data.id);
  store.token = String(data.token);
  store.tokenAt = Date.now();
}

async function apiPost(path, body = null) {
  await ensureLogin();
  const res = await client.post(`${HOST}${path}`, body == null ? '' : JSON.stringify(body), { headers: baseHeaders() });
  if (res.status === 401 || res.status === 403 || res.data?.code === 401) {
    await ensureLogin(true);
    return (await client.post(`${HOST}${path}`, body == null ? '' : JSON.stringify(body), { headers: baseHeaders() })).data;
  }
  return res.data || {};
}

async function apiGet(path, params = {}) {
  await ensureLogin();
  const res = await client.get(`${HOST}${path}`, { params, headers: baseHeaders() });
  if (res.status === 401 || res.status === 403 || res.data?.code === 401) {
    await ensureLogin(true);
    return (await client.get(`${HOST}${path}`, { params, headers: baseHeaders() })).data;
  }
  return res.data || {};
}

async function encryptedMovieDetails(body) {
  await ensureLogin();
  const paramsStr = paramsString({
    episodeId: body.episodeId || '',
    episodeIndex: body.episodeIndex || '',
    id: String(body.id || ''),
    playerId: body.playerId || '',
    typeId: body.typeId || '',
    userId: String(body.userId || ''),
  });
  const [headers, payload] = encryptedHeadersAndBody(body, paramsStr);
  const res = await client.post(`${HOST}/api/v1/app/play/movieDetails`, JSON.stringify(payload), { headers });
  if (!res.data || !res.data.data) throw new Error(`movieDetails data empty: ${JSON.stringify(res.data).slice(0, 120)}`);
  return JSON.parse(rsaDecrypt(res.data.data));
}

function vodItem(i = {}) {
  return {
    vod_id: b64u({ id: String(i.id || ''), typeId: String(i.typeId || 'M15') }),
    vod_name: clean(i.name),
    vod_pic: clean(i.cover),
    vod_remarks: clean(i.remarks || i.area || i.year),
    vod_year: clean(i.year),
    vod_area: clean(i.area),
    vod_content: clean(i.desc),
  };
}

function decodeVodId(id) {
  try {
    const obj = ub64u(id);
    return { id: String(obj.id || ''), typeId: String(obj.typeId || 'M15') };
  } catch (_) {
    return { id: String(id || ''), typeId: 'M15' };
  }
}

async function getHome() {
  const json = await apiPost('/api/v1/app/screen/screenType');
  const classes = asArr(json.data).map(i => ({ type_id: String(i.id), type_name: clean(i.name) })).filter(i => i.type_id && i.type_name);
  let list = [];
  try {
    const rec = await apiPost('/api/v1/app/recommend/recommendList');
    const groups = asArr(rec.data).slice(0, 5);
    const results = await Promise.all(groups.map(g => apiPost('/api/v1/app/recommend/recommendSubList', { condition: g.id, pageNum: 1, pageSize: 6 }).catch(() => ({}))));
    list = results.flatMap(r => asArr(r.data?.records).map(vodItem)).slice(0, 24);
  } catch (_) {}
  return { class: classes, list };
}

async function getCategory(tid, pg) {
  const page = Math.max(parseInt(pg) || 1, 1);
  const body = { condition: { classify: '', region: '', sreecnTypeEnum: 'NEWEST', typeId: String(tid), year: '' }, pageNum: page, pageSize: PAGE_SIZE };
  const json = await apiPost('/api/v1/app/screen/screenMovie', body);
  const data = json.data || {};
  const list = asArr(data.records).map(vodItem);
  const total = parseInt(data.total || data.totalRow || 0) || (page * PAGE_SIZE + (list.length >= PAGE_SIZE ? PAGE_SIZE : 0));
  return { list, page, pagecount: total ? Math.ceil(total / PAGE_SIZE) : page + (list.length >= PAGE_SIZE ? 1 : 0), limit: PAGE_SIZE, total };
}

async function doSearch(wd, pg) {
  const page = Math.max(parseInt(pg) || 1, 1);
  const json = await apiPost('/api/v1/app/search/searchMovie', { condition: { value: String(wd || '') }, pageNum: page, pageSize: PAGE_SIZE });
  const data = json.data || {};
  const list = asArr(data.records).map(vodItem);
  const total = parseInt(data.total || 0) || list.length;
  return { list, page, pagecount: total ? Math.ceil(total / PAGE_SIZE) : page, limit: PAGE_SIZE, total };
}

async function getDetail(rawId) {
  const { id, typeId } = decodeVodId(rawId);
  const body = { id, source: 0, typeId, userId: store.userId || '', episodeId: '', episodeIndex: '', playerId: '' };
  await ensureLogin();
  body.userId = store.userId;
  const data = await encryptedMovieDetails(body);
  const currentPlayerId = String(data.playerId || '');
  const playerList = asArr(data.moviePlayerList);
  const linesByPlayer = [];
  const names = [];

  const curEpisodes = asArr(data.episodeList);
  if (curEpisodes.length) {
    names.push(clean(playerList.find(p => String(p.id) === currentPlayerId)?.moviePlayerName || '默认'));
    linesByPlayer.push(curEpisodes.map(ep => `${clean(ep.episode || ep.episodeName || ep.name || ('第' + (ep.episodeIndex || '')) + '集')}$${b64u({ vid: id, typeId, playerId: currentPlayerId, episodeId: String(ep.id || ''), mode: 'episode' })}`).join('#'));
  }

  for (const p of playerList) {
    const playerId = String(p.id || '');
    if (!playerId || playerId === currentPlayerId) continue;
    const total = parseInt(p.episodeTotal || p.totalEpisode || 0) || parseInt(data.totalEpisode || 0) || 1;
    if (!total) continue;
    names.push(clean(p.moviePlayerName || `线路${names.length + 1}`));
    const lines = [];
    for (let i = 1; i <= Math.min(total, 300); i++) {
      lines.push(`第${i}集$${b64u({ vid: id, typeId, playerId, episodeIndex: String(i - 1), mode: 'virtual' })}`);
    }
    linesByPlayer.push(lines.join('#'));
  }

  let desc = {};
  try { desc = (await apiPost('/api/v1/app/play/movieDesc', { id, typeId })).data || {}; } catch (_) {}
  const vod = {
    vod_id: rawId,
    vod_name: clean(desc.name || data.name),
    vod_pic: clean(desc.cover),
    vod_content: clean(desc.introduce || desc.desc),
    vod_year: clean(desc.year),
    vod_area: clean(desc.area),
    vod_remarks: clean(desc.remarks || data.currentEpisode),
    vod_score: clean(desc.score),
    type_name: clean(desc.classify),
    vod_director: clean(desc.director),
    vod_actor: clean(desc.star),
    vod_play_from: names.join('$$$') || '默认',
    vod_play_url: linesByPlayer.join('$$$'),
  };
  return { list: [vod] };
}

function isWebPlayPage(url) {
  const u = String(url || '').toLowerCase();
  if (!u) return false;
  if (/\.(m3u8|mp4|flv|m4v|mov|ts)(\?|#|$)/.test(u)) return false;
  return /https?:\/\/(?:[^/]+\.)?(v\.qq\.com|youku\.com|iqiyi\.com|mgtv\.com|bilibili\.com)\//.test(u);
}

async function getPlay(playId) {
  try {
    const p = ub64u(playId);
    await ensureLogin();
    const body = p.mode === 'virtual'
      ? { episodeIndex: String(p.episodeIndex || '0'), id: String(p.vid), playerId: String(p.playerId), source: 0, typeId: String(p.typeId || 'M15'), userId: store.userId, episodeId: '' }
      : { episodeId: String(p.episodeId || ''), id: String(p.vid), playerId: String(p.playerId), source: 0, typeId: String(p.typeId || 'M15'), userId: store.userId, episodeIndex: '' };
    const data = await encryptedMovieDetails(body);
    const parseUrl = clean(data.url);
    const playerId = String(data.playerId || p.playerId || '');
    const ana = await apiGet('/api/v1/app/play/analysisMovieUrl', { playerUrl: parseUrl, playerId });
    const url = clean(ana.data || parseUrl);
    const needParse = isWebPlayPage(url);
    return { jx: needParse ? 1 : 0, parse: needParse ? 1 : 0, url, playUrl: '', header: { 'User-Agent': needParse ? UA : 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1' } };
  } catch (e) {
    return { jx: 0, parse: 0, url: '', msg: e.message, header: { 'User-Agent': UA } };
  }
}

async function handle(req) {
  const q = req.query || {};
  const ac = q.ac;
  const isPlay = !!q.play || ac === 'play' || (!!q.flag && !!q.id);
  const wd = q.wd || q.key || q.keyword;
  const tid = q.t || q.type_id;
  const ids = q.ids || (q.id && !isPlay && !tid ? q.id : '');
  if (isPlay) return await getPlay(q.play || q.id);
  if (ids) return await getDetail(ids);
  if (wd) return await doSearch(wd, q.pg || 1);
  if (tid && String(tid) !== '0') return await getCategory(tid, q.pg || 1);
  return await getHome();
}

module.exports = async (app, opt) => {
  const path = '/video/shanzha';
  app.get(path, async (req) => await handle(req));
  app.get('/video/山楂影视', async (req) => await handle(req));
  opt.sites.push({
    key: 'shanzha',
    name: '[纯]山楂影视',
    type: 4,
    api: path,
    searchable: 1,
    quickSearch: 1,
    filterable: 0,
    changeable: 0,
    ext: '',
  });
};
