/*
 * 听友 FM (tingyou.fm) - TVBox T4 接口插件（零外部密码库版）
 * 修改时间：2026-05-19
 */

const axios = require('axios');
const http = require('http');
const https = require('https');
const crypto = require('crypto');

let log = console;

/* ===============================
   常量与算法
=============================== */

const SITE_BASE = 'https://tingyou.fm';
const STATIC_HOSTS = [
  'https://json.hgeuz.cn',
  'https://json.fmfm.pro',
  'https://json.tingyou8.vip'
];
const STATIC_BASE_PATH = '/tyfm/json_v1';

const PAYLOAD_KEY_HEX = 'ea9d9d4f9a983fe6f6382f29c7b46b8d6dc47abc6da36662e6ddff8c78902f65';
const PAYLOAD_KEY = Buffer.from(PAYLOAD_KEY_HEX, 'hex');
const PAYLOAD_VERSION = 1;

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36';

/* ----- AES-256-GCM 请求加密 (12B IV) ----- */
function encryptRequest(plainBuf, version = PAYLOAD_VERSION) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', PAYLOAD_KEY, iv);
  const ct = Buffer.concat([c.update(plainBuf), c.final()]);
  let body = Buffer.concat([ct, c.getAuthTag()]);
  if (version === 2) body = Buffer.from(body).reverse();
  return Buffer.concat([Buffer.from([version]), iv, body]);
}

/* ----- 纯 JS 实现 HChaCha20（用于 XChaCha20 密钥派生） ----- */
function quarterRound(s, a, b, c, d) {
  s[a] = (s[a] + s[b]) >>> 0;
  s[d] ^= s[a];
  s[d] = ((s[d] << 16) | (s[d] >>> 16)) >>> 0;
  s[c] = (s[c] + s[d]) >>> 0;
  s[b] ^= s[c];
  s[b] = ((s[b] << 12) | (s[b] >>> 20)) >>> 0;
  s[a] = (s[a] + s[b]) >>> 0;
  s[d] ^= s[a];
  s[d] = ((s[d] << 8) | (s[d] >>> 24)) >>> 0;
  s[c] = (s[c] + s[d]) >>> 0;
  s[b] ^= s[c];
  s[b] = ((s[b] << 7) | (s[b] >>> 25)) >>> 0;
}

function hchacha20(key, nonce16) {
  // key: 32字节, nonce16: 16字节 → 32字节子密钥
  const state = new Uint32Array(16);
  state[0] = 0x61707865;
  state[1] = 0x3320646e;
  state[2] = 0x79622d32;
  state[3] = 0x6b206574;
  for (let i = 0; i < 8; i++) state[4 + i] = key.readUInt32LE(i * 4);
  for (let i = 0; i < 4; i++) state[12 + i] = nonce16.readUInt32LE(i * 4);

  const x = new Uint32Array(state);
  for (let i = 0; i < 10; i++) {
    quarterRound(x, 0, 4, 8, 12);
    quarterRound(x, 1, 5, 9, 13);
    quarterRound(x, 2, 6, 10, 14);
    quarterRound(x, 3, 7, 11, 15);
    quarterRound(x, 0, 5, 10, 15);
    quarterRound(x, 1, 6, 11, 12);
    quarterRound(x, 2, 7, 8, 13);
    quarterRound(x, 3, 4, 9, 14);
  }

  const out = Buffer.alloc(32);
  out.writeUInt32LE(x[0], 0);
  out.writeUInt32LE(x[1], 4);
  out.writeUInt32LE(x[2], 8);
  out.writeUInt32LE(x[3], 12);
  out.writeUInt32LE(x[12], 16);
  out.writeUInt32LE(x[13], 20);
  out.writeUInt32LE(x[14], 24);
  out.writeUInt32LE(x[15], 28);
  return out;
}

/* ----- XChaCha20-Poly1305 响应解密（仅用 Node 内置 crypto） ----- */
function decryptResponse(buf, version = PAYLOAD_VERSION) {
  if (!Buffer.isBuffer(buf)) buf = Buffer.from(buf);
  if (buf.length < 41) throw new Error('cipher too short');

  const v = buf[0];
  const nonce24 = buf.slice(1, 25);          // 24 字节 nonce
  let body = buf.slice(25);
  if (v === 2) body = Buffer.from(body).reverse();

  if (body.length < 16) throw new Error('ciphertext too short');
  const tag = body.slice(body.length - 16);   // 最后 16 字节认证标签
  const ciphertext = body.slice(0, body.length - 16);

  // HChaCha20(前16字节 nonce) → 32 字节子密钥
  const subKey = hchacha20(PAYLOAD_KEY, nonce24.slice(0, 16));

  // 构造 12 字节 nonce：counter=0(4字节) + nonce24 后8字节
  const nonce12 = Buffer.alloc(12);
  nonce24.copy(nonce12, 4, 16, 24);   // nonce[16..24] → nonce12[4..11]，前4字节保持 0

  const decipher = crypto.createDecipheriv('chacha20-poly1305', subKey, nonce12, { authTagLength: 16 });
  decipher.setAuthTag(tag);
  // 无需 AAD，直接解密
  return Buffer.concat([decipher.update(ciphertext), decipher.final()]);
}

/* ----- SM4-ECB-PKCS7 (用于 dfp 指纹 cookie) ----- */
const Ci = [214,144,233,254,204,225,61,183,22,182,20,194,40,251,44,5,43,103,154,118,42,190,4,195,170,68,19,38,73,134,6,153,156,66,80,244,145,239,152,122,51,84,11,67,237,207,172,98,228,179,28,169,201,8,232,149,128,223,148,250,117,143,63,166,71,7,167,252,243,115,23,186,131,89,60,25,230,133,79,168,104,107,129,178,113,100,218,139,248,235,15,75,112,86,157,53,30,36,14,94,99,88,209,162,37,34,124,59,1,33,120,135,212,0,70,87,159,211,39,82,76,54,2,231,160,196,200,158,234,191,138,210,64,199,56,181,163,247,242,206,249,97,21,161,224,174,93,164,155,52,26,85,173,147,50,48,245,140,177,227,29,246,226,46,130,102,202,96,192,41,35,171,13,83,78,111,213,219,55,69,222,253,142,47,3,255,106,114,109,108,91,81,141,27,175,146,187,221,188,127,17,217,92,65,31,16,90,216,10,193,49,136,165,205,123,189,45,116,208,18,184,229,180,176,137,105,151,74,12,150,119,126,101,185,241,9,197,110,198,132,24,240,125,236,58,220,77,32,121,238,95,62,215,203,57,72];
const Si = [2746333894,1453994832,1736282519,2993693404];
const Li = [462357,472066609,943670861,1415275113,1886879365,2358483617,2830087869,3301692121,3773296373,4228057617,404694573,876298825,1347903077,1819507329,2291111581,2762715833,3234320085,3705924337,4177462797,337322537,808926789,1280531041,1752135293,2223739545,2695343797,3166948049,3638552301,4110090761,269950501,741554753,1213159005,1684763257];

function sm4Mi(e) {
  const t = [e>>>24&255, e>>>16&255, e>>>8&255, 255&e];
  for (let o=0; o<4; o++) t[o] = Ci[t[o]];
  const n = ((t[0]<<24)|(t[1]<<16)|(t[2]<<8)|t[3]) >>> 0;
  return (n ^ ((n<<2)>>>0) ^ ((n<<10)>>>0) ^ ((n<<18)>>>0) ^ ((n<<24)>>>0)) >>> 0;
}
function sm4EncBlock(key, blk) {
  let t=(key[0]<<24|key[1]<<16|key[2]<<8|key[3])^Si[0];
  let n=(key[4]<<24|key[5]<<16|key[6]<<8|key[7])^Si[1];
  let o=(key[8]<<24|key[9]<<16|key[10]<<8|key[11])^Si[2];
  let a=(key[12]<<24|key[13]<<16|key[14]<<8|key[15])^Si[3];
  t>>>=0; n>>>=0; o>>>=0; a>>>=0;
  const rk = new Uint32Array(32);
  for (let i=0; i<32; i++) {
    let e = ((n^o^a^Li[i]) >>> 0);
    e = sm4Mi(e);
    const s = ((t^e) >>> 0);
    rk[i] = s; t = n; n = o; o = a; a = s;
  }
  let p0=(blk[0]<<24|blk[1]<<16|blk[2]<<8|blk[3])>>>0;
  let p1=(blk[4]<<24|blk[5]<<16|blk[6]<<8|blk[7])>>>0;
  let p2=(blk[8]<<24|blk[9]<<16|blk[10]<<8|blk[11])>>>0;
  let p3=(blk[12]<<24|blk[13]<<16|blk[14]<<8|blk[15])>>>0;
  for (let f=0; f<32; f++) {
    let e = ((p1^p2^p3^rk[f]) >>> 0);
    e = sm4Mi(e);
    const tt = ((p0^e) >>> 0);
    p0 = p1; p1 = p2; p2 = p3; p3 = tt;
  }
  const s = p3, l = p2, c = p1, u = p0;
  const d = Buffer.alloc(16);
  d[0] = s>>>24;  d[1] = (s>>>16)&255; d[2] = (s>>>8)&255; d[3] = 255&s;
  d[4] = l>>>24;  d[5] = (l>>>16)&255; d[6] = (l>>>8)&255; d[7] = 255&l;
  d[8] = c>>>24;  d[9] = (c>>>16)&255; d[10]=(c>>>8)&255;  d[11]=255&c;
  d[12]= u>>>24;  d[13]=(u>>>16)&255;  d[14]=(u>>>8)&255;  d[15]=255&u;
  return d;
}
function sm4EncryptECB(keyHex, plainStr) {
  const key = Buffer.from(keyHex, 'hex');
  if (key.length !== 16) throw new Error('SM4 key must be 16 bytes');
  const plain = Buffer.from(plainStr, 'utf8');
  const padLen = 16 - (plain.length % 16);
  const padded = Buffer.concat([plain, Buffer.alloc(padLen, padLen)]);
  const out = Buffer.alloc(padded.length);
  for (let i=0; i<padded.length; i+=16) {
    sm4EncBlock(key, padded.subarray(i, i+16)).copy(out, i);
  }
  return out.toString('base64');
}

const FAKE_RAW_FP = [
  'aabbccdd', '11223344', '55667788', '99aabbcc',
  UA,
  'Asia/Shanghai'
].join('|');

function buildDfp() {
  const d = new Date();
  const tf = `${d.getFullYear()}${String(d.getMonth()+1).padStart(2,'0')}${String(d.getDate()).padStart(2,'0')}`;
  const sm4Key = crypto.createHash('sha256').update(`fa317cd29b|${tf}`).digest('hex').slice(0, 32);
  const ct = sm4EncryptECB(sm4Key, FAKE_RAW_FP);
  const tfBase36 = parseInt(tf, 10).toString(36);
  return `dfp=f-${tfBase36}:f-${ct}`;
}

/* ===============================
   HTTP helper
=============================== */
const _http = axios.create({
  timeout: 12000,
  httpsAgent: new https.Agent({ rejectUnauthorized: false, keepAlive: true }),
  httpAgent: new http.Agent({ keepAlive: true }),
  validateStatus: () => true
});

async function staticGet(subPath) {
  let lastErr;
  for (const host of STATIC_HOSTS) {
    const url = `${host}${STATIC_BASE_PATH}${subPath.startsWith('/')?'':'/'}${subPath}`;
    try {
      const r = await _http.get(url, {
        headers: { 'User-Agent': UA, 'Accept': 'application/json' }
      });
      if (r.status >= 200 && r.status < 300 && r.data && typeof r.data === 'object' && r.data.payload) {
        const dec = decryptResponse(Buffer.from(r.data.payload, 'hex'), PAYLOAD_VERSION);
        try { return JSON.parse(dec.toString('utf8')); } catch { return dec.toString('utf8'); }
      }
      lastErr = new Error(`status=${r.status} body=${typeof r.data}`);
    } catch (e) { lastErr = e; }
  }
  throw new Error(`staticGet failed: ${lastErr?.message || 'unknown'}`);
}

async function apiPost(path, body, authToken) {
  const url = `${SITE_BASE}${path}`;
  const enc = encryptRequest(Buffer.from(JSON.stringify(body || {}), 'utf8'), PAYLOAD_VERSION);
  const headers = {
    'Content-Type': 'text/plain',
    'X-Payload-Version': String(PAYLOAD_VERSION),
    'User-Agent': UA,
    'Origin': SITE_BASE,
    'Referer': `${SITE_BASE}/`,
    'Accept': 'application/json',
    'Cookie': buildDfp()
  };
  if (authToken) headers['Authorization'] = `Bearer ${authToken}`;
  const r = await _http.post(url, enc.toString('hex'), { headers });
  if (r.data && typeof r.data === 'object' && r.data.payload) {
    const dec = decryptResponse(Buffer.from(r.data.payload, 'hex'), PAYLOAD_VERSION);
    try { return JSON.parse(dec.toString('utf8')); } catch { return dec.toString('utf8'); }
  }
  return r.data;
}

/* ===============================
   META
=============================== */
const META = {
  key: 'TingYoufm',
  name: '[听]听友 FM',
  type: 4,
  api: '/video/TingYouFm',
  searchable: 0,
  quickSearch: 0,
  filterable: 1
};

const HOME_TYPES = [
  { type_id: '46', type_name: '玄幻奇幻' },
  { type_id: '11', type_name: '武侠小说' },
  { type_id: '14', type_name: '恐怖惊悚' },
  { type_id: '15', type_name: '历史军事' },
  { type_id: '17', type_name: '官场商战' },
  { type_id: '19', type_name: '言情通俗' },
  { type_id: '21', type_name: '相声小品' },
  { type_id:  '9', type_name: '百家讲坛' }
];

const SORT_FILTER = {
  key: 'sort', name: '排序', init: 'comprehensive',
  value: [
    { n: '综合排序', v: 'comprehensive' },
    { n: '播放最多', v: 'popular' },
    { n: '最近更新', v: 'updated' },
    { n: '最新发布', v: 'new' }
  ]
};
const STATUS_FILTER = {
  key: 'status', name: '状态', init: '',
  value: [
    { n: '全部', v: '' },
    { n: '已完结', v: '0' },
    { n: '连载中', v: '1' }
  ]
};

function buildHomeMeta() {
  const classes = HOME_TYPES.map(t => ({ type_id: t.type_id, type_name: t.type_name }));
  const filters = {};
  for (const t of HOME_TYPES) filters[t.type_id] = [SORT_FILTER, STATUS_FILTER];
  return { classes, filters };
}

function mapAlbumToVod(a) {
  if (!a) return null;
  const remarkParts = [];
  if (a.author) remarkParts.push(a.author);
  if (typeof a.count === 'number') remarkParts.push(`${a.count}集`);
  if (a.status === 1) remarkParts.push('连载中');
  else if (a.status === 0) remarkParts.push('已完结');
  return {
    vod_id: String(a.id),
    vod_name: a.title || '',
    vod_pic: a.cover_url || '',
    vod_remarks: remarkParts.filter(Boolean).join(' | ')
  };
}

async function getHome() {
  try {
    const home = await staticGet('/homepage');
    const list = [];
    if (Array.isArray(home?.recommends)) {
      for (const a of home.recommends) {
        const v = mapAlbumToVod(a);
        if (v) list.push(v);
      }
    }
    if (Array.isArray(home?.albums)) {
      for (const a of home.albums) {
        const v = mapAlbumToVod(a);
        if (v) list.push(v);
      }
    }
    const seen = new Set();
    return list.filter(v => {
      if (seen.has(v.vod_id)) return false;
      seen.add(v.vod_id); return true;
    });
  } catch (e) {
    log.error?.('[TingYouFM] getHome err: ' + e.message);
    return [];
  }
}

async function getCategory(typeId, page = 1, filters = {}) {
  try {
    const sort = (filters && typeof filters.sort === 'string' && filters.sort) ? filters.sort : 'comprehensive';
    const status = (filters && typeof filters.status === 'string') ? filters.status : '';
    const parts = [];
    if (typeId && /^\d+$/.test(String(typeId))) {
      parts.push('types', String(typeId));
    } else {
      parts.push('album_list');
    }
    if (status !== '') parts.push(String(status));
    parts.push(sort, `p${page}`);
    const subPath = '/' + parts.join('/');
    const data = await staticGet(subPath);
    const arr = Array.isArray(data?.data) ? data.data : [];
    const list = arr.map(mapAlbumToVod).filter(Boolean);
    const pages = Number(data?.pages || 1);
    return {
      page: page,
      pagecount: pages > 0 ? pages : 1,
      limit: list.length,
      total: list.length,
      list: list
    };
  } catch (e) {
    log.error?.('[TingYouFM] getCategory err: ' + e.message);
    return { page, pagecount: 1, limit: 0, total: 0, list: [] };
  }
}

async function getDetail(albumId) {
  try {
    const idStr = String(albumId).trim();
    if (!/^\d+$/.test(idStr)) return null;
    const [info, ch] = await Promise.all([
      staticGet(`/album_info/${idStr}`).catch(() => null),
      staticGet(`/album_chapters/${idStr}`).catch(() => null)
    ]);
    if (!info) return null;

    const chapters = Array.isArray(ch?.chapters) ? ch.chapters : [];
    const playUrl = chapters
      .map(c => {
        const idx = Number(c.index);
        if (!Number.isFinite(idx) || idx <= 0) return null;
        const title = String(c.title || `第${idx}集`).replace(/[#$|]/g, ' ');
        return `${title}$${idStr}|${idx}`;
      })
      .filter(Boolean)
      .join('#');

    const remarkParts = [];
    if (typeof info.count === 'number') remarkParts.push(`${info.count}集`);
    if (info.status === 1) remarkParts.push('连载中');
    else if (info.status === 0) remarkParts.push('已完结');
    if (info.type) remarkParts.push(info.type);

    return {
      vod_id: idStr,
      vod_name: info.title || '',
      vod_pic: info.cover_url || '',
      vod_remarks: remarkParts.filter(Boolean).join(' | '),
      type_name: info.type || info.cat || '',
      vod_year: '',
      vod_area: '',
      vod_lang: '',
      vod_actor: info.teller || '',
      vod_director: info.author || '',
      vod_content: String(info.synopsis || '').trim(),
      vod_play_from: META.name,
      vod_play_url: playUrl
    };
  } catch (e) {
    log.error?.('[TingYouFM] getDetail err: ' + e.message);
    return null;
  }
}

async function getPlay(playStr) {
  const errOut = (msg) => ({ parse: 0, url: '', error: String(msg || 'play failed') });
  try {
    if (!playStr || typeof playStr !== 'string') return errOut('empty play arg');
    const m = playStr.match(/^(\d+)\|(\d+)$/);
    if (!m) return errOut(`bad play arg: ${playStr}`);
    const albumId = Number(m[1]);
    const chapterIdx = Number(m[2]);

    const guest = await apiPost('/api/guest', {});
    if (!guest || !guest.auth_token) {
      return errOut(`guest failed: ${JSON.stringify(guest).slice(0, 200)}`);
    }
    const token = await apiPost('/api/play_token',
      { album_id: albumId, chapter_idx: chapterIdx },
      guest.auth_token
    );
    const audio = token && (token.play_url || token.url);
    if (!audio) {
      return errOut(`play_token failed: ${JSON.stringify(token).slice(0, 300)}`);
    }
    return {
      parse: 0,
      url: audio,
      header: {
        'User-Agent': UA,
        'Referer': `${SITE_BASE}/`
      }
    };
  } catch (e) {
    return errOut(e?.message || e);
  }
}

module.exports = async (app, opt) => {
  log = app.log || console;

  app.get(META.api, async (req) => {
    try {
      const { ids, play, t, pg, ext } = req.query || {};
      const page = parseInt(pg) || 1;

      if (play) {
        return await getPlay(String(play));
      }
      if (ids) {
        const detail = await getDetail(String(ids));
        return { list: detail ? [detail] : [] };
      }
      if (t) {
        let filters = {};
        if (ext) {
          try { filters = JSON.parse(Buffer.from(String(ext), 'base64').toString('utf8')); }
          catch (_) { filters = {}; }
        }
        return await getCategory(String(t), page, filters || {});
      }

      const meta = buildHomeMeta();
      const list = await getHome();
      return {
        class: meta.classes,
        filters: meta.filters,
        list: list
      };
    } catch (e) {
      return { error: e?.message || String(e) };
    }
  });

  opt.sites.push(META);
};

module.exports.META = META;