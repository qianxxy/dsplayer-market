/**
 * 七猫短剧 (qimao) — T4 插件
 */
"use strict";
const crypto = require("node:crypto");
const axios = require("axios");

// ============================================================================
// 请求解码器 (v2.<keyid>.<b64ciphertext> → AES-128-CBC key||iv)
// 下面的代码块从混淆后的 index.js 中原样提取, 内部符号 (D6/cs/lj/dj 等)
// 仅在模块作用域内有效, 给下面 decryptV2() 使用。
// ============================================================================
/* Am/pj interop imports unused - stripped */var cs=D6;(function(e,t){let n=D6,x=e();for(;;)try{if(parseInt(n(320,"!xmx"))/1+parseInt(n(327,"[6W3"))/2+-parseInt(n(439,"iL)C"))/3+parseInt(n(433,"9SsE"))/4+parseInt(n(379,"#4N!"))/5+-parseInt(n(485,"DF$g"))/6*(-parseInt(n(461,"2vhn"))/7)+parseInt(n(339,"4%fN"))/8*(-parseInt(n(454,"!xmx"))/9)===t)break;x.push(x.shift())}catch{x.push(x.shift())}})(lj,-726893*1+-120*9138+-4*-641008);var vPt=cs(310,"UEHg"),Fx0=[104,2601+2537*-1,-6609+-6679*-1,166,3737*-1+3*1271+114,168,143,15224+7547*-2,353*-26+7+324*29,4223+-567*7,1*-9659+-2*3943+17796,217,-1761*-1+-723+-2*421,-8145+8179*1,-7750+-2*2213+-11*-1111,1698*-1+487*16+-6034,4*-749+6978+-3953,-3254*-1+6365+-9599,103,-5993*1+1*4171+1927],IPt=[134,7*-271+-4*2468+11952,-9460*1+-1*2978+-1811*-7,-1*-9259+2695+-11759,-400+-1*-6186+-1844*3,-1*-617+-3009*1+2426,-9702+2*-1154+12070,-1*-4376+-4556+190,-5605+-1*7329+-4*-3246,-2*-4663+7777+-16986,77],CPt=[5283*-1+4528*1+985,9615+-8161*-1+-17593,415*1+-1555+1283,-3*3329+1*-914+11064,183],TPt=[1286*1+-1406+318,-4424+-1*-4607,9219*1+2496+-11543,129,-7154+16*463,504+9769*1+-10170,1303+-2*4877+-3*-2857,-5991*-1+7223+1*-13181,-10*898+1729*5+-429*-1,-356*-15+3*1697+519*-20,-768+-1*3305+-1*-4177,-5947+-362*6+8144,2063+-1829*1],RPt=[[cs(440,"s1Al")+cs(409,"dVBP"),49],-3658+-767*-10+-4*1003,[cs(456,"j8ZR")+cs(319,"1uTM")+"ac",10*-944+10*412+1348*4],1,[cs(459,"%$4z")+cs(377,"gcac")+cs(432,"dVBP"),-4414*2+2113+1362*5],4049*-1+-182+4233,[cs(441,"v#9S")+cs(370,"FGDP")+cs(447,"Z&O6"),-2343+-1*287+2748],1844+-7*263,[cs(407,"2vhn"),-463*18+1938+-6537*-1]];function D6(e,t){e=e-(-7683+7*-655+739*17);let n=lj(),x=n[e];if(D6.zSAUtR===void 0){var c=function(k){let E="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=",w="",I="";for(let T=0,B,N,P=0;N=k.charAt(P++);~N&&(B=T%4?B*64+N:N,T++%4)?w+=String.fromCharCode(255&B>>(-2*T&6)):0)N=E.indexOf(N);for(let T=0,B=w.length;T<B;T++)I+="%"+("00"+w.charCodeAt(T).toString(16)).slice(-2);return decodeURIComponent(I)};let g=function(k,E){let w=[],I=0,T,B="";k=c(k);let N;for(N=0;N<256;N++)w[N]=N;for(N=0;N<256;N++)I=(I+w[N]+E.charCodeAt(N%E.length))%256,T=w[N],w[N]=w[I],w[I]=T;N=0,I=0;for(let P=0;P<k.length;P++)N=(N+1)%256,I=(I+w[N])%256,T=w[N],w[N]=w[I],w[I]=T,B+=String.fromCharCode(k.charCodeAt(P)^w[(w[N]+w[I])%256]);return B};D6.pAVUwB=g,D6.WVODCV={},D6.zSAUtR=!0}let f=n[0],p=e+f,h=D6.WVODCV[p];return h?x=h:(D6.BYGeHv===void 0&&(D6.BYGeHv=!0),x=D6.pAVUwB(x,t),D6.WVODCV[p]=x),x}function BPt(e){let t=cs,n={GRfXs:function(f,p){return f(p)},hBBpD:function(f,p){return f||p},OeaSy:function(f,p){return f%p},XjKNO:function(f,p){return f!==p},uBoKa:t(343,"iL)C")},x=n[t(444,"v#9S")](String,n[t(468,"iL)C")](e,""))[t(361,"2vhn")](/\s+/g,""),c=n[t(302,"4%fN")](x[t(342,"kpSx")],-7499*-1+-3360+-4135);return n[t(392,"!xmx")](c,1*7274+-7500+226)&&(x+=vPt[t(402,"BB!n")](c)),Buffer[t(353,"dVBP")](x,n[t(303,"v#9S")])}function NPt(e){let t=cs,n={NtHRW:function(x,c){return x(c)},NhCHS:function(x,c){return x||c},NmWHw:t(300,"XZ^G")};return Buffer[t(345,"PoIh")](n[t(389,"Obxt")](String,n[t(429,"xB5)")](e,"")),n[t(406,"!xmx")])}function DPt(e,t){let n=cs,x={pKMuc:function(c,f){return c&f},KwJJp:function(c,f){return c^f},zVhwT:function(c,f){return c&f},KDrdw:function(c,f){return c+f},Psawy:function(c,f){return c*f}};return x[n(330,"pl11")](x[n(483,"8S$A")](e,x[n(337,"BiWY")](x[n(365,"xB5)")](167,x[n(398,"PoIh")](t,19)),-9082+1*2993+2*3172)),6*1546+-5281*-1+1*-14302)}function OPt(e){let t=cs,n={YGwSU:t(430,"d0hM"),ikBYv:function(h,g){return h<g},pnDvx:function(h,g){return h^g},qXnqi:function(h,g){return h&g},jCbJV:function(h,g){return h+g},XpZzF:function(h,g){return h*g},ZkLkd:t(470,"rjbH")},[x,c]=e,f=Buffer[t(414,"4cHq")](x,n[t(295,"1uTM")]),p=Buffer[t(382,"6PYp")](f[t(408,"!xmx")]);for(let h=7759*-1+-4673*2+3421*5;n[t(297,"j8ZR")](h,f[t(373,"(nQn")]);h++)p[h]=n[t(384,"t8z5")](f[h],n[t(462,"iL)C")](n[t(318,"dVBP")](c,n[t(325,"PoIh")](h,4160+1136*5+9833*-1)),255));return p[t(486,"j8ZR")](n[t(469,"9SsE")])}function PPt(e){let t=cs,n={BuqNm:function(c,f){return c%f},IAcTR:function(c,f){return c&f},ARsDC:function(c,f){return c^f},sHMzw:function(c,f){return c&f},vCYwq:function(c,f){return c+f},xfXlN:function(c,f){return c*f}},x=n[t(298,"Z&O6")](e,Fx0[t(373,"(nQn")]);return n[t(395,"rjbH")](n[t(369,"rjbH")](n[t(326,"(nQn")](Fx0[x],n[t(436,"vmKM")](n[t(306,"H!)]")](13003+349*-37,n[t(378,"%$4z")](x,13)),-327*7+2226+318)),8813+-8*1091),-456*16+-788+8339)}function cde(e,t){let n=cs,x={xgXBv:function(c,f){return c<f},oxVPu:function(c,f,p){return c(f,p)},AWyhO:function(c,f){return c&f},hKbkW:function(c,f){return c+f},yQIzu:function(c,f){return c&f},SeFjR:function(c,f){return c===f},Capci:function(c,f){return c&f},mtBAD:function(c,f){return c-f},iqnDm:function(c,f){return c(f)},FnfXN:function(c,f){return c&f},rVrfN:function(c,f){return c-f},JCHWv:function(c,f){return c*f},SJeac:function(c,f){return c&f},EsUkn:function(c,f){return c|f},LxhYH:function(c,f){return c<<f},BnaIc:function(c,f){return c>>>f},rvgxf:function(c,f){return c^f},kEVlz:function(c,f){return c|f},XSydQ:function(c,f){return c&f},oJsnV:function(c,f){return c&f},RcKbj:function(c,f){return c&f},CGqkS:function(c,f){return c|f},cqhuY:function(c,f){return c&f},qaGuy:function(c,f){return c&f},zZeWi:function(c,f){return c&f},wRhvB:function(c,f){return c^f},FsKpU:function(c,f){return c-f},eFcAQ:function(c,f){return c-f},MGbKK:function(c,f){return c===f},jxHsB:function(c,f){return c&f},VBTqL:function(c,f){return c%f},tARXP:function(c,f){return c%f},SnDJJ:function(c,f){return c===f},QiNHU:function(c,f){return c===f},ASapl:n(348,"[6W3")};for(let c=1291*-4+-5489+10653*1;x[n(478,"D1GK")](c,e[n(463,"TgVw")]);c++)switch(x[n(415,"6PYp")](DPt,e[c],c)){case 9825+-11*892:t[n(344,"XcAP")]=x[n(435,"BiWY")](x[n(371,"iUQ(")](x[n(431,"XZ^G")](t[n(400,"QUHv")]||-3*1001+-375+-3378*-1,c),t.i||19306+-7*2758),128520+-2674*-7+-81703);break;case-13*-302+-5283+1390:t.r0=x[n(448,"t8z5")](t[n(357,"6PYp")][t.i],560*14+-12*484+-1777);break;case-1*-9814+-2128+-7652:t.r1=x[n(421,"(nQn")](t.i,-1*2285+-5217+7502)?-853+6*-302+2774:x[n(367,"d0hM")](t[n(394,"!vWY")][x[n(354,"H!)]")](t.i,1031*5+-1*8227+-439*-7)],1162+-1*-8609+-9516);break;case 3422*-1+4288+831*-1:t.r2=x[n(305,"iL)C")](PPt,t.i);break;case 36:t.r3=x[n(388,"rjbH")](x[n(411,"rjbH")](x[n(376,"!vWY")](t.r0,16686+-16471*1),x[n(311,"d0hM")](-767*1+14*695+-1119*8,t.i)),-1*-3299+3422+-6466);break;case-1950+379*-1+2366:t.r4=x[n(364,"pl11")](x[n(351,"4%fN")](x[n(333,"ViyB")](t.r3,-11162+-11*-1015),x[n(420,"gcac")](t.r3,-2236+-15*262+6171)),2*2127+4362+-8361);break;case-5*-1019+6055+-11112:t.r5=x[n(399,"#H56")](~x[n(403,"v#9S")](t.r2,t.r1),2580+-2393*2+2461);break;case 2567+1*8931+-1637*7:t.r6=x[n(451,"[6W3")](x[n(358,"pl11")](t.r5,54),x[n(482,"XZ^G")](x[n(349,"BiWY")](~t.r5,255),8938+2*-845+-7047)),t.r7=x[n(438,"%$4z")](x[n(299,"6PYp")](x[n(328,"2vhn")](~t.r4,255),-1368+4806*-1+6228),x[n(396,"gDm2")](t.r4,9361+9798*-1+638));break;case-823*-1+123+-906:t[n(355,"s1Al")][t.i]=x[n(449,"pl11")](x[n(427,"UEHg")](t.r6,t.r7),-9918+-2*-3495+1*3183);break;case-1*8075+5083+3057:t[n(332,"ViyB")]=t[n(336,"TgVw")][x[n(316,"DF$g")](x[n(296,"UEHg")](t[n(362,"BB!n")][n(423,"s1Al")],-3*2309+-1628*-2+-1*-3672),t.i)]||"";break;case 10097+-10031*1:t[n(418,"2vhn")]=x[n(410,"!xmx")](parseInt,t[n(457,"Z&O6")][n(324,"XRSJ")]("0x",""),-737+1046*6+-5529);break;case-2209*1+-2632+4908:x[n(360,"Z&O6")](x[n(313,"j8ZR")](t.i,8461+-2*4519+578),6914+2*3217+-13348)?t[n(381,"gDm2")]-=11:x[n(401,"dVBP")](x[n(428,"En$S")](t.i,-509+-257*-14+1543*-2),7800+-3*2600)?t[n(323,"FGDP")]-=4:x[n(393,"s1Al")](x[n(424,"%$4z")](t.i,6),1894*2+-2*3622+3456)?t[n(443,"K8bZ")]-=-7872+-9*-863+114:x[n(321,"XZ^G")](x[n(426,"rjbH")](t.i,-1873+-1086*1+4*741),-281*23+-1717+8180)?t[n(464,"En$S")]-=3944*1+2201+6143*-1:t[n(397,"Obxt")]-=-1*1033+-4519+5555;break;case 68:t[n(338,"UEHg")]+=String[n(391,"#H56")+"de"](x[n(309,"#4N!")](t[n(381,"gDm2")],-1*7231+1418+6068));break;case 346*-17+-8387*-1+-2408:{let f=RPt[t.i++];t[n(359,"!xmx")]+=x[n(484,"PoIh")](typeof f,x[n(301,"#4N!")])?x[n(305,"iL)C")](String,t[n(375,"H!)]")][f]??""):x[n(450,"vmKM")](OPt,f);break}default:throw new Error(n(455,"dVBP")+n(329,"H!)]")+e[c]+":"+c)}return t}function dj(e){let t=cs,n={UYiTH:function(f,p){return f<=p},iwuAz:function(f,p){return f(p)},MzhTW:function(f,p){return f<p},jhpbc:function(f,p,h){return f(p,h)}};if(!e||n[t(308,"BB!n")](e[t(373,"(nQn")],9309+-3361*1+743*-8))return Buffer[t(481,"t8z5")](-1693*1+-4076*-1+-1*2383);let x=n[t(304,"En$S")](NPt,e[t(390,"QUHv")](1658*-2+1*-949+4269)),c={raw:x,out:Buffer[t(385,"H!)]")](x[t(314,"ic6k")]),i:0};for(c.i=-298*-3+-7109+6215*1;n[t(465,"En$S")](c.i,x[t(467,"4cHq")]);c.i++)n[t(416,"4%fN")](cde,IPt,c);return c[t(372,"vmKM")]}function Qx0(e){let t=cs,n={OVsuP:function(f,p){return f(p)},bcYCI:t(470,"rjbH"),tFSSy:function(f,p){return f<p},qNNJV:function(f,p){return f-p},ZNLiL:function(f,p,h){return f(p,h)}},x=n[t(477,"Obxt")](BPt,e)[t(368,"rjbH")](n[t(413,"j8ZR")]),c={parts:x[t(340,"j8ZR")]("0x"),out:"",i:0};for(c.i=0;n[t(380,"#4N!")](c.i,n[t(335,"vmKM")](c[t(422,"%$4z")][t(445,"D1GK")],-6*409+3737*-1+6192));c.i++)n[t(412,"#4N!")](cde,CPt,c);return c[t(366,"8S$A")]}function Wx0(e,t,n,x){let c=cs,f={lUAcQ:function(h,g,k){return h(g,k)}},p={args:[e,t,n,x],out:"",i:0};return f[c(386,"4%fN")](cde,TPt,p),p[c(425,"gDm2")]}function lj(){let e=["smowW6dcPZK","h8kchGOO","b8kXd8k0AW","rmkWaKFdHq","oNiuoI4","ymoRW57dNmkaW7/dHrhdQmks","EtyOo8oG","WQj7nv3cHW","k18H","cmkEcSk4DW","WP3cJrJdV8kL","zmkXjW","W4SbW5FcNCoh","r8ooW4JdMCkm","j3eukI4","FH7cGmocWPm","WOhdPCklAbK","jLGtW4jC","eNRcN3NdPG","W4/dHdxcGJldK8o5BmoBgqaD","BZe0pCoy","W5y+WOvP","ttKneSoBWRe","agJdLCkWW60uWO/dUa","tIq1jCoA","m8kjg8kkAW","B8oUW6hcQvK","WOrQWQbPBq","ifJcQSkH","mSo3W6xdKSke","tSoRW5hcPGS","gSoUWQi","W5KTWO0","fwNcU2NdNN8","smoEWOq1nG","W5/dNSkGWRyv","ASoaWOiAbq","WOnzoxhcUmo8","BSoGWQi2jG","WOpcMsS","nCkEo8k0Dq","WOnxdq3dSG","hJVdKxFdSG","k8ofWRu5vW","WP4mW5W","WPNcKCo/W6qj","v2JcGCk9W6eDWOpcQK4M","W4JdHtRcHtddK8kTFSoPcamEW60","y8kEvdT6y2WyWOzY","W5T1W47dNCoN","bmopWOegWPy","W4DyWP3dTLWOW57cMCoq","wCoMWOefjq","ECoxv8kMW4VdTYxcL8k6WRfjsa","W5TDzNFdUmo2oquzWO0","yrPbWOTBELBdUCkuWQq","vmoSW43cHGS","WPmoW44","e3WsW6jj","rSkvtd1IyG","C8osWOmhga01mgyh","WOFcVmkKsCkpfhbcW7ZcIq","af3cNhtdNW","bmk0W6hcNWe","hSo2WQi4WOW","cmkqWOf2pa","fSk3WPpdTW","fKCsW5L4","eM5rrCkzW6elbveuectcVX8","utJcHSkPWQ5bWPVdTvT2","W5bOW48ze8kGbWFdR3G","WPpdRmk3cW","W49iWPhcJG","lCofW4qpqGWKn2vx","qcNcJSoGWQW","WOzPW5KZrvD2c2i","pCk6amoNWPe","WPxdISkZuGNdHW","jGZdQa","bqpdRvldQq","EX0Bmmof","kK/cQ8kRWP5V","jmkGlmoMWRW","WQhcNK7dMMe","nmkRd8ou","kSkikcaA","CcTlBNXeqchdSbZcT8o6","WP4uW5pdGW","W4awWRu6yW","WR8AW63dRwO","WQSRWPBdN8kVmG1zWQ/dNSksWRu","rCksowddGG","uSkxEHHG","W7SCWO0uqW","zCoKW7VdJmkWWObe","ggdcUwhdIq","WP7cKmoUW6ei","amktdGuj","W4OBW7JcOSoR","FYtcHLNcRmojW7XOB8oaamkJ","WPjMWQPEvSo9wWy","s8kwWQvEW68","WPfdbJRdOq","WO9IWRTZuG","WQhdUmk0mCkh","d8oSW7JdOmkB","WPNcV8oL","DmoZW4ZcShK","A8oMW4dcLXe","iwWBW7fB","iq7dSeFdHa","jCktamosWPu","DmkJaCkIuq","dCkBbmkOrW","WQFdKmklxZq","DSobW53cO3W","W4K4wey","WRWQW6ZdGK4","z8ooW5ZcPgC","WOXXWRfzzG","waiUW77cR8kL","agVdKmk5W64uWOJcQuvaDG1HlW","dwBdUHRdJG","WOhdJmkgj8kd","wrRcGmodWO4","iSkWW6fRWO7dU8ooo0hcVq","ggLvqSkyW6fOyvOeaJC","WQlcTmozW4uu","FSk0WRXQW47dSa","W7bRW4i","dCkWWPBdUCooW7Lt","W4mcW6ZcKmo4","W43dQCkvWPGe","uSoNW6qRDcNdQtFdV8ktyKBdKG","W5qPWOGLEa","BCkepCo1","dSkLW4NcVqS","fwrAq8kxW6SiqMCUoXxcKW","WQa2W7uG","WPWVW68nWO4","omkilsWC","bSojWOi2WRC","WONdJSkVqq4","W6b0W5/dGSo8","WPTWeq","hmoOW6NcIINcQ3a","WPv5WPvdua","WQ3dT8kDg8km","W40sW5KDkmoW","lSkdhCoZW47dSq","WO8hWPtcVCoB","W70aW5NcHW","W4dcUSocBX3cGCo8e2mk","BSkbk8kHArqjvwNcTW","dCkGWRP4i2S","W4HbW7ZdL8oc","W5FcRCk2gSkAtwDbW67cHW","yCoWW7tcRWy","wtTUF2y","vsVcJCoK","B8kugSkuza","WObjiW","aeGUW79R","l8oUW4q","jSk9W73cRdK","tIKx","WQ7dISkNnmkH","W4u9WPa8qeD3","WOldQmkqFW8","EmouFhTmaCoPm1iRW6P6xa","lCkKW6hcQqS","lSoPWOqvCW","jmkrma","WRuiW5tdTLe","nCkWoSkyv8kqWRfC","amkngSkOzG","W7GUW4ZcJmo/mX1mWQhdLq","lmoRhfip","gmoYWRG","W6ddNSkiWRSZW4u","rXmHW6VcR8k+W5yYc8kg","y8ksp8kM","mxu0emke","B8kjWOzjm8kErg0yW4y","ySohWQGcoa","aCkyWPtdTI3dJc/cUgtcV09ZWPC","qCoMW77cK2W","WOlcMti","pmoJW5/dRCks","DCkstqHQlCo1gSoEtmkLWP/dLW","cwlcKxJdKG","y8kmnmk6qW"];return lj=function(){return e},lj()}

function decryptV2(body) {
  const text = String(body || "");
  if (!text.startsWith("v2.")) return text;
  const parts = text.split(".");
  if (parts.length < 3) return text;
  const raw = dj(parts[1]);
  if (!raw || raw.length < 32) throw new Error("漫剧解密失败: key/iv 无效");
  const dc = crypto.createDecipheriv("aes-128-cbc", raw.subarray(0, 16), raw.subarray(16, 32));
  return Buffer.concat([dc.update(Buffer.from(parts[2], "base64")), dc.final()]).toString("utf8");
}

// ---- 通用请求/工具 ----
const API_BASE = "https://djapi.999888456.xyz";
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36";

// 上游已启用 HMAC-SHA256 请求签名, 未签名的请求会被统一回一条"请更新到唐三最新版"。
// 签名串 = METHOD + "\n" + pathname + "\n" + 排序后的 query + "\n" + 毫秒时间戳 + "\n" + 随机 nonce + "\n" + client
const SIGN_CLIENT = "20260916";
const SIGN_SECRET = "c6f2a9e7d1b84c03f5a6719e2d8b0c47a13f6e9d52c8b7a4061d3e9f75b2c8a1";

function signHeaders(url, method = "GET") {
  const u = new URL(String(url));
  const params = [];
  for (const [k, v] of u.searchParams.entries()) {
    if (k !== "__h") params.push([k, v]);
  }
  params.sort((a, b) => (a[0] === b[0] ? (a[1] === b[1] ? 0 : a[1] < b[1] ? -1 : 1) : a[0] < b[0] ? -1 : 1));
  const query = params.map(([k, v]) => `${k}=${v}`).join("&");
  const time = String(Date.now());
  const nonce = crypto.randomBytes(8).toString("hex");
  const payload = [String(method).toUpperCase(), u.pathname, query, time, nonce, SIGN_CLIENT].join("\n");
  const sign = crypto.createHmac("sha256", SIGN_SECRET).update(payload, "utf8").digest("hex");
  return {
    "User-Agent": UA,
    "X-Huolong-Client": SIGN_CLIENT,
    "X-Huolong-Time": time,
    "X-Huolong-Nonce": nonce,
    "X-Huolong-Sign": sign,
  };
}

async function apiFetch(urlPath) {
  const url = `${API_BASE}/api/qimao${urlPath}`;
  const res = await axios.get(url, {
    headers: signHeaders(url),
    responseType: "text",
    transformResponse: [(x) => x],
    timeout: 30000,
    family: 4,
  });
  return JSON.parse(decryptV2(String(res.data || "")));
}

function toStr(v, fallback = "") {
  return v == null || v === "" ? String(fallback || "") : String(v);
}

function parseVodList(items) {
  return (Array.isArray(items) ? items : [])
    .map((it) => {
      const id = toStr(it && it.vod_id);
      const name = toStr(it && it.vod_name);
      if (!id || !name) return null;
      const card = {
        vod_id: id,
        vod_name: name,
        vod_pic: toStr(it && it.vod_pic),
        vod_remarks: toStr(it && it.vod_remarks),
      };
      if ((it && it.vod_tag === "folder") || id.startsWith("rank_folder:")) {
        card.vod_tag = "folder";
        card.style = { type: "list" };
      }
      return card;
    })
    .filter(Boolean);
}

function decodeExt(ext) {
  if (!ext) return {};
  try {
    return JSON.parse(Buffer.from(String(ext), "base64").toString("utf8")) || {};
  } catch { return {}; }
}

async function home() {
  const w = await apiFetch("/home?filter=1");
  const out = {
    class: Array.isArray(w.class) ? w.class : [],
    filters: w.filters || {},
  };
  if (Array.isArray(w.list)) out.list = parseVodList(w.list);
  return out;
}

function buildCategoryUrl(cateId, page, ext) {
  const params = new URLSearchParams({ tid: cateId, pg: String(page) });
  for (const [k, v] of Object.entries(ext || {})) {
    if (k === "cateId" || v === undefined || v === null || v === "") continue;
    params.set(k, String(v));
  }
  return `/category?${params.toString()}`;
}

async function category(id, page, ext) {
  const cateId = toStr(ext.cateId, id);
  const pg = Number.parseInt(page, 10) > 0 ? Number.parseInt(page, 10) : 1;
  const resp = await apiFetch(buildCategoryUrl(cateId, pg, ext));
  return {
    page: pg,
    pagecount: 9999,
    limit: 26,
    total: 9999,
    list: parseVodList(resp.list || []),
  };
}

async function detail(idList) {
  const list = [];
  for (const rawId of idList) {
    const id = toStr(rawId);
    if (!id) continue;
    const resp = await apiFetch(`/detail?id=${encodeURIComponent(id)}`);
    const v = resp && resp.list && resp.list[0];
    if (!v) continue;
    list.push({
      vod_id: id,
      vod_name: toStr(v.vod_name),
      vod_pic: toStr(v.vod_pic),
      vod_remarks: toStr(v.vod_remarks),
      type_name: toStr(v.type_name),
      vod_content: toStr(v.vod_content),
      vod_play_from: toStr(v.vod_play_from, "播放"),
      vod_play_url: toStr(v.vod_play_url),
    });
  }
  return { list };
}

async function play(id) {
  // directPlay: vod_play_url 内部 id 已是可播放直链
  return { parse: 0, url: id, extra: { nodanmu: true } };
}

async function search(wd, pg) {
  const kw = toStr(wd).trim();
  if (!kw) return { list: [] };
  const page = Number.parseInt(pg, 10) > 0 ? Number.parseInt(pg, 10) : 1;
  const resp = await apiFetch(`/search?wd=${encodeURIComponent(kw)}&pg=${page}`);
  const list = parseVodList((resp && Array.isArray(resp.list) ? resp.list : []));
  const pageLimit = 26;
  const looksFull = list.length >= pageLimit;
  return {
    parse: 0,
    jx: 0,
    page,
    limit: pageLimit,
    // 上游 pagecount/total 是 Long.MAX_VALUE, 这里按当前页收敛
    pagecount: looksFull ? page + 1 : page,
    total: looksFull ? (page + 1) * pageLimit : (page - 1) * pageLimit + list.length,
    list,
  };
}

const meta = {
  key: "manjuqimao",
  name: "[短]七猫短剧",
  type: 4,
  api: "/video/manjuqimao",
  searchable: 1,
  quickSearch: 1,
  filterable: 1,
  changeable: 0,
};

module.exports = async (app, opt) => {
  app.get(meta.api, async (req) => {
    const q = req.query || {};
    const { ac, t, pg, wd, play: playId, ids, ext } = q;
    const filters = decodeExt(ext);
    try {
      if (playId) return await play(playId);
      if (wd) return await search(wd, pg);
      if (ids) return await detail([String(ids)]);
      if (t) return await category(t, pg || "1", filters);
      return await home(req);
    } catch (e) {
      app.log && app.log.error && app.log.error(`[漫剧|小猫] ${e && e.message || e}`);
      return { list: [] };
    }
  });

  opt.sites.push(meta);
};
