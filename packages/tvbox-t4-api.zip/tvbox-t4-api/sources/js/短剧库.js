/**
 * 短剧库（juku）聚合源 —— 不夜T4（Node）JS 插件版
 *
 * 与 sources/短剧/短剧库.py（Python T4API 版）功能一一对应：
 *   分类：红果 / 黄果 / 黄豆（各带「榜单」「题材」筛选）+ 剧库工具（4 张动作卡）
 *   剧库工具卡片：点了直接弹「执行结果」窗，不跳详情页
 *     （剧库统计 / 更新剧库 / 追剧清单 / 下载任务）
 *
 * 数据全部来自手机上的「短剧库」服务（juku，默认 http://127.0.0.1:8998）：
 *   本插件不做站点解析，剧库/榜单/搜索/分集/播放直链全部由服务端给出。
 *
 * 实测契约：
 *   GET  /api/ui/viewer                 第 1 次只下发 Cookie（{ready:false}），再调一次才给 id
 *   GET  /api/ui/dramas[?revision=0]    剧库快照 {data,total,hasMore,loading,loadingSource,revision}
 *   GET  /api/ui/rankings?board=&page=  榜单 {items:[{rank,drama}]}
 *   GET  /api/ui/search?q=              联网搜索 {data,total,limited,saved,warning}
 *   GET  /api/ui/following /api/ui/tasks 追剧清单 / 下载任务
 *   POST /api/ui/account/login          {username,password}，必须带 X-Juku-Viewer 头
 *   POST /api/emby/export               {dramaId,baseUrl} → zip（Season 01/S01E0NN.strm）
 *                                       每条 .strm = 一条带 token 的 m3u8 直链（免 cookie 播放）
 *   请求头：X-Juku-Viewer / X-Juku-Sources / X-Juku-Online-Only
 *
 * 装法：把本文件丢进 vod-routes/routes/ 后重启不夜T4服务（或按其热加载规则等它自动生效）。
 */
"use strict";
const zlib = require("node:zlib");
const axios = require("axios");

// ── 可调配置 ────────────────────────────────────────────────────────────
const JUKU_HOSTS = ["http://127.0.0.1:8998", "http://192.168.0.5:8998"]; // 按顺序探测可用地址
const JUKU_USER = "admin"; // ← 内置登录账号
const JUKU_PASS = "1234567890"; // ← 内置登录密码
const JUKU_AUTO_LOGIN = true; // 启动即登录 + 掉登录自动重登（纯后台保活，界面无登录入口）
// 播放/封面地址里给客户端用的服务地址；留空 = 用实际探测到的地址（同一台手机就是 127.0.0.1:8998）
// 壳子跑在另一台设备（电视盒子）上时，改成 "http://192.168.0.5:8998"
const JUKU_PUBLIC = "";
// 动作卡地址用的本服务地址；留空 = 自动用请求里的 Host（壳子怎么连进来的就怎么回）
const T4_BASE = "";
const PAGE_SIZE = 24; // 剧库每页条数
const LIB_TTL = 180; // 剧库快照缓存（秒）
const LOGIN_TTL = 1800; // 登录态多久后自动重新登录（秒）
const WARM_PLAY = true; // 详情页预热第 1 集，点播放时更快出画面
const WARM_MAX_CONCURRENT = 1; // 同时最多几个预热在跑（预热占服务端播放会话名额，别调大）

const UA =
  "Mozilla/5.0 (Linux; Android 12; TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36";

const SRC_LABEL = { hongguo: "红果", huangguo: "黄果", huangdou: "黄豆" };
const SRC_ORDER = ["hongguo", "huangguo", "huangdou"];
// 服务端 source 字段 → 三个分类（与剧库网页 sourceKey 口径一致）
const SRC_KEYS = {
  hongguo: ["hongguo", "hongguoduanju.com"],
  huangguo: ["huangguo", "huangguoai", "cloudfront", "huangguo-video", "huangguo.video", "api"],
  huangdou: ["huangdou", "tideember.cc", "xqjurgek.top"],
};
const BOARDS = {
  hongguo: [
    ["总热播榜", "hongguo-hot"],
    ["真人剧榜", "hongguo-real"],
    ["漫剧榜", "hongguo-comic"],
    ["AI剧榜", "hongguo-ai"],
  ],
  huangguo: [
    ["热播榜", "huangguo-hot"],
    ["推荐榜", "huangguo-recommend"],
    ["潜力榜", "huangguo-potential"],
  ],
  huangdou: [
    ["总榜", "huangdou-all"],
    ["魔改榜", "huangdou-mogai"],
    ["搜索榜", "huangdou-search"],
    ["收藏榜", "huangdou-favorite"],
    ["完结榜", "huangdou-finish"],
  ],
};
const REAUTH_CODES = new Set([
  "viewer_required",
  "viewer_changed",
  "login_required",
  "password_change_required",
  "sources_changed",
  "permissions_changed",
]);

const meta = {
  key: "juku",
  name: "短剧库",
  type: 4,
  api: "/video/juku",
  searchable: 1,
  quickSearch: 1,
  filterable: 1,
  changeable: 0,
};

// ── 运行时状态 ─────────────────────────────────────────────────────────
const st = {
  hosts: JUKU_HOSTS.slice(),
  host: "",
  cookie: "",
  viewer: {},
  viewerAt: 0,
  account: {},
  loginAt: 0,
  loginPromise: null,
  lib: [],
  libTs: 0,
  lastError: "",
  warming: 0,
  autoDone: false,
};

const http = axios.create({
  timeout: 60000,
  maxRedirects: 5,
  validateStatus: () => true, // 4xx 也当正常响应处理（自己判状态码）
  headers: {
    "User-Agent": UA,
    Accept: "application/json",
    "Accept-Language": "zh-CN,zh;q=0.9",
  },
  responseType: "text",
  transformResponse: [(x) => x], // 原样拿字符串，下面自己 JSON.parse
});

// 收 Cookie（服务端第一次只下发 Cookie）
function saveCookies(res) {
  const sc = res && res.headers && res.headers["set-cookie"];
  if (!sc) return;
  const jar = {};
  String(st.cookie || "")
    .split(";")
    .forEach((p) => {
      const i = p.indexOf("=");
      if (i > 0) jar[p.slice(0, i).trim()] = p.slice(i + 1).trim();
    });
  (Array.isArray(sc) ? sc : [sc]).forEach((line) => {
    const kv = String(line).split(";")[0];
    const i = kv.indexOf("=");
    if (i > 0) jar[kv.slice(0, i).trim()] = kv.slice(i + 1).trim();
  });
  st.cookie = Object.keys(jar)
    .map((k) => `${k}=${jar[k]}`)
    .join("; ");
}

function reqHeaders(extra) {
  const head = {
    "User-Agent": UA,
    Accept: "application/json",
    "Accept-Language": "zh-CN,zh;q=0.9",
  };
  if (st.cookie) head.Cookie = st.cookie;
  const vid = st.viewer && st.viewer.id;
  if (vid) {
    head["X-Juku-Viewer"] = String(vid);
    head["X-Juku-Sources"] = (st.viewer.sources || []).join(",");
    head["X-Juku-Online-Only"] = st.viewer.onlineOnly ? "true" : "false";
  }
  if (extra) Object.assign(head, extra);
  return head;
}

async function detectHost() {
  if (st.host) return st.host;
  for (const host of st.hosts) {
    try {
      const res = await http.get(`${host}/api/ui/viewer`, { headers: reqHeaders(), timeout: 8000 });
      saveCookies(res);
      if (res.status < 500) {
        st.host = host;
        return host;
      }
    } catch (e) {
      st.lastError = `${host} 不通（${(e && e.code) || (e && e.name) || "Error"}）`;
    }
  }
  st.host = st.hosts[0] || JUKU_HOSTS[0];
  return st.host;
}

function publicBase() {
  return String(JUKU_PUBLIC || st.host || JUKU_HOSTS[0]).replace(/\/+$/, "");
}

async function raw(method, path, opts = {}) {
  const host = await detectHost();
  const cfg = {
    method,
    url: host + path,
    headers: reqHeaders(opts.body != null ? { "Content-Type": "application/json" } : null),
    timeout: opts.timeout || 60000,
  };
  if (opts.params) cfg.params = opts.params;
  if (opts.body != null) cfg.data = JSON.stringify(opts.body);
  if (opts.responseType) cfg.responseType = opts.responseType;
  if (opts.responseType) delete cfg.transformResponse;
  const res = await http.request(cfg);
  saveCookies(res);
  return res;
}

function nextHost() {
  const idx = st.hosts.indexOf(st.host);
  if (idx >= 0 && idx < st.hosts.length - 1) {
    st.host = st.hosts[idx + 1];
    st.viewer = {};
    st.cookie = "";
    return st.host;
  }
  return "";
}

function parseJson(res) {
  try {
    const t = typeof res.data === "string" ? res.data : String(res.data || "");
    return t ? JSON.parse(t) : null;
  } catch (e) {
    return null;
  }
}

// 请求 + 解析 JSON；掉登录 / host 不通自动重试一次
async function jreq(method, path, opts = {}, retry = true) {
  let res;
  try {
    res = await raw(method, path, opts);
  } catch (e) {
    st.lastError = `${(e && e.code) || (e && e.name) || "Error"}: ${(e && e.message) || e}`;
    if (retry && nextHost()) return jreq(method, path, opts, false);
    return null;
  }
  const data = parseJson(res);
  if (retry && (res.status === 401 || res.status === 403 || (data && REAUTH_CODES.has(data.code)))) {
    // 掉登录自愈：无条件用内置账号重登（不要求「之前登录过」）
    await handshake(true);
    await login(true);
    return jreq(method, path, opts, false);
  }
  return data;
}

// ── 观看身份 / 账号 ────────────────────────────────────────────────────
async function handshake(force = false) {
  if (st.viewer.id && !force && Date.now() / 1000 - st.viewerAt < 1500) return st.viewer;
  let data = {};
  for (let i = 0; i < 3; i++) {
    data = (await jreq("GET", "/api/ui/viewer", { timeout: 20000 }, false)) || {};
    if (data && data.ready) break;
    await sleep(400);
  }
  if (!data || !data.ready) {
    await jreq("GET", "/api/ui/viewer", { params: { confirm: 1 }, timeout: 20000 }, false);
    await sleep(400);
    data = (await jreq("GET", "/api/ui/viewer", { timeout: 20000 }, false)) || data;
  }
  if (data && data.ready) {
    st.viewer = data;
    st.viewerAt = Date.now() / 1000;
    if (data.account) st.account = data.account;
  }
  return st.viewer;
}

async function doLogin(user, pwd, force = false) {
  if (st.account && Object.keys(st.account).length && !force && Date.now() / 1000 - st.loginAt < LOGIN_TTL) {
    return { ok: true, account: st.account, cached: true };
  }
  await handshake(true);
  if (!st.viewer.id) return { ok: false, error: st.lastError || "服务未就绪，拿不到观看身份" };
  const data =
    (await jreq(
      "POST",
      "/api/ui/account/login",
      { body: { username: String(user || JUKU_USER), password: String(pwd || JUKU_PASS) }, timeout: 30000 },
      false
    )) || {};
  if (!data.ok) {
    st.account = {};
    return { ok: false, error: data.error || "登录失败" };
  }
  st.viewer = {}; // 登录后 viewer id / 权限会变，重新握手
  st.account = data.account || {};
  st.loginAt = Date.now() / 1000;
  await handshake(true);
  return { ok: true, account: st.viewer.account || st.account };
}

// 登录串行化：并发请求同时掉登录时只登一次
function login(force = false, user, pwd) {
  if (st.loginPromise) return st.loginPromise;
  st.loginPromise = doLogin(user, pwd, force).finally(() => {
    st.loginPromise = null;
  });
  return st.loginPromise;
}

async function autoLogin() {
  try {
    await handshake(true);
    const info = await accountInfo();
    if (!info.logged) {
      const r = await login(true);
      st.autoDone = !!(r && r.ok);
    } else {
      st.autoDone = true;
    }
  } catch (e) {
    /* 静默：下次请求掉登录时还会自愈 */
  }
}

async function accountInfo() {
  await handshake();
  const acct = (st.viewer && st.viewer.account) || st.account || {};
  return {
    logged: !!acct && Object.keys(acct).length > 0,
    username: acct.username || "",
    admin: !!acct.admin,
    sources: (st.viewer && st.viewer.sources) || acct.sources || [],
    onlineOnly: !!(st.viewer && st.viewer.onlineOnly),
    ready: !!(st.viewer && st.viewer.ready),
    host: st.host || "",
  };
}

// ── 剧库 / 榜单 / 搜索 ─────────────────────────────────────────────────
async function library(refresh = false, timeout = 120000) {
  const now = Date.now() / 1000;
  if (!refresh && st.lib.length && now - st.libTs < LIB_TTL) return st.lib;
  const data = (await jreq("GET", "/api/ui/dramas", { params: { revision: 0 }, timeout })) || {};
  const items = data.data || [];
  if (items.length) {
    st.lib = items;
    st.libTs = now;
  }
  return st.lib;
}

function groupOf(drama) {
  const raw = String((drama && drama.source) || "")
    .trim()
    .toLowerCase();
  for (const g of SRC_ORDER) if (SRC_KEYS[g].indexOf(raw) >= 0) return g;
  const hint = `${(drama && drama.channelName) || ""} ${(drama && drama.id) || ""} ${
    (drama && drama.sourceId) || ""
  }`.toLowerCase();
  for (const g of SRC_ORDER) if (hint.startsWith(g) || hint.indexOf(" " + g) >= 0) return g;
  return "other";
}

function statsOf(lib) {
  const cnt = { hongguo: 0, huangguo: 0, huangdou: 0, other: 0 };
  (lib || []).forEach((d) => {
    cnt[groupOf(d)] = (cnt[groupOf(d)] || 0) + 1;
  });
  return {
    total: (lib || []).length,
    hongguo: cnt.hongguo,
    huangguo: cnt.huangguo,
    huangdou: cnt.huangdou,
    other: cnt.other,
  };
}

function catsOf(group, lib, top = 30) {
  const cnt = new Map();
  (lib || []).forEach((d) => {
    if (groupOf(d) !== group) return;
    const name = String((d && d.categoryName) || "").trim();
    if (name) cnt.set(name, (cnt.get(name) || 0) + 1);
  });
  return [...cnt.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, top)
    .map((x) => x[0]);
}

function vodOf(drama, remark = "") {
  let cover = String((drama && (drama.cover || drama.coverUrl)) || "");
  if (cover.startsWith("/")) cover = publicBase() + cover;
  const title = String((drama && (drama.title || drama.name)) || "").trim() || "未命名";
  if (!remark) {
    const bits = [SRC_LABEL[groupOf(drama)] || "其他"];
    const cat = String((drama && drama.categoryName) || "").trim();
    if (cat) bits.push(cat);
    const total = String((drama && (drama.totalEpisode || drama.chapterCount)) || "").trim();
    if (total && total !== "0" && total !== "1") bits.push(`全${total}集`);
    remark = bits.join(" · ");
  }
  return {
    vod_id: String((drama && drama.id) || ""),
    vod_name: title,
    vod_pic: cover,
    vod_remarks: remark,
  };
}

async function boardList(board, page = 1) {
  const data =
    (await jreq("GET", "/api/ui/rankings", { params: { board, page }, timeout: 60000 })) || {};
  const out = [];
  (data.items || []).forEach((it) => {
    const drama = (it && it.drama) || {};
    if (!drama || !Object.keys(drama).length) return;
    const rank = (it && it.rank) || out.length + 1;
    const heat = String(drama.heat || "").trim();
    out.push(vodOf(drama, `第${rank}名${heat ? " · " + heat : ""}`));
  });
  return out;
}

// ── 分集直链（Emby 导出 zip → 每条 .strm 一条 token 直链）───────────────
// 纯 Node 解 zip（不引第三方包）：中央目录 → 本地头 → inflateRaw
function unzipStrm(buf) {
  if (!buf || buf.length < 22 || buf.toString("latin1", 0, 2) !== "PK") throw new Error("不是有效的 zip");
  let eocd = -1;
  const from = Math.max(0, buf.length - 22 - 65535);
  for (let i = buf.length - 22; i >= from; i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) throw new Error("找不到 zip 中央目录");
  const count = buf.readUInt16LE(eocd + 10);
  let off = buf.readUInt32LE(eocd + 16);
  const rows = [];
  for (let n = 0; n < count; n++) {
    if (off + 46 > buf.length || buf.readUInt32LE(off) !== 0x02014b50) break;
    const method = buf.readUInt16LE(off + 10);
    const csize = buf.readUInt32LE(off + 20);
    const nlen = buf.readUInt16LE(off + 28);
    const elen = buf.readUInt16LE(off + 30);
    const clen = buf.readUInt16LE(off + 32);
    const lho = buf.readUInt32LE(off + 42);
    const name = buf.toString("utf8", off + 46, off + 46 + nlen);
    if (name.endsWith(".strm") && csize !== 0xffffffff && lho !== 0xffffffff) {
      const lnlen = buf.readUInt16LE(lho + 26);
      const lelen = buf.readUInt16LE(lho + 28);
      const start = lho + 30 + lnlen + lelen;
      const rawData = buf.subarray(start, start + csize);
      let text = "";
      try {
        text =
          method === 0
            ? rawData.toString("utf8")
            : zlib.inflateRawSync(rawData).toString("utf8");
      } catch (e) {
        text = "";
      }
      const m = /S(\d+)E(\d+)\.strm$/.exec(name);
      text = String(text || "").trim();
      if (text) rows.push([m ? parseInt(m[1], 10) : 0, m ? parseInt(m[2], 10) : rows.length + 1, text]);
    }
    off += 46 + nlen + elen + clen;
  }
  rows.sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  return rows.map((r) => r[2]);
}

async function episodeUrls(dramaId, timeout = 240000) {
  let res;
  try {
    res = await raw("POST", "/api/emby/export", {
      body: { dramaId: String(dramaId), baseUrl: publicBase() },
      timeout,
      responseType: "arraybuffer", // ★ 必须按二进制取，否则 zip 会被当文本解码弄坏
    });
  } catch (e) {
    return [[], `${(e && e.code) || (e && e.name) || "Error"}: ${(e && e.message) || e}`];
  }
  const buf = Buffer.isBuffer(res.data)
    ? res.data
    : Buffer.from(typeof res.data === "string" ? res.data : "", "latin1");
  if (res.status !== 200 || buf.toString("latin1", 0, 2) !== "PK") {
    const text = buf.toString("utf8");
    let msg = "";
    try {
      msg = (JSON.parse(text) || {}).error || "";
    } catch (e) {
      msg = text.slice(0, 120);
    }
    return [[], msg || `HTTP ${res.status}`];
  }
  try {
    return [unzipStrm(buf), ""];
  } catch (e) {
    return [[], `导出包解析失败：${(e && e.message) || e}`];
  }
}

function warm(url) {
  if (!WARM_PLAY || !url) return;
  if (st.warming >= WARM_MAX_CONCURRENT) return; // 已有预热在跑，这次跳过（防连点详情页占满会话名额）
  st.warming++;
  (async () => {
    try {
      const res = await http.get(url, {
        responseType: "stream",
        timeout: 240000,
        headers: { "User-Agent": UA, Referer: publicBase() + "/" },
      });
      const stream = res.data;
      if (stream && typeof stream.on === "function") {
        await new Promise((resolve) => {
          const done = () => {
            try {
              stream.destroy();
            } catch (e) {}
            resolve();
          };
          stream.once("data", done);
          stream.once("error", done);
          stream.once("end", done);
          setTimeout(done, 15000);
        });
      }
    } catch (e) {
      /* 预热失败不影响播放 */
    } finally {
      st.warming--;
    }
  })();
}

// ── 首页 / 一级 ────────────────────────────────────────────────────────
async function home() {
  const classes = SRC_ORDER.map((g) => ({ type_id: "src:" + g, type_name: SRC_LABEL[g] }));
  classes.push({ type_id: "account", type_name: "剧库工具" });
  const filters = {};
  try {
    const lib = await library(false, 60000);
    SRC_ORDER.forEach((g) => {
      const views = [{ n: "剧库全部", v: "lib" }].concat(
        BOARDS[g].map(([n, b]) => ({ n, v: b }))
      );
      const cats = [{ n: "全部", v: "" }].concat(catsOf(g, lib).map((c) => ({ n: c, v: "cat:" + c })));
      filters["src:" + g] = [
        { key: "view", name: "榜单", value: views },
        { key: "cat", name: "题材", value: cats },
      ];
    });
  } catch (e) {
    st.lastError = (e && e.message) || String(e);
  }
  return { class: classes, filters, list: await homeVideo() };
}

async function homeVideo() {
  try {
    let items = await boardList("hongguo-hot", 1);
    if (!items.length) {
      const lib = await library(false, 60000);
      items = lib.filter((d) => groupOf(d) === "hongguo").map((d) => vodOf(d));
    }
    return items.slice(0, 30);
  } catch (e) {
    return [];
  }
}

function emptyPage(page) {
  return { list: [], page, pagecount: 1, limit: PAGE_SIZE, total: 0 };
}

function decodeExt(ext) {
  if (!ext) return {};
  if (typeof ext === "object") return ext;
  const text = String(ext).trim();
  if (!text) return {};
  if (text.startsWith("{")) {
    try {
      return JSON.parse(text) || {};
    } catch (e) {
      /* 继续按 base64 试 */
    }
  }
  for (const s of [text, text.replace(/-/g, "+").replace(/_/g, "/")]) {
    try {
      const d = JSON.parse(Buffer.from(s, "base64").toString("utf8"));
      if (d && typeof d === "object") return d;
    } catch (e) {
      /* 换一种编码再试 */
    }
  }
  return {};
}

async function category(tid, pg, filters) {
  const page = Math.max(1, parseInt(pg || "1", 10) || 1);
  const ext = filters || {};
  const t = String(tid || "");
  try {
    if (t === "account") return accountPage();
    const group = t.indexOf(":") >= 0 ? t.split(":", 2)[1] : t;
    if (!SRC_LABEL[group]) return emptyPage(page);
    let view = String(ext.view || "lib");
    let cat = String(ext.cat || "");
    if (cat.startsWith("cat:")) cat = cat.slice(4);
    const boards = {};
    BOARDS[group].forEach(([n, b]) => {
      boards[b] = n;
    });
    if (boards[view]) {
      const items = await boardList(view, page);
      return {
        list: items,
        page,
        pagecount: items.length >= 20 ? page + 1 : page,
        limit: items.length || 20,
        total: items.length >= 20 ? page * 20 : (page - 1) * 20 + items.length,
      };
    }
    const lib = await library();
    let items = lib.filter((d) => groupOf(d) === group);
    if (cat) items = items.filter((d) => String((d && d.categoryName) || "").trim() === cat);
    const total = items.length;
    const chunk = items.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
    return {
      list: chunk.map((d) => vodOf(d)),
      page,
      pagecount: Math.max(1, Math.ceil(total / PAGE_SIZE)),
      limit: PAGE_SIZE,
      total,
    };
  } catch (e) {
    st.lastError = (e && e.message) || String(e);
    return emptyPage(page);
  }
}

// ── 二级（详情 / 剧库工具）─────────────────────────────────────────────
async function findDrama(dramaId) {
  const lib = await library(false, 90000);
  for (const d of lib) if (String(d.id) === String(dramaId)) return d;
  return {};
}

async function detail(ids) {
  const list = Array.isArray(ids) ? ids : [ids];
  const vid = String((list[0] != null ? list[0] : "") || "");
  if (vid.startsWith("acct:")) return { list: await actItems(vid, { headers: {} }) };
  try {
    const one = await detailOne(vid);
    return { list: one ? [one] : [] };
  } catch (e) {
    st.lastError = (e && e.message) || String(e);
    return { list: [] };
  }
}

async function detailOne(dramaId) {
  const drama = await findDrama(dramaId);
  const [urls, err] = await episodeUrls(dramaId);
  // 注意：这里不要调 /api/ui/playback/open 取分集标题 —— 它会在服务端创建常驻播放会话，
  // 占「同时播放数量」名额（默认上限 4，空闲 10 分钟才释放），连点几部剧就会 429。
  // 分集标题统一「第N集」即可。
  let playFrom = "";
  let playUrl = "";
  let extra = "";
  if (!urls.length) {
    extra = `\n⚠️ 取播放地址失败：${err || "未知原因"}`;
  } else {
    playFrom = `短剧库·${SRC_LABEL[groupOf(drama)] || "短剧"}`;
    playUrl = urls.map((u, i) => `第${i + 1}集$${u}`).join("#");
    warm(urls[0]);
  }
  const group = SRC_LABEL[groupOf(drama)] || "其他";
  const cat = String((drama && drama.categoryName) || "").trim();
  const total = String((drama && drama.totalEpisode) || urls.length || "").trim();
  let content = `【${group}${cat ? "·" + cat : ""}】${(drama && drama.title) || dramaId}\n分集：${
    total || "未知"
  } 集\n服务：${publicBase()}${extra}`;
  const intro = String((drama && (drama.desc || drama.intro)) || "").trim();
  if (intro) content += `\n\n简介：${intro}`;
  return {
    vod_id: String(dramaId),
    vod_name: String((drama && drama.title) || dramaId),
    vod_pic: drama && Object.keys(drama).length ? vodOf(drama).vod_pic : "",
    type_name: cat || group,
    vod_remarks: total && urls.length ? `全集 ${total} 集` : err || `共 ${urls.length} 集`,
    vod_content: content,
    vod_play_from: playFrom,
    vod_play_url: playUrl,
  };
}

// ── 剧库工具（动作卡）──────────────────────────────────────────────────
function reqBase(req) {
  if (T4_BASE) return String(T4_BASE).replace(/\/+$/, "");
  const h = (req && req.headers && (req.headers.host || req.headers.Host)) || "127.0.0.1:8887";
  // ⚠️ 别用 req.protocol：本服务的 req 不是完整 Express 请求，取它会抛
  //    "trust is not a function" → 分类页整个被 try/catch 吞成空列表。
  let proto = "http";
  try {
    const xf =
      req && req.headers && (req.headers["x-forwarded-proto"] || req.headers["X-Forwarded-Proto"]);
    if (xf) proto = String(xf).split(",")[0].trim();
  } catch (e) {
    /* 忽略 */
  }
  return `${proto}://${h}`.replace(/\/+$/, "");
}

const ACT_CARDS = [
  ["libstat", "📊 剧库统计", "红果/黄果/黄豆 各多少条"],
  ["libupdate", "🔄 更新剧库", "三个源增量刷新（1～3 分钟）"],
  ["following", "⭐ 追剧清单", "服务端追剧记录"],
  ["tasks", "⬇️ 下载任务", "服务端下载队列"],
];

function accountPage(req) {
  const base = reqBase(req);
  const list = ACT_CARDS.map(([id, name, rem]) => ({
    vod_id: id, // DS「基础动作」：壳子拿 vod_id 当动作ID 直接执行 action=<id>
    vod_name: name,
    vod_remarks: rem,
    vod_tag: "action", // ← 必须！没有它壳子会当普通影片去开详情页
    // 兼容「把 action 字段当网址 GET」的壳子（WebHTV 系）
    action: `${base}${meta.api}?ac=detail&ids=acct:${id}`,
  }));
  return { list, page: 1, pagecount: 1, limit: list.length, total: list.length };
}

// 壳子（DsPlayer/drplayer）击卡 → GET {api}?ac=action&action=<id>&value=…
// 返回 {action:{type:'msgbox'}} → 壳子弹「消息弹窗」；返回字符串 → 壳子弹提示
async function actMsg(id, req) {
  const one = (await actItems(`acct:${id}`, req))[0] || {};
  const title = one.vod_name || "剧库工具";
  const text = one.vod_remarks || one.vod_content || "完成";
  if (id === "libupdate") return text;
  return { action: { actionId: `${id}_result`, type: "msgbox", title, msg: text } };
}

function okCard(name, text) {
  // 结果卡片：壳子弹窗读 vod_name（标题）+ vod_remarks（正文）；兼写 vod_content 便于详情页查看
  return { vod_id: "acct:result", vod_name: name, vod_remarks: text, vod_content: text };
}

function srcLabel(src) {
  return SRC_LABEL[String(src || "").toLowerCase()] || src || "-";
}

async function actItems(vid, req) {
  try {
    if (vid === "acct:libstat") {
      const lib = await library(false, 60000);
      const s = statsOf(lib);
      const info = await accountInfo();
      return [
        okCard(
          "📊 剧库统计",
          `剧库共 ${s.total} 条\n  红果 ${s.hongguo}\n  黄果 ${s.huangguo}\n  黄豆 ${s.huangdou}\n  其他 ${
            s.other
          }\n\n服务：${info.host}\n在线模式：${info.onlineOnly ? "是" : "否"}`
        ),
      ];
    }
    if (vid === "acct:libupdate") {
      st.lib = [];
      st.libTs = 0;
      // 同步通知要 8～11 秒/源（壳子会当超时）→ 丢后台跑，卡片立刻出结果
      setTimeout(() => {
        SRC_ORDER.forEach((g) => {
          jreq("GET", "/api/ui/dramas", { params: { update: 1, source: g }, timeout: 60000 }).catch(
            () => {}
          );
        });
      }, 0);
      return [
        okCard(
          "🔄 更新剧库",
          "已通知服务端增量更新（红果 / 黄果 / 黄豆，后台跑 1～3 分钟）：\n  三个源：已提交\n\n过一会儿回列表刷新，或点「📊 剧库统计」看新条数。"
        ),
      ];
    }
    if (vid === "acct:following") {
      const data = (await jreq("GET", "/api/ui/following", { timeout: 60000 })) || {};
      const rows = data.data || [];
      if (!rows.length) return [okCard("⭐ 追剧清单", "追剧清单为空（可在剧库详情页追剧，或等壳子同步）")];
      return rows.slice(0, 60).map((r, i) =>
        okCard(`${i + 1}. ${r.title || r.dramaId || ""}`, `来源：${srcLabel(r.source)}`)
      );
    }
    if (vid === "acct:tasks") {
      const data = (await jreq("GET", "/api/ui/tasks", { timeout: 60000 })) || {};
      const rows = data.data || [];
      const ff = data.ffmpeg || {};
      if (!rows.length) {
        return [
          okCard(
            "⬇️ 下载任务",
            `没有下载任务。\nFFmpeg：${ff.status || "-"}（${ff.detail || ff.path || ""}）`
          ),
        ];
      }
      return rows.slice(0, 40).map((t, i) =>
        okCard(
          `${i + 1}. ${t.dramaTitle || t.title || ""} 第${t.episode || t.index || ""}集`,
          `${t.status || ""} ${t.progress || 0}%`
        )
      );
    }
  } catch (e) {
    return [okCard("❌ 执行出错", String((e && e.message) || e))];
  }
  return [okCard("剧库工具", `未知操作：${vid}`)];
}

// ── 搜索 ───────────────────────────────────────────────────────────────
async function search(wd, pg) {
  const keyword = String(wd || "").trim();
  const page = Math.max(1, parseInt(pg || "1", 10) || 1);
  if (!keyword) return { list: [], page: 1, pagecount: 1, limit: PAGE_SIZE, total: 0 };
  const rows = [];
  const seen = new Set();
  try {
    const data = (await jreq("GET", "/api/ui/search", { params: { q: keyword }, timeout: 90000 })) || {};
    (data.data || []).forEach((d) => {
      const did = String((d && d.id) || "");
      if (did && !seen.has(did)) {
        seen.add(did);
        rows.push(vodOf(d, `联网·${SRC_LABEL[groupOf(d)] || "结果"}`));
      } else if (!did) {
        rows.push(vodOf(d, "联网结果"));
      }
    });
  } catch (e) {
    st.lastError = (e && e.message) || String(e);
  }
  try {
    const low = keyword.toLowerCase();
    const lib = await library(false, 60000);
    lib.forEach((d) => {
      const did = String((d && d.id) || "");
      if (did && seen.has(did)) return;
      const blob = `${(d && (d.title || d.name)) || ""} ${(d && d.desc) || ""}`.toLowerCase();
      if (blob.indexOf(low) >= 0) {
        if (did) seen.add(did);
        rows.push(vodOf(d, `剧库·${SRC_LABEL[groupOf(d)] || "结果"}`));
      }
    });
  } catch (e) {
    st.lastError = (e && e.message) || String(e);
  }
  const total = rows.length;
  return {
    list: rows.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE),
    page,
    pagecount: Math.max(1, Math.ceil(total / PAGE_SIZE)),
    limit: PAGE_SIZE,
    total,
  };
}

// ── 播放 ───────────────────────────────────────────────────────────────
function playHeader() {
  // 直链由短剧库服务端转发（token 已带在 URL 里），这里只补常规头
  return { "User-Agent": UA, Referer: publicBase() + "/" };
}

function unb64(text) {
  for (const s of [text, String(text).replace(/-/g, "+").replace(/_/g, "/")]) {
    try {
      return Buffer.from(s, "base64").toString("utf8");
    } catch (e) {
      /* 换一种编码再试 */
    }
  }
  return "";
}

async function play(pid) {
  const target = String(pid || "");
  if (target.startsWith("jkpro|")) {
    try {
      const payload = JSON.parse(unb64(target.split("|", 2)[1]));
      return { parse: 0, jx: 0, url: payload.url || "", header: payload.header || playHeader() };
    } catch (e) {
      /* 落回普通直链 */
    }
  }
  return { parse: 0, jx: 0, url: /^https?:/i.test(target) ? target : "", header: playHeader() };
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

module.exports = async (app, opt) => {
  const log = (app && app.log && app.log.error && app.log.error.bind(app.log)) || (() => {});

  app.get(meta.api, async (req) => {
    const q = (req && req.query) || {};
    try {
      if (q.play) return await play(q.play);
      if (String(q.ac) === "action") return await actMsg(String(q.action || ""), req);
      if (q.wd) return await search(q.wd, q.pg);
      if (q.ids) {
        const ids = String(q.ids)
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean);
        return await detail(ids);
      }
      if (q.t) {
        const filters = decodeExt(q.ext || q.filter);
        if (filters && typeof filters === "object") {
          // 合并 filter 里可能直接给的键
          ["view", "cat"].forEach((k) => {
            if (q.filter && typeof q.filter === "object" && q.filter[k] != null) filters[k] = q.filter[k];
          });
        }
        if (String(q.t) === "account") return accountPage(req);
        return await category(q.t, q.pg, filters);
      }
      return await home();
    } catch (e) {
      log(`[短剧库] ${(e && e.message) || e}`);
      return { list: [] };
    }
  });

  // 注：动作卡已不再走自定义子路由（/act）——壳子击卡只会 GET 卡片里 action 字段那个
  // URL，现统一指向本源 detail 通道 `?ac=detail&ids=acct:<id>`（见 accountPage），
  // 由上面的 `if (q.ids)` 分支 → detail() → actItems() 出结果。

  opt.sites.push(meta);

  if (JUKU_AUTO_LOGIN) {
    // 启动即后台登录（不阻塞服务启动；失败静默，下次请求掉登录时自愈）
    setTimeout(() => {
      autoLogin().catch(() => {});
    }, 1500);
  }
};
