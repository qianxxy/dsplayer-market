/**
 * 🎵 DS落雪 — 洛雪音乐（lxserver）T4 源
 * ============================================================================
 * 由 drpy 源《DS落雪[听].js》移植为 vod-routes T4 JS 源（路由格式对齐 routes/guazi.js）。
 * 能力：
 *  - 首页 6 分类：排行榜 / 网易云 / 酷狗 / 酷我 / QQ / 咪咕
 *  - 筛选：排行榜（平台 + 榜单类型）、各平台歌单广场（语种/风格/场景/心情/主题/年代…）
 *  - 详情：歌单 / 榜单 / 单曲
 *  - 搜索：5 平台并发综合搜索
 *  - 播放：多音质（母带/全景声/杜比/Hi-Res/HQ无损/SQ无损/高品质/标准）+ 歌词 + 封面
 * 服务地址（host）/ 用户名 / 密码：已直接写在本脚本的 _cfg 里，不读环境变量、不读写配置文件。
 * 依赖：lxserver（http://127.0.0.1:9527，手机本机）
 * 部署：放 vod-routes/routes/ 下 → 8887 热重载自动加载。
 *
 * lxserver 契约要点（照 lxserver/server/server.js 实现而来）：
 *  - POST /api/music/url  body: {songInfo, quality, enableAutoSwitchApiSource}
 *    成功 200 → 结果对象里的 url；失败 500 → {error, attempts}；带具名用户但无有效 token → 401。
 *  - 音源（JS 音源）按用户名隔离：具名用户只能看到 owner 为自己或 owner='open' 的已启用音源；
 *    不带 x-user-name 时按 open 用户查找。⇒ 具名音源必须带 x-user-name + 有效 x-user-token。
 *  - 因此本源策略：具名用户先登录拿 token，请求先试「具名」再退「open」，并把成功的模式缓存。
 * ============================================================================
 */

const axios = require("axios");

// ==================== meta ====================
const meta = {
  key: "dsluoxue",
  name: "DS落雪",
  type: 4,
  api: "/video/dsluoxue",
  searchable: 1,
  quickSearch: 0,
  filterable: 1,
  changeable: 0,
};

// ==================== 常量 ====================
const UA = "Mozilla/5.0 (Linux; Android 12; NOH-AN01) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Mobile Safari/537.36";
const PLACEHOLDER_IMG = "https://pic.5577.com/up/2021-9/202198191219.png";
const SET_ICON = "https://pic.5577.com/up/2021-9/202198191801219.png";
const REQ_TIMEOUT = 10000; // 列表/搜索/歌词等普通请求
const URL_TIMEOUT = 12000; // /api/music/url 解析请求（服务端要调上游，给足时间）
const PLATFORMS = ["wy", "kg", "kw", "tx", "mg"];
const PLATFORM_NAME = { wy: "网易云", kg: "酷狗", kw: "酷我", tx: "QQ", mg: "咪咕" };
const QUALITY_PRIORITY = ["master", "atmos_plus", "atmos", "hires", "flac24bit", "flac", "320k", "128k"];
const QUALITY_NAME = {
  master: "母带",
  atmos_plus: "全景声",
  atmos: "杜比",
  hires: "Hi-Res",
  flac24bit: "HQ无损",
  flac: "SQ无损",
  "320k": "高品质",
  "128k": "标准",
};
const OPEN_USERS = ["default", "open", "_open"];

function ft(pairs) {
  return pairs.map(function (p) {
    return { n: p[0], v: p[1] };
  });
}

// ==================== 分类 ====================
const CLASSES = [
  { type_id: "rank", type_name: "排行榜" },
  { type_id: "wy", type_name: "网易云" },
  { type_id: "kg", type_name: "酷狗" },
  { type_id: "kw", type_name: "酷我" },
  { type_id: "tx", type_name: "QQ" },
  { type_id: "mg", type_name: "咪咕" },
];

// ==================== 筛选（自 DS 源 filter 原样移植）====================
const FILTERS = {
  
        rank: [
            { key: 'platform', name: '平台', value: [{ n: '网易云', v: 'wy' }, { n: '酷狗', v: 'kg' }, { n: '酷我', v: 'kw' }, { n: 'QQ', v: 'tx' }, { n: '咪咕', v: 'mg' }] },
            { key: 'lbType', name: '榜单类型', value: [
                { n: '全部', v: '' }, { n: '热歌', v: '热歌' }, { n: '飙升', v: '飙升' }, { n: '新歌', v: '新歌' },
                { n: '原创', v: '原创' }, { n: '说唱', v: '说唱' }, { n: '电音', v: '电音' }, { n: '摇滚', v: '摇滚' },
                { n: '民谣', v: '民谣' }, { n: 'DJ', v: 'DJ' }, { n: '流行', v: '流行' }, { n: '地区', v: '地区' }
            ] }
        ],
        wy: [
            { key: 'lang', name: '语种', value: ft([['全部',''],['华语','华语'],['欧美','欧美'],['日语','日语'],['韩语','韩语'],['粤语','粤语']]) },
            { key: 'style', name: '风格', value: ft([['全部',''],['流行','流行'],['摇滚','摇滚'],['民谣','民谣'],['电子','电子'],['舞曲','舞曲'],['说唱','说唱'],['轻音乐','轻音乐'],['爵士','爵士'],['乡村','乡村'],['R&B/Soul','R&B/Soul'],['古典','古典'],['民族','民族'],['英伦','英伦'],['金属','金属'],['朋克','朋克'],['蓝调','蓝调'],['雷鬼','雷鬼'],['世界音乐','世界音乐'],['拉丁','拉丁'],['New Age','New Age'],['古风','古风'],['后摇','后摇'],['Bossa Nova','Bossa Nova']]) },
            { key: 'scene', name: '场景', value: ft([['全部',''],['清晨','清晨'],['夜晚','夜晚'],['学习','学习'],['工作','工作'],['午休','午休'],['下午茶','下午茶'],['地铁','地铁'],['驾车','驾车'],['运动','运动'],['旅行','旅行'],['散步','散步'],['酒吧','酒吧']]) },
            { key: 'mood', name: '情感', value: ft([['全部',''],['怀旧','怀旧'],['清新','清新'],['浪漫','浪漫'],['伤感','伤感'],['治愈','治愈'],['放松','放松'],['孤独','孤独'],['感动','感动'],['兴奋','兴奋'],['快乐','快乐'],['安静','安静'],['思念','思念']]) },
            { key: 'theme', name: '主题', value: ft([['全部',''],['综艺','综艺'],['影视原声','影视原声'],['ACG','ACG'],['儿童','儿童'],['校园','校园'],['游戏','游戏'],['70后','70后'],['80后','80后'],['90后','90后'],['网络歌曲','网络歌曲'],['KTV','KTV'],['经典','经典'],['翻唱','翻唱'],['吉他','吉他'],['钢琴','钢琴'],['器乐','器乐'],['榜单','榜单'],['00后','00后']]) }
        ],
        kg: [
            { key: 'sort', name: '排序', value: [
                { n: '推荐', v: '5' }, { n: '最热', v: '6' }, { n: '最新', v: '7' }, { n: '热藏', v: '3' }, { n: '飙升', v: '8' }
            ] },
            { key: 'theme', name: '主题', value: ft([['全部',''],['精选','1084'],['经典','12'],['网络','35'],['DJ热碟','17'],['情歌对唱','68'],['游戏','74'],['舞曲','10'],['KTV','72'],['影视','79'],['翻唱','638'],['ACG','77'],['现场','680'],['综艺','80'],['厂牌音乐','1111'],['BGM','1112'],['儿童','1110'],['器乐演奏','682'],['官方歌单','1085'],['草原风','605'],['广场舞','628']]) },
            { key: 'lang', name: '语种', value: ft([['全部',''],['国语','84'],['英语','20'],['粤语','19'],['日语','21'],['韩语','23'],['闽南语','22'],['小语种','24'],['法语','570']]) },
            { key: 'style', name: '风格', value: ft([['全部',''],['流行','9'],['古风','574'],['电子','33'],['民谣','83'],['摇滚','27'],['嘻哈','31'],['后摇','1079'],['中国风','11'],['R&B','30'],['古典','28'],['乡村','15'],['爵士','32'],['新世纪','650'],['布鲁斯','94'],['拉丁','1057'],['轻音乐','34'],['中国传统','1108'],['金属','29'],['雷鬼','92']]) },
            { key: 'year', name: '年代', value: ft([['全部',''],['70后','13'],['80后','14'],['90后','76'],['00后','571']]) },
            { key: 'mood', name: '心情', value: ft([['全部',''],['怀旧','1107'],['伤感','578'],['安静','44'],['兴奋','50'],['轻松','577'],['治愈','780'],['快乐','49'],['甜蜜','47'],['寂寞','42'],['感动','48'],['小清新','642'],['励志','81'],['减压','643'],['失恋','684']]) },
            { key: 'scene', name: '场景', value: ft([['全部',''],['学习','587'],['工作','660'],['通勤','1104'],['运动','69'],['校园','67'],['旅途','585'],['咖啡厅','61'],['店铺','581'],['清晨','668'],['下午茶','670'],['夜晚','1105'],['睡前','583'],['派对','586'],['宅家','1106'],['车载','63'],['夜店','64'],['婚礼','88']]) }
        ],
        kw: [
            { key: 'sort', name: '排序', value: [{ n: '最新', v: 'new' }, { n: '最热', v: 'hot' }] },
            { key: 'area', name: '专区', value: ft([['全部',''],['经典老歌专区','211-43'],['网红专区','87-43'],['DJ专区','1-43'],['轻音乐专区','13-43'],['国风专区','12-43'],['影视专区','156-43'],['铃声专区','143-43'],['动漫专区','6-43'],['新歌首发专区','17-43'],['K歌专区','147-43'],['小说专区','18-43'],['佛乐专区','9-43'],['儿童专区','3-43'],['评书专区','20-43'],['综艺专区','109-43'],['古典专区','164-43'],['Vlog音乐','166-43']]) },
            { key: 'theme', name: '主题', value: ft([['全部',''],['短视频','2189-10000'],['经典','1265-10000'],['情歌','2200-10000'],['BGM','2199-10000'],['演唱会','2212-10000'],['游戏','1877-10000'],['怀旧','155-10000'],['合唱','2201-10000'],['网络','621-10000'],['儿童','171-10000'],['ACG','181-10000'],['影视','180-10000'],['网红','1879-10000'],['春节','2190-10000'],['翻唱','1848-10000'],['轻音助眠','241-43']]) },
            { key: 'mood', name: '心情', value: ft([['全部',''],['伤感','146-10000'],['解压','62-10000'],['励志','58-10000'],['开心','143-10000'],['甜蜜','137-10000'],['兴奋','139-10000'],['安静','67-10000'],['思念','160-10000']]) },
            { key: 'scene', name: '场景', value: ft([['全部',''],['开车','376-10000'],['运动','366-10000'],['睡眠','354-10000'],['跳舞','378-10000'],['学习','1876-10000'],['清晨','353-10000'],['KTV','361-10000'],['店铺专用','263-10000'],['校园','382-10000'],['旅行','375-10000'],['工作','386-10000'],['广场舞','334-10000'],['通勤','2202-10000'],['宅家','2203-10000'],['Citywalk','2214-10000'],['露营','2213-10000']]) },
            { key: 'year', name: '年代', value: ft([['全部',''],['70后','637-10000'],['80后','638-10000'],['90后','639-10000'],['00后','640-10000']]) },
            { key: 'style', name: '曲风流派', value: ft([['全部',''],['流行','393-10000'],['DJ','168-10000'],['古风','127-10000'],['佛乐','220-10000'],['轻音乐','173-10000'],['纯音乐','577-10000'],['电子','391-10000'],['喊麦','216-10000'],['3D','1366-10000'],['器乐','578-10000'],['摇滚','389-10000'],['民歌','1921-10000'],['民谣','392-10000'],['古典','390-10000'],['嘻哈','387-10000'],['乡村','399-10000'],['爵士','397-10000'],['R&B','394-10000']]) },
            { key: 'lang', name: '语言', value: ft([['全部',''],['华语','37-10000'],['欧美','35-10000'],['韩语','1093-10000'],['粤语','13-10000'],['日语','1091-10000'],['小语种','12-10000']]) }
        ],
        tx: [
            { key: 'sort', name: '排序', value: [{ n: '最热', v: '5' }, { n: '最新', v: '2' }] },
            { key: 'hot', name: '热门', value: ft([['全部',''],['官方歌单','3317'],['免费热歌','3418']]) },
            { key: 'theme', name: '主题', value: ft([['全部',''],['KTV金曲','64'],['网络歌曲','3056'],['现场音乐','95'],['背景音乐','107'],['经典老歌','59'],['情歌','71'],['儿歌','3200'],['ACG','3202'],['影视','3201'],['综艺','3256'],['游戏','73'],['乐器','3204'],['城市','93'],['戏曲','3361'],['DJ神曲','3357'],['MC喊麦','60'],['佛教音乐','3401'],['厂牌专区','3320'],['人气音乐节','136'],['精品','3819']]) },
            { key: 'scene', name: '场景', value: ft([['全部',''],['夜店','32'],['学习工作','3248'],['咖啡馆','3215'],['运动','132'],['睡前','27'],['旅行','36'],['跳舞','3216'],['派对','33'],['婚礼','3214'],['约会','35'],['校园','39']]) },
            { key: 'mood', name: '心情', value: ft([['全部',''],['伤感','74'],['快乐','3142'],['安静','13'],['励志','16'],['治愈','7'],['思念','10'],['甜蜜','20'],['寂寞','9'],['宣泄','17']]) },
            { key: 'year', name: '年代', value: ft([['全部',''],['00年代','144'],['90年代','142'],['80年代','141'],['70年代','140']]) },
            { key: 'style', name: '流派', value: ft([['全部',''],['流行','3152'],['电子','45'],['轻音乐','49'],['民谣','48'],['说唱','42'],['摇滚','41'],['爵士','46'],['R&B','43'],['布鲁斯','51'],['古典','47'],['后摇','3217'],['古风','61'],['中国风','68'],['乡村','44'],['金属','3065'],['新世纪','53'],['世界音乐','3066'],['中国传统','3176']]) },
            { key: 'lang', name: '语种', value: ft([['全部',''],['英语','3'],['粤语','146'],['韩语','4'],['日语','5'],['国语','1'],['闽南语','113'],['小语种','6'],['法语','149'],['拉丁语','3205']]) }
        ],
        mg: [
            { key: 'style', name: '风格', value: ft([['全部',''],['流行','1000001672'],['电子','1000001682'],['国风','1000001675'],['爵士','1000001681'],['乡村','1000001683'],['蓝调','1000001851'],['民谣','1000001775'],['纯音乐','1000001807'],['古典','1000001783'],['摇滚','1000001674'],['嘻哈','1000001809'],['R&B','1000001808']]) },
            { key: 'lang', name: '语种', value: ft([['全部',''],['国语','1000001762'],['粤语','1000001763'],['英语','1000001766'],['日语','1000001767'],['韩语','1000001599'],['小语种','1003449724']]) },
            { key: 'scene', name: '场景', value: ft([['全部',''],['运动','1003449615'],['瑜伽','1000587692'],['学习','1003449726'],['睡前安眠','1000587688'],['驾车','1000093923'],['旅行','1000001749'],['夜店','1000587686'],['派对','1002600606'],['下午茶','1003449723'],['读书','1003449726']]) },
            { key: 'theme', name: '主题', value: ft([['全部',''],['综艺','1001076083'],['KTV金曲','1000001827'],['爱情','1000001698'],['经典老歌','1000001635'],['网络热歌','1001076096'],['儿歌','1000001780'],['70后','1000587717'],['80后','1000587718'],['90后','1000587726'],['广场舞','1000587702'],['红歌','1000001670'],['游戏','1000587698'],['中国风','1000001675'],['青春校园','1000587712'],['小清新','1000587673'],['DJ舞曲','1000093902'],['电视剧','1001076078'],['电影','1001076080'],['翻唱','1000001831']]) },
            { key: 'mood', name: '心情', value: ft([['全部',''],['幸福','1000587677'],['治愈','1000587710'],['思念','1000001703'],['励志','1000001700'],['欢快','1000001694'],['叛逆','1002600588'],['宣泄','1002600585'],['怀旧','1000001696'],['减压','1000587679'],['寂寞','1000001699'],['忧郁','1002600579'],['伤感','1000001795']]) }
        ]
};

// ==================== 榜单上游接口（自 DS 源 leaderboardApis 原样移植）====================
const LEADERBOARD_APIS = {
  
        wy: {
            url: 'https://music.163.com/api/toplist',
            headers: { 'Referer': 'https://music.163.com' },
            extract: data => (data.list || []).map(b => ({ bangid: String(b.id), name: b.name || '', img: b.coverImgUrl || '' }))
        },
        kg: {
            url: 'http://mobilecdnbj.kugou.com/api/v5/rank/list?version=9108&plat=0&showtype=2&parentid=0&apiver=6&area_code=1&withsong=1',
            extract: data => (data.data && data.data.info || []).filter(b => b.isvol == 1).map(b => ({
                bangid: String(b.rankid), name: b.rankname || '', img: (b.imgurl || b.img_9 || b.banner_9 || '').replace('{size}', '400')
            }))
        },
        kw: {
            url: 'http://qukudata.kuwo.cn/q.k?op=query&cont=tree&node=2&pn=0&rn=1000&fmt=json&level=2',
            extract: data => (data.child || []).filter(b => b.source == '1').map(b => ({
                bangid: String(b.sourceid), name: b.name || '', img: b.pic || b.img || ''
            }))
        },
        tx: {
            url: 'https://c.y.qq.com/v8/fcg-bin/fcg_myqq_toplist.fcg?g_tk=1928093487&inCharset=utf-8&outCharset=utf-8&notice=0&format=json&uin=0&needNewCode=1&platform=h5',
            headers: { 'Referer': 'https://y.qq.com' },
            extract: data => (data.data && data.data.topList || []).filter(b => b.id != 201).map(b => {
                let name = (b.topTitle || '').replace(/^巅峰榜·/, '');
                if (!name.endsWith('榜')) name += '榜';
                return { bangid: String(b.id), name: name, img: b.frontPicUrl || b.picUrl || '' };
            })
        },
        mg: {
            url: 'https://app.c.nf.migu.cn/pc/bmw/rank/rank-index/v1.0',
            headers: { 'Referer': 'https://app.c.nf.migu.cn/', 'channel': '0146921' },
            extract: data => {
                const list = [], ids = {};
                (function recurse(items) {
                    (items || []).forEach(item => {
                        if (item.rankId && !ids[item.rankId]) {
                            ids[item.rankId] = 1;
                            list.push({ bangid: String(item.rankId), name: item.rankName || '', img: item.imageUrl || '' });
                        }
                        if (item.contents) recurse(item.contents);
                    });
                })(data.data && data.data.contents);
                return list;
            }
        }
};

// ==================== 配置持久化 ====================
// 服务地址 / 用户名 / 密码：直接写死在脚本里（不读环境变量、不读写配置文件）
const _cfg = {
  host: "http://127.0.0.1:9527",
  user: "admin",
  password: "123456",
  token: "",
};

let _readMode = null; // 普通 GET 成功的模式：true=具名用户, false=open
let _urlMode = null; // /api/music/url 成功的模式
let _lastError = "";
const _diag = [];

function pushDiag(line) {
  try {
    _diag.push(new Date().toISOString().substring(11, 19) + " " + line);
    while (_diag.length > 40) _diag.shift();
  } catch (_) {}
}

function currentHost() {
  return String(_cfg.host || "").replace(/\/+$/, "");
}

function namedUser() {
  const user = String(_cfg.user || "").trim();
  if (!user || OPEN_USERS.indexOf(user) >= 0) return "";
  if (!String(_cfg.password || "").trim()) return "";
  return user;
}

// ==================== 请求层 ====================
function headersFor(mode) {
  const headers = { "User-Agent": UA, Accept: "application/json" };
  if (mode === "auth") {
    const user = namedUser();
    if (user) {
      headers["X-User-Name"] = user;
      if (_cfg.token) headers["X-User-Token"] = _cfg.token;
    }
  }
  return headers;
}

async function fetchJson(method, pathName, body, mode, timeoutMs) {
  const host = currentHost();
  if (!host) return { ok: false, status: 0, message: "未配置 lxserver 地址", data: null };
  const headers = headersFor(mode);
  if (body !== undefined && body !== null) headers["Content-Type"] = "application/json";
  try {
    const res = await axios({
      method,
      url: host + pathName,
      headers,
      data: body === undefined || body === null ? undefined : JSON.stringify(body),
      timeout: timeoutMs || REQ_TIMEOUT,
      validateStatus: () => true,
      responseType: "text",
      transformResponse: (d) => d,
    });
    const raw = typeof res.data === "string" ? res.data : res.data == null ? "" : JSON.stringify(res.data);
    let data = null;
    if (raw) {
      try {
        data = JSON.parse(raw);
      } catch (_) {
        data = raw;
      }
    }
    let message = "";
    if (data && typeof data === "object") message = data.message || data.error || data.msg || "";
    if (!message && res.status >= 400) message = "HTTP " + res.status;
    return { ok: res.status < 400, status: res.status, data: data, message: String(message || "") };
  } catch (error) {
    const msg = String((error && error.message) || error);
    return { ok: false, status: 0, message: msg, data: null };
  }
}

// 普通读接口：先试具名（若配置了），401 就退 open，成功后记住模式
async function readJson(pathName) {
  const modes = _readMode === null ? (namedUser() ? ["auth", "open"] : ["open"]) : [_readMode ? "auth" : "open"];
  let last = null;
  for (const mode of modes) {
    const res = await fetchJson("get", pathName, null, mode);
    last = res;
    if (res.status === 401) continue;
    _readMode = mode === "auth";
    if (!res.ok) _lastError = res.message;
    return res.ok ? res.data : null;
  }
  _lastError = (last && last.message) || "";
  return null;
}

// 需要登录的读接口（readJsonAuth：带用户名 + token，保留备用）
async function readJsonAuth(pathName) {
  const token = await loginUser();
  if (!token) return null;
  let res = await fetchJson("get", pathName, null, "auth");
  if (res.status === 401) {
    _cfg.token = "";
    const again = await loginUser(true);
    if (!again) return null;
    res = await fetchJson("get", pathName, null, "auth");
  }
  return res.ok ? res.data : null;
}

async function loginUser(force) {
  if (_cfg.token && !force) return _cfg.token;
  const user = namedUser();
  if (!user) return "";
  const res = await fetchJson("post", "/api/user/login", { username: user, password: String(_cfg.password || "") }, "open", REQ_TIMEOUT);
  if (res.ok && res.data && res.data.success && res.data.token) {
    _cfg.token = String(res.data.token);
    pushDiag("login ok user=" + user + " token=" + _cfg.token.substring(0, 6) + "…");
    return _cfg.token;
  }
  _cfg.token = "";
  pushDiag("login fail user=" + user + " status=" + res.status + " " + res.message);
  return "";
}

// 播放地址解析：先试具名（带 token），失败退 open；成功模式缓存
async function fetchMusicUrlOnce(song, quality, mode) {
  if (mode === "auth") await loginUser();
  const body = { songInfo: song, quality: quality, enableAutoSwitchApiSource: true };
  let res = await fetchJson("post", "/api/music/url", body, mode, URL_TIMEOUT);
  if (res.status === 401 && mode === "auth") {
    _cfg.token = "";
    const again = await loginUser(true);
    if (again) res = await fetchJson("post", "/api/music/url", body, mode, URL_TIMEOUT);
  }
  if (res.status === 401) return { url: "", status: 401, message: "401 Unauthorized（用户 token 无效）" };
  const data = res.data;
  let url = "";
  if (res.ok && data && typeof data === "object") {
    url = String(data.url || data.playUrl || (data.data && data.data.url) || "");
  }
  return { url: url, status: res.status, message: res.message, data: data };
}

async function fetchMusicUrl(song, quality) {
  const modes = _urlMode === null ? (namedUser() ? ["auth", "open"] : ["open"]) : [_urlMode ? "auth" : "open"];
  let last = { status: 0, message: "服务端无响应" };
  for (const mode of modes) {
    const r = await fetchMusicUrlOnce(song, quality, mode);
    last = r;
    if (r.url) {
      _urlMode = mode === "auth";
      _lastError = "";
      pushDiag("url ok q=" + quality + " mode=" + mode + " " + r.url.substring(0, 60));
      return { q: quality, url: r.url };
    }
    const attempts = r.data && Array.isArray(r.data.attempts) ? r.data.attempts.length : 0;
    pushDiag("url fail q=" + quality + " mode=" + mode + " status=" + r.status + " msg=" + (r.message || "") + (attempts ? " attempts=" + attempts : ""));
  }
  _lastError = last.message || ("HTTP " + last.status);
  return null;
}

// ==================== ID 编解码（base64url）====================
function b64encode(obj) {
  return Buffer.from(JSON.stringify(obj), "utf-8").toString("base64url").replace(/=+$/, "");
}

function b64decode(text) {
  try {
    return JSON.parse(Buffer.from(String(text), "base64url").toString("utf-8"));
  } catch (_) {
    return null;
  }
}

function songName(song) {
  return String((song && (song.name || song.songname || song.title)) || "");
}

function fmtSinger(song) {
  if (!song) return "";
  if (song.singer || song.artist) return String(song.singer || song.artist);
  if (Array.isArray(song.artists)) return song.artists.map((s) => (s && s.name) || s).join(" ");
  return "";
}

function imgOf(song) {
  if (!song) return "";
  return song.img || song.pic || song.album_img || song.cover || song.picUrl || (song.meta && song.meta.picUrl) || "";
}

function stripDollar(text) {
  return String(text == null ? "" : text).replace(/\$/g, "");
}

// 完整保存歌曲对象（lxserver 解析播放地址需要 meta/qualitys/_types 等原始字段）
function encodeSongId(pt, song) {
  const rawMid = String(song.songmid || song.song_id || song.id || song.mid || "");
  const songmid = rawMid.indexOf(pt + "_") === 0 ? rawMid.substring(pt.length + 1) : rawMid;
  const payload = Object.assign({}, song, {
    source: pt,
    songmid: songmid,
    name: songName(song),
    singer: fmtSinger(song),
    img: imgOf(song),
  });
  return "song_" + b64encode(payload);
}

function encodeListId(t, pt, id, title, img) {
  return "list_" + b64encode({ t: t, pt: pt, id: String(id), title: title || "", img: img || "" });
}

function decodeId(id) {
  const text = String(id || "");
  const idx = text.indexOf("_");
  if (idx < 1) return null;
  const data = b64decode(text.substring(idx + 1));
  if (!data || typeof data !== "object") return null;
  return { type: text.substring(0, idx), data: data };
}

function parseExt(ext) {
  if (!ext) return {};
  if (typeof ext === "object") return ext;
  const text = String(ext).replace(/&amp;/g, "&").replace(/^\?/, "").trim();
  if (!text) return {};
  if (text.charAt(0) === "{") {
    try {
      const obj = JSON.parse(text);
      return obj && typeof obj === "object" ? obj : {};
    } catch (_) {
      return {};
    }
  }
  const out = {};
  for (const [key, val] of new URLSearchParams(text)) out[key] = val;
  return out;
}

function withTimeout(promise, ms) {
  return Promise.race([promise, new Promise((resolve) => setTimeout(() => resolve(null), ms))]);
}

// 可用音质：types（数组）+ _types（对象键），按优先级排序
function availableQualities(song) {
  const set = {};
  if (song && Array.isArray(song.types)) {
    song.types.forEach((item) => {
      const t = item && typeof item === "object" ? item.type : item;
      if (t) set[String(t)] = 1;
    });
  }
  if (song && song._types && typeof song._types === "object") {
    Object.keys(song._types).forEach((k) => {
      set[String(k)] = 1;
    });
  }
  if (song && song.meta) {
    if (Array.isArray(song.meta.qualitys)) {
      song.meta.qualitys.forEach((item) => {
        const t = item && typeof item === "object" ? item.type : item;
        if (t) set[String(t)] = 1;
      });
    }
    if (song.meta._qualitys && typeof song.meta._qualitys === "object") {
      Object.keys(song.meta._qualitys).forEach((k) => {
        set[String(k)] = 1;
      });
    }
  }
  const list = Object.keys(set).sort((a, b) => QUALITY_PRIORITY.indexOf(a) - QUALITY_PRIORITY.indexOf(b));
  return list.length ? list : ["320k", "128k", "flac"];
}

// 探测音质：优先 320k/128k（最稳最快），没有就取排序第一
function pickProbeQuality(qualities) {
  for (const q of ["320k", "128k", "flac"]) {
    if (qualities.indexOf(q) >= 0) return q;
  }
  return qualities[0];
}

// ==================== 列表片段 ====================
function songListResult(songs, listName, playFrom, extraCovers) {
  const items = [];
  (Array.isArray(songs) ? songs : []).forEach((song, index) => {
    const name = stripDollar(songName(song));
    if (!name) return;
    const singer = stripDollar(fmtSinger(song));
    const src = song.source || playFrom || "wy";
    const cover = (extraCovers && extraCovers[index]) || imgOf(song) || "";
    items.push(name + "$" + encodeSongId(src, song) + "$" + singer + "$" + cover);
  });
  const listCover = (extraCovers && extraCovers.find((c) => c)) || imgOf((songs && songs[0]) || {}) || PLACEHOLDER_IMG;
  return {
    vod_name: listName,
    vod_pic: listCover,
    vod_content: listName + " · 共 " + items.length + " 首",
    vod_play_from: playFrom,
    vod_play_url: items.join("#"),
    vod_play_pic_ratio: 1.0,
  };
}

async function fillMissingCovers(songs) {
  const covers = (Array.isArray(songs) ? songs : []).map((s) => imgOf(s));
  const missing = [];
  covers.forEach((c, i) => {
    if (!c) missing.push(i);
  });
  if (!missing.length) return covers;
  const tasks = missing.map((i) => {
    const song = songs[i];
    const name = songName(song);
    if (!name) return Promise.resolve(null);
    const src = song.source || "wy";
    return withTimeout(
      readJson("/api/music/search?source=" + src + "&name=" + encodeURIComponent(name) + "&page=1&limit=10"),
      2500
    );
  });
  const results = await Promise.all(tasks);
  missing.forEach((idx, k) => {
    const data = results[k];
    const list = Array.isArray(data) ? data : (data && data.list) || [];
    const song = songs[idx];
    const matched =
      list.find((s) => String((s && (s.songmid || s.song_id || s.id || s.mid)) || "") === String(song.songmid || song.id)) ||
      list[0];
    if (matched) covers[idx] = imgOf(matched);
  });
  return covers;
}

// ==================== 首页（DS 推荐）====================
async function homeContent() {
  const pt = PLATFORMS[Math.floor(Math.random() * PLATFORMS.length)];
  const pg = Math.floor(Math.random() * 5) + 1;
  const data = await readJson("/api/music/songList/list?source=" + pt + "&sortId=hot&page=" + pg);
  const list = ((data && data.list) || []).map((item) => ({
    vod_name: item.name || "",
    vod_pic: item.img || "",
    vod_remarks: (PLATFORM_NAME[pt] || pt) + "·歌单",
    vod_id: encodeListId("gd", pt, item.id, item.name, item.img),
  }));
  return { class: CLASSES, filters: FILTERS, list: list };
}

// ==================== 分类 ====================
async function listSonglist(pt, pg, sort, tag) {
  let url = "/api/music/songList/list?source=" + pt + "&sortId=" + (sort || "hot") + "&page=" + pg;
  if (tag) url += "&tagId=" + encodeURIComponent(tag);
  const data = await readJson(url);
  const list = (data && data.list) || [];
  const pName = PLATFORM_NAME[pt] || pt;
  return list.map((item) => ({
    vod_name: item.name || "",
    vod_pic: item.img || "",
    vod_remarks: pName + "·歌单",
    vod_id: encodeListId("gd", pt, item.id, item.name, item.img),
  }));
}

async function fetchLeaderboardUpstream(pt) {
  const config = LEADERBOARD_APIS[pt];
  if (!config) return null;
  try {
    const res = await axios({
      method: "get",
      url: config.url,
      headers: Object.assign({ "User-Agent": UA, "Accept-Encoding": "identity" }, config.headers || {}),
      timeout: 15000,
      validateStatus: () => true,
      responseType: "text",
      transformResponse: (d) => d,
    });
    const raw = typeof res.data === "string" ? res.data : JSON.stringify(res.data);
    if (!raw) return null;
    const data = JSON.parse(raw);
    const out = config.extract(data);
    return Array.isArray(out) && out.length ? out : null;
  } catch (_) {
    return null;
  }
}

async function listLeaderboard(pt, pg, lbType) {
  if (pg > 1) return [];
  const pName = PLATFORM_NAME[pt] || pt;
  let boards = await fetchLeaderboardUpstream(pt);
  if (!boards || !boards.length) {
    const data = await readJson("/api/music/leaderboard/boards?source=" + pt);
    if (!data || !data.list) return [];
    boards = data.list.map((b) => ({
      bangid: String(b.bangid || b.id || ""),
      name: b.name || "排行榜",
      img: b.img || PLACEHOLDER_IMG,
    }));
  }
  if (lbType) {
    boards = boards.filter((b) => {
      const name = b.name || "";
      if (lbType === "电音") return name.indexOf("电音") >= 0 || name.indexOf("DJ") >= 0;
      if (lbType === "地区") return /内地|欧美|韩国|日本|香港|港台|美国|英国|新加坡|马来西亚/.test(name);
      return name.indexOf(lbType) >= 0;
    });
  }
  return boards.map((board) => ({
    vod_name: board.name || "排行榜",
    vod_pic: board.img || PLACEHOLDER_IMG,
    vod_remarks: pName + "·榜单",
    vod_id: encodeListId("lb", pt, board.bangid, board.name, board.img || PLACEHOLDER_IMG),
  }));
}

function pageResult(list, pg, pageCount, limit) {
  const items = (Array.isArray(list) ? list : []).filter((i) => i && i.vod_name);
  return {
    list: items,
    page: pg,
    pagecount: pageCount || 9999,
    limit: limit || 30,
    total: items.length,
  };
}

async function categoryContent(q) {
  const tid = String(q.id || "");
  const pg = parseInt(q.page, 10) || 1;
  const extend = parseExt(q.ext);
  if (tid === "rank") {
    return pageResult(await listLeaderboard(extend.platform || "wy", pg, extend.lbType || ""), pg, 1, 200);
  }
  const sort = extend.sort || (tid === "mg" ? "15127315" : tid === "kg" || tid === "tx" ? "5" : "hot");
  let tag = "";
  for (const key of ["hot", "lang", "style", "scene", "mood", "theme", "area", "year"]) {
    if (extend[key]) {
      tag = extend[key];
      break;
    }
  }
  return pageResult(await listSonglist(tid, pg, sort, tag), pg, 9999, 30);
}

// ==================== 详情 ====================
function diagDetail() {
  const lines = [];
  lines.push("lxserver: " + currentHost());
  lines.push("用户: " + (namedUser() || "(open 公开用户)"));
  lines.push("token: " + (_cfg.token ? _cfg.token.substring(0, 8) + "…" : "(无)"));
  lines.push("读接口模式: " + (_readMode === null ? "未定" : _readMode ? "具名" : "open"));
  lines.push("播放模式: " + (_urlMode === null ? "未定" : _urlMode ? "具名" : "open"));
  lines.push("最近错误: " + (_lastError || "无"));
  lines.push("──── 最近播放请求 ────");
  lines.push(_diag.length ? _diag.slice(-25).join("\n") : "(暂无记录，先播放一首歌再来)");
  return {
    list: [
      {
        vod_name: "播放诊断",
        vod_pic: PLACEHOLDER_IMG,
        vod_content: lines.join("\n"),
        vod_play_from: "提示",
        vod_play_url: "返回$$",
      },
    ],
  };
}

async function detailContent(q) {
  const ids = Array.isArray(q.ids) ? q.ids : [q.ids || q.id || ""];
  const rawId = String(ids[0] || "");
  if (rawId === "diag") return diagDetail();
  const decoded = decodeId(rawId);
  if (!decoded) return { list: [] };
  if (decoded.type === "song") {
    const info = decoded.data;
    const pName = PLATFORM_NAME[info.source] || info.source;
    const name = stripDollar(info.name);
    const pic = info.img || "";
    return {
      list: [
        {
          vod_name: name,
          vod_pic: pic,
          vod_content: pName + " · 单曲",
          vod_play_from: pName,
          vod_play_url: name + "$" + rawId + "$$" + pic,
          vod_play_pic_ratio: 1.0,
        },
      ],
    };
  }
  if (decoded.type !== "list") return { list: [] };
  const info = decoded.data;
  const apiUrl =
    info.t === "lb"
      ? "/api/music/leaderboard/list?source=" + info.pt + "&bangid=" + info.id + "&page=1"
      : "/api/music/songList/detail?source=" + info.pt + "&id=" + info.id + "&page=1";
  const data = await readJson(apiUrl);
  const songs = (data && data.list) || [];
  const pName = PLATFORM_NAME[info.pt] || info.pt;
  return {
    list: [
      {
        vod_name: info.title || "歌单",
        vod_pic: info.img || "",
        vod_content: pName + " · 共 " + songs.length + " 首",
        vod_play_from: pName,
        vod_play_url: songs
          .map((song) => {
            const name = stripDollar(songName(song));
            const singer = stripDollar(fmtSinger(song));
            return name + "$" + encodeSongId(info.pt, song) + "$" + singer + "$" + imgOf(song);
          })
          .join("#"),
        vod_play_pic_ratio: 1.0,
      },
    ],
  };
}

// ==================== 搜索（5 平台并发）====================
async function searchContent(q) {
  const keyword = String(q.wd || "");
  const page = parseInt(q.page, 10) || 1;
  if (!keyword) return { list: [] };
  const encKey = encodeURIComponent(keyword);
  const fetchPlatform = async (pt) => {
    const data = await withTimeout(
      readJson("/api/music/search?source=" + pt + "&name=" + encKey + "&page=" + page + "&limit=20"),
      6000
    );
    if (!data) return [];
    const list = Array.isArray(data) ? data : data.list || [];
    const pName = PLATFORM_NAME[pt] || pt;
    const out = [];
    list.forEach((song) => {
      const name = songName(song);
      if (!name) return;
      const singer = fmtSinger(song);
      out.push({
        vod_name: name + (singer ? " - " + singer : ""),
        vod_pic: imgOf(song),
        vod_remarks: pName,
        vod_id: encodeSongId(pt, song),
      });
    });
    return out;
  };
  const groups = await Promise.all(PLATFORMS.map((pt) => fetchPlatform(pt)));
  return { list: groups.reduce((acc, arr) => acc.concat(arr), []) };
}

// ==================== 播放（多音质 + 歌词 + 封面）====================
async function playContent(q) {
  const decoded = decodeId(String(q.id || "").split("$")[0]);
  if (!decoded || decoded.type !== "song" || !decoded.data.songmid) {
    return { parse: 0, jx: 0, playUrl: "", url: "", msg: "无效的歌曲 ID" };
  }
  const song = decoded.data;
  await loginUser();
  const qualities = availableQualities(song);
  pushDiag("play " + songName(song) + " src=" + song.source + " mid=" + song.songmid + " qualities=" + qualities.join("/"));

  // 1) 先探测首选音质（拿到可播 url + 确定可用模式）
  const probeQ = pickProbeQuality(qualities);
  const collected = [];
  const probe = await fetchMusicUrl(song, probeQ);
  if (probe) collected.push(probe);

  // 2) 其余音质并行补齐（组成多音质列表）
  const rest = qualities.filter((x) => x !== probeQ);
  if (rest.length) {
    const results = await Promise.all(rest.map((x) => withTimeout(fetchMusicUrl(song, x), URL_TIMEOUT)));
    results.forEach((r) => {
      if (r) collected.push(r);
    });
  }

  // 3) 全失败 → 按优先级串行再试一轮
  if (!collected.length) {
    for (const x of qualities) {
      const r = await fetchMusicUrl(song, x);
      if (r) {
        collected.push(r);
        break;
      }
    }
  }
  if (!collected.length) {
    return {
      parse: 0,
      jx: 0,
      playUrl: "",
      url: "",
      msg: "无可用播放地址" + (_lastError ? "（" + _lastError + "）" : ""),
    };
  }

  // 歌词 + 封面（与音质请求并行发出，避免串行拖时间）
  const lyricParams = ["source=" + song.source, "songmid=" + encodeURIComponent(song.songmid)];
  if (song.hash) lyricParams.push("hash=" + song.hash);
  if (song.name) lyricParams.push("name=" + encodeURIComponent(song.name));
  if (song.interval) lyricParams.push("interval=" + encodeURIComponent(song.interval));
  const lrc = (await withTimeout(
    (async () => {
      const data = await readJson("/api/music/lyric?" + lyricParams.join("&"));
      let text = typeof data === "string" ? data : (data && (data.lyric || data.lrc || (data.info && data.info.lrc))) || "";
      if (text) text = String(text).replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, "").substring(0, 10000);
      return text;
    })(),
    5000
  )) || "";
  let cover = song.img || imgOf(song) || "";
  if (!cover) {
    cover =
      (await withTimeout(
        (async () => {
          const data = await readJson(
            "/api/music/search?source=" + song.source + "&name=" + encodeURIComponent(song.name || "") + "&page=1&limit=10"
          );
          const list = Array.isArray(data) ? data : (data && data.list) || [];
          const matched =
            list.find((s) => String((s && (s.songmid || s.song_id || s.id || s.mid)) || "") === String(song.songmid)) ||
            list[0];
          return imgOf(matched || "");
        })(),
        3000
      )) || "";
  }

  // 排序：默认音质取 SQ 无损（DS 语义），没有则取最接近的
  const prio = (x) => QUALITY_PRIORITY.indexOf(x);
  const flacP = prio("flac");
  const dedup = [];
  const seen = {};
  collected.forEach((r) => {
    if (seen[r.url]) return;
    seen[r.url] = 1;
    dedup.push(r);
  });
  const defaultEntry =
    dedup.find((r) => r.q === "flac") || dedup.find((r) => prio(r.q) > flacP) || dedup[0];
  const others = dedup.filter((r) => r !== defaultEntry);
  const higher = others.filter((r) => prio(r.q) < flacP).sort((a, b) => prio(a.q) - prio(b.q));
  const lower = others.filter((r) => prio(r.q) > flacP).sort((a, b) => prio(a.q) - prio(b.q));
  const urlArray = [];
  [defaultEntry].concat(higher, lower).forEach((r) => {
    urlArray.push(QUALITY_NAME[r.q] || r.q, r.url);
  });
  pushDiag("play ok 可用=" + dedup.map((r) => r.q).join("/") + " 默认=" + defaultEntry.q);

  return {
    parse: 0,
    jx: 0,
    playUrl: "",
    url: urlArray,
    header: { "User-Agent": UA },
    lrc: lrc || "",
    cover: cover,
    pic: cover,
    artwork: cover,
    height: 720,
    flag: "DS落雪",
  };
}

// ==================== 路由注册（对齐 guazi.js）====================
module.exports = async function dsLuoxue(app, opt) {
  const handler = async (req) => {
    try {
      const q = Object.assign({}, req.query || {});
      if (req.body && typeof req.body === "object" && Object.keys(req.body).length) {
        q.body = req.body;
      }
      // 播放
      if (q.play || q.ac === "play") return await playContent({ id: q.play || q.id, flag: q.flag });
      // 搜索
      if (q.wd) return await searchContent({ wd: q.wd, page: q.pg || q.page });
      // 详情
      if (q.ids || (q.ac === "detail" && q.id && !q.t)) {
        return await detailContent({ ids: q.ids || q.id });
      }
      // 分类
      if (q.t) return await categoryContent({ id: q.t, page: q.pg || q.page, ext: q.ext || q.extend || q.f });
      // 兜底：单独 id 当详情
      if (q.id) return await detailContent({ ids: q.id });
      return await homeContent();
    } catch (error) {
      return { list: [], msg: (error && error.message) || String(error) };
    }
  };

  app.get(meta.api, handler);
  app.post(meta.api, handler);

  if (opt && Array.isArray(opt.sites)) {
    opt.sites.push(meta);
  }
};

module.exports.meta = meta;
