"use strict"; module.exports = require("./appv7-client").createRoute({ key: "appv7xiaohuangren", name: "[影]黄人秒播", configKey: "AppV7Xhr" });
