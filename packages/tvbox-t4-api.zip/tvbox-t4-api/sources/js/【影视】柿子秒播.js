"use strict"; module.exports = require("./appv7-client").createRoute({ key: "appv7xiaoshizi", name: "[影]柿子秒播", configKey: "AppV7Xsz" });
