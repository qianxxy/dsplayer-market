// author: cupid
// 黄豆短剧 T4 源 - https://lzlukvca.cc
// 1) 全站 API 加密：requestId 派生密钥(HMAC-SHA256) → gzip → AES-256-CBC(前 16 字节为 IV)，响应同法回解
// 2) 该域名被国内运营商 DNS 污染成 0.0.0.0（四川电信 61.139.2.69 / 202.98.96.68 实测），
//    所以不能用系统 DNS：先 DoH（阿里 223.5.5.5 / 腾讯 120.53.53.53，直连 IP 无需解析）取 A 记录，
//    再直连 IP + SNI/Host 头访问；全部请求走原生 http/https，不依赖 axios
// 3) 播放：m3u8 播放列表由主站下发（分片和密钥在 CloudFront 上，没被污染），播放器自己取不到列表，
//    因此源进程内起一个只监听 127.0.0.1 的小代理，列表由本源代取、改写后再交给播放器
// 4) 排障：/video/hddj?diag=1 返回 DNS / 路由 / 接口 / 代理的实时状态

const http = require('http');
const https = require('https');
const net = require('net');
const dns = require('dns');
const crypto = require('crypto');
const zlib = require('zlib');

const SITE_NAME = '黄豆短剧';
const BUILD = '20260904-dns';
let HOST = 'https://lzlukvca.cc';
let TOKEN = '';

// Dart 客户端硬编码的平台密钥；sign = sha256("Dart|sessionId|requestId|ts|path") + "-" + ts
const PLATFORM_KEY = '7961beb44246e3012ce228d6b5ced05a';
const VERSION = '2.0.0';
const DEVICE_TYPE = 'web';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
const PAGE_SIZE = 18;
const REQ_TIMEOUT = 15000;

// line 参数不参与签名：free/line2/line3 对应三个不同 CDN，可直接换参数切线路
const LINES = [
  { name: 'free', label: '黄豆线路1' },
  { name: 'line2', label: '黄豆线路2' },
  { name: 'line3', label: '黄豆线路3' },
];

const ORDER_FILTER = {
  key: 'order',
  name: '排序',
  value: [
    { n: '推荐', v: 'new:top' },
    { n: '最新', v: 'new' },
    { n: '最热', v: 'hot' },
    { n: '点击', v: 'click' },
    { n: '默认', v: '' },
  ],
};

const STATUS_FILTER = {
  key: 'update_status',
  name: '状态',
  value: [
    { n: '全部', v: '' },
    { n: '连载', v: '0' },
    { n: '完结', v: '1' },
  ],
};

function uuid() {
  if (typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  const b = crypto.randomBytes(16);
  b[6] = (b[6] & 0x0f) | 0x40;
  b[8] = (b[8] & 0x3f) | 0x80;
  const h = b.toString('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}

// 一个进程内固定 sessionId / deviceId，与 Dart 端行为一致
const SESSION_ID = uuid().replace(/-/g, '');
const DEVICE_ID = SESSION_ID;

// ---------- 诊断收集 ----------
const DIAG = { errors: [], dns: {} };

function noteErr(where, e) {
  const msg = e && (e.code || e.message) ? String(e.code || e.message) : String(e);
  DIAG.errors.push({ t: new Date().toISOString().slice(11, 19), where, msg });
  if (DIAG.errors.length > 20) DIAG.errors.shift();
  DIAG.lastAt = Date.now();
  return msg;
}

// 壳子里看不到日志，接口整体失败时用一张占位卡把原因直接显示在列表上
function recentFail() {
  return DIAG.lastAt && Date.now() - DIAG.lastAt < 20000;
}

function failCard() {
  const last = DIAG.errors[DIAG.errors.length - 1] || {};
  const why = `${last.where || '接口'} ${last.msg || '无数据'}`.trim();
  return {
    vod_id: '__diag__',
    vod_name: `⚠ ${SITE_NAME}取数失败`,
    vod_pic: '',
    vod_remarks: why.slice(0, 60),
  };
}

// ---------- DNS：DoH 优先，系统解析兜底 ----------
const DOH_SERVERS = [
  { ip: '223.5.5.5', sni: 'dns.alidns.com', path: '/resolve' },
  { ip: '120.53.53.53', sni: 'doh.pub', path: '/dns-query' },
  { ip: '223.6.6.6', sni: 'dns.alidns.com', path: '/resolve' },
];
// DoH 全挂时的最后兜底：Cloudflare 任意边缘 IP 凭 Host 头都能回到本站
const STATIC_IPS = { 'lzlukvca.cc': ['104.21.12.21', '172.67.151.77'] };
const BAD_IP = /^(0\.0\.0\.0|255\.255\.255\.255|::)$/;
const DNS_TTL = 10 * 60 * 1000;
const dnsCache = new Map();
const dnsPending = new Map();
const ROUTE_OK = new Map(); // hostname -> { host, sni }

const httpAgent = new http.Agent({ keepAlive: true, maxSockets: 16 });
const httpsAgent = new https.Agent({ keepAlive: true, maxSockets: 16, rejectUnauthorized: false });

function hostOf(u) {
  try {
    return new URL(u).hostname;
  } catch (e) {
    return '';
  }
}

function dohQuery(srv, name) {
  return new Promise((resolve) => {
    let done = false;
    const finish = (v) => {
      if (!done) {
        done = true;
        resolve(v);
      }
    };
    try {
      const req = https.request({
        host: srv.ip,
        port: 443,
        path: `${srv.path}?name=${encodeURIComponent(name)}&type=A`,
        method: 'GET',
        servername: srv.sni,
        rejectUnauthorized: false,
        timeout: 6000,
        headers: { Host: srv.sni, Accept: 'application/dns-json', 'User-Agent': UA },
      }, (res) => {
        const chunks = [];
        res.on('data', (d) => chunks.push(d));
        res.on('end', () => {
          try {
            const j = JSON.parse(Buffer.concat(chunks).toString('utf8'));
            const ips = (j.Answer || [])
              .filter((a) => a && a.type === 1 && !BAD_IP.test(String(a.data)))
              .map((a) => String(a.data));
            finish(ips);
          } catch (e) {
            finish([]);
          }
        });
        res.on('error', () => finish([]));
      });
      req.on('error', () => finish([]));
      req.on('timeout', () => {
        req.destroy();
        finish([]);
      });
      req.end();
    } catch (e) {
      finish([]);
    }
  });
}

// 三家并发，谁先给出有效结果就用谁
function dohResolve(name) {
  return new Promise((resolve) => {
    let pending = DOH_SERVERS.length;
    let settled = false;
    for (const srv of DOH_SERVERS) {
      dohQuery(srv, name).then((ips) => {
        if (settled) return;
        if (ips && ips.length) {
          settled = true;
          resolve(ips);
          return;
        }
        pending -= 1;
        if (pending <= 0) {
          settled = true;
          resolve([]);
        }
      });
    }
  });
}

// Android 上没有 /etc/resolv.conf，只能用 getaddrinfo（dns.lookup），并把污染结果过滤掉
function systemResolve(name) {
  return new Promise((resolve) => {
    try {
      dns.lookup(name, { all: true, family: 4 }, (err, list) => {
        if (err || !Array.isArray(list)) return resolve([]);
        resolve(list.map((x) => x && x.address).filter((ip) => ip && !BAD_IP.test(ip)));
      });
    } catch (e) {
      resolve([]);
    }
  });
}

async function resolveHost(name) {
  if (!name) return [];
  if (net.isIP(name)) return [name];
  const hit = dnsCache.get(name);
  if (hit && Date.now() < hit.expire) return hit.ips;
  if (dnsPending.has(name)) return dnsPending.get(name);

  const job = (async () => {
    let ips = await dohResolve(name);
    let from = 'doh';
    if (!ips.length) {
      ips = await systemResolve(name);
      from = 'system';
    }
    if (!ips.length) {
      ips = STATIC_IPS[name] || [];
      from = 'static';
    }
    if (ips.length) dnsCache.set(name, { ips, expire: Date.now() + DNS_TTL });
    DIAG.dns[name] = { from, ips, at: new Date().toISOString().slice(11, 19) };
    return ips;
  })();

  dnsPending.set(name, job);
  try {
    return await job;
  } finally {
    dnsPending.delete(name);
  }
}

// 连接候选顺序：上次成功的 → IP+SNI → IP 无 SNI（防 SNI 阻断）→ 域名直连
async function buildRoutes(hostname, isHttps) {
  const routes = [];
  const seen = new Set();
  const add = (host, sni) => {
    if (!host) return;
    const k = `${host}|${sni || ''}`;
    if (seen.has(k)) return;
    seen.add(k);
    routes.push({ host, sni: sni || undefined });
  };
  const sticky = ROUTE_OK.get(hostname);
  if (sticky) add(sticky.host, sticky.sni);
  const ips = net.isIP(hostname) ? [hostname] : await resolveHost(hostname);
  const sni = isHttps && !net.isIP(hostname) ? hostname : undefined;
  for (const ip of ips) add(ip, sni);
  for (const ip of ips) add(ip, undefined);
  add(hostname, undefined);
  return routes;
}

function rawRequest(u, route, method, headers, body, timeout) {
  return new Promise((resolve, reject) => {
    const isHttps = u.protocol === 'https:';
    const mod = isHttps ? https : http;
    const options = {
      host: route.host,
      port: u.port ? Number(u.port) : (isHttps ? 443 : 80),
      method,
      path: u.pathname + (u.search || ''),
      headers,
      timeout: timeout || REQ_TIMEOUT,
      agent: isHttps ? httpsAgent : httpAgent,
    };
    if (isHttps) {
      options.rejectUnauthorized = false;
      if (route.sni) options.servername = route.sni;
    }
    let settled = false;
    const fail = (e) => {
      if (settled) return;
      settled = true;
      reject(e);
    };
    try {
      const req = mod.request(options, (res) => {
        const chunks = [];
        res.on('data', (d) => chunks.push(d));
        res.on('error', fail);
        res.on('end', () => {
          if (settled) return;
          settled = true;
          let buf = Buffer.concat(chunks);
          const enc = String(res.headers['content-encoding'] || '').toLowerCase();
          try {
            if (enc === 'gzip' || enc === 'x-gzip') buf = zlib.gunzipSync(buf);
            else if (enc === 'deflate') buf = zlib.inflateSync(buf);
            else if (enc === 'br' && zlib.brotliDecompressSync) buf = zlib.brotliDecompressSync(buf);
          } catch (e) {
            // 解压失败就保留原始字节，交给上层判断
          }
          resolve({ status: res.statusCode, headers: res.headers, data: buf });
        });
      });
      req.on('error', fail);
      req.on('timeout', () => {
        const e = new Error('timeout');
        e.code = 'ETIMEDOUT';
        req.destroy(e);
        fail(e);
      });
      if (body) req.end(body);
      else req.end();
    } catch (e) {
      fail(e);
    }
  });
}

async function request(url, opt = {}, depth = 0) {
  const u = new URL(url);
  const method = String(opt.method || 'GET').toUpperCase();
  const body = opt.body;
  const headers = Object.assign(
    {
      'User-Agent': UA,
      Accept: '*/*',
      'Accept-Language': 'zh-CN,zh;q=0.9',
      'Accept-Encoding': 'identity',
    },
    opt.headers || {},
  );
  headers.Host = u.port ? `${u.hostname}:${u.port}` : u.hostname;
  if (body) headers['Content-Length'] = Buffer.byteLength(body);

  const routes = await buildRoutes(u.hostname, u.protocol === 'https:');
  let lastErr = null;
  for (const route of routes) {
    try {
      const res = await rawRequest(u, route, method, headers, body, opt.timeout);
      ROUTE_OK.set(u.hostname, route);
      const loc = res.headers && res.headers.location;
      if (loc && res.status >= 300 && res.status < 400 && opt.follow !== false && depth < 4) {
        const next = new URL(loc, u).toString();
        const keep = res.status === 307 || res.status === 308;
        return await request(next, Object.assign({}, opt, {
          method: keep ? method : 'GET',
          body: keep ? body : undefined,
        }), depth + 1);
      }
      return res;
    } catch (e) {
      lastErr = e;
      if (ROUTE_OK.get(u.hostname) === route) ROUTE_OK.delete(u.hostname);
    }
  }
  throw lastErr || new Error('no route to ' + u.hostname);
}

// ---------- 简易缓存 ----------
const CACHE_TTL = 30 * 60 * 1000;
const cache = new Map();

function cacheGet(key) {
  const hit = cache.get(key);
  if (hit && Date.now() < hit.expire) return hit.value;
  if (hit) cache.delete(key);
  return undefined;
}

function cacheSet(key, value, ttl = CACHE_TTL) {
  cache.set(key, { expire: Date.now() + ttl, value });
  return value;
}

// ---------- 加解密 ----------
function deriveKey(rid) {
  const hex = String(rid).replace(/-/g, '');
  return crypto
    .createHmac('sha256', Buffer.from(PLATFORM_KEY, 'utf8'))
    .update(Buffer.from(hex, 'hex'))
    .digest();
}

function encodeBody(key, data) {
  const raw = Buffer.from(JSON.stringify({ token: TOKEN || '', deviceId: DEVICE_ID, data: data || {} }), 'utf8');
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
  return Buffer.concat([iv, cipher.update(zlib.gzipSync(raw)), cipher.final()]);
}

function decodeBody(key, blob) {
  if (!blob || !blob.length) return {};
  if (blob.length >= 32 && (blob.length - 16) % 16 === 0) {
    try {
      const decipher = crypto.createDecipheriv('aes-256-cbc', key, blob.subarray(0, 16));
      let plain = Buffer.concat([decipher.update(blob.subarray(16)), decipher.final()]);
      if (plain[0] === 0x1f && plain[1] === 0x8b) plain = zlib.gunzipSync(plain);
      return JSON.parse(plain.toString('utf8'));
    } catch (e) {
      // 落到明文分支：少数错误响应是裸 JSON
    }
  }
  try {
    return JSON.parse(blob.toString('utf8'));
  } catch (e) {
    return {};
  }
}

async function apiPost(path, data, silent = false) {
  const url = '/' + String(path || '').replace(/^\/+/, '');
  for (let attempt = 0; attempt < 2; attempt++) {
    const rid = uuid();
    const key = deriveKey(rid);
    const ts = Math.floor(Date.now() / 1000);
    const sign = crypto.createHash('sha256').update(`Dart|${SESSION_ID}|${rid}|${ts}|${url}`).digest('hex') + '-' + ts;
    try {
      const res = await request(HOST + '/api' + url, {
        method: 'POST',
        body: encodeBody(key, data),
        timeout: REQ_TIMEOUT,
        headers: {
          'Content-Type': 'application/octet-stream',
          Origin: HOST,
          Referer: HOST + '/home',
          version: VERSION,
          deviceType: DEVICE_TYPE,
          time: String(ts),
          sign,
          requestId: rid,
          sessionId: SESSION_ID,
          deviceBrand: '',
          deviceModel: '',
          systemName: '',
          systemVersion: '',
        },
      });
      if (res.status !== 200) {
        noteErr('api' + url, 'status ' + res.status);
        if (!silent) console.error(`[${SITE_NAME}] api ${url} status:`, res.status);
        if (attempt === 0) continue;
        return {};
      }
      return decodeBody(key, Buffer.from(res.data));
    } catch (e) {
      const msg = noteErr('api' + url, e);
      if (attempt === 0) continue;
      if (!silent) console.error(`[${SITE_NAME}] api ${url} error:`, msg);
      return {};
    }
  }
  return {};
}

// ---------- 通用工具 ----------
function intOf(x, def = 0) {
  const n = parseInt(x, 10);
  return Number.isNaN(n) ? def : n;
}

function sid(x) {
  return String(x == null ? '' : x).trim().replace(/^rp_/, '');
}

// 名称里出现 $ # | 会破坏 vod_play_url 协议，必须先洗掉
function sanitize(text) {
  return String(text || '')
    .replace(/[$#|]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function pickList(data) {
  if (Array.isArray(data)) return data;
  if (!data || typeof data !== 'object') return [];
  if (Array.isArray(data.list)) return data.list;
  if (Array.isArray(data.items)) return data.items;
  if (Array.isArray(data.data)) return data.data;
  if (data.data && typeof data.data === 'object') return pickList(data.data);
  return [];
}

function flattenBlocks(blocks) {
  const items = [];
  for (const b of blocks) {
    if (!b || typeof b !== 'object') continue;
    if (Array.isArray(b.items)) items.push(...b.items);
    else if (b.id || b.drama_id) items.push(b);
  }
  return items;
}

function picOf(item) {
  return item.img_y || item.img_x || item.img || item.cover || item.pic || '';
}

function vodOf(item) {
  const it = item || {};
  const vid = sid(it.id || it.drama_id || '');
  const count = intOf(it.episode_count, 0);
  return {
    vod_id: vid,
    vod_name: it.name || it.title || it.t || vid,
    vod_pic: picOf(it),
    vod_remarks: it.update_label || it.corner || (count ? `全${count}集` : ''),
  };
}

function bareHls(vid, seq, line) {
  return `${HOST}/api/drama/hls/${sid(vid)}/${seq}/play.m3u8?line=${line || 'free'}`;
}

function switchLine(url, line) {
  const target = line || 'free';
  if (/[?&]line=/.test(url)) return url.replace(/([?&]line=)[^&]*/, `$1${target}`);
  return url + (url.includes('?') ? '&' : '?') + 'line=' + target;
}

// 播放 id 形如 vid~seq~line（~ 是 URL 保留字之外的安全字符，不会被转义）
function splitPlayId(x) {
  const parts = String(x || '').split(/[~|]/);
  const vid = sid(parts[0]);
  const seq = intOf(parts[1], 1) || 1;
  const line = (parts[2] || '').trim();
  const valid = LINES.some((l) => l.name === line);
  return { vid, seq, line: valid ? line : 'free' };
}

function extendOf(q) {
  const ext = {};
  if (q.f) {
    try {
      const obj = JSON.parse(q.f);
      if (obj && typeof obj === 'object') Object.assign(ext, obj);
    } catch (e) {
      // 忽略非法筛选串
    }
  }
  for (const k of ['sub', 'order', 'update_status', 'tag_id']) {
    if (q[k] !== undefined && q[k] !== null && q[k] !== '') ext[k] = q[k];
  }
  return ext;
}

// 支持 ext 传 {"site":"https://xxx","token":"..."} 或直接一个域名
function applyExt(ext) {
  if (!ext) return;
  let host = '';
  let token;
  const raw = String(ext).trim();
  if (raw.startsWith('{')) {
    try {
      const cfg = JSON.parse(raw);
      host = String(cfg.site || cfg.url || cfg.host || '').trim();
      if (cfg.token !== undefined) token = String(cfg.token);
    } catch (e) {
      return;
    }
  } else if (/^https?:\/\//i.test(raw)) {
    host = raw;
  }
  if (host) {
    host = host.replace(/\/+$/, '');
    if (host !== HOST) {
      HOST = host;
      cache.clear();
    }
  }
  if (token !== undefined) TOKEN = token;
}

// ---------- 本地 HLS 代理 ----------
// 播放列表在被污染的主站上，播放器用系统 DNS 取不到；这里只监听 127.0.0.1，
// 播放列表由本源代取并改写，分片和密钥仍然让播放器直连 CloudFront
let proxyServer = null;
let proxyBase = '';
let proxyStarting = null;
const playlistCache = new Map();
const PLAYLIST_TTL = 60 * 60 * 1000;

function b64url(s) {
  return Buffer.from(String(s), 'utf8').toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function unb64url(s) {
  return Buffer.from(String(s || '').replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8');
}

// 只允许代理主站自己的地址，别在设备上留一个任意转发的开放代理
function allowTarget(url) {
  const h = hostOf(url);
  return !!h && h === hostOf(HOST);
}

function rewritePlaylist(text, baseUrl) {
  const fix = (raw) => {
    let abs;
    try {
      abs = new URL(raw, baseUrl).toString();
    } catch (e) {
      return raw;
    }
    return allowTarget(abs) && proxyBase ? `${proxyBase}/p?u=${b64url(abs)}` : abs;
  };
  return String(text)
    .split('\n')
    .map((line) => {
      const s = line.trim();
      if (!s) return line;
      if (s.startsWith('#')) return line.replace(/URI="([^"]+)"/g, (m, v) => `URI="${fix(v)}"`);
      return fix(s);
    })
    .join('\n');
}

async function onProxyRequest(req, res) {
  const send = (code, type, buf) => {
    try {
      res.writeHead(code, {
        'Content-Type': type,
        'Access-Control-Allow-Origin': '*',
        'Cache-Control': 'no-cache',
      });
      res.end(buf);
    } catch (e) {
      // 播放器提前断开，忽略
    }
  };
  try {
    const u = new URL(req.url, 'http://127.0.0.1');
    if (u.pathname.startsWith('/m3u8/')) {
      const token = u.pathname.slice(6).replace(/\.m3u8$/i, '');
      const hit = playlistCache.get(token);
      if (!hit || Date.now() > hit.expire) {
        playlistCache.delete(token);
        return send(404, 'text/plain', 'expired');
      }
      return send(200, 'application/vnd.apple.mpegurl', hit.body);
    }
    if (u.pathname === '/p') {
      const target = unb64url(u.searchParams.get('u') || '');
      if (!/^https?:\/\//i.test(target) || !allowTarget(target)) return send(403, 'text/plain', 'forbidden');
      const r = await request(target, {
        timeout: REQ_TIMEOUT,
        headers: { Referer: HOST + '/home', Origin: HOST, Accept: '*/*' },
      });
      const ctype = String((r.headers && r.headers['content-type']) || '');
      let out = Buffer.from(r.data);
      if (/mpegurl|m3u8/i.test(ctype) || out.toString('utf8', 0, 7) === '#EXTM3U') {
        out = Buffer.from(rewritePlaylist(out.toString('utf8'), target), 'utf8');
        return send(r.status || 200, 'application/vnd.apple.mpegurl', out);
      }
      return send(r.status || 200, ctype || 'application/octet-stream', out);
    }
    return send(404, 'text/plain', 'not found');
  } catch (e) {
    noteErr('proxy', e);
    return send(502, 'text/plain', 'proxy error');
  }
}

function startProxy() {
  if (proxyBase) return Promise.resolve(proxyBase);
  if (proxyStarting) return proxyStarting;
  proxyStarting = new Promise((resolve) => {
    try {
      proxyServer = http.createServer(onProxyRequest);
      proxyServer.on('error', (e) => {
        noteErr('proxy-listen', e);
        proxyBase = '';
        resolve('');
      });
      proxyServer.listen(0, '127.0.0.1', () => {
        const addr = proxyServer.address();
        proxyBase = `http://127.0.0.1:${addr && addr.port}`;
        resolve(proxyBase);
      });
    } catch (e) {
      noteErr('proxy-start', e);
      resolve('');
    }
  });
  return proxyStarting;
}

function publishPlaylist(text, baseUrl) {
  const token = crypto.randomBytes(8).toString('hex');
  const body = Buffer.from(rewritePlaylist(text, baseUrl), 'utf8');
  playlistCache.set(token, { body, expire: Date.now() + PLAYLIST_TTL });
  if (playlistCache.size > 128) {
    const now = Date.now();
    for (const [k, v] of playlistCache) if (now > v.expire) playlistCache.delete(k);
  }
  return `${proxyBase}/m3u8/${token}.m3u8`;
}

async function fetchPlaylist(url) {
  try {
    const res = await request(url, {
      timeout: 12000,
      headers: { Referer: HOST + '/home', Origin: HOST, Accept: '*/*' },
    });
    if (res.status !== 200) return '';
    const text = Buffer.from(res.data).toString('utf8');
    return text.trimStart().startsWith('#EXTM3U') ? text : '';
  } catch (e) {
    noteErr('m3u8', e);
    return '';
  }
}

// ---------- 分类 / 筛选 ----------
async function getClasses() {
  const hit = cacheGet('classes');
  if (hit) return hit;
  const classes = [{ type_id: 'all', type_name: '全部短剧' }];
  const items = pickList(await apiPost('/drama/navList', {}));
  for (const it of items) {
    const tid = String((it && (it.code || it.id || it.cat_id)) || '').trim();
    const name = (it && (it.name || it.title)) || tid;
    if (tid && name) classes.push({ type_id: tid, type_name: name });
  }
  // 只有兜底项说明接口没通，别把空结果缓存 30 分钟
  if (classes.length === 1) return classes;
  return cacheSet('classes', classes);
}

// 每个导航下的子分类：navFilter 优先，没有 cat_id 的（如黄豆原创只有 recommend 页）用 navBlock 拆板块
async function getSubs(code) {
  const key = `subs:${code}`;
  const hit = cacheGet(key);
  if (hit) return hit;

  const tabs = pickList(await apiPost('/drama/navFilter', { code: String(code) }));
  let subs = tabs
    .map((t) => {
      const f = (t && t.filter) || {};
      return {
        name: sanitize((t && (t.name || t.title)) || ''),
        cat_id: String(f.cat_id || ''),
        tag_id: String(f.tag_id || ''),
        order: String(f.order || ''),
        tab: String((t && t.tab) || ''),
      };
    })
    .filter((s) => s.name);

  if (!subs.some((s) => s.cat_id)) {
    const tab = (subs[0] && subs[0].tab) || 'recommend';
    const blocks = pickList(await apiPost('/drama/navBlock', { code: String(code), tab, page: '1' }));
    const fromBlocks = blocks
      .filter((b) => b && b.filter && b.filter.cat_id)
      .map((b) => ({
        name: sanitize(b.name || b.sub_name || '板块'),
        cat_id: String(b.filter.cat_id),
        tag_id: String(b.filter.tag_id || ''),
        order: String(b.filter.order || ''),
        tab,
      }));
    if (fromBlocks.length) subs = fromBlocks;
  }
  if (!subs.length) return subs;
  return cacheSet(key, subs);
}

function pickSub(subs, value) {
  if (!subs.length) return null;
  const v = String(value == null ? '' : value).trim();
  if (!v) return subs[0];
  const byCat = subs.find((s) => s.cat_id && s.cat_id === v);
  if (byCat) return byCat;
  const m = v.match(/^#(\d+)$/);
  if (m) {
    const i = intOf(m[1], 0);
    return subs[i] || subs[0];
  }
  // 允许直接传未在列表里的 cat_id
  if (/^\d+$/.test(v)) return { name: v, cat_id: v, tag_id: '', order: '', tab: '' };
  return subs[0];
}

async function buildFilters(classes) {
  const key = 'filters';
  const hit = cacheGet(key);
  if (hit) return hit;
  const filters = {};
  const codes = classes.filter((c) => c.type_id !== 'all').map((c) => c.type_id);
  const subsList = await Promise.all(codes.map((code) => getSubs(code).catch(() => [])));
  filters.all = [ORDER_FILTER, STATUS_FILTER];
  codes.forEach((code, i) => {
    const subs = subsList[i] || [];
    const head = subs.length
      ? [{
          key: 'sub',
          name: '分类',
          value: subs.map((s, idx) => ({ n: s.name || `分类${idx + 1}`, v: s.cat_id || `#${idx}` })),
        }]
      : [];
    filters[code] = head.concat([ORDER_FILTER, STATUS_FILTER]);
  });
  return cacheSet(key, filters);
}

// ---------- 主流程 ----------
async function getHome() {
  const classes = await getClasses();
  const [filters, data] = await Promise.all([
    buildFilters(classes).catch(() => ({})),
    apiPost('/drama/list', { page: '1', page_size: String(PAGE_SIZE) }),
  ]);
  let list = pickList(data).map(vodOf);
  if (!list.length && recentFail()) list = [failCard()];
  return {
    class: classes,
    filters,
    list,
    parse: 0,
    jx: 0,
  };
}

function pageResult(list, page, single = false) {
  if (!list.length && page === 1 && recentFail()) list = [failCard()];
  const pagecount = single || list.length < PAGE_SIZE ? page : page + 1;
  return {
    list,
    page,
    pagecount,
    limit: PAGE_SIZE,
    total: pagecount > page ? 99999 : (page - 1) * PAGE_SIZE + list.length,
    parse: 0,
    jx: 0,
  };
}

async function getCategory(tid, pg = 1, ext = {}) {
  const page = Math.max(intOf(pg, 1), 1);
  const id = String(tid || 'all');
  const req = { page: String(page), page_size: String(PAGE_SIZE) };
  let items = null;
  let single = false;

  if (id !== 'all') {
    const subs = await getSubs(id);
    const sel = pickSub(subs, ext.sub);
    if (sel && sel.cat_id) {
      req.cat_id = sel.cat_id;
      const tag = ext.tag_id || sel.tag_id;
      if (tag) req.tag_id = tag;
      req.order = ext.order !== undefined && ext.order !== '' ? String(ext.order) : sel.order || '';
    } else {
      // 该导航没有可用 cat_id，只能取板块数据（接口不分页）
      const blocks = pickList(await apiPost('/drama/navBlock', {
        code: id,
        tab: (sel && sel.tab) || 'recommend',
        page: String(page),
      }));
      items = flattenBlocks(blocks);
      single = true;
      // 板块也没数据时退回全站列表，避免整个分类空白
      if (!items.length) {
        items = null;
        single = false;
      }
    }
  } else if (ext.order) {
    req.order = String(ext.order);
  }

  if (!items) {
    if (ext.update_status) req.update_status = String(ext.update_status);
    items = pickList(await apiPost('/drama/list', req));
  }
  return pageResult(items.map(vodOf), page, single);
}

async function doSearch(wd, pg = 1) {
  const page = Math.max(intOf(pg, 1), 1);
  const keyword = String(wd || '').trim();
  if (!keyword) return pageResult([], page, true);
  const data = await apiPost('/drama/list', {
    page: String(page),
    page_size: String(PAGE_SIZE),
    keywords: keyword,
  });
  return pageResult(pickList(data).map(vodOf), page);
}

function episodeName(ep, seq) {
  const name = sanitize((ep && (ep.name || ep.title)) || '');
  if (!name || /^\d+$/.test(name)) return `第${seq}集`;
  return name;
}

async function getDetail(ids) {
  const raw = String(ids || '').split(',')[0];
  // 点击错误占位卡时把完整诊断信息摆出来
  if (raw === '__diag__') {
    let info;
    try {
      info = JSON.stringify(await diagnose(), null, 1);
    } catch (e) {
      info = String((e && e.message) || e);
    }
    return {
      list: [{
        vod_id: '__diag__',
        vod_name: `${SITE_NAME} 诊断`,
        vod_pic: '',
        vod_remarks: BUILD,
        vod_content: info,
        vod_play_from: '',
        vod_play_url: '',
      }],
      parse: 0,
      jx: 0,
    };
  }
  const vid = sid(raw);
  if (!vid) return { list: [], parse: 0, jx: 0 };
  const obj = await apiPost('/drama/detail', { id: vid });
  const data = obj && typeof obj.data === 'object' && obj.data ? obj.data : {};
  if (!data.id && !data.drama_id && !data.name) {
    console.error(`[${SITE_NAME}] detail empty:`, vid, (obj && obj.error) || '');
    return { list: [], parse: 0, jx: 0 };
  }

  const vodId = sid(data.id || data.drama_id || vid);
  const eps = Array.isArray(data.episodes) ? data.episodes : [];
  const count = Math.min(Math.max(intOf(data.episode_count, eps.length || 1), 1), 5000);

  const nodes = eps.length
    ? eps.map((ep, i) => {
        const seq = intOf(ep && (ep.seq || ep.episode || ep.ep), i + 1) || i + 1;
        return { seq, name: episodeName(ep, seq) };
      })
    : Array.from({ length: count }, (_, i) => ({ seq: i + 1, name: `第${i + 1}集` }));

  const playFrom = LINES.map((l) => l.label);
  const playUrl = LINES.map((l) => nodes.map((n) => `${n.name}$${vodId}~${n.seq}~${l.name}`).join('#'));

  const tags = Array.isArray(data.tags) ? data.tags.map((t) => (typeof t === 'string' ? t : t && t.name)).filter(Boolean) : [];
  const name = data.name || data.title || data.t || vodId;

  return {
    list: [
      {
        vod_id: vodId,
        vod_name: name,
        vod_pic: picOf(data),
        type_name: data.category || data.type_name || '',
        vod_year: String(data.issue_date || '').slice(0, 4),
        vod_area: '',
        vod_remarks: data.update_label || `全${count}集`,
        vod_actor: tags.join(' / '),
        vod_director: data.publisher || '',
        vod_content: data.description || data.summary || name,
        vod_play_from: playFrom.join('$$$'),
        vod_play_url: playUrl.join('$$$'),
      },
    ],
    parse: 0,
    jx: 0,
  };
}

async function getPlay(playId) {
  const headers = { 'User-Agent': UA, Referer: HOST + '/home', Origin: HOST };
  const { vid, seq, line } = splitPlayId(playId);
  if (!vid) return { parse: 0, jx: 0, url: '', playUrl: '', header: headers, message: '播放参数为空' };

  // 无签名直链不带 exp（接口签名只有 5 分钟），金币/VIP 锁集也能直出，优先用
  let upstream = bareHls(vid, seq, line);
  let text = await fetchPlaylist(upstream);

  if (!text) {
    // 直链被拦时回退到接口的签名地址
    const obj = await apiPost('/drama/play', { id: vid, seq: String(seq) }, true);
    const data = obj && typeof obj.data === 'object' && obj.data ? obj.data : {};
    const lines = Array.isArray(data.lines) ? data.lines : [];
    const hit = lines.find((l) => l && String(l.name) === line && l.url);
    let url = '';
    if (hit) url = String(hit.url);
    else if (data.m3u8) url = switchLine(String(data.m3u8), line);
    else if (data.url) url = String(data.url);
    if (url) {
      upstream = url;
      text = await fetchPlaylist(upstream);
    }
  }

  // 主站域名在国内被 DNS 污染，播放器直接取列表会失败，交给本地代理
  const base = await startProxy();
  if (text && base) return { parse: 0, playUrl: '', url: publishPlaylist(text, upstream), jx: 0, header: headers };
  return { parse: 0, playUrl: '', url: upstream, jx: 0, header: headers };
}

// ---------- 诊断 ----------
async function diagnose() {
  const hostname = hostOf(HOST);
  const t0 = Date.now();
  const nav = pickList(await apiPost('/drama/navList', {}));
  const apiMs = Date.now() - t0;
  const [doh, sys] = await Promise.all([dohResolve(hostname), systemResolve(hostname)]);
  const base = await startProxy();
  return {
    site: SITE_NAME,
    build: BUILD,
    node: process.version,
    host: HOST,
    api: { ms: apiMs, nav: nav.length },
    dns: { doh, system: sys, static: STATIC_IPS[hostname] || [], used: DIAG.dns[hostname] || null },
    route: ROUTE_OK.get(hostname) || null,
    proxy: base || '(启动失败)',
    errors: DIAG.errors.slice(-8),
  };
}

async function handle(req) {
  const q = req.query || {};
  applyExt(q.ext);
  if (q.diag) return await diagnose();
  const ac = q.ac;
  const isPlay = !!q.play || ac === 'play' || (!!q.flag && !!q.id);
  const wd = q.wd || q.key || q.keyword;
  const tid = q.t || q.type_id;
  // 分类请求同样带 ac=detail，只有明确 ids / 非分类 id 才当详情
  const ids = q.ids || (q.id && !isPlay && !tid ? q.id : '');
  if (isPlay) return await getPlay(q.play || q.id);
  if (ids) return await getDetail(ids);
  if (wd) return await doSearch(wd, q.pg || 1);
  if (tid && String(tid) !== '0') return await getCategory(tid, q.pg || 1, extendOf(q));
  return await getHome();
}

module.exports = async (app, opt) => {
  const path = '/video/hddj';
  app.get(path, async (req) => await handle(req));
  app.get('/video/黄豆短剧', async (req) => await handle(req));
  opt.sites.push({
    key: 'hddj',
    name: '[短]黄豆短剧+',
    type: 4,
    api: path,
    searchable: 1,
    quickSearch: 1,
    filterable: 1,
    changeable: 0,
    ext: '',
  });
};
