const crypto = require("crypto");
const axios = require("axios");
const cheerio = require("cheerio");
const https = require("https");

// ========== 全局配置 ==========
const host = "https://zrys.pw";

const headers = {
    "User-Agent": "Mozilla/5.0 (Linux; Android 13; M2102J2S Build/TKQ1.221114.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/143.0.7499.3 Mobile Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2",
    "Accept-Encoding": "gzip, deflate, br",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
    "Cache-Control": "max-age=0"
};

// 站点分类配置
const CATEGORIES = [
    { type_id: "1", type_name: "电影" },
    { type_id: "2", type_name: "剧集" },
    { type_id: "3", type_name: "综艺" },
    { type_id: "4", type_name: "动漫" },
    { type_id: "47", type_name: "短视频" }
];

// 分类筛选条件
const FILTERS = {
    "1": [{
        "key": "class",
        "name": "类型",
        "value": [
            { "n": "全部", "v": "" },
            { "n": "动作片", "v": "6" },
            { "n": "喜剧片", "v": "7" },
            { "n": "爱情片", "v": "8" },
            { "n": "科幻片", "v": "9" },
            { "n": "恐怖片", "v": "11" }
        ]
    }],
    "2": [{
        "key": "class",
        "name": "类型",
        "value": [
            { "n": "全部", "v": "" },
            { "n": "国产剧", "v": "13" },
            { "n": "港台剧", "v": "14" },
            { "n": "日剧", "v": "15" },
            { "n": "韩剧", "v": "33" },
            { "n": "欧美剧", "v": "16" }
        ]
    }],
    "3": [{
        "key": "class",
        "name": "类型",
        "value": [
            { "n": "全部", "v": "" },
            { "n": "内地综艺", "v": "27" },
            { "n": "港台综艺", "v": "28" },
            { "n": "韩国综艺", "v": "29" },
            { "n": "日本综艺", "v": "36" }
        ]
    }],
    "4": [{
        "key": "class",
        "name": "类型",
        "value": [
            { "n": "全部", "v": "" },
            { "n": "国产动漫", "v": "31" },
            { "n": "日本动漫", "v": "32" },
            { "n": "欧美动漫", "v": "42" },
            { "n": "其他动漫", "v": "43" }
        ]
    }]
};

// 缓存系统
class CacheManager {
    constructor(ttl = 300000) { // 5分钟缓存
        this.cache = new Map();
        this.ttl = ttl;
    }

    get(key) {
        const item = this.cache.get(key);
        if (!item) return null;
        
        if (Date.now() - item.timestamp > this.ttl) {
            this.cache.delete(key);
            return null;
        }
        
        return item.data;
    }

    set(key, data) {
        this.cache.set(key, { data, timestamp: Date.now() });
    }

    clear() {
        this.cache.clear();
    }
}

// 全局缓存实例
const cache = new CacheManager();

// 优化axios实例配置
const axiosInstance = axios.create({
    httpsAgent: new https.Agent({ 
        rejectUnauthorized: false,
        keepAlive: true,
        maxSockets: 5
    }),
    timeout: 15000,
    maxRedirects: 0
});

// ========== 工具函数 ==========
const utils = {
    // 处理图片URL
    processImageUrl: (url) => {
        if (!url) return "";
        
        if (url.startsWith("http")) {
            return url;
        } else if (url.startsWith("//")) {
            return "https:" + url;
        } else {
            return host + url;
        }
    },

    // 清理文本
    cleanText: (text) => {
        if (!text) return "";
        return text.replace(/<[^>]*>/g, "").trim();
    },

    // 提取数字
    extractNumber: (text) => {
        const match = text.match(/\d+/);
        return match ? parseInt(match[0]) : 0;
    },

    // 延迟函数
    delay: (ms) => new Promise(resolve => setTimeout(resolve, ms))
};

// ========== 请求处理工具 ==========
const requestUtil = {
    // 发送HTTP请求（带重试）
    sendRequest: async (url, retryCount = 0) => {
        const maxRetries = 3;
        
        try {
            if (global.store) global.store.log.debug(`发送请求: ${url}, 重试次数: ${retryCount}`);
            
            const response = await axiosInstance.get(url, {
                headers,
                timeout: 10000
            });
            
            if (!response.data) {
                throw new Error("响应数据为空");
            }
            
            return response.data;
            
        } catch (e) {
            if (e.code === 'ECONNRESET' || e.code === 'ETIMEDOUT' || 
                e.message.includes('timeout') || e.message.includes('network')) {
                
                if (retryCount < maxRetries) {
                    const delay = 1000 * (retryCount + 1);
                    if (global.store) global.store.log.warn(`网络错误，${delay}ms后第 ${retryCount + 1} 次重试...`);
                    await utils.delay(delay);
                    return await requestUtil.sendRequest(url, retryCount + 1);
                }
            }
            
            if (global.store) global.store.log.error(`HTTP请求失败 (重试 ${retryCount} 次): ${e.message}`);
            throw e;
        }
    },

    // 解析视频列表
    parseVideoList: (html) => {
        const $ = cheerio.load(html);
        const list = [];
        
        // 多种选择器尝试
        const selectors = [
            ".module-play-list a",
            ".module-item",
            ".video-item",
            ".module-card-item",
            ".module-list .module-item"
        ];
        
        for (const selector of selectors) {
            $(selector).each((_, el) => {
                try {
                    const $el = $(el);
                    const href = $el.attr("href") || "";
                    
                    // 提取视频ID
                    let vodId = "";
                    const idMatch = href.match(/\/detail\/id\/(\d+)\.html/);
                    if (idMatch) {
                        vodId = idMatch[1];
                    } else {
                        // 尝试其他格式的ID
                        const otherIdMatch = href.match(/\/vod\/detail\/id\/(\d+)/);
                        if (otherIdMatch) vodId = otherIdMatch[1];
                    }
                    
                    if (!vodId) return;
                    
                    // 提取标题
                    let title = $el.attr("title") || 
                               $el.find("img").attr("alt") || 
                               $el.find(".module-item-text").text() ||
                               $el.find(".video-title").text() ||
                               $el.find(".title").text() ||
                               $el.text().trim();
                    
                    title = utils.cleanText(title);
                    if (!title) return;
                    
                    // 提取图片
                    let pic = $el.find("img").attr("data-original") || 
                             $el.find("img").attr("data-src") ||
                             $el.find("img").attr("src") ||
                             $el.attr("data-original") ||
                             $el.attr("data-src") || "";
                    
                    pic = utils.processImageUrl(pic);
                    
                    // 提取备注/状态
                    let remarks = $el.find(".module-item-note").text() || 
                                 $el.find(".video-item-note").text() ||
                                 $el.find(".pic-text").text() ||
                                 $el.find(".note").text() ||
                                 $el.find(".remarks").text() ||
                                 "";
                    
                    remarks = utils.cleanText(remarks);
                    
                    // 避免重复添加
                    if (!list.some(item => item.vod_id === vodId)) {
                        list.push({
                            vod_id: vodId,
                            vod_name: title,
                            vod_pic: pic,
                            vod_remarks: remarks
                        });
                    }
                } catch (e) {
                    if (global.store) global.store.log.debug(`解析列表项失败: ${e.message}`);
                }
            });
            
            if (list.length > 0) break;
        }
        
        return list;
    },

    // 获取总页数
    getTotalPages: (html) => {
        try {
            const $ = cheerio.load(html);
            
            // 尝试多种方式获取总页数
            let totalPages = 1;
            
            // 方式1: 分页元素
            const pageItems = $(".page-item, .pagination li");
            if (pageItems.length > 0) {
                const lastPageText = pageItems.last().prev().text();
                const num = utils.extractNumber(lastPageText);
                if (num > 0) totalPages = num;
            }
            
            // 方式2: 文本匹配
            const pageMatch = html.match(/共\s*(\d+)\s*页/);
            if (pageMatch && pageMatch[1]) {
                totalPages = parseInt(pageMatch[1]);
            }
            
            // 方式3: 总条数计算
            const totalMatch = html.match(/共\s*(\d+)\s*条/);
            if (totalMatch && totalMatch[1]) {
                const totalItems = parseInt(totalMatch[1]);
                totalPages = Math.ceil(totalItems / 30); // 假设每页30条
            }
            
            return Math.max(1, totalPages);
        } catch (e) {
            return 1;
        }
    }
};

// ========== 主要功能函数 ==========
const _home = async ({ filter }) => {
    return {
        class: CATEGORIES,
        filters: FILTERS
    };
};

const _category = async ({ id, page, filter, filters }) => {
    const pg = page || 1;
    
    if (global.store) global.store.log.info(`获取分类数据: id=${id}, page=${pg}`);
    
    // 缓存键
    const cacheKey = `category_${id}_${pg}_${JSON.stringify(filters || {})}`;
    const cached = cache.get(cacheKey);
    if (cached) {
        if (global.store) global.store.log.debug(`缓存命中: ${cacheKey}`);
        return cached;
    }
    
    try {
        let url = `${host}/index.php/vod/show/id/${id}`;
        
        // 添加筛选条件
        if (filters && filters.class) {
            url += `/class/${filters.class}`;
        }
        
        // 添加分页
        if (pg > 1) {
            url += `/page/${pg}`;
        }
        
        url += ".html";
        
        const html = await requestUtil.sendRequest(url);
        const list = requestUtil.parseVideoList(html);
        
        const pagecount = requestUtil.getTotalPages(html);
        
        const result = {
            list,
            page: pg,
            pagecount: pagecount
        };
        
        // 缓存结果
        cache.set(cacheKey, result);
        
        if (global.store) global.store.log.info(`成功获取到 ${list.length} 条数据，总页数: ${pagecount}`);
        
        return result;
        
    } catch (e) {
        if (global.store) global.store.log.error(`分类数据获取失败: ${e.message}`);
        return { list: [], page: pg, pagecount: 0 };
    }
};

const _detail = async ({ ids }) => {
    if (!ids) {
        return { list: [] };
    }
    
    const idList = Array.isArray(ids) ? ids : [ids];
    const videos = [];
    
    for (const id of idList) {
        try {
            // 缓存键
            const cacheKey = `detail_${id}`;
            const cached = cache.get(cacheKey);
            if (cached) {
                videos.push(cached);
                continue;
            }
            
            const url = `${host}/index.php/vod/detail/id/${id}.html`;
            const html = await requestUtil.sendRequest(url);
            const $ = cheerio.load(html);
            
            // 提取基本信息
            const vodName = $("h1").text().trim() || 
                           $(".module-info-heading h1").text().trim() ||
                           $(".title").text().trim();
            
            if (!vodName) continue;
            
            // 提取图片
            let vodPic = $(".module-item-pic img").attr("data-original") || 
                        $(".module-item-pic img").attr("src") ||
                        $(".video-cover img").attr("data-original") ||
                        $(".video-cover img").attr("src") ||
                        $("img[data-original]").attr("data-original") ||
                        $("img[src]").attr("src") || "";
            
            vodPic = utils.processImageUrl(vodPic);
            
            // 提取年份
            let vodYear = "";
            const yearMatch = html.match(/title="(\d{4})" href="[^"]*year\/(\d{4})/);
            if (yearMatch) {
                vodYear = yearMatch[1];
            } else {
                const yearText = $("a[href*='year']").text();
                vodYear = utils.extractNumber(yearText);
            }
            
            // 提取地区
            let vodArea = "";
            const areaMatch = html.match(/<a title="([^"]+)" href="[^"]*area\/([^"]+)\/id\//);
            if (areaMatch) {
                vodArea = areaMatch[1];
            } else {
                vodArea = $("a[href*='area']").first().text().trim();
            }
            
            // 提取导演
            let vodDirector = "";
            const directorMatch = html.match(/导演：<\/span>\s*<div[^>]*>([\s\S]*?)<\/div>/);
            if (directorMatch) {
                const directorHtml = directorMatch[1];
                const $director = cheerio.load(directorHtml);
                const directors = [];
                $director("a").each((_, el) => {
                    directors.push($director(el).text().trim());
                });
                vodDirector = directors.join(",");
            }
            
            // 提取演员
            let vodActor = "";
            const actorMatch = html.match(/主演：<\/span>\s*<div[^>]*>([\s\S]*?)<\/div>/);
            if (actorMatch) {
                const actorHtml = actorMatch[1];
                const $actor = cheerio.load(actorHtml);
                const actors = [];
                $actor("a").each((_, el) => {
                    actors.push($actor(el).text().trim());
                });
                vodActor = actors.join(",");
            }
            
            // 提取简介
            let vodContent = "";
            const contentMatch = html.match(/module-info-introduction[^>]*>.*?<p>([\s\S]*?)<\/p>/);
            if (contentMatch) {
                vodContent = utils.cleanText(contentMatch[1]);
            } else {
                vodContent = $(".module-info-introduction p").text().trim();
            }
            
            // 提取播放线路和地址
            const playLines = [];
            const playUrls = [];
            
            // 提取播放线路
            $(".module-play-list-link .module-tab-item").each((index, el) => {
                const lineName = $(el).find("span").text().trim() || `线路${index + 1}`;
                playLines.push(lineName);
            });
            
            // 如果没有线路，设置默认
            if (playLines.length === 0) {
                playLines.push("默认线路");
            }
            
            // 提取播放地址
            $(".module-play-list-content").each((index, contentEl) => {
                const $content = $(contentEl);
                const episodes = [];
                
                $content.find("a").each((epIndex, episodeEl) => {
                    const $episode = $(episodeEl);
                    const episodeName = $episode.find("span").text().trim() || `第${epIndex + 1}集`;
                    const episodeHref = $episode.attr("href") || "";
                    
                    // 提取播放ID
                    const playIdMatch = episodeHref.match(/\/play\/id\/(.*?)\.html/);
                    if (playIdMatch) {
                        episodes.push(`${episodeName}$${playIdMatch[1]}`);
                    }
                });
                
                if (episodes.length > 0) {
                    playUrls.push(episodes.join("#"));
                }
            });
            
            // 如果没找到播放地址，尝试其他选择器
            if (playUrls.length === 0) {
                $(".module-list a, .play-list a").each((_, el) => {
                    const href = $(el).attr("href") || "";
                    const text = $(el).text().trim();
                    const playIdMatch = href.match(/\/play\/id\/(.*?)\.html/);
                    if (playIdMatch && text) {
                        playUrls.push(`${text}$${playIdMatch[1]}`);
                    }
                });
            }
            
            // 如果还是没有，尝试直接匹配
            if (playUrls.length === 0) {
                const playMatches = html.match(/\/play\/id\/([^"']+)\.html/g);
                if (playMatches) {
                    const uniqueIds = [...new Set(playMatches.map(m => m.match(/\/play\/id\/([^"']+)\.html/)[1]))];
                    uniqueIds.forEach((id, index) => {
                        playUrls.push(`第${index + 1}集$${id}`);
                    });
                }
            }
            
            const videoDetail = {
                vod_id: id,
                vod_name: vodName,
                vod_pic: vodPic,
                vod_year: vodYear,
                vod_area: vodArea,
                vod_director: vodDirector,
                vod_actor: vodActor,
                vod_content: vodContent,
                vod_play_from: playLines.join("$$$"),
                vod_play_url: playUrls.join("$$$")
            };
            
            // 缓存详情
            cache.set(cacheKey, videoDetail);
            videos.push(videoDetail);
            
        } catch (e) {
            if (global.store) global.store.log.error(`获取详情失败 ${id}: ${e.message}`);
        }
    }
    
    return { list: videos };
};

const _play = async ({ id, flags }) => {
    if (!id) {
        return { parse: 0, url: '' };
    }
    
    try {
        // 缓存键
        const cacheKey = `play_${id}`;
        const cached = cache.get(cacheKey);
        if (cached) {
            return cached;
        }
        
        const url = `${host}/index.php/vod/play/id/${id}.html`;
        const html = await requestUtil.sendRequest(url);
        
        // 尝试多种方式提取播放地址
        let playUrl = "";
        
        // 方式1: 直接匹配m3u8
        const m3u8Match = html.match(/"url"\s*:\s*"([^"]+\.m3u8)"/);
        if (m3u8Match) {
            playUrl = m3u8Match[1].replace(/\\\//g, '/');
        }
        
        // 方式2: 匹配video标签
        if (!playUrl) {
            const videoMatch = html.match(/<video[^>]+src="([^"]+)"/);
            if (videoMatch) {
                playUrl = videoMatch[1];
            }
        }
        
        // 方式3: 匹配iframe
        if (!playUrl) {
            const iframeMatch = html.match(/<iframe[^>]+src="([^"]+)"/);
            if (iframeMatch) {
                playUrl = iframeMatch[1];
            }
        }
        
        // 方式4: 查找video.js配置
        if (!playUrl) {
            const configMatch = html.match(/videojs\s*\([^)]+\)\s*\.src\s*\(\s*{.*?src\s*:\s*['"]([^'"]+)['"]/s);
            if (configMatch) {
                playUrl = configMatch[1];
            }
        }
        
        let result;
        if (playUrl) {
            result = {
                parse: 0,
                url: playUrl,
                header: headers
            };
        } else {
            // 无法直接提取，返回页面地址让播放器解析
            result = {
                parse: 1,
                url: url,
                header: headers
            };
        }
        
        // 缓存播放地址（短期缓存，5分钟）
        cache.set(cacheKey, result);
        
        return result;
        
    } catch (e) {
        if (global.store) global.store.log.error(`播放URL获取失败: ${e.message}`);
        return { parse: 0, url: '' };
    }
};

const _search = async ({ wd, page }) => {
    const pg = page || 1;
    
    if (!wd) {
        return { list: [], page: pg, pagecount: 0 };
    }
    
    // 缓存键
    const cacheKey = `search_${wd}_${pg}`;
    const cached = cache.get(cacheKey);
    if (cached) {
        return cached;
    }
    
    try {
        let url = `${host}/index.php/vod/search`;
        
        if (pg > 1) {
            url += `/page/${pg}`;
        }
        
        url += `.html?wd=${encodeURIComponent(wd)}`;
        
        const html = await requestUtil.sendRequest(url);
        const list = requestUtil.parseVideoList(html);
        
        const pagecount = requestUtil.getTotalPages(html);
        
        const result = {
            list,
            page: pg,
            pagecount: pagecount
        };
        
        // 缓存搜索结果（短期）
        cache.set(cacheKey, result);
        
        return result;
        
    } catch (e) {
        if (global.store) global.store.log.error(`搜索失败: ${e.message}`);
        return { list: [], page: pg, pagecount: 0 };
    }
};

// ========== 站点元数据 ==========
const meta = {
    key: "ZiRanYS",
    name: "[纯]孜然影视",
    type: 4,
    api: "/video/ZiRanYS",
    searchable: 1,
    quickSearch: 1,
    filterable: 1
};

const store = { init: false };
const init = async (server) => {
    if (store.init) return;
    store.log = server.log;
    global.store = store;
    store.init = true;
    
    store.log.info(`孜然影视初始化完成，Node.js版本: ${process.version}`);
};

// ========== 模块导出 ==========
module.exports = async (app, opt) => {
    app.get(meta.api, async (req, reply) => {
        if (!store.init) await init(req.server);
        
        const { extend, filter, t, ac, pg, ext, ids, play, wd, quick } = req.query;

        try {
            if (play) {
                return await _play({ id: play, flags: ext });
            } else if (wd) {
                return await _search({ wd: wd, page: parseInt(pg || "1") });
            } else if (!ac) {
                return await _home({ filter: filter ?? false });
            } else if (ac === "detail") {
                if (t) {
                    const filters = filter ? JSON.parse(filter) : {};
                    return await _category({ id: t, page: parseInt(pg || "1"), filters: filters });
                } else if (ids) {
                    return await _detail({ ids: ids });
                }
            }
            return { code: 404, msg: "未知请求" };
        } catch (e) {
            if (global.store) global.store.log.error(`请求处理失败: ${e.message}`);
            return { code: 500, msg: "服务器内部错误" };
        }
    });
    
    // 添加清除缓存路由
    app.get(`${meta.api}/clear-cache`, async (req, reply) => {
        cache.clear();
        if (global.store) global.store.log.info("缓存已清空");
        return { code: 200, msg: "缓存已清空" };
    });
    
    // 添加健康检查路由
    app.get(`${meta.api}/health`, async (req, reply) => {
        try {
            await requestUtil.sendRequest(host);
            return { 
                code: 200, 
                msg: "服务正常",
                cacheSize: cache.cache.size,
                uptime: process.uptime()
            };
        } catch (e) {
            return { code: 500, msg: "服务异常: " + e.message };
        }
    });
    
    opt.sites.push(meta);
};