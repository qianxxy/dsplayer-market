// author: cupid
// 可可影视 T4 源 - https://www.kkys04.com
// 带 cdndefend 防护；列表/详情走 HTML，播放页直取 m3u8 / TMDPPPP(AES)

const axios = require('axios');
const http = require('http');
const https = require('https');
const crypto = require('crypto');

const HOST = 'https://www.kkys04.com';
// XBPQ 同款 UA：部分线路更稳；4K 仍是 APP 专线，改 UA 无效
const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1';
const SITE_NAME = '可可影视';
// XBPQ: 解aes-Isu7fOAvI6!&IKpAbVdhf&^F  => AES-192-ECB
const TMD_AES_KEY = Buffer.from('Isu7fOAvI6!&IKpAbVdhf&^F', 'utf8');

const CLASSES = [
  { type_id: '1', type_name: '电影' },
  { type_id: '2', type_name: '连续剧' },
  { type_id: '3', type_name: '动漫' },
  { type_id: '4', type_name: '综艺纪录' },
  { type_id: '6', type_name: '短剧' },
];

const client = axios.create({
  timeout: 20000,
  proxy: false,
  httpAgent: new http.Agent({ keepAlive: true }),
  httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
  // cdndefend 挑战页返回 850，必须放行才能读 body 解 cookie
  validateStatus: (s) => (s >= 200 && s < 500) || s === 850,
  maxRedirects: 5,
  headers: {
    'User-Agent': UA,
    Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
  },
});

let cachedCookie = '';
let cookieExpireAt = 0;
let cachedSearchToken = '';
let searchTokenExpireAt = 0;

function cleanText(text) {
  return String(text || '')
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/\u3000/g, ' ')
    .split(/\s+/)
    .join(' ')
    .trim();
}

function fixUrl(u) {
  u = String(u || '').replace(/&amp;/g, '&').trim();
  if (!u) return '';
  if (u.startsWith('//')) return 'https:' + u;
  if (u.startsWith('/')) return HOST + u;
  if (!/^https?:\/\//i.test(u)) return HOST + '/' + u.replace(/^\/+/, '');
  return u;
}

function decodeJsString(s) {
  return String(s || '')
    .replace(/\\u([0-9a-fA-F]{4})/g, (_, h) => String.fromCharCode(parseInt(h, 16)))
    .replace(/\\x([0-9a-fA-F]{2})/g, (_, h) => String.fromCharCode(parseInt(h, 16)))
    .replace(/\\\//g, '/')
    .replace(/\\'/g, "'")
    .replace(/\\"/g, '"')
    .replace(/&amp;/g, '&');
}

function isAppOnlyPlayPage(html) {
  return /当前线路仅供APP端观看|仅供APP端观看/i.test(String(html || ''));
}

function decryptTmdPppp(cipher) {
  const raw = String(cipher || '').trim();
  if (!raw || raw.length < 16) return '';
  try {
    const data = Buffer.from(raw, 'base64');
    if (!data.length) return '';
    const decipher = crypto.createDecipheriv('aes-192-ecb', TMD_AES_KEY, null);
    decipher.setAutoPadding(true);
    const plain = Buffer.concat([decipher.update(data), decipher.final()]).toString('utf8').trim();
    return plain;
  } catch (e) {
    return '';
  }
}

function looksLikePlayUrl(u) {
  const s = String(u || '').trim();
  if (!s) return false;
  return /\.m3u8(\?|#|$)/i.test(s) || /\.mp4(\?|#|$)/i.test(s) || /^https?:\/\//i.test(s);
}

function extractPlayUrl(html) {
  if (!html) return '';

  // 1) 明文 playSource.src（含 unicode 转义）
  const patterns = [
    /playSource\s*=\s*\{[\s\S]*?(?:src|['"]\\u0073\\u0072\\u0063['"]|['"]src['"])\s*:\s*["']([^"']+)["']/i,
    /playSource\s*=\s*\{[\s\S]{0,1200}?['"]src['"]\s*:\s*["']([^"']+)["']/i,
  ];
  for (const re of patterns) {
    const m = html.match(re);
    if (!m) continue;
    const u = decodeJsString(m[1]).trim();
    if (looksLikePlayUrl(u)) return u;
  }

  // 2) XBPQ 同款：window.whatTMDwhatTMDPPPP = 'AES密文'
  const tmdRe = /(?:window\.)?(?:whatTMDwhatTMDPPPP|TMDPPPP|tTMDPPPP)\s*=\s*['"]([^'"]+)['"]/i;
  const tm = html.match(tmdRe);
  if (tm) {
    const plain = decryptTmdPppp(tm[1]);
    if (looksLikePlayUrl(plain)) return plain;
  }

  // 3) 全文 unicode 转义 / 裸 m3u8
  const uni = html.match(/(?:https?:)?(?:\\u[0-9a-fA-F]{4}){10,}/i);
  if (uni) {
    const u = decodeJsString(uni[0]);
    if (looksLikePlayUrl(u)) return u;
  }
  const m3 = html.match(/https?:\/\/[^"'\\\s<>]+\.m3u8[^"'\\\s<>]*/i);
  if (m3) return decodeJsString(m3[0]);
  return '';
}

function isCdnChallenge(status, html) {
  if (status === 850) return true;
  const head = String(html || '').slice(0, 1200);
  return /Protected by cdndefend|cdndefend_js_cookie/i.test(head);
}

function solveCdnDefend(html) {
  const arrM = String(html || '').match(/a0_0x2a54=\[([\s\S]*?)\];/);
  if (!arrM) return '';
  const arr = [...arrM[1].matchAll(/'([^']+)'/g)].map((m) => m[1]);
  const c = arr.find((x) => /^[0-9A-F]{40}$/.test(x));
  if (!c) return '';
  const n1 = parseInt(c[0], 16);
  if (Number.isNaN(n1)) return '';
  for (let i = 0; i < 5000000; i++) {
    const digest = crypto.createHash('sha1').update(c + String(i)).digest();
    if (digest[n1] === 0xb0 && digest[n1 + 1] === 0x0b) {
      return c + String(i);
    }
  }
  return '';
}

function buildHeaders(extra = {}) {
  const headers = {
    'User-Agent': UA,
    Referer: HOST + '/',
    Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    ...extra,
  };
  if (cachedCookie) headers.Cookie = `cdndefend_js_cookie=${cachedCookie}`;
  return headers;
}

async function refreshCookie(force = false) {
  if (!force && cachedCookie && Date.now() < cookieExpireAt) return cachedCookie;
  try {
    const res = await client.get(HOST + '/', {
      headers: {
        'User-Agent': UA,
        Accept: 'text/html',
        'Accept-Language': 'zh-CN,zh;q=0.9',
      },
    });
    const body = typeof res.data === 'string' ? res.data : String(res.data || '');
    if (!isCdnChallenge(res.status, body)) {
      // 可能已放行；尝试从 set-cookie 取
      const sc = res.headers['set-cookie'] || [];
      for (const line of sc) {
        const m = String(line).match(/cdndefend_js_cookie=([^;]+)/i);
        if (m) {
          cachedCookie = m[1];
          cookieExpireAt = Date.now() + 25 * 60 * 1000;
          return cachedCookie;
        }
      }
      // 无挑战也无 cookie，仍可继续
      cookieExpireAt = Date.now() + 5 * 60 * 1000;
      return cachedCookie;
    }
    const cookie = solveCdnDefend(body);
    if (!cookie) {
      console.error(`[${SITE_NAME}] solve cdndefend failed`);
      return cachedCookie;
    }
    cachedCookie = cookie;
    cookieExpireAt = Date.now() + 25 * 60 * 1000;
    return cachedCookie;
  } catch (e) {
    console.error(`[${SITE_NAME}] refreshCookie error:`, e.message);
    return cachedCookie;
  }
}

async function getHtml(url, params = undefined) {
  await refreshCookie(false);
  const tryOnce = async () => {
    const res = await client.get(url, {
      params,
      headers: buildHeaders(),
    });
    const body = typeof res.data === 'string' ? res.data : String(res.data || '');
    return { status: res.status, body };
  };
  try {
    let { status, body } = await tryOnce();
    if (isCdnChallenge(status, body)) {
      await refreshCookie(true);
      ({ status, body } = await tryOnce());
    }
    if (status !== 200 || isCdnChallenge(status, body)) {
      console.error(`[${SITE_NAME}] getHtml bad status:`, status, url);
      return '';
    }
    return body;
  } catch (e) {
    console.error(`[${SITE_NAME}] getHtml error:`, e.message, url);
    return '';
  }
}

function pickPic(block) {
  const pics = [...String(block || '').matchAll(/data-original=["']([^"']+)["']/gi)].map((x) => x[1]);
  for (const p of pics) {
    if (/logo_placeholder|favicon|avatar|empty-box/i.test(p)) continue;
    return fixUrl(p);
  }
  return pics.length ? fixUrl(pics[pics.length - 1]) : '';
}

function parseList(html) {
  const list = [];
  const seen = new Set();
  let m;

  // 首页 / 分类：v-item 卡片
  const cardRe = /href=["'](\/detail\/\d+\.html)["'][^>]*class=["'][^"']*v-item[^"']*["'][^>]*>([\s\S]*?)<\/a>/gi;
  while ((m = cardRe.exec(html || ''))) {
    const href = m[1];
    const block = m[2] || '';
    const vid = (href.match(/\/detail\/(\d+)\.html/) || [])[1];
    if (!vid || seen.has(vid)) continue;

    let title = '';
    const titles = [...block.matchAll(/<div class="v-item-title"([^>]*)>([\s\S]*?)<\/div>/gi)];
    for (const t of titles) {
      const attrs = t[1] || '';
      const text = cleanText(t[2]);
      if (/display\s*:\s*none/i.test(attrs)) continue;
      if (!text || /可可影视|kekys\.com|kkys/i.test(text)) continue;
      title = text;
      break;
    }
    if (!title) {
      for (const t of titles) {
        const text = cleanText(t[2]);
        if (text && !/可可影视|kekys\.com|kkys/i.test(text)) {
          title = text;
          break;
        }
      }
    }
    if (!title) continue;
    seen.add(vid);
    const rm = block.match(/class="v-item-bottom"[\s\S]*?<span>([\s\S]*?)<\/span>/i);
    list.push({
      vod_id: vid,
      vod_name: title,
      vod_pic: pickPic(block),
      vod_remarks: rm ? cleanText(rm[1]) : '',
    });
  }

  // 搜索页：search-result-item
  const searchRe = /href=["'](\/detail\/\d+\.html)["'][^>]*class=["'][^"']*search-result-item[^"']*["'][^>]*>([\s\S]*?)<\/a>/gi;
  while ((m = searchRe.exec(html || ''))) {
    const href = m[1];
    const block = m[2] || '';
    const vid = (href.match(/\/detail\/(\d+)\.html/) || [])[1];
    if (!vid || seen.has(vid)) continue;

    let title = '';
    const tm = block.match(/class=["']title["'][^>]*>([\s\S]*?)<\/div>/i)
      || block.match(/title=["']([^"']+)["']/i)
      || block.match(/alt=["']([^"']+)["']/i);
    if (tm) title = cleanText(tm[1]);
    if (!title || /可可影视|kekys\.com|kkys/i.test(title)) continue;
    seen.add(vid);

    let remarks = '';
    const header = block.match(/class=["']search-result-item-header["'][^>]*>\s*<div>([\s\S]*?)<\/div>/i);
    if (header) remarks = cleanText(header[1]);
    const tags = [...block.matchAll(/class=["']tags["'][^>]*>[\s\S]*?<span>([\s\S]*?)<\/span>/gi)].map((x) => cleanText(x[1])).filter(Boolean);
    if (tags.length) remarks = remarks ? `${remarks} ${tags[0]}` : tags[0];

    list.push({
      vod_id: vid,
      vod_name: title,
      vod_pic: pickPic(block),
      vod_remarks: remarks,
    });
  }

  return list;
}

async function getSearchToken(force = false) {
  if (!force && cachedSearchToken && Date.now() < searchTokenExpireAt) return cachedSearchToken;
  const html = await getHtml(HOST + '/');
  const m = html.match(/name=["']t["']\s+value=["']([^"']+)["']/i);
  if (m) {
    cachedSearchToken = m[1];
    searchTokenExpireAt = Date.now() + 20 * 60 * 1000;
  }
  return cachedSearchToken;
}

async function getHome() {
  const html = await getHtml(HOST + '/');
  return {
    class: CLASSES,
    filters: {},
    list: parseList(html),
    parse: 0,
    jx: 0,
  };
}

async function getCategory(tid, pg = 1) {
  const page = Math.max(parseInt(pg, 10) || 1, 1);
  const id = String(tid || '1');
  // 站点筛选页：/show/{tid}-----3-{page}.html
  const target = `${HOST}/show/${id}-----3-${page}.html`;
  const html = await getHtml(target);
  const list = parseList(html);
  return {
    list,
    page,
    pagecount: list.length ? page + 1 : page,
    limit: list.length || 18,
    total: list.length,
    parse: 0,
    jx: 0,
  };
}

async function getDetail(ids) {
  const vid = String(ids || '').split(',')[0].trim();
  if (!vid) return { list: [], parse: 0, jx: 0 };
  const html = await getHtml(`${HOST}/detail/${vid}.html`);
  if (!html) return { list: [], parse: 0, jx: 0 };

  let title = '';
  const titleBlock = html.match(/class="detail-title"[^>]*>([\s\S]*?)<\/div>/i);
  if (titleBlock) {
    const strongs = [...titleBlock[1].matchAll(/<strong>([\s\S]*?)<\/strong>/gi)].map((m) => cleanText(m[1]));
    title = strongs.find((t) => t && !/kkys|kekys|可可|com|^\W+$/i.test(t)) || '';
  }
  if (!title) {
    const tm = html.match(/<title>([^<]+)/i);
    if (tm) title = cleanText(tm[1]).replace(/[-_].*$/, '').trim();
  }

  let pic = '';
  const pics = [...html.matchAll(/data-original=["']([^"']+)["']/gi)].map((x) => x[1]);
  for (const p of pics) {
    if (/logo_placeholder|favicon|avatar|empty-box/i.test(p)) continue;
    if (/\/vod1\/|\/cover\/|\/upload\//i.test(p)) {
      pic = fixUrl(p);
      break;
    }
  }

  let desc = '';
  const dm = html.match(/<meta\s+name=["']description["']\s+content=["']([^"']*)["']/i);
  if (dm) desc = cleanText(dm[1]);

  let remarks = '';
  const rmk = html.match(/class="detail-info[^"]*"[\s\S]{0,400}?class="detail-info-value"[^>]*>([\s\S]*?)<\//i);
  if (rmk) remarks = cleanText(rmk[1]);

  // 同时拿 label/sublabel，便于过滤 APP 专线
  const sourceItems = [...html.matchAll(/class="source-item[^"]*"[^>]*>\s*<span class="source-item-label">([^<]+)<\/span>(?:\s*<span class="source-item-sublabel">([^<]*)<\/span>)?/gi)].map((m) => ({
    label: cleanText(m[1]),
    sub: cleanText(m[2] || ''),
  }));
  const episodeLists = [...html.matchAll(/<div class="episode-list"[^>]*>([\s\S]*?)<\/div>/gi)].map((m) => m[1]);

  const playFrom = [];
  const playUrl = [];
  const count = Math.max(sourceItems.length, episodeLists.length);
  for (let i = 0; i < count; i++) {
    const item = sourceItems[i] || {};
    const from = item.label || `线路${i + 1}`;
    // 4K 线路在 PC 端是 APP 专享，HTML 不给 m3u8；直接过滤避免点了播不了
    if (/^4k$/i.test(from) || /APP专|仅APP|APP端/i.test(item.sub || '')) {
      continue;
    }
    const panel = episodeLists[i] || '';
    const eps = [];
    const epRe = /href=["'](\/play\/[^"']+)["'][^>]*class="episode-item"[^>]*>\s*<span>([\s\S]*?)<\/span>/gi;
    let em;
    while ((em = epRe.exec(panel))) {
      const name = cleanText(em[2]) || '正片';
      eps.push(`${name}$${em[1]}`);
    }
    // 兼容属性顺序不同
    if (!eps.length) {
      const epRe2 = /class="episode-item"[^>]*href=["'](\/play\/[^"']+)["'][^>]*>\s*<span>([\s\S]*?)<\/span>/gi;
      while ((em = epRe2.exec(panel))) {
        eps.push(`${cleanText(em[2]) || '正片'}$${em[1]}`);
      }
    }
    if (!eps.length) continue;
    playFrom.push(from);
    playUrl.push(eps.join('#'));
  }

  return {
    list: [
      {
        vod_id: vid,
        vod_name: title || vid,
        vod_pic: pic,
        type_name: '',
        vod_year: '',
        vod_area: '',
        vod_remarks: remarks,
        vod_actor: '',
        vod_director: '',
        vod_content: desc,
        vod_play_from: playFrom.join('$$$'),
        vod_play_url: playUrl.join('$$$'),
      },
    ],
    parse: 0,
    jx: 0,
  };
}

async function getPlay(playId) {
  const headers = { 'User-Agent': UA, Referer: HOST + '/' };
  let playPath = String(playId || '').trim();
  if (!playPath) return { parse: 1, jx: 0, url: '', playUrl: '', header: headers };
  if (!/^https?:\/\//i.test(playPath)) {
    if (!playPath.startsWith('/')) playPath = '/' + playPath;
    playPath = HOST + playPath;
  }
  const html = await getHtml(playPath);
  if (!html) return { parse: 1, jx: 0, url: playPath, playUrl: '', header: headers };

  // APP 专线：页面明确提示仅 APP 可看，且 playSource.src 为空
  if (isAppOnlyPlayPage(html)) {
    return {
      parse: 0,
      jx: 0,
      url: '',
      playUrl: '',
      header: headers,
      message: '该线路仅供 APP 端观看，请换其他线路',
    };
  }

  const playUrl = extractPlayUrl(html);
  if (playUrl) {
    return {
      parse: 0,
      jx: 0,
      url: playUrl,
      playUrl: '',
      header: headers,
    };
  }
  return { parse: 1, jx: 0, url: playPath, playUrl: '', header: headers };
}

async function doSearch(wd, pg = 1) {
  const page = Math.max(parseInt(pg, 10) || 1, 1);
  const keyword = String(wd || '').trim();
  if (!keyword) return { list: [], page, pagecount: 1, limit: 0, total: 0, parse: 0, jx: 0 };

  let token = await getSearchToken(false);
  const params = { k: keyword, t: token || '' };
  if (page > 1) params.page = page;
  let html = await getHtml(`${HOST}/search`, params);
  let list = parseList(html);

  // token 失效时刷新一次
  if (!list.length) {
    token = await getSearchToken(true);
    params.t = token || '';
    html = await getHtml(`${HOST}/search`, params);
    list = parseList(html);
  }

  return {
    list,
    page,
    pagecount: list.length ? page + 1 : page,
    limit: list.length,
    total: list.length,
    parse: 0,
    jx: 0,
  };
}

async function handle(req) {
  const q = req.query || {};
  const ac = q.ac;
  const isPlay = !!q.play || ac === 'play' || (!!q.flag && !!q.id);
  const wd = q.wd || q.key || q.keyword;
  const tid = q.t || q.type_id;
  // 分类可能带 ac=detail&t=分类ID；只有明确 ids / 非分类 id 才走详情
  const ids = q.ids || (q.id && !isPlay && !tid ? q.id : '');
  if (isPlay) return await getPlay(q.play || q.id);
  if (ids) return await getDetail(ids);
  if (wd) return await doSearch(wd, q.pg || 1);
  if (tid && String(tid) !== '0') return await getCategory(tid, q.pg || 1);
  return await getHome();
}

module.exports = async (app, opt) => {
  const path = '/video/kkys';
  app.get(path, async (req) => await handle(req));
  app.get('/video/可可影视', async (req) => await handle(req));
  opt.sites.push({
    key: 'kkys',
    name: '[纯]可可影视',
    type: 4,
    api: path,
    searchable: 1,
    quickSearch: 1,
    filterable: 0,
    changeable: 0,
    ext: '',
  });
};
