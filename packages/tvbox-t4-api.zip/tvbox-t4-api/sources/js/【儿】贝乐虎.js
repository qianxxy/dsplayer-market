/**
 * 贝乐虎[儿] - Fastify T4 JS 源
 * 站点：https://vd.ubestkid.com
 */

const axios = require("axios");
const http = require("http");
const https = require("https");
const zlib = require("zlib");

const _http = axios.create({
  timeout: 15000,
  httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
  httpAgent: new http.Agent({ keepAlive: true }),
  maxRedirects: 5,
});

const SITE_CONFIG = {
  title: "[儿]贝乐虎",
  host: "https://vd.ubestkid.com",
  debug: true,
  searchable: 0,
  quickSearch: 0,
  filterable: 0,
  headers: {
    "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
  },
  PAGE_LIMIT: 60,
};

const CLASS_DATA_B64 = "H4sIAAAAAAAAA4VUy27aUBD9F6+zwKRAk1+pqqpSsuiiVRfdVFUlUnCCwU1IwqNuHggFQ1owOCGNjAnwM547l10/oZeiRmTuoO5s6ZyZc87M3BefjA8f3+++erNjbKdTG8ufd6/f7hrbxu9GeSDOs6IWxGFRXN4bnzdW0Ka5qcPjKBJBBXO+OPGfwlNpHY3jI7BC7HoyuCLFNzM6HB6yMMvJu4t4VJbuIanPqIFpCYrXkJ8J3yHorXVqOLSZMHW4vLcw6oibiZy0TRoNU34Vj71eHDnga66ZkCgvtDXeFjO4v7i68kRbcDmNHha2bZXWTBYuqRluFKd5vGhyWWUSjIXSjagdsMmanOPiF1H34vBw8RFUiFdGjdgrz6duHNawSufMJKNWAitjtFlBKa78rz3ZdBRUnN1S+c8Z+f8WFCwPznzZD+g2cZ4fSa0OulPsHD8lpZNrF/aoJQd1gmaGvESLqhVHJSIoybkoOws1fhuKDWh1qQVmyjj+Js57fAPmfsg1L3cE7QIZN5MV1K8faSJnQXV/OVKqkXG1ANo/5o2hYou7KQxGVCnXTyOtEWsmuHXzDqDt4ve8jLrx5JT2e/ZfxppmaYYp+y1sePC1qbabSmOfpCs4HmI/i72Kll+GiU9UA/WosIec5O5+sK/gysL8p6OHleTeFUU6cXE4hsIq7+UfFA1HoacGAAA=";

let _classes = null;
function decodeClasses() {
  if (_classes) return _classes;
  const buf = Buffer.from(CLASS_DATA_B64, "base64");
  _classes = JSON.parse(zlib.gunzipSync(buf).toString("utf8"));
  return _classes;
}

let log = () => {};
const safeStr = (v) => (v == null ? "" : String(v).trim());
const pageNumber = (v) => { const n = parseInt(String(v || "1"), 10); return n > 0 ? n : 1; };

const _home = async (filter) => {
  return { class: decodeClasses(), filters: {}, list: [] };
};

const _category = async (tid, pg) => {
  const cid = safeStr(tid) || "56";
  const page = pageNumber(pg);
  const pdata = { age: 1, appver: "6.1.9", egvip_status: 0, svip_status: 0, vps: 60, subcateId: Number(cid), p: page };
  try {
    const res = await _http.post(SITE_CONFIG.host + "/api/v1/bv/video", pdata, {
      headers: { ...SITE_CONFIG.headers, "Content-Type": "application/json" },
      responseType: "json",
      validateStatus: () => true,
    });
    const items = Array.isArray(res.data?.result?.items) ? res.data.result.items : [];
    const list = items.map((it) => ({
      vod_id: safeStr(it.url) + "@@" + safeStr(it.title) + "@@" + safeStr(it.image),
      vod_name: safeStr(it.title),
      vod_pic: safeStr(it.image),
      vod_remarks: it.viewcount != null ? "👀" + safeStr(it.viewcount) : "",
    }));
    return { list, page, pagecount: list.length >= SITE_CONFIG.PAGE_LIMIT ? 9999 : page, limit: SITE_CONFIG.PAGE_LIMIT, total: 999999 };
  } catch (e) {
    return { list: [], page, pagecount: 1, limit: SITE_CONFIG.PAGE_LIMIT, total: 0 };
  }
};

const _detail = async (ids) => {
  const idList = Array.isArray(ids) ? ids : [ids];
  const list = [];
  for (const rawId of idList) {
    const id = safeStr(rawId);
    if (!id) continue;
    const parts = id.split("@@");
    list.push({
      vod_id: id,
      vod_name: parts[1] || "",
      vod_pic: parts[2] || "",
      vod_play_from: "贝乐虎",
      vod_play_url: "播放$" + (parts[0] || ""),
    });
  }
  return { list };
};

const _play = async (flag, id) => {
  const url = safeStr(id).split("@@")[0];
  if (!url) return { parse: 0, url: "" };
  return { parse: 0, url: url + "#.mp4", header: SITE_CONFIG.headers };
};

const meta = {
  key: "beilehu", name: SITE_CONFIG.title, type: 4, api: "/video/beilehu",
  searchable: 0, quickSearch: 0, changeable: 0, filterable: 0,
};

module.exports = async (app, opt) => {
  const flog = app?.log?.info?.bind(app?.log);
  log = SITE_CONFIG.debug ? (...a) => (flog || console.log)(`[贝乐虎] ${a.join(" ")}`) : () => {};
  app.get(meta.api, async (req) => {
    const { filter, t, ac, pg, ids, flag, play } = req.query;
    try {
      if (play) return await _play(flag || "", play);
      if (ac === "detail") {
        if (t) return await _category(t, parseInt(pg || "1", 10));
        if (ids) return await _detail(ids.split(",").map(s => s.trim()).filter(Boolean));
      }
      if (!ac) return await _home(filter ?? false);
      if (t) return await _category(t, parseInt(pg || "1", 10));
    } catch (e) {
      return { error: e.message };
    }
    return req.query;
  });
  if (opt && Array.isArray(opt.sites)) opt.sites.push(meta);
};
