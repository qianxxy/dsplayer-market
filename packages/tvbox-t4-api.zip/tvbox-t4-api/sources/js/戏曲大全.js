const axios = require("axios");
const http = require("http");
const https = require("https");

const _http = axios.create({
    timeout: 15 * 1000,
    httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
    httpAgent: new http.Agent({ keepAlive: true })
});

// 戏曲大全配置
const avConfig = {
    host: "https://fly.daoran.tv",
    headers: {
        "User-Agent": "okhttp/3.12.10",
        "Connection": "Keep-Alive",
        "Accept-Encoding": "gzip",
        "md5": "SkvyrWqK9QHTdCT12Rhxunjx+WwMTe9y4KwgeASFDhbYabRSPskR0Q==",
        "Content-Type": "application/json; charset=UTF-8",
        "Cookie": "JSESSIONID=41ABA76E6D45A44D6419B3F26A0851ED"
    }
};

const PAGE_LIMIT = 24;

// ---------- 分类映射（已人工校对，确保一一对应） ----------
// 格式：{ id: "分类URL标识", name: "显示名称" }
const CLASS_MAP = [
    { id: "yuju", name: "豫剧" },
    { id: "hmx", name: "黄梅戏" },
    { id: "yueju", name: "越剧" },
    { id: "jingju", name: "京剧" },
    { id: "pingju", name: "评剧" },
    { id: "quju", name: "曲剧" },
    { id: "hnzz", name: "坠子" },
    { id: "qinq", name: "秦腔" },
    { id: "hbbz", name: "河北梆子" },
    { id: "chaoju", name: "潮剧" },
    { id: "gddx", name: "粤剧" },
    { id: "huju", name: "沪剧" },
    { id: "ejx", name: "二夹弦" },
    { id: "kunqu", name: "昆曲" },
    { id: "hnqs", name: "河南琴书" },
    { id: "huaiju", name: "淮剧" },
    { id: "danxian", name: "单弦" },
    { id: "xqx", name: "西秦戏" },
    { id: "wuju", name: "婺剧" },
    { id: "bzx", name: "白字戏" },
    { id: "hndgs", name: "河南大鼓书" },
    { id: "yued", name: "越调" },
    { id: "dianju", name: "滇剧" },
    { id: "tkdq", name: "太康道情" },
    { id: "MZYY", name: "民族音乐" },
    { id: "yangju", name: "扬剧" },
    { id: "other", name: "其他" },
    { id: "else", name: "曲艺晚会" },
    { id: "ERT", name: "二人台" },
    { id: "blbz", name: "北路梆子" },
    { id: "caidiao", name: "彩调" },
    { id: "lq", name: "乐腔" },
    { id: "WK", name: "老年大学" },
    { id: "lvjv", name: "吕剧" },
    { id: "tjsd", name: "天津时调" },
    { id: "liuqx", name: "柳琴戏" },
    { id: "jydg", name: "京韵大鼓" },
    { id: "pyx", name: "皮影戏" },
    { id: "xj", name: "湘剧" },
    { id: "spd", name: "四平调" },
    { id: "qiongju", name: "琼剧" },
    { id: "xiju", name: "锡剧" },
    { id: "pingshu", name: "评书" },
    { id: "shaojv", name: "绍剧" },
    { id: "jddg", name: "京东大鼓" },
    { id: "luju", name: "庐剧" },
    { id: "huaju", name: "话剧" },
    { id: "xhdg", name: "西河大鼓" },
    { id: "huagx", name: "莆仙戏" },
    { id: "chuanju", name: "川剧" },
    { id: "xiang", name: "相声" },
    { id: "wb", name: "宛梆" },
    { id: "jzyg", name: "晋中秧歌" },       // 这个无数据，可删
    { id: "caichaxi", name: "采茶戏" },
    { id: "pujv", name: "蒲剧" },
    { id: "hj", name: "汉剧" },
    { id: "minju", name: "闽剧" },
    { id: "jinju", name: "晋剧" },
    { id: "jiju", name: "吉剧" },
    { id: "zzx", name: "正字戏" },
    { id: "gj", name: "赣剧" },
    { id: "chuju", name: "楚剧" },
    { id: "dpd", name: "大平调" },
    { id: "bdld", name: "保定老调" }
];
// 默认封面图
const DEFAULT_COVER = "https://img0.baidu.com/it/u=4079405848,3806507810&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=750";

// 获取分类（返回按映射顺序）
const getClasses = async () => {
    return CLASS_MAP.map(item => ({
        type_id: item.id,
        type_name: item.name
    }));
};

// 首页推荐（该站暂无推荐，返回空）
const getHomeRecommend = async () => {
    return [];
};

// 生成 vodId：code@@encodeURIComponent(title)
const makeVodId = (code, title) => {
    if (!code) return '';
    const t = String(title || '').trim();
    if (!t) return code;
    return `${code}@@${encodeURIComponent(t)}`;
};

// 解析 vodId
const parseVodId = (id) => {
    const raw = String(id || '');
    const idx = raw.lastIndexOf('@@');
    if (idx === -1) return { code: raw, title: '' };
    const code = raw.slice(0, idx);
    const encTitle = raw.slice(idx + 2);
    let title = '';
    try {
        title = decodeURIComponent(encTitle);
    } catch (e) {
        title = encTitle;
    }
    return { code, title: String(title || '').trim() };
};

// 分类列表请求（使用正确的接口 /API_ROP/search/album/screen）
const getCategoryList = async (type, page = 1, extend = {}) => {
    try {
        const pg = parseInt(page, 10) || 1;
        const data = {
            cur: pg,
            free: 0,
            orderby: "hot",
            pageSize: 3000,
            resType: 1,
            sect: type,
            tagId: 0,
            userId: "d4b29595b6fe764e09078a0dad7352ff",
            channel: "oppo",
            item: "y9",
            nodeCode: "001000",
            project: "lyhxcx"
        };

        const url = `${avConfig.host}/API_ROP/search/album/screen`;
        const response = await _http.post(url, data, { headers: avConfig.headers });
        const result = response.data;

        // 打印响应（调试用）
        console.log('📦 分类响应:', JSON.stringify(result).substring(0, 500));

        let items = result?.pb?.dataList || [];
        let total = result?.pb?.total || 0;

        // 如果列表为空，尝试使用备用接口（/API_ROP/search/album/list）
        if (items.length === 0) {
            console.log('⚠️ 主接口无数据，尝试备用接口...');
            const backupData = {
                cur: pg,
                free: 0,
                orderby: "hot",
                pageSize: 300,
                resType: 1,
                sect: type,
                tagId: 0,
                userId: "d4b29595b6fe764e09078a0dad7352ff",
                channel: "oppo",
                item: "y9",
                nodeCode: "001000",
                project: "lyhxcx"
            };
            const backupUrl = `${avConfig.host}/API_ROP/search/album/list`;
            const backupResponse = await _http.post(backupUrl, backupData, { headers: avConfig.headers });
            const backupResult = backupResponse.data;
            items = backupResult?.pb?.dataList || [];
            total = backupResult?.pb?.total || 0;
            console.log(`📦 备用接口返回 ${items.length} 条数据`);
        }

        // 如果备用接口也无数据，尝试调整 resType
        if (items.length === 0) {
            console.log('⚠️ 备用接口无数据，尝试 resType=0...');
            const retryData = { ...data, resType: 0 };
            const retryResponse = await _http.post(url, retryData, { headers: avConfig.headers });
            const retryResult = retryResponse.data;
            items = retryResult?.pb?.dataList || [];
            total = retryResult?.pb?.total || 0;
        }

        const list = [];
        items.forEach(it => {
            const title = it.name || '';
            const code = it.code || '';
            const desc = it.des || '';
            if (title && code) {
                list.push({
                    vod_id: makeVodId(code, title),
                    vod_name: title,
                    vod_pic: DEFAULT_COVER,
                    vod_remarks: desc
                });
            }
        });

        const pageCount = Math.ceil(total / 3000) || 1;

        console.log(`✅ 分类 ${type} 第 ${page} 页获取到 ${list.length} 个项目，总计 ${total}`);
        return {
            list: list,
            page: pg,
            pagecount: pageCount
        };
    } catch (error) {
        console.error('❌ 分类列表错误:', error.message);
        return { list: [], page: parseInt(page), pagecount: 1 };
    }
};

// 搜索功能
const searchVod = async (keyword, page = 1) => {
    try {
        const pg = parseInt(page, 10) || 1;
        const data = {
            cur: pg,
            free: 0,
            keyword: keyword,
            nodeCode: "001000",
            orderby: "hot",
            pageSize: 200,
            project: "lyhxcx",
            px: 2,
            sect: [],
            userId: "d4b29595b6fe764e09078a0dad7352ff"
        };

        const url = `${avConfig.host}/API_ROP/search/album/list`;
        const response = await _http.post(url, data, { headers: avConfig.headers });
        const result = response.data;

        const list = [];
        const items = result?.pb?.dataList || [];
        items.forEach(it => {
            const title = it.name || '';
            const code = it.code || '';
            const desc = it.des || '';
            if (title && code) {
                list.push({
                    vod_id: makeVodId(code, title),
                    vod_name: title,
                    vod_pic: DEFAULT_COVER,
                    vod_remarks: desc
                });
            }
        });

        const total = result?.pb?.total || list.length;
        const pageCount = Math.ceil(total / 200) || 1;

        console.log(`✅ 搜索 "${keyword}" 找到 ${list.length} 个结果`);
        return {
            list: list,
            page: pg,
            pagecount: pageCount,
            total: total
        };
    } catch (error) {
        console.error('❌ 搜索错误:', error.message);
        return { list: [], page: parseInt(page), pagecount: 1, total: 0 };
    }
};

// 详情获取
const getDetail = async (id) => {
    try {
        const parsed = parseVodId(id);
        const sourceTitle = parsed.title;
        const code = parsed.code;

        if (!code) {
            console.error('❌ 无效的 id，缺少 code');
            return null;
        }

        const data = {
            albumCode: code,
            cur: 1,
            pageSize: 100,
            userId: "d4b29595b6fe764e09078a0dad7352ff",
            channel: "oppo",
            item: "y9",
            nodeCode: "001000",
            project: "lyhxcx"
        };

        const url = `${avConfig.host}/API_ROP/album/res/list`;
        const response = await _http.post(url, data, { headers: avConfig.headers });
        const result = response.data;

        const playList = [];
        const items = result?.pb?.dataList || [];
        items.forEach(it => {
            const title = it.name || '';
            const itemCode = it.code || '';
            if (title && itemCode) {
                const playUrl = `https://zheshiyitaiojialianjie.com?${itemCode}`;
                playList.push(`${title}$${playUrl}`);
            }
        });

        if (playList.length === 0) {
            playList.push(`正片$https://zheshiyitaiojialianjie.com?${code}`);
        }

        const detail = {
            vod_id: code,
            vod_name: sourceTitle || '未知剧名',
            vod_pic: DEFAULT_COVER,
            vod_content: '',
            type_name: '',
            vod_remarks: '',
            vod_year: '',
            vod_area: '',
            vod_director: '未知',
            vod_actor: '未知',
            vod_play_from: '球球啦',
            vod_play_url: playList.join('#')
        };

        console.log(`✅ 详情获取成功，找到 ${playList.length} 个剧集`);
        return detail;
    } catch (error) {
        console.error('❌ 详情获取错误:', error.message);
        return null;
    }
};

// 获取真实播放地址
const getPlayUrl = async (playUrl) => {
    try {
        console.log('🎬 处理播放URL:', playUrl);

        let code = '';
        if (playUrl.includes('?')) {
            code = playUrl.split('?')[1] || '';
        }
        if (!code) {
            code = playUrl;
        }

        if (!code) {
            console.error('❌ 未提取到 code');
            return { parse: 1, url: playUrl, header: avConfig.headers };
        }

        const data = {
            item: "o3",
            mask: 0,
            nodeCode: "001000",
            project: "lyhxcx",
            px: 2,
            resCode: code,
            userId: "d4b29595b6fe764e09078a0dad7352ff"
        };

        const url = `${avConfig.host}/API_ROP/play/get/playurl`;
        const response = await _http.post(url, data, { headers: avConfig.headers });
        const result = response.data;

        const realUrl = result?.playUrls?.hd || '';
        if (realUrl) {
            console.log('✅ 获取真实视频地址:', realUrl);
            return {
                parse: 0,
                url: realUrl,
                header: {
                    "User-Agent": "okhttp/3.12.10",
                    "Referer": avConfig.host + "/",
                    "Origin": avConfig.host
                }
            };
        }

        console.log('⚠️ 未获取到真实视频地址，返回原始链接');
        return {
            parse: 1,
            url: playUrl,
            header: avConfig.headers
        };
    } catch (error) {
        console.error('❌ 播放解析错误:', error.message);
        return { parse: 1, url: playUrl, header: avConfig.headers };
    }
};

// T4 接口处理
const handleT4Request = async (req) => {
    try {
        const { ac, t, pg, wd, ids, play, quick, extend } = req.query;
        const page = parseInt(pg) || 1;

        console.log('📥 请求参数:', { ac, t, pg, wd, ids, play: play ? '***' : null, quick, extend });

        // 1. 搜索
        if (wd) {
            const result = await searchVod(wd, page);
            if (quick === 'true') result.list = result.list.slice(0, 10);
            return { list: result.list, page: result.page, pagecount: result.pagecount, limit: PAGE_LIMIT, total: result.total };
        }

        // 2. 播放
        if (play) {
            return await getPlayUrl(play);
        }

        // 3. 详情
        if (ids) {
            const detail = await getDetail(ids);
            return { list: detail ? [detail] : [], page: 1, pagecount: 1, total: detail ? 1 : 0 };
        }

        // 4. 分类列表
        if (t) {
            const extendParams = {};
            if (extend) {
                try { Object.assign(extendParams, JSON.parse(extend)); } catch (e) {}
            }
            const result = await getCategoryList(t, page, extendParams);
            return { list: result.list, page: result.page, pagecount: result.pagecount, limit: PAGE_LIMIT };
        }

        // 5. 首页
        if (!ac || ac === 'class') {
            const classes = await getClasses();
            if (ac === 'class') {
                return { class: classes };
            }
            const homeList = await getHomeRecommend();
            return {
                class: classes,
                list: homeList.slice(0, 20),
                page: 1,
                pagecount: 1,
                total: homeList.length
            };
        }

        return { list: [], page: 1, pagecount: 1 };
    } catch (error) {
        console.error('❌ 接口处理错误:', error.message);
        return { list: [], page: 1, pagecount: 1, error: error.message };
    }
};

const meta = {
    key: "戏曲大全",
    name: "[听]戏曲大全",
    type: 4,
    api: "/video/xiqu",
    searchable: 1,
    quickSearch: 1,
    filterable: 0
};

module.exports = async (app, opt) => {
    app.get(meta.api, async (req, reply) => {
        const result = await handleT4Request(req);
        return result;
    });
    opt.sites.push(meta);
};