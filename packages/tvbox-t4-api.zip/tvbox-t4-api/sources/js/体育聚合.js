// 体育聚合 T4 独立版：内置 88看球/咖啡直播/919体育/JRS直播/爱球直播/球通体育逻辑，不依赖其它 routes js 文件。
const path = require('path');

const INTERNAL_ROUTES = {};
let INTERNAL_READY = false;
let INTERNAL_SERVER = null;

function packId(src, rawId) { return `${src.id}@@@${String(rawId || '')}`; }
function splitId(id) {
  const s = String(Array.isArray(id) ? id[0] : (id || ''));
  const p = s.indexOf('@@@');
  if (p < 0) return { srcId: '', rawId: s };
  return { srcId: s.slice(0, p), rawId: s.slice(p + 3) };
}
function parseExtend(raw) {
  if (!raw) return {};
  if (typeof raw === 'object') return raw;
  const candidates = [String(raw)];
  try { candidates.push(decodeURIComponent(String(raw))); } catch (_) {}
  try { candidates.push(Buffer.from(String(raw), 'base64').toString('utf8')); } catch (_) {}
  try { candidates.push(Buffer.from(String(raw).replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8')); } catch (_) {}
  for (const s of candidates) {
    const v = String(s || '').trim();
    if (!v || (!v.startsWith('{') && !v.startsWith('['))) continue;
    try { const obj = JSON.parse(v); return obj && typeof obj === 'object' ? obj : {}; } catch (_) {}
  }
  return {};
}
function normalizePayload(data) {
  if (!data) return {};
  if (typeof data === 'string') { try { return JSON.parse(data || '{}'); } catch (_) { return {}; } }
  return data;
}
const SOURCES = [
  { id: 'kafeizhibo', name: '咖啡直播', api: '/video/kafeizhibo', defaultTid: 'all', cats: [{ n: '全部直播', v: 'all' }, { n: '热门直播', v: 'hot' }, { n: 'NBA', v: 'nba' }, { n: '足球直播', v: '1' }, { n: '篮球直播', v: '2' }, { n: '网球直播', v: '3' }, { n: '台球直播', v: '19' }, { n: '赛程列表', v: 'schedule' }, { n: '录像', v: 'recordings' }] },
  { id: 'tiyu919', name: '919体育', api: '/video/tiyu919', defaultTid: '1', cats: [{ n: '全部', v: '1' }, { n: '足球', v: '2' }, { n: '篮球', v: '3' }] },
  { id: 'jrszhibo', name: 'JRS直播', api: '/video/jrszhibo', defaultTid: 'live', cats: [{ n: '正在直播', v: 'live' }, { n: '全部赛程', v: 'all' }, { n: '篮球直播', v: 'basketball' }, { n: '足球直播', v: 'football' }, { n: '热门赛事', v: 'hot' }, { n: '其他赛事', v: 'other' }] },
  { id: 'iqzhibo', name: '爱球直播', api: '/video/iqzhibo', defaultTid: 'zuqiu', cats: [{ n: '足球直播', v: 'zuqiu' }, { n: '篮球直播', v: 'lanqiu' }, { n: '实时赛程', v: 'sssc' }, { n: '赛事回放', v: 'huifang' }, { n: '世界杯', v: 'fifa' }, { n: '中超', v: 'zhongchao' }, { n: '英超', v: 'yingchao' }, { n: '西甲', v: 'xijia' }, { n: '德甲', v: 'dejia' }, { n: '意甲', v: 'yijia' }, { n: '法甲', v: 'fajia' }] },
  { id: 'qiutongtiyu', name: '球通体育', api: '/video/qiutongtiyu', defaultTid: '-1', cats: [{ n: '全部', v: '-1' }, { n: '足球', v: '1' }, { n: '篮球', v: '2' }] },
  { id: '88kanqiu', name: '88看球', api: '/video/88kanqiu', defaultTid: 'all', cats: [{ n: '正在直播', v: 'all' }, { n: '足球直播', v: 'zuqiu' }, { n: '篮球直播', v: 'lanqiu' }, { n: '综合直播', v: 'zonghe' }] },
];
function sourceById(id) { return SOURCES.find(s => s.id === String(id || '')) || null; }

async function register_kafeizhibo() {
  const module = { exports: null };
  const exports = module.exports;
const axios = require('axios');
const http = require('http');
const https = require('https');

const HOST = 'https://kafeizhibo.com';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36';
const PAGE_SIZE = 30;

const meta = {
  key: 'kafeizhibo',
  name: '咖啡直播',
  type: 4,
  api: '/video/kafeizhibo',
  searchable: 0,
  quickSearch: 0,
  filterable: 0,
};

const store = {
  init: false,
  log: console,
};

const client = axios.create({
  timeout: 20000,
  proxy: false,
  maxRedirects: 5,
  httpAgent: new http.Agent({ keepAlive: true }),
  httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
  validateStatus: s => s >= 200 && s < 500,
  headers: {
    'User-Agent': UA,
    'Referer': HOST + '/pc',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'zh-CN,zh;q=0.9',
  },
});

const CLASSES = [
  { type_id: 'all', type_name: '全部直播' },
  { type_id: 'hot', type_name: '热门直播' },
  { type_id: 'nba', type_name: 'NBA' },
  { type_id: '1', type_name: '足球直播' },
  { type_id: '2', type_name: '篮球直播' },
  { type_id: '3', type_name: '网球直播' },
  { type_id: '19', type_name: '台球直播' },
  { type_id: 'schedule', type_name: '赛程列表' },
  { type_id: 'recordings', type_name: '录像' },
];

function clean(s) {
  return String(s || '').replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
}

function absUrl(url) {
  const value = String(url || '').trim();
  if (!value) return '';
  if (/^https?:\/\//i.test(value)) return value;
  if (value.startsWith('//')) return 'https:' + value;
  if (value.startsWith('/')) return HOST + value;
  return HOST + '/' + value.replace(/^\/+/, '');
}

async function apiGet(path, params = {}) {
  const url = path.startsWith('http') ? path : HOST + path;
  const res = await client.get(url, { params: { ...params, _t: Date.now() } });
  if (res.status < 200 || res.status >= 300) throw new Error(`HTTP ${res.status}: ${url}`);
  return typeof res.data === 'string' ? JSON.parse(res.data || '{}') : (res.data || {});
}

function titleOf(it = {}) {
  const mi = it.match_info || {};
  const league = it.league_name || mi.league_name || it.league || '';
  const home = it.home_team || mi.home_team || it.homeTeam?.name || '';
  const away = it.away_team || mi.away_team || it.awayTeam?.name || '';
  const title = it.title || it.name || '';
  if (title && title !== it.name) return clean(title);
  if (league && home && away) return clean(`${league} ${home} vs ${away}`);
  return clean(title || it.name || `直播间 ${it.room_id || it.id || ''}`);
}

function remarkOf(it = {}) {
  const status = it.status || it.match_info?.status || '';
  const parts = [];
  if (status === 'live' || it.is_live) parts.push('直播中');
  else if (status === 'online') parts.push('在线');
  else if (status === 'upcoming') parts.push('未开赛');
  else if (status === 'finished') parts.push('已结束');
  else if (status) parts.push(status);

  const hasScore = it.home_score !== undefined && it.away_score !== undefined;
  const score = hasScore ? `${it.home_score}-${it.away_score}` : '';
  if (score && score !== '0-0') parts.push(score);
  if (it.heat) parts.push(`热度:${it.heat}`);
  if (it.start_time && !parts.includes(it.start_time)) parts.push(it.start_time);
  if (it.name && it.title && it.name !== it.title) parts.push(it.name);
  return clean(parts.join(' ')) || '直播';
}

function picOf(it = {}) {
  return absUrl(
    it.screenshot ||
    it.cover_image ||
    it.avatar ||
    it.home_team_logo ||
    it.away_team_logo ||
    it.homeTeam?.logo ||
    it.awayTeam?.logo ||
    '/images/logo.png'
  );
}

function itemToVod(it = {}) {
  const roomId = it.room_id || it.archor?.room_id || (Array.isArray(it.archors) && it.archors[0]?.room_id) || '';
  if (!roomId) return null;
  const title = titleOf(it);
  return {
    vod_id: `${roomId}###${encodeURIComponent(title)}`,
    vod_name: title,
    vod_pic: picOf(it),
    vod_remarks: remarkOf(it),
  };
}

function recordingToVod(it = {}) {
  const matchId = it.match_id || it.id || '';
  if (!matchId) return null;
  const title = titleOf(it);
  return {
    vod_id: `rec$${matchId}###${encodeURIComponent(title)}`,
    vod_name: title,
    vod_pic: picOf(it),
    vod_remarks: clean([it.start_time || '', it.recording_count ? `录像:${it.recording_count}` : '录像'].filter(Boolean).join(' ')),
  };
}

function pushUnique(list, seen, vod) {
  if (!vod || !vod.vod_id || seen.has(vod.vod_id)) return;
  seen.add(vod.vod_id);
  list.push(vod);
}

async function home() {
  const result = await category({ id: 'all', page: 1 });
  return {
    class: CLASSES,
    filters: {},
    list: result.list,
    page: 1,
    pagecount: 1,
    total: result.total || result.list.length,
  };
}

async function category({ id = 'all', page = 1 }) {
  const tid = String(id || 'all');
  const pg = Math.max(1, parseInt(page || '1'));
  const list = [];
  const seen = new Set();
  let total = 0;

  try {
    if (tid === 'recordings') {
      const json = await apiGet('/api/v1/recordings', { page: pg, size: PAGE_SIZE });
      const data = Array.isArray(json.data) ? json.data : [];
      data.forEach(it => pushUnique(list, seen, recordingToVod(it)));
      total = json.total || list.length;
    } else if (tid === 'schedule' || tid === 'nba') {
      // 官网没有单独 NBA API。NBA 分类用篮球赛程聚合后按 NBA/WNBA/美职篮关键字过滤；没有 NBA 时保持空列表。
      const json = await apiGet('/api/v1/schedule', {
        type: tid === 'nba' ? '2' : 'all',
        page: pg,
        size: tid === 'nba' ? 100 : PAGE_SIZE,
      });
      const data = Array.isArray(json.data) ? json.data : [];
      for (const row of data) {
        const title = titleOf(row);
        if (tid === 'nba' && !/NBA|WNBA|美职篮|美国职业篮球/i.test(title)) continue;
        if (Array.isArray(row.archors) && row.archors.length) {
          for (const a of row.archors) {
            pushUnique(list, seen, itemToVod({ ...row, ...a, title, screenshot: row.screenshot || a.screenshot }));
          }
        } else {
          pushUnique(list, seen, itemToVod(row));
        }
      }
      total = tid === 'nba' ? list.length : (json.total || list.length);
    } else {
      const type = tid === 'all' ? '' : tid;
      const json = await apiGet('/api/v1/archor', { type });
      const data = Array.isArray(json.data) ? json.data : [];
      data.forEach(it => pushUnique(list, seen, itemToVod(it)));
      total = json.total || list.length;
    }
  } catch (e) {
    store.log.error(e);
  }

  return { list, page: pg, pagecount: list.length ? pg + 1 : pg, limit: PAGE_SIZE, total };
}

async function detail(ids) {
  const raw = Array.isArray(ids) ? ids[0] : String(ids || '').split(',')[0];
  let id = String(raw || '');
  let displayName = '咖啡直播';
  if (id.includes('###')) {
    const parts = id.split('###', 2);
    id = parts[0];
    try { displayName = decodeURIComponent(parts[1] || displayName); } catch (_) { displayName = parts[1] || displayName; }
  }
  if (!id) return { list: [] };

  if (id.startsWith('rec$')) {
    const matchId = id.slice(4);
    let vod = {
      vod_id: id,
      vod_name: displayName,
      vod_pic: HOST + '/images/logo.png',
      vod_remarks: '录像',
      vod_play_from: '咖啡录像',
      vod_play_url: '',
      vod_content: '咖啡直播赛事录像',
    };
    try {
      const json = await apiGet(`/api/v1/match/${encodeURIComponent(matchId)}/recordings`);
      const data = json.data || {};
      const match = data.match || {};
      const urls = [];
      const replays = Array.isArray(data.replays) ? data.replays : [];
      const highlights = Array.isArray(data.highlights) ? data.highlights : [];
      replays.forEach((it, i) => { if (it.video_url) urls.push(`${clean(it.title || `录像${i + 1}`)}$${it.video_url}`); });
      highlights.forEach((it, i) => { if (it.video_url) urls.push(`${clean(it.title || `集锦${i + 1}`)}$${it.video_url}`); });
      vod = {
        vod_id: id,
        vod_name: titleOf(match) || displayName,
        vod_pic: absUrl(replays[0]?.cover_image || match.cover_image || match.home_team_logo || match.away_team_logo || '/images/logo.png'),
        vod_remarks: clean([match.start_time || '', match.home_score !== undefined ? `${match.home_score}-${match.away_score}` : ''].filter(Boolean).join(' ')) || '录像',
        vod_play_from: '咖啡录像',
        vod_play_url: urls.join('#'),
        vod_content: '咖啡直播赛事录像',
      };
    } catch (e) {
      store.log.error(e);
    }
    return { list: [vod], page: 1, pagecount: 1, total: 1 };
  }

  let vod = {
    vod_id: id,
    vod_name: displayName,
    vod_pic: HOST + '/images/logo.png',
    vod_remarks: '直播',
    vod_play_from: '咖啡直播',
    vod_play_url: '',
    vod_content: '咖啡直播实时体育直播',
  };

  try {
    const json = await apiGet(`/api/v1/room/${encodeURIComponent(id)}`);
    const data = json.data || {};
    const room = data.room_info || {};
    const archor = data.archor || {};
    const signals = Array.isArray(data.signals) ? data.signals : [];
    const urls = [];
    const seen = new Set();
    const addLine = (name, url) => {
      const u = String(url || '').trim();
      if (!u || seen.has(u)) return;
      seen.add(u);
      urls.push(`${clean(name || `线路${urls.length + 1}`)}$${u}`);
    };
    signals.forEach(it => addLine(it.name, it.stream_url));
    addLine(archor.name, archor.stream_url);

    vod = {
      vod_id: id,
      vod_name: clean(room.title || displayName),
      vod_pic: absUrl(archor.screenshot || room.avatar || archor.avatar || '/images/logo.png'),
      vod_remarks: remarkOf({ ...room, ...archor }),
      vod_play_from: '咖啡直播',
      vod_play_url: urls.join('#'),
      vod_content: clean(room.notice || room.notice_h5 || '咖啡直播实时体育直播'),
    };
  } catch (e) {
    store.log.error(e);
  }

  return { list: [vod], page: 1, pagecount: 1, total: 1 };
}

async function search() {
  return { list: [], page: 1, pagecount: 1, total: 0 };
}

function player(id) {
  return {
    parse: 0,
    url: id,
    header: {
      'User-Agent': UA,
      'Referer': HOST + '/pc',
    },
  };
}

async function handleT4Request(req) {
  const q = req.query || {};
  const ac = q.ac || '';

  if (q.play || q.url) return player(q.play || q.url);
  if (q.ids || (q.id && !q.t)) return await detail(q.ids || q.id);
  if (ac === 'search' || q.wd) return await search(q.wd, q.pg || 1);
  if (q.t !== undefined || q.tid !== undefined) return await category({ id: q.t ?? q.tid, page: q.pg || 1 });
  if (ac === 'class') return { class: CLASSES, filters: {} };
  return await home();
}

async function init(server) {
  if (store.init) return;
  store.log = server?.log || console;
  store.init = true;
}

module.exports = async (app, opt) => {
  app.get(meta.api, async (req, reply) => {
    if (!store.init) await init(req.server);
    try {
      return await handleT4Request(req);
    } catch (e) {
      store.log.error(e);
      return { list: [], page: 1, pagecount: 1, total: 0, error: e.message || String(e) };
    }
  });
  opt.sites.push(meta);
};

  if (typeof module.exports !== 'function') throw new Error('embedded source did not export function');
  const fakeApp = { get(p, h) { INTERNAL_ROUTES[p] = h; } };
  const fakeOpt = { sites: [] };
  await module.exports(fakeApp, fakeOpt);
}

async function register_tiyu919() {
  const module = { exports: null };
  const exports = module.exports;
const axios = require('axios');
const http = require('http');
const https = require('https');

const API_BASE = 'https://01cs01.fusk39cd.com/api/web/live_lists';
const HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Accept': 'application/json, text/plain, */*',
  'Referer': 'https://01cs01.fusk39cd.com/'
};
const PAGE_SIZE = 20;

const _http = axios.create({
  timeout: 10000,
  headers: HEADERS,
  httpAgent: new http.Agent({ keepAlive: true }),
  httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
  validateStatus: status => status >= 200 && status < 500
});

const meta = {
  key: 'tiyu919',
  name: '919体育',
  type: 4,
  api: '/video/tiyu919',
  searchable: 0,
  quickSearch: 0,
  filterable: 0,
  changeable: 1,
  style: { type: 'rect', ratio: 1.78 }
};

const store = { init: false, log: console };

function safeString(v) {
  if (v === null || v === undefined || v === 'null') return '';
  return String(v);
}

async function requestJson(url) {
  const res = await _http.get(url);
  const data = res.data;
  if (typeof data === 'object') return data;
  if (!data) return null;
  try { return JSON.parse(data); } catch (e) { return null; }
}

function getClasses() {
  return [
    { type_id: '1', type_name: '全部' },
    { type_id: '2', type_name: '足球' },
    { type_id: '3', type_name: '篮球' }
  ];
}

async function getCategory(tid, pg) {
  const page = Math.max(parseInt(pg || '1', 10) || 1, 1);
  const typeId = safeString(tid || '1') || '1';
  const list = [];

  try {
    const url = `${API_BASE}/${encodeURIComponent(typeId)}`;
    const json = await requestJson(url);
    const rows = json && json.code === 200 && json.data && Array.isArray(json.data.data) ? json.data.data : [];

    for (const item of rows) {
      if (!item.tournament_id) continue;
      const type = safeString(item.type || typeId);
      const tournamentId = safeString(item.tournament_id);
      const memberId = safeString(item.member_id);
      const home = safeString(item.home_team_zh);
      const away = safeString(item.away_team_zh);
      const name = [home, away].filter(Boolean).join(' VS ') || safeString(item.league_name_zh) || tournamentId;

      list.push({
        vod_id: `${type}|${tournamentId}|${memberId}`,
        vod_name: name,
        vod_pic: safeString(item.cover),
        vod_remarks: safeString(item.league_name_zh) || safeString(item.match_time) || safeString(item.status)
      });
    }
  } catch (e) {
    store.log.error && store.log.error(`[919体育] category failed: ${e.message}`);
  }

  return {
    page,
    pagecount: list.length >= PAGE_SIZE ? page + 1 : page,
    limit: PAGE_SIZE,
    total: list.length,
    list
  };
}

async function getDetail(ids) {
  const idList = Array.isArray(ids) ? ids : String(ids || '').split(',').filter(Boolean);
  const list = [];

  for (const rawId of idList) {
    const vid = safeString(rawId).trim();
    const parts = vid.split('|');
    if (parts.length !== 3) continue;

    const [type, tournamentId, memberId] = parts;
    try {
      const url = `${API_BASE}/${encodeURIComponent(type)}/detail/${encodeURIComponent(tournamentId)}?member_id=${encodeURIComponent(memberId)}`;
      const json = await requestJson(url);
      if (!json || json.code !== 200) continue;

      const detailObj = json.data && json.data.detail ? json.data.detail : {};
      const moreArr = json.data && Array.isArray(json.data.more) ? json.data.more : [];
      const home = safeString(detailObj.home_team_zh);
      const away = safeString(detailObj.away_team_zh);
      const vodName = [home, away].filter(Boolean).join(' VS ') || safeString(detailObj.league_name_zh) || vid;

      const playFromList = [];
      const playUrlList = [];
      moreArr.forEach((source, i) => {
        const username = safeString(source.username) || `线路${i + 1}`;
        const urls = [];
        const flv = safeString(source.screen_url);
        const m3u8 = safeString(source.screen_url_m3u8);
        if (flv) urls.push(`线路一$${flv}`);
        if (m3u8) urls.push(`线路二$${m3u8}`);
        if (!urls.length) return;
        playFromList.push(username.replace(/\$|#/g, ''));
        playUrlList.push(urls.join('#'));
      });

      list.push({
        vod_id: vid,
        vod_name: vodName,
        vod_pic: safeString(detailObj.cover),
        type_name: safeString(detailObj.league_name_zh),
        vod_remarks: safeString(detailObj.match_time) || safeString(detailObj.status),
        vod_content: safeString(detailObj.room_notice) || '体育直播',
        vod_play_from: playFromList.join('$$$') || '919体育',
        vod_play_url: playUrlList.join('$$$') || `暂无播放$${vid}`
      });
    } catch (e) {
      store.log.error && store.log.error(`[919体育] detail failed id=${vid}: ${e.message}`);
    }
  }

  return { list, page: 1, pagecount: 1, total: list.length };
}

async function playUrl(id) {
  const url = safeString(id).replace(/\*\*\*/g, '#');
  if (!/^https?:\/\//i.test(url)) {
    return { parse: 0, jx: 0, url: '', msg: '暂无播放地址' };
  }
  return { parse: 0, jx: 0, url, header: HEADERS };
}

async function search() {
  return { list: [], page: 1, pagecount: 1, total: 0 };
}

async function handleT4Request(req) {
  const { ac, t, ids, play, pg, wd } = req.query;

  if (play) return await playUrl(play);
  if (wd) return await search();
  if (ids) return await getDetail(ids);

  if (ac === 'detail' && t !== undefined) {
    return await getCategory(t, pg);
  }

  if (!ac || ac === 'class') {
    const classes = getClasses();
    if (ac === 'class') return { class: classes };
    const result = await getCategory('1', 1);
    return { class: classes, list: result.list, page: 1, pagecount: result.pagecount, total: result.total };
  }

  return { list: [], page: 1, pagecount: 1, total: 0 };
}

async function init(server) {
  if (store.init) return;
  store.log = server.log || console;
  store.init = true;
}

module.exports = async (app, opt) => {
  app.get(meta.api, async (req, reply) => {
    if (!store.init) await init(req.server);
    try {
      return await handleT4Request(req);
    } catch (e) {
      req.server.log.error(e);
      return { list: [], code: -1, msg: e.message };
    }
  });
  opt.sites.push(meta);
};

  if (typeof module.exports !== 'function') throw new Error('embedded source did not export function');
  const fakeApp = { get(p, h) { INTERNAL_ROUTES[p] = h; } };
  const fakeOpt = { sites: [] };
  await module.exports(fakeApp, fakeOpt);
}

async function register_jrszhibo() {
  const module = { exports: null };
  const exports = module.exports;
const axios = require('axios');
const cheerio = require('cheerio');
const http = require('http');
const https = require('https');

const HOSTS = [
  'https://m.jrskk.com',
  'https://m.jrs21.com',
  'https://www.jrs33.com',
  'https://3.swjrzx.com'
];
const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1';
const DEFAULT_PIC = 'https://im-imgs-bucket.oss-accelerate.aliyuncs.com/icon-192.png';
const playCache = new Map();
const VOD_TOKEN = '';

const _http = axios.create({
  timeout: 30000,
  maxRedirects: 5,
  proxy: false,
  httpAgent: new http.Agent({ keepAlive: true }),
  httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false })
});

const headers = (referer) => ({
  'User-Agent': UA,
  'Referer': referer || HOSTS[0] + '/',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,application/json,*/*;q=0.8',
  'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8'
});

const classes = [
  { type_id: 'live', type_name: '正在直播' },
  { type_id: 'all', type_name: '全部赛程' },
  { type_id: 'basketball', type_name: '篮球直播' },
  { type_id: 'football', type_name: '足球直播' },
  { type_id: 'hot', type_name: '热门赛事' },
  { type_id: 'other', type_name: '其他赛事' }
];

let activeHost = HOSTS[0];
let homeCache = { time: 0, html: '', host: activeHost };

function cleanText(s) {
  return String(s || '').replace(/\s+/g, ' ').trim();
}

function absUrl(url, base = activeHost) {
  url = String(url || '').trim();
  if (!url) return '';
  if (/^https?:\/\//i.test(url)) return url;
  if (url.startsWith('//')) return 'https:' + url;
  try { return new URL(url, base).toString(); } catch (e) { return url; }
}

function b64Encode(str) {
  return Buffer.from(String(str || ''), 'utf8').toString('base64url');
}

function b64Decode(str) {
  try { return Buffer.from(String(str || ''), 'base64url').toString('utf8'); } catch (e) { return ''; }
}

function getOrigin(url) {
  try { return new URL(url).origin; } catch (e) { return activeHost; }
}

function parseQueryValue(url, key) {
  try { return new URL(url).searchParams.get(key) || ''; } catch (e) { return ''; }
}

function requestBase(req) {
  const proto = String(req?.headers?.['x-forwarded-proto'] || 'http').split(',')[0].trim() || 'http';
  const host = String(req?.headers?.['x-forwarded-host'] || req?.headers?.host || '').split(',')[0].trim();
  return host ? `${proto}://${host}` : '';
}

function requestToken(req) {
  return String(req?.query?.token || VOD_TOKEN).trim();
}

function proxyUrl(req, targetUrl, type = '') {
  const qs = new URLSearchParams({ url: b64Encode(targetUrl) });
  if (type) qs.set('type', type);
  const token = requestToken(req);
  if (token) qs.set('token', token);
  const path = `/video/jrszhibo/proxy?${qs.toString()}`;
  return requestBase(req) ? requestBase(req) + path : path;
}

async function proxy(req, reply) {
  const targetUrl = b64Decode(req.query?.url || '');
  const type = String(req.query?.type || '').toLowerCase();
  if (!/^https?:\/\//i.test(targetUrl)) {
    if (reply?.code) reply.code(400);
    return 'bad url';
  }
  const isM3u8 = type === 'm3u8' || /\.m3u8(\?|$)/i.test(targetUrl);
  const hd = headers('https://cloud.yumixiu768.com/player/msss.html');
  hd.Origin = 'https://cloud.yumixiu768.com';
  hd.Accept = isM3u8 ? 'application/vnd.apple.mpegurl,application/x-mpegURL,*/*' : '*/*';
  if (req.headers?.range && !isM3u8) hd.Range = req.headers.range;
  try {
    const res = await _http.get(targetUrl, {
      responseType: isM3u8 ? 'text' : 'arraybuffer',
      headers: hd,
      timeout: isM3u8 ? 15000 : 45000,
      validateStatus: s => s >= 200 && s < 500,
    });
    if (res.status < 200 || res.status >= 300) {
      if (reply?.code) reply.code(res.status || 502);
      return `proxy status ${res.status}`;
    }
    if (reply?.header) {
      reply.header('Access-Control-Allow-Origin', '*');
      reply.header('Cache-Control', 'no-store');
    }
    if (isM3u8) {
      const body = typeof res.data === 'string' ? res.data : Buffer.from(res.data || '').toString('utf8');
      if (reply?.type) reply.type('application/vnd.apple.mpegurl; charset=utf-8');
      return body.split(/\r?\n/).map(line => {
        const t = line.trim();
        if (!t) return line;
        if (t.startsWith('#')) {
          return line.replace(/URI="([^"]+)"/g, (_, u) => `URI="${proxyUrl(req, absUrl(u, targetUrl), 'key')}"`);
        }
        const u = absUrl(t, targetUrl);
        return proxyUrl(req, u, /\.m3u8(\?|$)/i.test(u) ? 'm3u8' : 'media');
      }).join('\n');
    }
    if (reply?.code && res.status === 206) reply.code(206);
    if (reply?.header) {
      reply.header('Content-Type', res.headers?.['content-type'] || (type === 'key' ? 'application/octet-stream' : 'video/mp2t'));
      for (const h of ['content-length', 'content-range', 'accept-ranges']) {
        if (res.headers?.[h]) reply.header(h, res.headers[h]);
      }
    }
    return Buffer.from(res.data || []);
  } catch (e) {
    if (reply?.code) reply.code(502);
    return `proxy error: ${e.message}`;
  }
}

function matchCategory(tid, league, name, stype, hot) {
  tid = String(tid || 'all');
  const text = `${league} ${name}`;
  if (tid === 'all') return true;
  if (tid === 'live') return true;
  if (tid === 'hot') return !!hot || /(NBA|CBA|英超|西甲|意甲|德甲|法甲|欧冠|中超|世界杯|世俱杯|亚冠|热门)/i.test(text);
  if (tid === 'basketball') return stype === 'lq' || /(NBA|CBA|WNBA|NBL|篮球|篮)/i.test(text);
  if (tid === 'football') return stype === 'zq' || /(足球|英超|西甲|意甲|德甲|法甲|欧冠|欧联|中超|亚冠|足协|世界杯|世俱|巴西甲|巴西乙|日职|韩K|联赛|杯)/i.test(text) && !/(NBA|CBA|WNBA|NBL|篮球|篮)/i.test(text);
  if (tid === 'other') return !matchCategory('basketball', league, name, stype) && !matchCategory('football', league, name, stype);
  return true;
}

async function requestText(url, referer) {
  const res = await _http.get(url, { headers: headers(referer), responseType: 'arraybuffer' });
  const buf = Buffer.from(res.data || '');
  let text = buf.toString('utf8');
  if (/�|å|ç|æ/.test(text.slice(0, 1000))) {
    try { text = buf.toString('latin1'); } catch (e) {}
  }
  return text;
}

async function fetchHome(force = false) {
  if (!force && homeCache.html && Date.now() - homeCache.time < 60 * 1000) return homeCache;
  let lastErr = null;
  for (const host of HOSTS) {
    try {
      const html = await requestText(host + '/', host + '/');
      if (html && /loc_match|lab_team|JRKAN|play\/steam/i.test(html)) {
        activeHost = host;
        homeCache = { time: Date.now(), html, host };
        return homeCache;
      }
    } catch (e) { lastErr = e; }
  }
  if (lastErr) throw lastErr;
  return homeCache;
}

function parseHomeList(html, tid) {
  const $ = cheerio.load(html || '');
  const list = [];
  $('ul.item').each((_, el) => {
    const $el = $(el);
    const links = [];
    $el.find('a.ok.me').each((__, a) => {
      const $a = $(a);
      const href = $a.attr('href') || $a.attr('data-play') || '';
      if (!href || href === 'javascript:void(0)') return;
      links.push({ name: cleanText($a.find('strong').text() || $a.text()) || `线路${links.length + 1}`, url: absUrl(href, activeHost) });
    });
    if (!links.length) return;

    const league = cleanText($el.find('.lab_events .name').first().text());
    const time = cleanText($el.find('.lab_time').first().text());
    const home = cleanText($el.find('.lab_team_home .name').first().text());
    const away = cleanText($el.find('.lab_team_away .name').first().text());
    let name = [time, league, [home, away].filter(Boolean).join(' vs ')].filter(Boolean).join(' ');
    if (!name) name = cleanText($el.text()).slice(0, 80) || '赛事直播';
    const stype = cleanText($el.attr('data-stype'));
    const hot = /hot/.test($el.attr('class') || '');
    if (!matchCategory(tid, league, name, stype, hot)) return;

    let pic = $el.find('.lab_team_home img').attr('src') || $el.find('.lab_team_away img').attr('src') || DEFAULT_PIC;
    pic = absUrl(pic, activeHost);
    const payload = { name, pic, links };
    list.push({
      vod_id: 'jrs$' + b64Encode(JSON.stringify(payload)),
      vod_name: name,
      vod_pic: pic,
      vod_remarks: links.map(x => x.name).slice(0, 3).join('/') || '直播'
    });
  });
  return list;
}

async function category(tid, pg) {
  const { html } = await fetchHome(false);
  const list = parseHomeList(html, tid);
  return { list, page: Number(pg || 1), pagecount: 1, limit: list.length, total: list.length };
}

async function resolveOuterPlayPage(url) {
  const cacheKey = String(url || '');
  const cached = playCache.get(cacheKey);
  if (cached && Date.now() - cached.time < 2 * 60 * 1000) return cached.links;

  const links = [];
  try {
    const html = await requestText(url, activeHost + '/');
    const $ = cheerio.load(html || '');
    $('a.ok.me').each((_, a) => {
      const $a = $(a);
      const p = $a.attr('data-play') || $a.attr('href') || '';
      if (!p || p === 'javascript:void(0)') return;
      const name = cleanText($a.find('strong').text() || $a.text()) || `线路${links.length + 1}`;
      links.push({ name, url: absUrl(p, getOrigin(url)) });
    });
    if (!links.length) {
      const iframe = $('iframe').first().attr('src') || '';
      if (iframe) links.push({ name: '直播', url: absUrl(iframe, getOrigin(url)) });
    }
  } catch (e) {}

  const finalLinks = links.length ? links : [{ name: '直播', url }];
  playCache.set(cacheKey, { time: Date.now(), links: finalLinks });
  return finalLinks;
}

function normalizeInnerPlayUrl(url) {
  const s = String(url || '');
  const origin = getOrigin(s);
  const id = parseQueryValue(s, 'id');
  if (/\/play\/sm\.html/i.test(s) && id) return `${origin}/play/${encodeURIComponent(id)}.html`;
  if (/\/play\/kbs\.html/i.test(s) && id) return `${origin}/play/kbmm.php?id=${encodeURIComponent(id)}`;
  return s;
}

async function resolveM3u8Variant(url) {
  if (!/\.m3u8(\?|$)/i.test(String(url || ''))) return url;
  try {
    const res = await _http.get(url, {
      headers: headers('https://cloud.yumixiu768.com/player/msss.html'),
      responseType: 'text',
      timeout: 12000
    });
    const text = String(res.data || '');
    if (!/#EXT-X-STREAM-INF/i.test(text)) return url;
    const lines = text.split(/\r?\n/).map(x => x.trim()).filter(Boolean);
    for (const line of lines) {
      if (!line.startsWith('#')) return absUrl(line, url);
    }
  } catch (e) {}
  return url;
}

async function resolvePlayableUrl(url) {
  let u = normalizeInnerPlayUrl(url);
  try {
    const html = await requestText(u, activeHost + '/');
    const iframe = String(html || '').match(/<iframe[^>]+src=["']([^"']+)["']/i);
    if (iframe && iframe[1]) {
      const iframeUrl = absUrl(iframe[1], getOrigin(u));
      const m3u8 = iframeUrl.match(/[?&]id=([^#]+?\.m3u8[^#]*)/i);
      if (m3u8 && m3u8[1]) {
        let direct = decodeURIComponent(m3u8[1]);
        // cloud.yumixiu768.com/player/msss.html 会在前端把 /live/xxx.m3u8 拼到 hdl6.szsummer.cn，
        // 直接拼 cloud 域名会 404，所以这里按播放器 JS 的逻辑还原真实 m3u8。
        if (direct.startsWith('/')) direct = 'https://hdl6.szsummer.cn' + direct;
        else if (!/^https?:\/\//i.test(direct)) direct = absUrl(direct, 'https://hdl6.szsummer.cn');
        return direct;
      }
      return iframeUrl;
    }
  } catch (e) {}
  return u;
}

async function detail(id) {
  let payload = null;
  const raw = String(id || '');
  if (raw.startsWith('jrs$')) {
    try { payload = JSON.parse(b64Decode(raw.slice(4))); } catch (e) {}
  }
  if (!payload && /^https?:\/\//i.test(raw)) payload = { name: '赛事直播', pic: DEFAULT_PIC, links: [{ name: '直播', url: raw }] };
  if (!payload) return null;
  let links = [];
  for (const outer of (payload.links || [])) {
    const inner = await resolveOuterPlayPage(outer.url);
    for (const it of inner) {
      const name = `${cleanText(outer.name) || '直播'}-${cleanText(it.name) || '线路'}`.replace(/^-|-$/g, '');
      links.push({ name, url: normalizeInnerPlayUrl(it.url) });
    }
  }
  if (!links.length) links = payload.links || [];
  const seen = new Set();
  links = links.filter(x => { const k = x.url; if (!k || seen.has(k)) return false; seen.add(k); return true; });
  const directList = links.map((x, i) => `${cleanText(x.name) || '线路' + (i + 1)}$${x.url}`).join('#');
  const webList = (payload.links || []).map((x, i) => `${cleanText(x.name) || '网页线路' + (i + 1)}$web@${x.url}`).join('#');
  return {
    vod_id: raw,
    vod_name: payload.name || '赛事直播',
    vod_pic: payload.pic || DEFAULT_PIC,
    vod_remarks: '直播',
    vod_content: 'JRKAN 体育赛事直播。直链超时时请切换到「网页嗅探」分组。',
    vod_play_from: 'JRS直链$$$网页嗅探',
    vod_play_url: `${directList}$$$${webList}`
  };
}

async function handleT4Request(req) {
  const { ac, t, ids, play, proxy: proxyFlag } = req.query || {};
  if (proxyFlag !== undefined || req.url?.includes('/proxy?')) return await proxy(req, req.reply);
  if (play) {
    if (String(play).startsWith('web@')) {
      const webUrl = String(play).slice(4);
      return { parse: 1, url: webUrl, header: headers(activeHost + '/') };
    }
    const url = await resolvePlayableUrl(play);
    const referer = /(?:hdl6\.szsummer\.cn|livehwc\d*\.com|cloud\.yumixiu768\.com)/i.test(String(url))
      ? 'https://cloud.yumixiu768.com/player/msss.html'
      : activeHost + '/';
    const isMedia = /\.(m3u8|mp4|flv)(\?|$)/i.test(String(url));
    // 不在服务端继续追 livehwc4，也不走本机代理：该 CDN 边缘容易按服务端出口超时。
    // 直接把 hdl6 master m3u8 + cloud Referer 交给壳子，让客户端自行取边缘节点。
    return { parse: isMedia ? 0 : 1, url, header: headers(referer) };
  }
  if (ids) {
    const vod = await detail(ids);
    return { list: vod ? [vod] : [], page: 1, pagecount: 1, total: vod ? 1 : 0 };
  }
  if (t !== undefined) return await category(t || 'all', req.query.pg || 1);
  if (!ac || ac === 'class') {
    if (ac === 'class') return { class: classes };
    const home = await category('live', 1);
    return { class: classes, filters: {}, list: home.list, page: 1, pagecount: 1, total: home.list.length };
  }
  return { list: [], page: 1, pagecount: 1 };
}

const meta = { key: 'jrszhibo', name: 'JRS直播', type: 4, api: '/video/jrszhibo', searchable: 0, quickSearch: 0, filterable: 0 };

module.exports = async (app, opt) => {
  app.get(meta.api + '/proxy', async (req, reply) => {
    try { return await proxy(req, reply); }
    catch (e) {
      req.server.log.error('[JRS直播 proxy] ' + (e && e.stack || e));
      if (reply?.code) reply.code(502);
      return 'proxy error';
    }
  });
  app.get(meta.api, async (req, reply) => {
    req.reply = reply;
    try { return await handleT4Request(req); }
    catch (e) {
      req.server.log.error('[JRS直播] ' + (e && e.stack || e));
      return { list: [], page: 1, pagecount: 1, error: String(e && e.message || e) };
    }
  });
  opt.sites.push(meta);
};

  if (typeof module.exports !== 'function') throw new Error('embedded source did not export function');
  const fakeApp = { get(p, h) { INTERNAL_ROUTES[p] = h; } };
  const fakeOpt = { sites: [] };
  await module.exports(fakeApp, fakeOpt);
}

async function register_iqzhibo() {
  const module = { exports: null };
  const exports = module.exports;
const axios = require('axios');
const cheerio = require('cheerio');
const http = require('http');
const https = require('https');

const HOST = 'https://www.iqzhibo.com';
const DB_HOST = 'https://www.doubaozhibo.com';
const DB_SCHEDULE_API = `${DB_HOST}/api/v1/schedules/public/local`;
const DB_PLAYBACK_API = `${DB_HOST}/api/v1/playbacks`;
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36';

const _http = axios.create({
  timeout: 30000,
  httpAgent: new http.Agent({ keepAlive: true }),
  httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false })
});

const headers = (referer = HOST + '/') => ({
  'User-Agent': UA,
  'Referer': referer,
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8'
});

const absUrl = (url, base = HOST) => {
  if (!url) return '';
  try { return new URL(url, base).toString(); } catch (e) { return url; }
};

const cleanText = (s) => String(s || '').replace(/\s+/g, ' ').trim();

const classes = [
  { type_id: 'zuqiu', type_name: '足球直播' },
  { type_id: 'lanqiu', type_name: '篮球直播' },
  { type_id: 'sssc', type_name: '实时赛程' },
  { type_id: 'huifang', type_name: '赛事回放' },
  { type_id: 'fifa', type_name: '世界杯' },
  { type_id: 'zhongchao', type_name: '中超' },
  { type_id: 'yingchao', type_name: '英超' },
  { type_id: 'xijia', type_name: '西甲' },
  { type_id: 'dejia', type_name: '德甲' },
  { type_id: 'yijia', type_name: '意甲' },
  { type_id: 'fajia', type_name: '法甲' }
];

async function requestHtml(url, referer) {
  const res = await _http.get(url, { headers: headers(referer) });
  return res.data || '';
}

async function requestJson(url, referer = DB_HOST + '/') {
  const res = await _http.get(url, { headers: headers(referer) });
  if (typeof res.data === 'object') return res.data;
  try { return JSON.parse(res.data || '{}'); } catch (e) { return {}; }
}

function parseIqList(html, tid) {
  const $ = cheerio.load(html);
  const list = [];
  $('.applive li').each((_, el) => {
    const $el = $(el);
    const title = cleanText($el.find('.liveinfo .title').text());
    const home = cleanText($el.find('.team-zhu').contents().filter(function () { return this.type === 'text'; }).text());
    const away = cleanText($el.find('.team-ke').contents().filter(function () { return this.type === 'text'; }).text());
    const a = $el.find('.livesource a').first();
    const href = a.attr('href') || '';
    if (!href) return;
    let pic = $el.find('.team img').first().attr('src') || HOST + '/logo.png';
    pic = absUrl(pic, HOST);
    const teams = [home, away].filter(Boolean).join(' vs ');
    const name = [title, teams].filter(Boolean).join(' ');
    list.push({
      vod_id: absUrl(href, HOST),
      vod_name: name || teams || title || '赛事直播',
      vod_pic: pic,
      vod_remarks: cleanText(a.text()) || '高清'
    });
  });
  return list;
}

function matchCategory(tid, league, name, dataType) {
  tid = String(tid || '');
  league = cleanText(league);
  name = cleanText(name);
  dataType = String(dataType || '');
  const text = `${league} ${name}`;
  if (!tid || tid === 'sssc' || tid === 'huifang') return true;
  if (tid === 'zuqiu') return dataType === 'football' || (/(足|超|甲|乙|冠|欧联|日职|韩K|世界杯|世俱|足球|杯)/i.test(text) && !/(篮|NBA|CBA|WNBA|NBL|篮球)/i.test(text));
  if (tid === 'lanqiu') return dataType === 'basketball' || /(篮|NBA|CBA|WNBA|NBL|篮球)/i.test(text);
  const rules = {
    fifa: /(世界杯|世俱杯|世预赛|国际足联|FIFA)/i,
    zhongchao: /(中超|足协杯|中国超级联赛)/i,
    yingchao: /(英超|英格兰超级联赛)/i,
    xijia: /(西甲|西班牙甲级联赛)/i,
    dejia: /(德甲|德国甲级联赛)/i,
    yijia: /(意甲|意大利甲级联赛)/i,
    fajia: /(法甲|法国甲级联赛)/i
  };
  return rules[tid] ? rules[tid].test(text) : true;
}

function formatTimeText(matchTime) {
  const d = new Date(matchTime);
  if (!matchTime || Number.isNaN(d.getTime())) return '';
  const pad = n => String(n).padStart(2, '0');
  return `${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function parseApiSchedule(json, tid) {
  const days = json && json.data && Array.isArray(json.data.days) ? json.data.days : [];
  const list = [];
  for (const day of days) {
    const rows = Array.isArray(day.live) ? day.live : [];
    for (const item of rows) {
      const signals = Array.isArray(item.signals) ? item.signals : [];
      if (!signals.length) continue;
      const name = `${formatTimeText(item.matchTime)} ${cleanText(item.league)} ${cleanText(item.teamA)} vs ${cleanText(item.teamB)}`.trim();
      if (!matchCategory(tid, item.league, name, item.dataType)) continue;
      const links = signals.map((s, idx) => ({
        name: cleanText(s.name || s.label) || `信号${idx + 1}`,
        url: `${DB_HOST}/play/${s.playId}?device=pc_web`
      }));
      list.push({
        vod_id: 'db$' + encodeURIComponent(JSON.stringify({ name, links })),
        vod_name: name,
        vod_pic: item.teamAImage || item.teamBImage || HOST + '/logo.png',
        vod_remarks: links.map(x => x.name).join('/') || '直播'
      });
    }
  }
  return list;
}

function parsePlaybackList(json, tid) {
  const rows = json && json.data && Array.isArray(json.data.list) ? json.data.list : [];
  const list = [];
  for (const row of rows) {
    const s = row.schedule || {};
    const p = row.playback || {};
    const lines = Array.isArray(p.lines) ? p.lines : [];
    if (!lines.length) continue;
    const fullName = cleanText(p.title) || `${formatTimeText(s.matchTime)} ${cleanText(s.league)} ${cleanText(s.teamA)} vs ${cleanText(s.teamB)} 回放`.trim();
    if (!matchCategory(tid, s.league, fullName, s.dataType)) continue;
    const shortName = `${cleanText(s.teamA)} vs ${cleanText(s.teamB)}`.replace(/^\s*vs\s*|\s*vs\s*$/g, '') || fullName.replace(/^\d{4}年\d{1,2}月\d{1,2}日\s*/, '').replace(/\s*赛事回放$/, '');
    const remarkPrefix = [formatTimeText(s.matchTime), cleanText(s.league)].filter(Boolean).join(' ');
    const links = lines.map((line, idx) => ({
      name: cleanText(line.title) || `回放${idx + 1}`,
      url: absUrl(line.proxyUrl, DB_HOST)
    }));
    list.push({
      vod_id: 'db$' + encodeURIComponent(JSON.stringify({ name: fullName, links })),
      vod_name: shortName,
      vod_pic: s.teamAImage || s.teamBImage || HOST + '/logo.png',
      vod_remarks: [remarkPrefix, links.map(x => x.name).join('/')].filter(Boolean).join(' · ') || '回放'
    });
  }
  return list;
}

function parseProxySchedule(html, tid) {
  const $ = cheerio.load(html);
  const list = [];
  $('article').each((_, el) => {
    const $el = $(el);
    const time = cleanText($el.find('p.text-sm.font-black').first().text());
    const league = cleanText($el.find('p.truncate.text-xs').first().text());
    const teams = [];
    $el.find('span.truncate').each((__, span) => {
      const t = cleanText($(span).text());
      if (t && !teams.includes(t) && !/^信号|高清|返回/.test(t)) teams.push(t);
    });
    if (teams.length < 2) return;
    const name = `${time} ${league} ${teams[0]} vs ${teams[1]}`.trim();
    if (!matchCategory(tid, league, name)) return;

    const links = [];
    $el.find('a.home-signal-link').each((__, a) => {
      const href = $(a).attr('href') || '';
      if (!href) return;
      links.push({
        name: cleanText($(a).attr('title') || $(a).text()) || `信号${links.length + 1}`,
        url: absUrl(href, DB_HOST)
      });
    });
    if (!links.length) return;
    const pic = $el.find('img').first().attr('src') || HOST + '/logo.png';
    list.push({
      vod_id: 'db$' + encodeURIComponent(JSON.stringify({ name, links })),
      vod_name: name,
      vod_pic: absUrl(pic, DB_HOST),
      vod_remarks: links.map(x => x.name).join('/') || '直播'
    });
  });
  return list;
}

async function category(tid, pg) {
  tid = String(tid || 'zuqiu');
  const page = Math.max(Number(pg || 1) || 1, 1);

  if (tid === 'huifang') {
    const json = await requestJson(`${DB_PLAYBACK_API}?page=${page}&pageSize=20&dataType=all`);
    return parsePlaybackList(json, tid);
  }

  try {
    const json = await requestJson(DB_SCHEDULE_API);
    const list = parseApiSchedule(json, tid);
    if (list.length || tid === 'lanqiu') return list;
  } catch (e) {}

  // API 异常时保留旧 HTML 解析兜底。
  const html = await requestHtml(HOST + '/proxy.php', HOST + '/sssc/');
  return parseProxySchedule(html, tid);
}

function parseNuxtProxy(html) {
  const m = html.match(/"proxyUrl"\s*:\s*"((?:\\.|[^"\\])*)"/);
  if (!m) return '';
  try {
    return JSON.parse('"' + m[1] + '"');
  } catch (e) {
    return m[1].replace(/\\u002F/g, '/');
  }
}

async function resolvePlayUrl(playUrl) {
  const html = await requestHtml(playUrl, HOST + '/sssc/');
  const hls = html.match(/(?:\\u002F|\/)hls(?:\\u002F|\/)[A-Za-z0-9._-]+\.m3u8/i);
  if (hls) return absUrl(hls[0].replace(/\\u002F/g, '/'), DB_HOST);
  const proxy = parseNuxtProxy(html);
  if (proxy) return absUrl(proxy, DB_HOST);
  const iframe = html.match(/https?:\/\/www\.kanqiuge\.com\/embed\/play\/[A-Za-z0-9._-]+/i);
  if (iframe) return iframe[0];
  return playUrl;
}

async function detail(id) {
  if (String(id).startsWith('db$')) {
    const data = JSON.parse(decodeURIComponent(String(id).slice(3)));
    const playList = data.links.map(x => `${x.name}$${x.url}`).join('#');
    return {
      vod_id: id,
      vod_name: data.name || '实时赛程',
      vod_pic: HOST + '/logo.png',
      vod_content: '爱球直播实时赛程，播放时解析豆包直播信号。',
      vod_play_from: '爱球直播',
      vod_play_url: playList
    };
  }

  const html = await requestHtml(id, HOST + '/');
  const $ = cheerio.load(html);
  const name = cleanText($('.match-header h1').first().text()) || cleanText($('h1').first().text()) || '赛事直播';
  const time = cleanText($('.match-header p').first().text());
  const links = [];
  $('.gohome a').each((i, a) => {
    const text = cleanText($(a).text()) || `信号${i + 1}`;
    const href = $(a).attr('href') || '';
    if (!href || /赛程|返回|首页/.test(text)) return;
    if (href === '/sssc/' || href.includes('/sssc/')) {
      links.push(`${text}$${HOST}/proxy.php`);
    } else {
      links.push(`${text}$${absUrl(href, HOST)}`);
    }
  });
  if (!links.length) links.push(`赛程$${HOST}/proxy.php`);
  return {
    vod_id: id,
    vod_name: name,
    vod_pic: HOST + '/logo.png',
    vod_remarks: time,
    vod_content: time || '爱球直播赛事导航',
    vod_play_from: '爱球直播',
    vod_play_url: links.join('#')
  };
}

async function search(wd) {
  const html = await requestHtml(`${HOST}/search.html?keywords=${encodeURIComponent(wd)}&method=1`, HOST + '/');
  return parseIqList(html, 'search');
}

async function handle(req) {
  const q = req.query || {};
  const { ac, t, ids, wd, play } = q;

  if (play) {
    const raw = String(play);
    const isLive = /\.(m3u8|flv|mp4)(\?|$)/i.test(raw);
    const finalUrl = isLive ? raw : await resolvePlayUrl(raw);
    const direct = /\.(m3u8|flv|mp4)(\?|$)/i.test(finalUrl);
    return {
      parse: direct ? 0 : 1,
      url: finalUrl,
      header: {
        'User-Agent': UA,
        'Referer': finalUrl.includes('doubaozhibo.com') ? DB_HOST + '/' : HOST + '/'
      }
    };
  }

  if (ids) {
    const vod = await detail(ids);
    return { list: vod ? [vod] : [], page: 1, pagecount: 1, total: vod ? 1 : 0 };
  }

  if (wd) {
    const list = await search(wd);
    return { list, page: 1, pagecount: 1, total: list.length };
  }

  if (t !== undefined) {
    const list = await category(String(t || 'zuqiu'), Number(q.pg || 1));
    return { list, page: 1, pagecount: 1, total: list.length };
  }

  const list = await category('zuqiu', 1);
  return { class: classes, list, page: 1, pagecount: 1, total: list.length };
}

const meta = {
  key: 'iqzhibo',
  name: '爱球直播',
  type: 4,
  api: '/video/iqzhibo',
  searchable: 1,
  quickSearch: 0,
  filterable: 0
};

module.exports = async (app, opt) => {
  app.get(meta.api, async (req, reply) => {
    try {
      return await handle(req);
    } catch (e) {
      req.server.log.error(e);
      return { list: [], page: 1, pagecount: 1, total: 0, msg: e.message };
    }
  });
  opt.sites.push(meta);
};

  if (typeof module.exports !== 'function') throw new Error('embedded source did not export function');
  const fakeApp = { get(p, h) { INTERNAL_ROUTES[p] = h; } };
  const fakeOpt = { sites: [] };
  await module.exports(fakeApp, fakeOpt);
}

async function register_qiutongtiyu() {
  const module = { exports: null };
  const exports = module.exports;
const axios = require('axios');
const http = require('http');
const https = require('https');

const API_BASE = 'https://aapi2.xbncs.com/api';
const HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',
  'Accept': 'application/json, text/plain, */*',
  'Referer': 'https://aapi2.xbncs.com/'
};
const PAGE_SIZE = 30;

const _http = axios.create({
  timeout: 10000,
  headers: HEADERS,
  httpAgent: new http.Agent({ keepAlive: true }),
  httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
  validateStatus: status => status >= 200 && status < 500
});

const meta = {
  key: 'qiutongtiyu',
  name: '球通体育',
  type: 4,
  api: '/video/qiutongtiyu',
  searchable: 0,
  quickSearch: 0,
  filterable: 0,
  changeable: 1,
  style: { type: 'rect', ratio: 1.78 }
};

const store = { init: false, log: console };

function safeString(v) {
  if (v === null || v === undefined || v === 'null') return '';
  return String(v);
}

async function requestJson(url) {
  const res = await _http.get(url);
  const data = res.data;
  if (typeof data === 'object') return data;
  if (!data) return null;
  try { return JSON.parse(data); } catch (e) { return null; }
}

function getClasses() {
  return [
    { type_id: '-1', type_name: '全部' },
    { type_id: '1', type_name: '足球' },
    { type_id: '2', type_name: '篮球' }
  ];
}

async function getCategory(tid, pg) {
  const page = Math.max(parseInt(pg || '1', 10) || 1, 1);
  const navId = tid === '-1' || tid === undefined || tid === null ? '' : String(tid);
  const url = `${API_BASE}/room/page?roomType=&navId=${encodeURIComponent(navId)}&roomId=&word=&page=${page}&pageSize=${PAGE_SIZE}&channelId=3&platform=1`;
  const list = [];

  try {
    const json = await requestJson(url);
    const rows = json && json.data && Array.isArray(json.data.list) ? json.data.list : [];
    for (const item of rows) {
      const roomId = safeString(item.roomId);
      if (!roomId) continue;
      list.push({
        vod_id: roomId,
        vod_name: safeString(item.title) || safeString(item.nickName) || `房间 ${roomId}`,
        vod_pic: safeString(item.cover),
        vod_remarks: safeString(item.navName) || safeString(item.statusName) || safeString(item.liveStatus)
      });
    }
  } catch (e) {
    store.log.error && store.log.error(`[球通体育] category failed: ${e.message}`);
  }

  return {
    page,
    pagecount: list.length >= PAGE_SIZE ? page + 1 : page,
    limit: PAGE_SIZE,
    total: list.length,
    list
  };
}

async function getDetail(ids) {
  const idList = Array.isArray(ids) ? ids : String(ids || '').split(',').filter(Boolean);
  const list = [];

  for (const rawId of idList) {
    const roomId = safeString(rawId).trim();
    if (!roomId) continue;
    const vod = {
      vod_id: roomId,
      vod_name: `房间 ${roomId}`,
      vod_pic: '',
      vod_content: '',
      type_name: '',
      vod_play_from: '球通',
      vod_play_url: ''
    };

    try {
      const url = `${API_BASE}/room/info?roomId=${encodeURIComponent(roomId)}&channelId=3&platform=1`;
      const json = await requestJson(url);
      const data = json && json.data ? json.data : null;
      if (data) {
        vod.vod_name = safeString(data.title) || vod.vod_name;
        vod.vod_pic = safeString(data.cover);
        vod.vod_content = safeString(data.description) || safeString(data.notice) || '体育直播';
        vod.type_name = safeString(data.nickName) || safeString(data.navName);

        const playUrls = [];
        const pushUrl = safeString(data.pushUrl);
        const pullUrl = safeString(data.pullUrl);
        if (pushUrl) playUrls.push(`flv$${pushUrl}`);
        if (pullUrl) playUrls.push(`m3u8$${pullUrl}`);
        vod.vod_play_url = playUrls.join('#');
      }
    } catch (e) {
      store.log.error && store.log.error(`[球通体育] detail failed roomId=${roomId}: ${e.message}`);
    }

    if (!vod.vod_play_url) {
      vod.vod_play_url = `暂无播放$${roomId}`;
    }
    list.push(vod);
  }

  return { list, page: 1, pagecount: 1, total: list.length };
}

async function playUrl(id) {
  const url = safeString(id).replace(/\*\*\*/g, '#');
  if (!/^https?:\/\//i.test(url)) {
    return { parse: 0, jx: 0, url: '', msg: '暂无播放地址' };
  }
  return { parse: 0, jx: 0, url, header: HEADERS };
}

async function search() {
  return { list: [], page: 1, pagecount: 1, total: 0 };
}

async function handleT4Request(req) {
  const { ac, t, ids, play, pg, wd } = req.query;

  if (play) return await playUrl(play);
  if (wd) return await search();
  if (ids) return await getDetail(ids);

  if (ac === 'detail' && t !== undefined) {
    return await getCategory(t, pg);
  }

  if (!ac || ac === 'class') {
    const classes = getClasses();
    if (ac === 'class') return { class: classes };
    const result = await getCategory('-1', 1);
    return { class: classes, list: result.list, page: 1, pagecount: result.pagecount, total: result.total };
  }

  return { list: [], page: 1, pagecount: 1, total: 0 };
}

async function init(server) {
  if (store.init) return;
  store.log = server.log || console;
  store.init = true;
}

module.exports = async (app, opt) => {
  app.get(meta.api, async (req, reply) => {
    if (!store.init) await init(req.server);
    try {
      return await handleT4Request(req);
    } catch (e) {
      req.server.log.error(e);
      return { list: [], code: -1, msg: e.message };
    }
  });
  opt.sites.push(meta);
};

  if (typeof module.exports !== 'function') throw new Error('embedded source did not export function');
  const fakeApp = { get(p, h) { INTERNAL_ROUTES[p] = h; } };
  const fakeOpt = { sites: [] };
  await module.exports(fakeApp, fakeOpt);
}

async function register_kan88kanqiu() {
  const module = { exports: null };
  const exports = module.exports;
const CryptoJS = require("crypto-js");
const axios = require("axios");
const http = require("http");
const https = require("https");
const cheerio = require("cheerio");

const _http = axios.create({
  timeout: 60 * 1000,
  httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
  httpAgent: new http.Agent({ keepAlive: true }),
});

// 【关键修复】使用 .cc 域名 + 强制 Referer
const kanqiuConfig = {
  host: "https://www.88kanqiu.la",
  headers: {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
    "Referer": "https://www.88kanqiu.la/"
  }
};

const decodePlaySource = (raw) => {
  if (!raw || typeof raw !== "string") return null;
  const trimmed = raw.trim();

  for (let prefix = 0; prefix <= 8; prefix++) {
    for (let suffix = 0; suffix <= 4; suffix++) {
      if (trimmed.length <= prefix + suffix) continue;
      const candidate = trimmed.slice(prefix, trimmed.length - suffix || undefined);
      try {
        const decoded = Buffer.from(candidate, 'base64').toString('utf8');
        const jsonStart = decoded.indexOf('{');
        if (jsonStart >= 0) {
          return JSON.parse(decoded.slice(jsonStart));
        }
      } catch (e) {
        // continue
      }
    }
  }

  try {
    const decoded = Buffer.from(trimmed.replace(/[^A-Za-z0-9+/=]/g, ''), 'base64').toString('utf8');
    const jsonStart = decoded.indexOf('{');
    if (jsonStart >= 0) return JSON.parse(decoded.slice(jsonStart));
  } catch (e) {
    // ignore
  }
  return null;
};

const toDirectPlayUrl = (url) => {
  if (!url) return "";
  try {
    const u = new URL(url);
    const direct = u.searchParams.get('url');
    if (direct) return decodeURIComponent(direct);
  } catch (e) {
    // ignore
  }
  return url;
};
const getClasses = () => {
  return [
    { type_id: "live", type_name: "正在直播" },
    { type_id: "all", type_name: "全部直播" },
    { type_id: "1", type_name: "篮球直播" },
    { type_id: "8", type_name: "足球直播" },
    { type_id: "21", type_name: "其他直播" }
  ];
};

const getFilters = () => {
  return {
    "1": [{ "key": "cateId", "name": "类型", "value": [{ "n": "NBA", "v": "1" }, { "n": "CBA", "v": "2" }, { "n": "篮球综合", "v": "4" }, { "n": "纬来体育", "v": "21" }] }],
    "8": [{ "key": "cateId", "name": "类型", "value": [{ "n": "英超", "v": "8" }, { "n": "西甲", "v": "9" }, { "n": "意甲", "v": "10" }, { "n": "欧冠", "v": "12" }, { "n": "欧联", "v": "13" }, { "n": "德甲", "v": "14" }, { "n": "法甲", "v": "15" }, { "n": "欧国联", "v": "16" }, { "n": "足总杯", "v": "27" }, { "n": "国王杯", "v": "33" }, { "n": "中超", "v": "7" }, { "n": "亚冠", "v": "11" }, { "n": "足球综合", "v": "23" }, { "n": "欧协联", "v": "28" }, { "n": "美职联", "v": "26" }] }]
  };
};

const getCategoryList = async (type, extend = {}) => {
  try {
    const rawCateId = extend.cateId || type || "";
    const onlyLiving = rawCateId === "live";
    const cateId = rawCateId === "all" || rawCateId === "0" || rawCateId === "live" ? "" : rawCateId;
    const path = cateId ? `/match/${cateId}/live` : "";
    const url = kanqiuConfig.host + path;

    // store.log.error(url);

    const response = await _http.get(url, { headers: kanqiuConfig.headers });

    const $ = cheerio.load(response.data);
    const list = [];

    $(".list-group-item").each((_, element) => {
      const $el = $(element);
      const btnPrimary = $el.find(".btn.btn-primary");

      const time = $el.find(".category-game-time").text()?.trim() || "";
      const gameType = $el.find(".game-type").text()?.trim() || "";
      const teamNames = $el.find(".team-name");
      const homeTeam = teamNames.length > 0 ? teamNames.first().text().trim() : "";
      const awayTeam = teamNames.length > 1 ? teamNames.last().text().trim() : "";

      const name = `${time} ${gameType} ${homeTeam} vs ${awayTeam}`.trim();
      if (name === "vs" || !name) return;

      let vid = kanqiuConfig.host;
      let remark = "暂无";
      if (btnPrimary.length > 0) {
        vid = kanqiuConfig.host + btnPrimary.attr("href");
        remark = btnPrimary.text().trim();
      } else {
        vid = name;
      }
      if (onlyLiving && remark !== "直播中") return;

      const imgs = $el.find("img");
      let pic = imgs.length > 0 ? imgs.first().attr("src") : "";
      if (!pic) pic = "https://pic.imgdb.cn/item/657673d6c458853aeff94ab9.jpg";
      if (!pic.startsWith("http")) pic = kanqiuConfig.host + pic;

      // 【优化】在 vod_id 中嵌入比赛名称，用于详情页显示
      const encodedName = encodeURIComponent(name);
      list.push({
        vod_id: `${vid}###${encodedName}`,
        vod_name: name,
        vod_pic: pic,
        vod_remarks: remark
      });
    });

    return {
      list: list,
      page: 1,
      pagecount: 1,
      limit: list.length
    };
  } catch (error) {
    store.log.error(error);
    return { list: [], page: 1, pagecount: 1 };
  }
};

// 【核心优化】详情页解析真实比赛名称
const getDetail = async (id) => {
  try {
    let realId = id;
    let displayName = "赛事直播";
    if (id.includes("###")) {
      const parts = id.split("###", 2);
      realId = parts[0];
      displayName = decodeURIComponent(parts[1] || "赛事直播");
    }

    const gameMatch = realId.match(/\/live\/(\d+)\/play/);
    const gameId = gameMatch ? gameMatch[1] : "";
    if (!gameId) return null;

    const response = await _http.get(`${kanqiuConfig.host}/live/${gameId}/source`, {
      headers: {
        ...kanqiuConfig.headers,
        "Referer": realId
      }
    });

    const data = response.data && response.data.data ? response.data.data : "";
    const decodedData = decodePlaySource(data);
    const links = decodedData?.links || [];
    const playlist = links.map(it => {
      const playUrl = toDirectPlayUrl(it.url || "");
      return `${it.name || "线路"}$${playUrl}`;
    }).filter(Boolean).join("#");

    return {
      vod_id: realId,
      vod_name: displayName,
      vod_play_from: "88看球",
      vod_content: "实时体育直播",
      vod_play_url: playlist
    };
  } catch (error) {
    store.log.error(error);
    return null;
  }
};

const PAGE_LIMIT = 20;


const handleT4Request = async (req) => {
  const { ac, t, ids, play, ext } = req.query;

  // store.log.error(req.query);

  if (play) {
    const isDirect = /\.(m3u8|mp4)(\?|$)/i.test(String(play));
    return {
      parse: isDirect ? 0 : 1,
      url: play,
      header: kanqiuConfig.headers
    };
  }

  if (ids) {
    const detail = await getDetail(ids);
    return {
      list: detail ? [detail] : [],
      page: 1,
      pagecount: 1,
      total: detail ? 1 : 0
    };
  }

  if (t !== undefined) {
    let extendParams = {};
    if (ext) {
      try {
        extendParams = JSON.parse(
          CryptoJS.enc.Base64.parse(ext).toString(CryptoJS.enc.Utf8)
        );
      } catch (e) {
        req.server.log.error(e)
      }
    }
    return await getCategoryList(t, extendParams);
  }

  if (!ac || ac === 'class') {
    const classes = getClasses();
    if (ac === 'class') return { class: classes };

    const result = await getCategoryList("all");
    return {
      class: classes,
      filters: getFilters(),
      list: result.list,
      page: 1,
      pagecount: 1,
      total: result.list.length
    };
  }

  return { list: [], page: 1, pagecount: 1 };
};

const meta = {
  key: "88kanqiu",
  name: "88看球",
  type: 4,
  api: "/video/88kanqiu",
  searchable: 0,
  quickSearch: 0,
  filterable: 1
};

const store = {
  init: false,
};

const init = async (server) => {
  if (store.init) return;
  store.log = server.log;
  store.init = true;
};

module.exports = async (app, opt) => {
  app.get(meta.api, async (req, reply) => {
    if (!store.init) {
      await init(req.server);
    }
    try {
      return await handleT4Request(req);
    } catch (error) {
      console.error(error);
      return { error: 'Internal Server Error' };
    }
  });
  opt.sites.push(meta);
};
  if (typeof module.exports !== 'function') throw new Error('embedded source did not export function');
  const fakeApp = { get(p, h) { INTERNAL_ROUTES[p] = h; } };
  const fakeOpt = { sites: [] };
  await module.exports(fakeApp, fakeOpt);
}

async function ensureInternal(server) {
  INTERNAL_SERVER = server || INTERNAL_SERVER || { log: console };
  if (INTERNAL_READY) return;
  await Promise.all([register_kafeizhibo(), register_tiyu919(), register_jrszhibo(), register_iqzhibo(), register_qiutongtiyu(), register_kan88kanqiu()]);
  INTERNAL_READY = true;
}
async function callSource(src, params = {}) {
  const handler = INTERNAL_ROUTES[src.api];
  if (!handler) throw new Error(`${src.name} handler missing`);
  const req = { query: { ...params }, server: INTERNAL_SERVER || { log: console } };
  const data = await handler(req, null);
  return normalizePayload(data || {});
}
function classes() { return SOURCES.map(s => ({ type_id: s.id, type_name: s.name })); }
function filters() {
  const out = {};
  for (const s of SOURCES) out[s.id] = [{ key: 'cat', name: '分类', value: s.cats }];
  return out;
}
function prefixPlayUrl(src, raw) {
  return String(raw || '').split('$$$').map(group => group.split('#').map(seg => {
    const s = String(seg || '');
    const i = s.indexOf('$');
    if (i < 0) return s;
    const name = s.slice(0, i);
    const url = s.slice(i + 1);
    if (!url || url.startsWith(src.id + '@@@')) return s;
    return name + '$' + packId(src, url);
  }).join('#')).join('$$$');
}
function prefixList(src, list) {
  return (Array.isArray(list) ? list : []).filter(it => it && it.vod_id !== undefined && it.vod_id !== null).map(it => ({
    ...it,
    vod_id: packId(src, it.vod_id),
    vod_remarks: it.vod_remarks || src.name,
  }));
}
async function getHome() {
  const src = SOURCES[0];
  const data = await callSource(src, { ac: 'detail', t: src.defaultTid, pg: 1 }).catch(() => ({}));
  const list = prefixList(src, data.list || []);
  return { class: classes(), filters: filters(), list, page: 1, pagecount: 1, total: list.length, limit: list.length };
}
async function getCategory(srcId, pg, ext = {}) {
  const src = sourceById(srcId) || SOURCES[0];
  const tid = String(ext.cat || ext.type || ext.class || ext.cate || src.defaultTid);
  const data = await callSource(src, { ac: 'detail', t: tid, pg: pg || 1 });
  const list = prefixList(src, data.list || []);
  return {
    list,
    page: parseInt(data.page || pg || 1) || 1,
    pagecount: parseInt(data.pagecount || 1) || 1,
    limit: parseInt(data.limit || list.length) || list.length,
    total: parseInt(data.total || list.length) || list.length,
  };
}
async function getDetail(id) {
  const sp = splitId(id);
  const src = sourceById(sp.srcId);
  if (!src) return { list: [], page: 1, pagecount: 1, total: 0 };
  const data = await callSource(src, { ac: 'detail', ids: sp.rawId });
  const list = (Array.isArray(data.list) ? data.list : []).map(vod => {
    const out = { ...vod };
    out.vod_id = packId(src, out.vod_id || sp.rawId);
    if (out.vod_play_url) out.vod_play_url = prefixPlayUrl(src, out.vod_play_url);
    return out;
  });
  return { ...data, list, page: 1, pagecount: 1, total: list.length };
}
async function doSearch(wd, pg) {
  const list = [];
  for (const src of SOURCES) {
    try { const data = await callSource(src, { wd, pg: pg || 1 }); list.push(...prefixList(src, data.list || [])); } catch (_) {}
  }
  return { list, page: parseInt(pg || 1) || 1, pagecount: 1, total: list.length, limit: list.length };
}
async function getPlay(req) {
  const q = req.query || {};
  const sp = splitId(q.play || q.id || '');
  const src = sourceById(sp.srcId);
  if (!src) return { parse: 1, url: sp.rawId || q.play || q.id || '' };
  const data = await callSource(src, { play: sp.rawId, flag: q.flag || '', flags: q.flags || '' });
  return data || { parse: 1, url: sp.rawId };
}
async function handle(req) {
  const q = req.query || {};
  const ac = q.ac;
  const pg = Math.max(parseInt(q.pg) || 1, 1);
  const extJson = parseExtend(q.ext || q.extend || q.f);
  const isPlay = !!q.play || ac === 'play' || (!!q.flag && !!q.id);
  const wd = q.wd || q.key || q.keyword;
  const tid = q.t || q.type_id;
  const ids = q.ids || (q.id && !isPlay && !tid ? q.id : '');
  const ext = {
    ...extJson,
    cat: q.cat ?? extJson.cat ?? '',
    type: q.type ?? extJson.type ?? '',
    class: q.class ?? extJson.class ?? '',
    cate: q.cate ?? extJson.cate ?? '',
  };
  await ensureInternal(req.server);
  if (isPlay) return await getPlay(req);
  if (ids) return await getDetail(ids);
  if (wd) return await doSearch(wd, pg);
  if (ac === 'class') return { class: classes(), filters: filters() };
  if (tid && String(tid) !== '0') return await getCategory(tid, pg, ext);
  return await getHome();
}

module.exports = async (app, opt) => {
  const path = '/video/tiyujuhe';
  app.get(path, async (req) => {
    try { return await handle(req); }
    catch (e) {
      req.server.log.error('[体育聚合独立] ' + (e && e.stack || e));
      return { list: [], page: 1, pagecount: 1, total: 0, msg: String(e && e.message || e) };
    }
  });
  opt.sites.push({
    key: 'tiyujuhe',
    name: '体育｜聚合[官]',
    type: 4,
    api: path,
    searchable: 1,
    quickSearch: 0,
    filterable: 1,
    changeable: 0,
    style: { type: 'rect', ratio: 0.75 },
    ext: '',
  });
};
