const axios = require("axios");
const http = require("http");
const https = require("https");

const _http = axios.create({
  timeout: 15 * 1000,
  httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
  httpAgent: new http.Agent({ keepAlive: true }),
});

// 配置项：需要排除的分类名称
const excludeClassNames = ["伦理片", "倫理片", "情色", "成人", "限制级", "18禁", "R级", "三级"];

// 分类排序配置：可以按照需要调整顺序
const classSortOrder = [
  "国产剧", "动作片","大陆综艺", "国产动漫", "短剧", 
  "纪录片", "喜剧片", "爱情片", "科幻片", "恐怖片", 
  "剧情片", "战争片", "犯罪片", "动画片", "悬疑片", 
  "惊悚片", "奇幻片", "冒险片", "音乐片", "歌舞片", 
  "家庭片", "儿童片", "传记片", "历史片", "运动片", 
  "武侠片", "古装片", "西部片", "短片", "脱口秀", 
  "真人秀", "选秀", "美食", "旅游", "汽车", 
  "科技", "军事", "体育", "游戏", "财经", 
  "时尚", "音乐", "教育", "自然", "其他"
];

// 检查分类是否需要排除
const shouldExcludeClass = (typeName) => {
  if (!typeName) return false;
  return excludeClassNames.some(keyword => typeName && typeName.includes(keyword));
};

// 分类排序函数
const sortClasses = (classes) => {
  if (!classes || !Array.isArray(classes)) return classes;
  
  return classes.sort((a, b) => {
    const nameA = a.type_name || "";
    const nameB = b.type_name || "";
    
    // 获取在排序配置中的索引
    const indexA = classSortOrder.indexOf(nameA);
    const indexB = classSortOrder.indexOf(nameB);
    
    // 如果两个都在排序配置中，按配置顺序排序
    if (indexA !== -1 && indexB !== -1) {
      return indexA - indexB;
    }
    
    // 如果只有a在排序配置中，a排前面
    if (indexA !== -1) return -1;
    
    // 如果只有b在排序配置中，b排前面
    if (indexB !== -1) return 1;
    
    // 如果都不在排序配置中，按字母顺序排序
    return nameA.localeCompare(nameB, 'zh-CN');
  });
};

const fetch = async (req) => {
  delete req.query["token"];
  const { flag, play } = req.query;
  
  // 如果是播放地址，直接返回
  if (
    play &&
    /\.(m3u8|mp4|rmvb|avi|wmv|flv|mkv|webm|mov|m3u)(?!\w)/i.test(play)
  ) {
    return {
      url: play,
      jx: 0,
      parse: 0,
    };
  }

  // 处理播放请求的代理
  if (req.query.ac === "videourl" || req.query.ac === "play") {
    const pid = req.query.id || req.query.url;
    if (pid) {
      return {
        url: "http://127.0.0.1:9978/proxy?do=js&url=" + encodeURIComponent(pid),
        parse: 0,
        jx: 0,
        header: { 'User-Agent': 'okhttp/5.0.0' }
      };
    }
  }

  try {
    const ret = await _http("", {
      params: req.query,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.95 Safari/537.36',
      },
      baseURL: "http://caiji.dyttzyapi.com/api.php/provide/vod/from/dyttm3u8/at/json/",
    });
    
    // 处理返回的数据格式
    const data = ret.data || {};
    
    // 首页分类数据转换
    if (req.query.ac === "list") {
      const excludeTypeIds = [1, 2, 3, 4, 5];
      const return_data = {
        class: []
      };
      
      // 添加空值检查
      if (data.class && Array.isArray(data.class)) {
        const filteredClasses = [];
        
        data.class.forEach((i) => {
          // 排除指定的type_id
          if (excludeTypeIds.includes(i.type_id)) return;
          
          // 排除指定的分类名称
          if (shouldExcludeClass(i.type_name)) return;
          
          filteredClasses.push({
            type_id: i.type_id?.toString() || '',
            type_name: i.type_name || ''
          });
        });
        
        // 对分类进行排序
        return_data.class = sortClasses(filteredClasses);
      }
      
      return return_data;
    }
    
    // 分类/搜索/详情数据转换
    if (req.query.ac === "detail") {
      const return_data = {
        list: [],
        page: parseInt(req.query.pg) || 1,
        pagecount: data.pagecount || 1,
        limit: data.limit || 20,
        total: data.total || 0,
        parse: 0,
        jx: 0
      };
      
      // 修复：添加空值检查
      const movieList = data.list || [];
      
      movieList.forEach(function (i) {
        if (!i) return; // 跳过空项
        
        // 在分类内容页也过滤不符合的内容
        if (shouldExcludeClass(i.type_name)) return;
        
        if (req.query.ids) {
          // 详情页
          return_data.list.push({
            type_name: i.type_name || '',
            vod_id: i.vod_id || '',
            vod_name: i.vod_name || '',
            vod_remarks: i.vod_remarks || '',
            vod_year: i.vod_year || '',
            vod_area: i.vod_area || '',
            vod_actor: i.vod_actor || '',
            vod_director: i.vod_director || '',
            vod_content: i.vod_content || '',
            vod_play_from: '电影天堂',
            vod_play_url: i.vod_play_url || '',
          });
        } else {
          // 分类/搜索结果
          return_data.list.push({
            vod_id: i.vod_id || '',
            vod_name: i.vod_name || '',
            vod_pic: i.vod_pic || '',
            vod_remarks: i.vod_remarks || '',
            vod_year: i.vod_year || '',
            type_name: i.type_name || '', // 添加分类名称，方便前端显示
          });
        }
      });
      
      // 更新实际的总数
      return_data.total = return_data.list.length;
      
      return return_data;
    }
    
    return data;
  } catch (error) {
    console.error("Fetch error:", error.message);
    
    // 根据请求类型返回不同的空数据结构
    if (req.query.ac === "list") {
      return { class: [] };
    } else if (req.query.ac === "detail") {
      return {
        list: [],
        page: parseInt(req.query.pg) || 1,
        pagecount: 1,
        limit: 20,
        total: 0,
        parse: 0,
        jx: 0
      };
    }
    
    return { error: error.message };
  }
};

// 广告过滤函数
async function del_ads(url) {
  const url1 = url.replace('index.m3u8', '');
  const response = await axios.get(url, {
    headers: { 'User-Agent': 'okhttp/5.0.0' }
  });
  
  let text = response.data.trim().split('\n');
  let url2 = url1 + text[text.length - 1];
  let root_url = url2.replace('mixed.m3u8', '');
  
  const res2 = await axios.get(url2, {
    headers: { 'User-Agent': 'okhttp/5.0.0' }
  });
  
  return res2.data
    .replace(/#EXT-X-DISCONTINUITY\n((.*?\n){1,10})#EXT-X-DISCONTINUITY\n/g, '')
    .replace(/#EXT-X-DISCONTINUITY\n((.*?\n){2})#EXT-X-ENDLIST\n/g, '#EXT-X-ENDLIST')
    .replace(/#EXT-X-DISCONTINUITY\n/g, '')
    .replace(/(.*\.ts.*)/g, root_url + '$1');
}

const meta = {
  key: "dytt", // key不能与其他site冲突
  name: "[纯]电影天堂",
  type: 4,
  api: "/video/dytt", // 使用相对地址，不能与其他site冲突
  // 添加扩展信息，便于用户知道有过滤和排序功能
  ext: {
    desc: "已启用分类过滤和排序功能",
    filterNote: `已过滤以下分类名称: ${excludeClassNames.join(', ')}`,
    sortNote: `分类已按以下顺序排序: ${classSortOrder.slice(0, 5).join(', ')}... (共${classSortOrder.length}个分类)`
  }
};

module.exports = async (app, opt) => {
  // 使用kan360.js的模式处理请求路由
  app.get(meta.api, async (req, reply) => {
    const { extend, filter, t, ac, pg, ext, ids, flag, play, wd, quick } = req.query;
    
    // 修改req.query以适配fetch函数
    if (play) {
      req.query.ac = "play";
      req.query.id = play;
    } else if (wd) {
      req.query.ac = "detail";
      req.query.wd = wd;
      req.query.pg = pg;
    } else if (!ac) {
      req.query.ac = "list";
    } else if (ac === "detail") {
      if (t) {
        req.query.ac = "detail";
        req.query.t = t;
        req.query.pg = pg;
      } else if (ids) {
        req.query.ac = "detail";
        req.query.ids = ids;
      }
    }
    
    try {
      // 调用原来的fetch函数
      return await fetch(req);
    } catch (error) {
      console.error(`Error in ${meta.api}:`, error.message);
      
      // 根据请求类型返回错误响应
      if (req.query.ac === "list") {
        return { class: [] };
      } else if (req.query.ac === "detail") {
        return {
          list: [],
          page: parseInt(req.query.pg) || 1,
          pagecount: 1,
          limit: 20,
          total: 0,
          parse: 0,
          jx: 0
        };
      }
      
      return { error: "Internal server error" };
    }
  });
  
  opt.sites.push(meta);
  
  // 添加广告过滤代理
  app.get("/dytt/proxy", async (req, res) => {
    const url = req.query.url;
    if (!url) {
      return res.status(400).send("缺少URL参数");
    }
    
    try {
      const result = await del_ads(url);
      res.header("Content-Type", "application/vnd.apple.mpegurl");
      res.send(result);
    } catch (error) {
      console.error("Proxy error:", error.message);
      res.status(500).send("处理失败: " + error.message);
    }
  });
  
  // 添加一个查看配置的接口（可选）
  app.get("/dytt/config", (req, res) => {
    res.json({
      excludeClassNames: excludeClassNames,
      classSortOrder: classSortOrder,
      note: "如需修改过滤规则或排序顺序，请直接编辑代码中的excludeClassNames和classSortOrder数组"
    });
  });
  
  // 添加一个测试分类排序的接口（可选）
  app.get("/dytt/test-sort", (req, res) => {
    // 示例数据
    const testClasses = [
      { type_id: "1", type_name: "喜剧片" },
      { type_id: "2", type_name: "动作片" },
      { type_id: "3", type_name: "爱情片" },
      { type_id: "4", type_name: "科幻片" },
      { type_id: "5", type_name: "恐怖片" },
      { type_id: "6", type_name: "纪录片" },
      { type_id: "7", type_name: "动画片" },
      { type_id: "8", type_name: "战争片" },
      { type_id: "9", type_name: "未定义分类A" },
      { type_id: "10", type_name: "未定义分类B" }
    ];
    
    const sorted = sortClasses(testClasses);
    
    res.json({
      original: testClasses.map(c => c.type_name),
      sorted: sorted.map(c => c.type_name),
      sortOrder: classSortOrder
    });
  });
};