/**
 * 红果短剧 (hongguo) — T4 插件
 */
"use strict";
const crypto = require("node:crypto");
const fs = require("node:fs");
const fsp = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");
const { spawn } = require("node:child_process");
const { pipeline } = require("node:stream/promises");
const axios = require("axios");

// ============================================================================
// 请求解码器 (v2.<keyid>.<b64ciphertext> → AES-128-CBC key||iv)
// 下面的代码块从混淆后的 index.js 中原样提取, 内部符号 (D6/cs/lj/dj 等)
// 仅在模块作用域内有效, 给下面 decryptV2() 使用。
// ============================================================================
/* Am/pj interop imports unused - stripped */var cs=D6;(function(e,t){let n=D6,x=e();for(;;)try{if(parseInt(n(320,"!xmx"))/1+parseInt(n(327,"[6W3"))/2+-parseInt(n(439,"iL)C"))/3+parseInt(n(433,"9SsE"))/4+parseInt(n(379,"#4N!"))/5+-parseInt(n(485,"DF$g"))/6*(-parseInt(n(461,"2vhn"))/7)+parseInt(n(339,"4%fN"))/8*(-parseInt(n(454,"!xmx"))/9)===t)break;x.push(x.shift())}catch{x.push(x.shift())}})(lj,-726893*1+-120*9138+-4*-641008);var vPt=cs(310,"UEHg"),Fx0=[104,2601+2537*-1,-6609+-6679*-1,166,3737*-1+3*1271+114,168,143,15224+7547*-2,353*-26+7+324*29,4223+-567*7,1*-9659+-2*3943+17796,217,-1761*-1+-723+-2*421,-8145+8179*1,-7750+-2*2213+-11*-1111,1698*-1+487*16+-6034,4*-749+6978+-3953,-3254*-1+6365+-9599,103,-5993*1+1*4171+1927],IPt=[134,7*-271+-4*2468+11952,-9460*1+-1*2978+-1811*-7,-1*-9259+2695+-11759,-400+-1*-6186+-1844*3,-1*-617+-3009*1+2426,-9702+2*-1154+12070,-1*-4376+-4556+190,-5605+-1*7329+-4*-3246,-2*-4663+7777+-16986,77],CPt=[5283*-1+4528*1+985,9615+-8161*-1+-17593,415*1+-1555+1283,-3*3329+1*-914+11064,183],TPt=[1286*1+-1406+318,-4424+-1*-4607,9219*1+2496+-11543,129,-7154+16*463,504+9769*1+-10170,1303+-2*4877+-3*-2857,-5991*-1+7223+1*-13181,-10*898+1729*5+-429*-1,-356*-15+3*1697+519*-20,-768+-1*3305+-1*-4177,-5947+-362*6+8144,2063+-1829*1],RPt=[[cs(440,"s1Al")+cs(409,"dVBP"),49],-3658+-767*-10+-4*1003,[cs(456,"j8ZR")+cs(319,"1uTM")+"ac",10*-944+10*412+1348*4],1,[cs(459,"%$4z")+cs(377,"gcac")+cs(432,"dVBP"),-4414*2+2113+1362*5],4049*-1+-182+4233,[cs(441,"v#9S")+cs(370,"FGDP")+cs(447,"Z&O6"),-2343+-1*287+2748],1844+-7*263,[cs(407,"2vhn"),-463*18+1938+-6537*-1]];function D6(e,t){e=e-(-7683+7*-655+739*17);let n=lj(),x=n[e];if(D6.zSAUtR===void 0){var c=function(k){let E="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=",w="",I="";for(let T=0,B,N,P=0;N=k.charAt(P++);~N&&(B=T%4?B*64+N:N,T++%4)?w+=String.fromCharCode(255&B>>(-2*T&6)):0)N=E.indexOf(N);for(let T=0,B=w.length;T<B;T++)I+="%"+("00"+w.charCodeAt(T).toString(16)).slice(-2);return decodeURIComponent(I)};let g=function(k,E){let w=[],I=0,T,B="";k=c(k);let N;for(N=0;N<256;N++)w[N]=N;for(N=0;N<256;N++)I=(I+w[N]+E.charCodeAt(N%E.length))%256,T=w[N],w[N]=w[I],w[I]=T;N=0,I=0;for(let P=0;P<k.length;P++)N=(N+1)%256,I=(I+w[N])%256,T=w[N],w[N]=w[I],w[I]=T,B+=String.fromCharCode(k.charCodeAt(P)^w[(w[N]+w[I])%256]);return B};D6.pAVUwB=g,D6.WVODCV={},D6.zSAUtR=!0}let f=n[0],p=e+f,h=D6.WVODCV[p];return h?x=h:(D6.BYGeHv===void 0&&(D6.BYGeHv=!0),x=D6.pAVUwB(x,t),D6.WVODCV[p]=x),x}function BPt(e){let t=cs,n={GRfXs:function(f,p){return f(p)},hBBpD:function(f,p){return f||p},OeaSy:function(f,p){return f%p},XjKNO:function(f,p){return f!==p},uBoKa:t(343,"iL)C")},x=n[t(444,"v#9S")](String,n[t(468,"iL)C")](e,""))[t(361,"2vhn")](/\s+/g,""),c=n[t(302,"4%fN")](x[t(342,"kpSx")],-7499*-1+-3360+-4135);return n[t(392,"!xmx")](c,1*7274+-7500+226)&&(x+=vPt[t(402,"BB!n")](c)),Buffer[t(353,"dVBP")](x,n[t(303,"v#9S")])}function NPt(e){let t=cs,n={NtHRW:function(x,c){return x(c)},NhCHS:function(x,c){return x||c},NmWHw:t(300,"XZ^G")};return Buffer[t(345,"PoIh")](n[t(389,"Obxt")](String,n[t(429,"xB5)")](e,"")),n[t(406,"!xmx")])}function DPt(e,t){let n=cs,x={pKMuc:function(c,f){return c&f},KwJJp:function(c,f){return c^f},zVhwT:function(c,f){return c&f},KDrdw:function(c,f){return c+f},Psawy:function(c,f){return c*f}};return x[n(330,"pl11")](x[n(483,"8S$A")](e,x[n(337,"BiWY")](x[n(365,"xB5)")](167,x[n(398,"PoIh")](t,19)),-9082+1*2993+2*3172)),6*1546+-5281*-1+1*-14302)}function OPt(e){let t=cs,n={YGwSU:t(430,"d0hM"),ikBYv:function(h,g){return h<g},pnDvx:function(h,g){return h^g},qXnqi:function(h,g){return h&g},jCbJV:function(h,g){return h+g},XpZzF:function(h,g){return h*g},ZkLkd:t(470,"rjbH")},[x,c]=e,f=Buffer[t(414,"4cHq")](x,n[t(295,"1uTM")]),p=Buffer[t(382,"6PYp")](f[t(408,"!xmx")]);for(let h=7759*-1+-4673*2+3421*5;n[t(297,"j8ZR")](h,f[t(373,"(nQn")]);h++)p[h]=n[t(384,"t8z5")](f[h],n[t(462,"iL)C")](n[t(318,"dVBP")](c,n[t(325,"PoIh")](h,4160+1136*5+9833*-1)),255));return p[t(486,"j8ZR")](n[t(469,"9SsE")])}function PPt(e){let t=cs,n={BuqNm:function(c,f){return c%f},IAcTR:function(c,f){return c&f},ARsDC:function(c,f){return c^f},sHMzw:function(c,f){return c&f},vCYwq:function(c,f){return c+f},xfXlN:function(c,f){return c*f}},x=n[t(298,"Z&O6")](e,Fx0[t(373,"(nQn")]);return n[t(395,"rjbH")](n[t(369,"rjbH")](n[t(326,"(nQn")](Fx0[x],n[t(436,"vmKM")](n[t(306,"H!)]")](13003+349*-37,n[t(378,"%$4z")](x,13)),-327*7+2226+318)),8813+-8*1091),-456*16+-788+8339)}function cde(e,t){let n=cs,x={xgXBv:function(c,f){return c<f},oxVPu:function(c,f,p){return c(f,p)},AWyhO:function(c,f){return c&f},hKbkW:function(c,f){return c+f},yQIzu:function(c,f){return c&f},SeFjR:function(c,f){return c===f},Capci:function(c,f){return c&f},mtBAD:function(c,f){return c-f},iqnDm:function(c,f){return c(f)},FnfXN:function(c,f){return c&f},rVrfN:function(c,f){return c-f},JCHWv:function(c,f){return c*f},SJeac:function(c,f){return c&f},EsUkn:function(c,f){return c|f},LxhYH:function(c,f){return c<<f},BnaIc:function(c,f){return c>>>f},rvgxf:function(c,f){return c^f},kEVlz:function(c,f){return c|f},XSydQ:function(c,f){return c&f},oJsnV:function(c,f){return c&f},RcKbj:function(c,f){return c&f},CGqkS:function(c,f){return c|f},cqhuY:function(c,f){return c&f},qaGuy:function(c,f){return c&f},zZeWi:function(c,f){return c&f},wRhvB:function(c,f){return c^f},FsKpU:function(c,f){return c-f},eFcAQ:function(c,f){return c-f},MGbKK:function(c,f){return c===f},jxHsB:function(c,f){return c&f},VBTqL:function(c,f){return c%f},tARXP:function(c,f){return c%f},SnDJJ:function(c,f){return c===f},QiNHU:function(c,f){return c===f},ASapl:n(348,"[6W3")};for(let c=1291*-4+-5489+10653*1;x[n(478,"D1GK")](c,e[n(463,"TgVw")]);c++)switch(x[n(415,"6PYp")](DPt,e[c],c)){case 9825+-11*892:t[n(344,"XcAP")]=x[n(435,"BiWY")](x[n(371,"iUQ(")](x[n(431,"XZ^G")](t[n(400,"QUHv")]||-3*1001+-375+-3378*-1,c),t.i||19306+-7*2758),128520+-2674*-7+-81703);break;case-13*-302+-5283+1390:t.r0=x[n(448,"t8z5")](t[n(357,"6PYp")][t.i],560*14+-12*484+-1777);break;case-1*-9814+-2128+-7652:t.r1=x[n(421,"(nQn")](t.i,-1*2285+-5217+7502)?-853+6*-302+2774:x[n(367,"d0hM")](t[n(394,"!vWY")][x[n(354,"H!)]")](t.i,1031*5+-1*8227+-439*-7)],1162+-1*-8609+-9516);break;case 3422*-1+4288+831*-1:t.r2=x[n(305,"iL)C")](PPt,t.i);break;case 36:t.r3=x[n(388,"rjbH")](x[n(411,"rjbH")](x[n(376,"!vWY")](t.r0,16686+-16471*1),x[n(311,"d0hM")](-767*1+14*695+-1119*8,t.i)),-1*-3299+3422+-6466);break;case-1950+379*-1+2366:t.r4=x[n(364,"pl11")](x[n(351,"4%fN")](x[n(333,"ViyB")](t.r3,-11162+-11*-1015),x[n(420,"gcac")](t.r3,-2236+-15*262+6171)),2*2127+4362+-8361);break;case-5*-1019+6055+-11112:t.r5=x[n(399,"#H56")](~x[n(403,"v#9S")](t.r2,t.r1),2580+-2393*2+2461);break;case 2567+1*8931+-1637*7:t.r6=x[n(451,"[6W3")](x[n(358,"pl11")](t.r5,54),x[n(482,"XZ^G")](x[n(349,"BiWY")](~t.r5,255),8938+2*-845+-7047)),t.r7=x[n(438,"%$4z")](x[n(299,"6PYp")](x[n(328,"2vhn")](~t.r4,255),-1368+4806*-1+6228),x[n(396,"gDm2")](t.r4,9361+9798*-1+638));break;case-823*-1+123+-906:t[n(355,"s1Al")][t.i]=x[n(449,"pl11")](x[n(427,"UEHg")](t.r6,t.r7),-9918+-2*-3495+1*3183);break;case-1*8075+5083+3057:t[n(332,"ViyB")]=t[n(336,"TgVw")][x[n(316,"DF$g")](x[n(296,"UEHg")](t[n(362,"BB!n")][n(423,"s1Al")],-3*2309+-1628*-2+-1*-3672),t.i)]||"";break;case 10097+-10031*1:t[n(418,"2vhn")]=x[n(410,"!xmx")](parseInt,t[n(457,"Z&O6")][n(324,"XRSJ")]("0x",""),-737+1046*6+-5529);break;case-2209*1+-2632+4908:x[n(360,"Z&O6")](x[n(313,"j8ZR")](t.i,8461+-2*4519+578),6914+2*3217+-13348)?t[n(381,"gDm2")]-=11:x[n(401,"dVBP")](x[n(428,"En$S")](t.i,-509+-257*-14+1543*-2),7800+-3*2600)?t[n(323,"FGDP")]-=4:x[n(393,"s1Al")](x[n(424,"%$4z")](t.i,6),1894*2+-2*3622+3456)?t[n(443,"K8bZ")]-=-7872+-9*-863+114:x[n(321,"XZ^G")](x[n(426,"rjbH")](t.i,-1873+-1086*1+4*741),-281*23+-1717+8180)?t[n(464,"En$S")]-=3944*1+2201+6143*-1:t[n(397,"Obxt")]-=-1*1033+-4519+5555;break;case 68:t[n(338,"UEHg")]+=String[n(391,"#H56")+"de"](x[n(309,"#4N!")](t[n(381,"gDm2")],-1*7231+1418+6068));break;case 346*-17+-8387*-1+-2408:{let f=RPt[t.i++];t[n(359,"!xmx")]+=x[n(484,"PoIh")](typeof f,x[n(301,"#4N!")])?x[n(305,"iL)C")](String,t[n(375,"H!)]")][f]??""):x[n(450,"vmKM")](OPt,f);break}default:throw new Error(n(455,"dVBP")+n(329,"H!)]")+e[c]+":"+c)}return t}function dj(e){let t=cs,n={UYiTH:function(f,p){return f<=p},iwuAz:function(f,p){return f(p)},MzhTW:function(f,p){return f<p},jhpbc:function(f,p,h){return f(p,h)}};if(!e||n[t(308,"BB!n")](e[t(373,"(nQn")],9309+-3361*1+743*-8))return Buffer[t(481,"t8z5")](-1693*1+-4076*-1+-1*2383);let x=n[t(304,"En$S")](NPt,e[t(390,"QUHv")](1658*-2+1*-949+4269)),c={raw:x,out:Buffer[t(385,"H!)]")](x[t(314,"ic6k")]),i:0};for(c.i=-298*-3+-7109+6215*1;n[t(465,"En$S")](c.i,x[t(467,"4cHq")]);c.i++)n[t(416,"4%fN")](cde,IPt,c);return c[t(372,"vmKM")]}function Qx0(e){let t=cs,n={OVsuP:function(f,p){return f(p)},bcYCI:t(470,"rjbH"),tFSSy:function(f,p){return f<p},qNNJV:function(f,p){return f-p},ZNLiL:function(f,p,h){return f(p,h)}},x=n[t(477,"Obxt")](BPt,e)[t(368,"rjbH")](n[t(413,"j8ZR")]),c={parts:x[t(340,"j8ZR")]("0x"),out:"",i:0};for(c.i=0;n[t(380,"#4N!")](c.i,n[t(335,"vmKM")](c[t(422,"%$4z")][t(445,"D1GK")],-6*409+3737*-1+6192));c.i++)n[t(412,"#4N!")](cde,CPt,c);return c[t(366,"8S$A")]}function Wx0(e,t,n,x){let c=cs,f={lUAcQ:function(h,g,k){return h(g,k)}},p={args:[e,t,n,x],out:"",i:0};return f[c(386,"4%fN")](cde,TPt,p),p[c(425,"gDm2")]}function lj(){let e=["smowW6dcPZK","h8kchGOO","b8kXd8k0AW","rmkWaKFdHq","oNiuoI4","ymoRW57dNmkaW7/dHrhdQmks","EtyOo8oG","WQj7nv3cHW","k18H","cmkEcSk4DW","WP3cJrJdV8kL","zmkXjW","W4SbW5FcNCoh","r8ooW4JdMCkm","j3eukI4","FH7cGmocWPm","WOhdPCklAbK","jLGtW4jC","eNRcN3NdPG","W4/dHdxcGJldK8o5BmoBgqaD","BZe0pCoy","W5y+WOvP","ttKneSoBWRe","agJdLCkWW60uWO/dUa","tIq1jCoA","m8kjg8kkAW","B8oUW6hcQvK","WOrQWQbPBq","ifJcQSkH","mSo3W6xdKSke","tSoRW5hcPGS","gSoUWQi","W5KTWO0","fwNcU2NdNN8","smoEWOq1nG","W5/dNSkGWRyv","ASoaWOiAbq","WOnzoxhcUmo8","BSoGWQi2jG","WOpcMsS","nCkEo8k0Dq","WOnxdq3dSG","hJVdKxFdSG","k8ofWRu5vW","WP4mW5W","WPNcKCo/W6qj","v2JcGCk9W6eDWOpcQK4M","W4JdHtRcHtddK8kTFSoPcamEW60","y8kEvdT6y2WyWOzY","W5T1W47dNCoN","bmopWOegWPy","W4DyWP3dTLWOW57cMCoq","wCoMWOefjq","ECoxv8kMW4VdTYxcL8k6WRfjsa","W5TDzNFdUmo2oquzWO0","yrPbWOTBELBdUCkuWQq","vmoSW43cHGS","WPmoW44","e3WsW6jj","rSkvtd1IyG","C8osWOmhga01mgyh","WOFcVmkKsCkpfhbcW7ZcIq","af3cNhtdNW","bmk0W6hcNWe","hSo2WQi4WOW","cmkqWOf2pa","fSk3WPpdTW","fKCsW5L4","eM5rrCkzW6elbveuectcVX8","utJcHSkPWQ5bWPVdTvT2","W5bOW48ze8kGbWFdR3G","WPpdRmk3cW","W49iWPhcJG","lCofW4qpqGWKn2vx","qcNcJSoGWQW","WOzPW5KZrvD2c2i","pCk6amoNWPe","WPxdISkZuGNdHW","jGZdQa","bqpdRvldQq","EX0Bmmof","kK/cQ8kRWP5V","jmkGlmoMWRW","WQhcNK7dMMe","nmkRd8ou","kSkikcaA","CcTlBNXeqchdSbZcT8o6","WP4uW5pdGW","W4awWRu6yW","WR8AW63dRwO","WQSRWPBdN8kVmG1zWQ/dNSksWRu","rCksowddGG","uSkxEHHG","W7SCWO0uqW","zCoKW7VdJmkWWObe","ggdcUwhdIq","WP7cKmoUW6ei","amktdGuj","W4OBW7JcOSoR","FYtcHLNcRmojW7XOB8oaamkJ","WPjMWQPEvSo9wWy","s8kwWQvEW68","WPfdbJRdOq","WO9IWRTZuG","WQhdUmk0mCkh","d8oSW7JdOmkB","WPNcV8oL","DmoZW4ZcShK","A8oMW4dcLXe","iwWBW7fB","iq7dSeFdHa","jCktamosWPu","DmkJaCkIuq","dCkBbmkOrW","WQFdKmklxZq","DSobW53cO3W","W4K4wey","WRWQW6ZdGK4","z8ooW5ZcPgC","WOXXWRfzzG","waiUW77cR8kL","agVdKmk5W64uWOJcQuvaDG1HlW","dwBdUHRdJG","WOhdJmkgj8kd","wrRcGmodWO4","iSkWW6fRWO7dU8ooo0hcVq","ggLvqSkyW6fOyvOeaJC","WQlcTmozW4uu","FSk0WRXQW47dSa","W7bRW4i","dCkWWPBdUCooW7Lt","W4mcW6ZcKmo4","W43dQCkvWPGe","uSoNW6qRDcNdQtFdV8ktyKBdKG","W5qPWOGLEa","BCkepCo1","dSkLW4NcVqS","fwrAq8kxW6SiqMCUoXxcKW","WQa2W7uG","WPWVW68nWO4","omkilsWC","bSojWOi2WRC","WONdJSkVqq4","W6b0W5/dGSo8","WPTWeq","hmoOW6NcIINcQ3a","WPv5WPvdua","WQ3dT8kDg8km","W40sW5KDkmoW","lSkdhCoZW47dSq","WO8hWPtcVCoB","W70aW5NcHW","W4dcUSocBX3cGCo8e2mk","BSkbk8kHArqjvwNcTW","dCkGWRP4i2S","W4HbW7ZdL8oc","W5FcRCk2gSkAtwDbW67cHW","yCoWW7tcRWy","wtTUF2y","vsVcJCoK","B8kugSkuza","WObjiW","aeGUW79R","l8oUW4q","jSk9W73cRdK","tIKx","WQ7dISkNnmkH","W4u9WPa8qeD3","WOldQmkqFW8","EmouFhTmaCoPm1iRW6P6xa","lCkKW6hcQqS","lSoPWOqvCW","jmkrma","WRuiW5tdTLe","nCkWoSkyv8kqWRfC","amkngSkOzG","W7GUW4ZcJmo/mX1mWQhdLq","lmoRhfip","gmoYWRG","W6ddNSkiWRSZW4u","rXmHW6VcR8k+W5yYc8kg","y8ksp8kM","mxu0emke","B8kjWOzjm8kErg0yW4y","ySohWQGcoa","aCkyWPtdTI3dJc/cUgtcV09ZWPC","qCoMW77cK2W","WOlcMti","pmoJW5/dRCks","DCkstqHQlCo1gSoEtmkLWP/dLW","cwlcKxJdKG","y8kmnmk6qW"];return lj=function(){return e},lj()}

function decryptV2(body) {
  const text = String(body || "");
  if (!text.startsWith("v2.")) return text;
  const parts = text.split(".");
  if (parts.length < 3) return text;
  const raw = dj(parts[1]);
  if (!raw || raw.length < 32) throw new Error("漫剧解密失败: key/iv 无效");
  const dc = crypto.createDecipheriv("aes-128-cbc", raw.subarray(0, 16), raw.subarray(16, 32));
  return Buffer.concat([dc.update(Buffer.from(parts[2], "base64")), dc.final()]).toString("utf8");
}

// ---- 通用请求/工具 ----
const API_BASE = "https://djapi.999888456.xyz";
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36";

// 上游已启用 HMAC-SHA256 请求签名, 未签名的请求会被统一回一条"请更新到唐三最新版"。
// 签名串 = METHOD + "\n" + pathname + "\n" + 排序后的 query + "\n" + 毫秒时间戳 + "\n" + 随机 nonce + "\n" + client
const SIGN_CLIENT = "20260916";
const SIGN_SECRET = "c6f2a9e7d1b84c03f5a6719e2d8b0c47a13f6e9d52c8b7a4061d3e9f75b2c8a1";

function signHeaders(url, method = "GET") {
  const u = new URL(String(url));
  const params = [];
  for (const [k, v] of u.searchParams.entries()) {
    if (k !== "__h") params.push([k, v]);
  }
  params.sort((a, b) => (a[0] === b[0] ? (a[1] === b[1] ? 0 : a[1] < b[1] ? -1 : 1) : a[0] < b[0] ? -1 : 1));
  const query = params.map(([k, v]) => `${k}=${v}`).join("&");
  const time = String(Date.now());
  const nonce = crypto.randomBytes(8).toString("hex");
  const payload = [String(method).toUpperCase(), u.pathname, query, time, nonce, SIGN_CLIENT].join("\n");
  const sign = crypto.createHmac("sha256", SIGN_SECRET).update(payload, "utf8").digest("hex");
  return {
    "User-Agent": UA,
    "X-Huolong-Client": SIGN_CLIENT,
    "X-Huolong-Time": time,
    "X-Huolong-Nonce": nonce,
    "X-Huolong-Sign": sign,
  };
}

async function apiFetch(urlPath) {
  const url = `${API_BASE}/api/hongguo${urlPath}`;
  const res = await axios.get(url, {
    headers: signHeaders(url),
    responseType: "text",
    transformResponse: [(x) => x],
    timeout: 30000,
    family: 4,
  });
  return JSON.parse(decryptV2(String(res.data || "")));
}

function toStr(v, fallback = "") {
  return v == null || v === "" ? String(fallback || "") : String(v);
}

function parseVodList(items) {
  return (Array.isArray(items) ? items : [])
    .map((it) => {
      const id = toStr(it && it.vod_id);
      const name = toStr(it && it.vod_name);
      if (!id || !name) return null;
      const card = {
        vod_id: id,
        vod_name: name,
        vod_pic: toStr(it && it.vod_pic),
        vod_remarks: toStr(it && it.vod_remarks),
      };
      if ((it && it.vod_tag === "folder") || id.startsWith("rank_folder:")) {
        card.vod_tag = "folder";
        card.style = { type: "list" };
      }
      return card;
    })
    .filter(Boolean);
}

function decodeExt(ext) {
  if (!ext) return {};
  try {
    return JSON.parse(Buffer.from(String(ext), "base64").toString("utf8")) || {};
  } catch { return {}; }
}

// ============================================================================
// CENC 解密
// 红果的播放地址是 MPEG-CENC 加密的 MP4 (schm=cenc, 视频 encv/hvc1, 音频 enca/mp4a),
// 播放器直接拿到只会黑屏。内容密钥由接口返回的 spade_a 派生。
// 密钥派生与解密算法移植自 MIT 开源项目 short-drama-downloader (derive_content_key /
// decrypt_mp4_cenc), 见同目录 红果TVBox_Ubuntu版/short-drama-downloader-main。
// ============================================================================

function popcount(n) {
  let c = 0;
  let v = n;
  while (v) { c += v & 1; v >>>= 1; }
  return c;
}

function deriveContentKey(spadeB64) {
  let text = String(spadeB64 || "").trim();
  const pad = 4 - (text.length % 4);
  if (pad !== 4) text += "=".repeat(pad);
  const raw = Buffer.from(text, "base64");
  if (raw.length < 3) throw new Error(`spade_a 过短: ${raw.length}`);
  const v6 = raw[0] ^ raw[1] ^ raw[2];
  let v8 = raw.length - v6 + 47;
  if (v8 <= 0 || v8 > raw.length * 2) throw new Error(`spade_a 长度异常: v8=${v8}`);
  if (1 + v8 > raw.length) v8 = raw.length - 1;
  if (v8 < 33) throw new Error(`spade_a 长度不足: v8=${v8}`);
  const buf = Buffer.from(raw.subarray(1, 1 + v8));
  let prevOdd = 85;
  let prevEven = 246;
  for (let i = 0; i < v8; i++) {
    let prev;
    if (i & 1) { prev = prevOdd; prevOdd = buf[i]; }
    else { prev = prevEven; prevEven = buf[i]; }
    buf[i] = (-21 - popcount(i) + (prev ^ buf[i])) & 0xff;
  }
  return Buffer.from(buf.subarray(1, 33).toString("ascii"), "hex");
}

function findBox(buf, fourcc, start) {
  const tag = Buffer.from(fourcc, "ascii");
  for (let i = Math.max(start, 4); i < buf.length - 8; i++) {
    if (buf[i] === tag[0] && buf[i + 1] === tag[1] && buf[i + 2] === tag[2] && buf[i + 3] === tag[3]) {
      const size = buf.readUInt32BE(i - 4);
      if (size > 0 && size < 5000000) return [i - 4, size];
    }
  }
  return [-1, 0];
}

function getBoxBody(buf, fourcc, start) {
  const [off, size] = findBox(buf, fourcc, start);
  return off >= 0 ? buf.subarray(off + 8, off + size) : null;
}

function parseTrack(moov, trakOff) {
  const [stblOff] = findBox(moov, "stbl", trakOff + 8);
  if (stblOff < 0) return null;

  const stsz = getBoxBody(moov, "stsz", stblOff);
  if (!stsz) return null;
  const defaultSize = stsz.readUInt32BE(4);
  const sampleCount = stsz.readUInt32BE(8);
  const sizes = new Array(sampleCount);
  if (defaultSize === 0) {
    for (let i = 0; i < sampleCount; i++) sizes[i] = stsz.readUInt32BE(12 + i * 4);
  } else {
    sizes.fill(defaultSize);
  }

  const stco = getBoxBody(moov, "stco", stblOff);
  if (!stco) return null;
  const chunkCount = stco.readUInt32BE(4);
  const offsets = new Array(chunkCount);
  for (let i = 0; i < chunkCount; i++) offsets[i] = stco.readUInt32BE(8 + i * 4);

  const stsc = getBoxBody(moov, "stsc", stblOff);
  if (!stsc) return null;
  const entryCount = stsc.readUInt32BE(4);
  const entries = [];
  for (let i = 0; i < entryCount; i++) {
    entries.push([stsc.readUInt32BE(8 + i * 12), stsc.readUInt32BE(12 + i * 12)]);
  }
  const perChunk = new Array(chunkCount).fill(0);
  for (let i = 0; i < entryCount; i++) {
    const firstChunk = entries[i][0];
    const samplesPerChunk = entries[i][1];
    const end = i + 1 < entryCount ? entries[i + 1][0] - 1 : chunkCount;
    for (let c = firstChunk - 1; c < Math.min(end, chunkCount); c++) perChunk[c] = samplesPerChunk;
  }

  const saiz = getBoxBody(moov, "saiz", stblOff);
  if (!saiz) return null;
  const saio = getBoxBody(moov, "saio", stblOff);
  if (!saio) return null;

  return {
    sizes,
    offsets,
    perChunk,
    sampleCount,
    auxOff: saio.readUInt32BE(8),
    auxSize: saiz.readUInt32BE(5) * Math.max(saiz[4], 8),
  };
}

// 读取轨道被加密前的真实编码。加密样本条目是 encv/enca, 原编码记在 sinf/frma 里。
// 红果同一集的不同清晰度编码并不一致 (常见 1080P=hvc1, 720P 及以下=bvc2),
// 所以必须逐轨道按 frma 还原, 不能写死成 hvc1。
function readTrackCodec(moov, trakOff, trakSize) {
  const scope = moov.subarray(trakOff, trakOff + trakSize);
  for (const entry of ["encv", "enca"]) {
    const [entryOff] = findBox(scope, entry, 0);
    if (entryOff < 0) continue;
    const [frmaOff] = findBox(scope, "frma", entryOff);
    if (frmaOff < 0) continue;
    return {
      entry,
      entryAbs: trakOff + entryOff + 4,
      original: scope.subarray(frmaOff + 8, frmaOff + 12).toString("latin1"),
    };
  }
  return null;
}

const PLAYABLE_VIDEO_CODECS = new Set(["hvc1", "hev1", "avc1", "avc3"]);

function restoreFourcc(data, moovStart, codec) {
  if (!codec) return;
  Buffer.from(codec.original, "ascii").copy(data, moovStart + codec.entryAbs);
}

function stripSinf(data) {
  const free = Buffer.from("free", "ascii");
  let i = 0;
  while (i < data.length - 4) {
    if (data[i] === 0x73 && data[i + 1] === 0x69 && data[i + 2] === 0x6e && data[i + 3] === 0x66 && i >= 4) {
      const size = data.readUInt32BE(i - 4);
      if (size > 0 && size < 50000) {
        data.writeUInt32BE(8, i - 4);
        free.copy(data, i);
        const end = Math.min(i - 4 + size, data.length);
        data.fill(0, i + 4, end);
        i = end;
        continue;
      }
    }
    i++;
  }
}

function decryptMp4Cenc(input, contentKey) {
  const data = Buffer.isBuffer(input) ? input : Buffer.from(input);
  const ftypEnd = data.readUInt32BE(0);
  if (ftypEnd + 8 >= data.length) throw new Error("MP4 结构异常: ftyp 越界");
  const moovSize = data.readUInt32BE(ftypEnd);
  if (ftypEnd + 8 + moovSize > data.length) throw new Error("MP4 结构异常: moov 越界");
  const moovStart = ftypEnd + 8;
  const moov = data.subarray(moovStart, ftypEnd + moovSize);

  const [firstOff, firstSize] = findBox(moov, "trak", 0);
  const [secondOff, secondSize] = findBox(moov, "trak", firstOff + firstSize);

  const codecs = [];
  let decrypted = 0;
  for (const [trakOff, trakSize] of [[firstOff, firstSize], [secondOff, secondSize]]) {
    if (trakOff < 0) continue;
    const codec = readTrackCodec(moov, trakOff, trakSize);
    if (codec) codecs.push(codec);

    const track = parseTrack(moov, trakOff);
    if (!track || track.sampleCount === 0) continue;
    if (track.auxOff + track.auxSize > data.length) {
      throw new Error("MP4 结构异常: 加密辅助信息越界");
    }
    const aux = data.subarray(track.auxOff, track.auxOff + track.auxSize);

    let sampleIndex = 0;
    let auxPos = 0;
    for (let ci = 0; ci < track.offsets.length; ci++) {
      let off = track.offsets[ci];
      for (let k = 0; k < track.perChunk[ci]; k++) {
        if (sampleIndex >= track.sampleCount) break;
        const size = track.sizes[sampleIndex];
        if (off + size > data.length) break;
        // CENC 的 IV 取 aux 的高 8 字节, 低 8 字节为计数器
        const counter = Buffer.alloc(16);
        if (auxPos + 8 <= aux.length) aux.copy(counter, 0, auxPos, auxPos + 8);
        const decipher = crypto.createDecipheriv("aes-128-ctr", contentKey, counter);
        const plain = Buffer.concat([decipher.update(data.subarray(off, off + size)), decipher.final()]);
        plain.copy(data, off);
        off += size;
        sampleIndex += 1;
        auxPos += 8;
      }
    }
    decrypted += 1;
  }

  // 一个轨道都没解开时不能继续: 否则改写 fourcc 只会产出"看起来正常但全是密文"的
  // 文件, 播放器表现为黑屏, 比直接报错更难排查。
  if (!decrypted) throw new Error("解密失败: 未能解析出任何可解密轨道");

  for (const codec of codecs) restoreFourcc(data, moovStart, codec);
  stripSinf(data);
  return data;
}

function videoCodecOf(header) {
  const buf = Buffer.isBuffer(header) ? header : Buffer.from(header);
  const [entryOff] = findBox(buf, "encv", 0);
  if (entryOff < 0) return "";
  const [frmaOff] = findBox(buf, "frma", entryOff);
  if (frmaOff < 0) return "";
  return buf.subarray(frmaOff + 8, frmaOff + 12).toString("latin1");
}

// 只取头部若干字节即可读出 frma, 避免为了判编码把整集拉下来。
async function probeVideoCodec(src) {
  try {
    const res = await axios.get(src, {
      headers: { "User-Agent": UA, Range: "bytes=0-16383" },
      responseType: "arraybuffer",
      timeout: 20000,
    });
    return videoCodecOf(Buffer.from(res.data));
  } catch {
    return "";
  }
}

function variantQualityScore(name) {
  const text = String(name || "").toLowerCase();
  const match = text.match(/(?:2160|1440|1080|720|540|480|360)\s*p?/);
  if (match) return Number.parseInt(match[0], 10);
  if (/原画|蓝光|超清|臻清|高清/.test(text)) return 1000;
  return 0;
}

async function playableVariants(keyed) {
  const codecs = await Promise.all(keyed.map((item) => probeVideoCodec(item.src)));
  const all = keyed.map((item, i) => ({ ...item, codec: codecs[i] }));
  const playable = all.filter((x) => PLAYABLE_VIDEO_CODECS.has(x.codec));
  // 探测全部失败时不做过滤, 交给播放器碰运气, 总比一个清晰度都不给要好。
  const usable = playable.length ? playable : (codecs.some(Boolean) ? [] : all);
  // 上游偶尔把低清放在第一项; 播放器默认档应优先使用最高可播源。
  usable.sort((a, b) => variantQualityScore(b.name) - variantQualityScore(a.name));
  return { all, playable: usable };
}

// ============================================================================
// 解密后 MP4 的本地缓存与代理
// ============================================================================
const CACHE_DIR = path.join(os.tmpdir(), "buye-hongguo-cenc");
const CACHE_TTL_MS = 60 * 60 * 1000;
// 预热会持续往缓存里写, 这里给一个总量上限, 超出后按最旧优先淘汰。
const CACHE_MAX_BYTES = Number(process.env.HONGGUO_CACHE_MAX_MB || 2048) * 1024 * 1024;
// 短剧连播场景: 播放当前集时顺带把后面几集解好, 切集就不用等。设 0 可关闭。
const PREFETCH_COUNT = Math.max(0, Number(process.env.HONGGUO_PREFETCH ?? 1));
const inflight = new Map();

const FFMPEG_BIN = process.env.FFMPEG_BIN || "ffmpeg";

function streamRoute() {
  return `${meta.api}/stream`;
}

function requestOrigin(req) {
  const pick = (v) => String(v || "").split(",")[0].trim();
  const proto = pick(req && req.headers && req.headers["x-forwarded-proto"]) || (req && req.protocol) || "http";
  const host = pick(req && req.headers && req.headers["x-forwarded-host"]) || pick(req && req.headers && req.headers.host);
  return host ? `${proto}://${host}` : "";
}

async function removeCacheEntry(file, st) {
  if (st && st.isDirectory()) await fsp.rm(file, { recursive: true, force: true });
  else await fsp.unlink(file);
}

async function sweepCache() {
  try {
    const names = await fsp.readdir(CACHE_DIR);
    const now = Date.now();
    const alive = [];
    await Promise.all(names.map(async (name) => {
      const file = path.join(CACHE_DIR, name);
      try {
        const st = await fsp.stat(file);
        const size = st.isDirectory()
          ? (await fsp.readdir(file)).reduce((sum, child) => {
              try { return sum + fs.statSync(path.join(file, child)).size; } catch { return sum; }
            }, 0)
          : st.size;
        if (now - st.mtimeMs > CACHE_TTL_MS) await removeCacheEntry(file, st);
        else alive.push({ file, size, mtime: st.mtimeMs, dir: st.isDirectory() });
      } catch { /* 忽略单个文件的清理失败 */ }
    }));

    let total = alive.reduce((sum, x) => sum + x.size, 0);
    if (total <= CACHE_MAX_BYTES) return;
    alive.sort((a, b) => a.mtime - b.mtime);
    for (const item of alive) {
      if (total <= CACHE_MAX_BYTES) break;
      if (inflight.has(item.file)) continue;
      try {
        await removeCacheEntry(item.file, item.dir ? { isDirectory: () => true } : null);
        total -= item.size;
      } catch { /* 文件可能正在被读取, 下轮再试 */ }
    }
  } catch { /* 缓存目录不存在时无需清理 */ }
}

function cacheFileFor(tag) {
  const hash = crypto.createHash("sha1").update(tag).digest("hex");
  return path.join(CACHE_DIR, `${hash}.mp4`);
}

// 同一个目标文件只允许一个构建任务, 后到的请求复用同一个 Promise。
async function withCache(file, build) {
  try {
    const st = await fsp.stat(file);
    if (st.size > 0 && Date.now() - st.mtimeMs < CACHE_TTL_MS) return file;
  } catch { /* 未命中缓存, 继续构建 */ }

  if (inflight.has(file)) return inflight.get(file);
  const task = build(file);
  inflight.set(file, task);
  try {
    return await task;
  } finally {
    inflight.delete(file);
    sweepCache();
  }
}

async function downloadToFile(url, dest) {
  const res = await axios.get(url, {
    headers: { "User-Agent": UA },
    responseType: "stream",
    timeout: 120000,
    maxContentLength: Infinity,
    maxBodyLength: Infinity,
  });
  const out = fs.createWriteStream(dest);
  try {
    await pipeline(res.data, out);
  } catch (err) {
    out.destroy();
    throw err;
  }
}

async function buildDecrypted(id, quality, file) {
  const resp = await apiFetch(`/play?id=${encodeURIComponent(id)}`);
  const list = (Array.isArray(resp && resp.key_urls) ? resp.key_urls : [])
    .filter((x) => x && x.src && x.spade_a);
  if (!list.length) throw new Error("上游未返回可解密的播放地址");

  const { playable } = await playableVariants(list);
  if (!playable.length) throw new Error("该集仅提供 bvc2 编码, 播放器无法解码");
  writeVariantCache(id, playable.map((x) => toStr(x.name, "默认")));
  const item = playable.find((x) => toStr(x.name) === quality) || playable[0];

  const contentKey = deriveContentKey(item.spade_a);
  await fsp.mkdir(CACHE_DIR, { recursive: true });
  const encrypted = `${file}.${process.pid}.enc`;
  const temp = `${file}.${process.pid}.part`;
  try {
    await downloadToFile(item.src, encrypted);
    const raw = await fsp.readFile(encrypted);
    await fsp.unlink(encrypted).catch(() => {});
    decryptMp4Cenc(raw, contentKey);
    await fsp.writeFile(temp, raw);
    raw.fill(0);
    await remuxFaststart(temp);
    await fsp.rename(temp, file);
  } finally {
    await fsp.unlink(encrypted).catch(() => {});
    await fsp.unlink(temp).catch(() => {});
  }
  return file;
}

// 把 moov 挪到文件头, Exo 才不必靠 bytes=-N 去文件尾探测时长。
// 红果 HEVC 的 SPS 把 Level 标成 186 (约 6.2), 对 1080p/25fps 虚高很多,
// ExoPlayer 的设备解码器可能因此直接拒绝初始化, 表现为"有速度但黑屏"。
// 这里用 hevc_metadata 只改 level_idc, 不重新编码; 失败时保留原文件即可。
async function remuxFaststart(file) {
  // 优先直接套 hevc_metadata: 有些集的 codec 探测失败, 不能再依赖传入的 codec。
  // 非 HEVC 时该 bsf 会失败, 再回退普通 faststart, 两种结果都不会丢文件。
  const run = async (withLevelFix) => {
    const dest = `${file}.faststart`;
    const args = [
      "-hide_banner", "-v", "error", "-y",
      "-i", file, "-c", "copy",
      ...(withLevelFix ? ["-bsf:v", "hevc_metadata=level=120"] : []),
      "-movflags", "+faststart",
      "-f", "mp4", dest,
    ];
    try {
      await new Promise((resolve, reject) => {
        const proc = spawn(FFMPEG_BIN, args, { stdio: ["ignore", "ignore", "pipe"] });
        let stderr = "";
        proc.stderr.on("data", (chunk) => { stderr = `${stderr}${chunk}`.slice(-1500); });
        proc.on("error", reject);
        proc.on("close", (code) => {
          if (code === 0) resolve();
          else reject(new Error(stderr.trim().split("\n").pop() || `faststart 退出码 ${code}`));
        });
      });
      await fsp.rename(dest, file);
      return true;
    } catch {
      await fsp.unlink(dest).catch(() => {});
      return false;
    }
  };
  await run(true) || await run(false);
}
function ensureDecrypted(id, quality) {
  // v6-level: faststart 把 moov 移到文件头, 并把虚高的 HEVC level 改回 120 (4.0)。
  return withCache(cacheFileFor(`${id}|${quality}|v6-level`), (file) => buildDecrypted(id, quality, file));
}

function parseByteRange(header, size) {
  const first = Array.isArray(header) ? header[0] : header;
  const raw = String(first || "").trim();
  if (!raw) return null;
  const match = /^bytes\s*=\s*(\d*)\s*-\s*(\d*)$/i.exec(raw);
  if (!match) return { invalid: true };
  const hasStart = match[1] !== "";
  const hasEnd = match[2] !== "";
  let start;
  let end;
  if (!hasStart && hasEnd) {
    const suffix = Number(match[2]);
    if (!Number.isFinite(suffix) || suffix <= 0) return { invalid: true };
    start = Math.max(0, size - suffix);
    end = size - 1;
  } else {
    start = hasStart ? Number(match[1]) : 0;
    end = hasEnd ? Number(match[2]) : size - 1;
  }
  if (!Number.isFinite(start) || !Number.isFinite(end) || start < 0 || start >= size || end < start) {
    return { invalid: true };
  }
  if (end >= size) end = size - 1;
  return { start, end };
}

function isHeadRequest(req) {
  return String(req && req.method || "").toUpperCase() === "HEAD";
}

function sendFileRange(req, reply, file, st, contentType) {
  reply.header("Accept-Ranges", "bytes");
  reply.header("Content-Type", contentType);
  reply.header("Cache-Control", "no-store");
  reply.header("Content-Encoding", "identity");
  const range = parseByteRange(req.headers && (req.headers.range || req.headers.Range), st.size);
  if (range && range.invalid) {
    reply.code(416).header("Content-Range", `bytes */${st.size}`);
    return reply.send("");
  }
  const start = range ? range.start : 0;
  const end = range ? range.end : st.size - 1;
  const length = end - start + 1;
  if (range) {
    reply.code(206);
    reply.header("Content-Range", `bytes ${start}-${end}/${st.size}`);
  }
  reply.header("Content-Length", String(length));
  if (isHeadRequest(req)) return reply.send("");
  return reply.send(fs.createReadStream(file, { start, end }));
}

// ============================================================================
// 选集预热
// 客户端切集时才请求 /stream, 冷缓存要等下载+解密。这里在播放某一集时,
// 顺带把后面几集在后台解好放进缓存, 让连播不再等待。
// ============================================================================
const episodeIndex = new Map();
const EPISODE_INDEX_MAX = 64;

function seriesKeyOf(playId) {
  try {
    const meta = JSON.parse(Buffer.from(String(playId), "base64").toString("utf8"));
    const series = toStr(meta && meta.series_id);
    return series || "";
  } catch {
    return "";
  }
}

// vod_play_url 形如 "第1集$<id>#第2集$<id>...", 按顺序留下 id 即可。
function rememberEpisodes(playUrl) {
  const ids = String(playUrl || "")
    .split("#")
    .map((part) => part.split("$")[1])
    .filter(Boolean);
  if (ids.length < 2) return;
  const key = seriesKeyOf(ids[0]);
  if (!key) return;
  episodeIndex.set(key, { ids, at: Date.now() });
  if (episodeIndex.size > EPISODE_INDEX_MAX) {
    const oldest = [...episodeIndex.entries()].sort((a, b) => a[1].at - b[1].at)[0];
    if (oldest) episodeIndex.delete(oldest[0]);
  }
}

// play 每次都要等上游 /play (约 1s) 再探测编码。预热时把结果记下来,
// 客户端真正切到该集时就能直接出地址。签名地址有时效, 所以只缓存清晰度名单,
// 真实地址仍由 /stream 现取。
const variantCache = new Map();
const VARIANT_TTL_MS = 5 * 60 * 1000;
const VARIANT_MAX = 128;

function readVariantCache(id) {
  const hit = variantCache.get(String(id));
  if (!hit) return null;
  if (Date.now() - hit.at > VARIANT_TTL_MS) {
    variantCache.delete(String(id));
    return null;
  }
  return hit.names;
}

function writeVariantCache(id, names) {
  if (!Array.isArray(names) || !names.length) return;
  variantCache.set(String(id), { names, at: Date.now() });
  if (variantCache.size > VARIANT_MAX) {
    const oldest = [...variantCache.entries()].sort((a, b) => a[1].at - b[1].at)[0];
    if (oldest) variantCache.delete(oldest[0]);
  }
}

const prefetch = { queue: [], running: false };

async function runPrefetch() {
  if (prefetch.running) return;
  prefetch.running = true;
  try {
    while (prefetch.queue.length) {
      const job = prefetch.queue.shift();
      try {
        // 预热在后台把后续剧集下载并解密, 切集时直接命中缓存。
        await ensureDecrypted(job.id, job.quality);
      } catch { /* 预热失败不影响正常播放, 用户真正切到该集时会再试一次 */ }
    }
  } finally {
    prefetch.running = false;
  }
}

function schedulePrefetch(currentId, quality) {
  if (!PREFETCH_COUNT) return;
  const key = seriesKeyOf(currentId);
  if (!key) return;
  const entry = episodeIndex.get(key);
  if (!entry) return;
  const at = entry.ids.indexOf(String(currentId));
  if (at < 0) return;

  // 每次只围绕当前进度排队, 避免用户跳集后还在下载早已过期的目标。
  prefetch.queue = entry.ids
    .slice(at + 1, at + 1 + PREFETCH_COUNT)
    .map((id) => ({ id, quality }));
  runPrefetch();
}

async function serveStream(req, reply) {
  const id = toStr(req.query && req.query.id);
  const quality = toStr(req.query && req.query.q);
  if (!id) {
    reply.code(400);
    return { error: "缺少 id 参数" };
  }

  let file;
  try {
    file = await ensureDecrypted(id, quality);
  } catch (e) {
    reply.code(502);
    return { error: `解密失败: ${(e && e.message) || e}` };
  }

  const st = await fsp.stat(file);
  return sendFileRange(req, reply, file, st, "video/mp4");
}

async function home() {
  const w = await apiFetch("/home?filter=1");
  const out = {
    class: Array.isArray(w.class) ? w.class : [],
    filters: w.filters || {},
  };
  if (Array.isArray(w.list)) out.list = parseVodList(w.list);
  return out;
}

const RANK_FOLDER_PIC = "https://cac.opple.com/yc-media/getFile?id=fa81d1107fe344028799301f85745982#.png";
const RANK_FOLDERS = [
  ["rank_recommend", "全部-推荐榜"],
  ["rank_hot", "全部-热播榜"],
  ["rank_zhenguo", "全部-臻果榜"],
  ["rank_new", "全部-新剧榜"],
  ["rank_search", "全部-热搜榜"],
  ["rank_must_watch", "全部-必看榜"],
  ["rank_collect", "全部-收藏榜"],
  ["rank_human_recommend", "真人剧-推荐榜"],
  ["rank_human_hot", "真人剧-热播榜"],
  ["rank_human_new", "真人剧-新剧榜"],
  ["rank_human_search", "真人剧-热搜榜"],
  ["rank_human_must_watch", "真人剧-必看榜"],
  ["rank_human_collect", "真人剧-收藏榜"],
  ["rank_comic_recommend", "漫剧-推荐榜"],
  ["rank_comic_hot", "漫剧-热播榜"],
  ["rank_comic_new", "漫剧-新剧榜"],
  ["rank_comic_search", "漫剧-热搜榜"],
  ["rank_ai_recommend", "AI剧-推荐榜"],
  ["rank_ai_hot", "AI剧-热播榜"],
  ["rank_ai_new", "AI剧-新剧榜"],
  ["rank_ai_search", "AI剧-热搜榜"],
  ["rank_ai_must_watch", "AI剧-必看榜"],
  ["rank_ai_collect", "AI剧-收藏榜"],
];

function buildCategoryUrl(cateId, page, ext) {
  const params = new URLSearchParams({ tid: cateId, pg: String(page) });
  for (const [k, v] of Object.entries(ext || {})) {
    if (k === "cateId" || v === undefined || v === null || v === "") continue;
    params.set(k, String(v));
  }
  return `/category?${params.toString()}`;
}

async function category(id, page, ext) {
  const cateId = toStr(ext.cateId, id);
  const pg = Number.parseInt(page, 10) > 0 ? Number.parseInt(page, 10) : 1;
  if (cateId === "rank_home") {
    const list = RANK_FOLDERS.map(([rid, name]) => ({
      vod_id: `rank_folder:${rid}`,
      vod_name: name,
      vod_pic: RANK_FOLDER_PIC,
      vod_remarks: "",
      vod_tag: "folder",
      style: { type: "list" },
    }));
    return { page: 1, pagecount: 1, limit: list.length, total: list.length, list };
  }
  const resp = await apiFetch(buildCategoryUrl(cateId, pg, ext));
  return {
    page: pg,
    pagecount: 9999,
    limit: 18,
    total: 9999,
    list: parseVodList(resp.list || []),
  };
}

async function detail(idList) {
  const list = [];
  for (const rawId of idList) {
    const id = toStr(rawId);
    if (!id) continue;
    const resp = await apiFetch(`/detail?id=${encodeURIComponent(id)}`);
    const v = resp && resp.list && resp.list[0];
    if (!v) continue;
    rememberEpisodes(v.vod_play_url);
    list.push({
      vod_id: id,
      vod_name: toStr(v.vod_name),
      vod_pic: toStr(v.vod_pic),
      vod_remarks: toStr(v.vod_remarks),
      type_name: toStr(v.type_name),
      vod_content: toStr(v.vod_content),
      vod_play_from: toStr(v.vod_play_from, "播放"),
      vod_play_url: toStr(v.vod_play_url),
    });
  }
  return { list };
}

function buildPlayUrls(id, names, req) {
  const origin = requestOrigin(req);
  const list = [];
  for (const name of names) {
    const query = `id=${encodeURIComponent(id)}&q=${encodeURIComponent(name)}`;
    list.push(name, `${origin}${streamRoute()}?${query}`);
  }
  return list;
}

async function play(id, req) {
  // 预热命中: 不必再问上游, 直接给代理地址。
  const cached = readVariantCache(id);
  if (cached) {
    schedulePrefetch(id, cached[0]);
    return {
      parse: 0,
      url: buildPlayUrls(id, cached, req),
      extra: { nodanmu: true },
    };
  }

  const resp = await apiFetch(`/play?id=${encodeURIComponent(id)}`);
  const out = resp && typeof resp === "object" ? { ...resp } : {};

  // 上游 url / key_urls 都是 CENC 加密的 MP4, 直接交给播放器只有黑屏,
  // 这里改为指向本地解密代理。
  const keyed = Array.isArray(out.key_urls)
    ? out.key_urls.filter((x) => x && x.src && x.spade_a)
    : [];
  if (keyed.length) {
    // 同一集各清晰度编码可能不同, 只暴露播放器能解的那些。
    const { playable } = await playableVariants(keyed);
    const names = playable.map((x) => toStr(x.name, "默认"));
    if (names.length) {
      writeVariantCache(id, names);
      out.url = buildPlayUrls(id, names, req);
      out.parse = 0;
      delete out.key_urls;
      // 播放器通常取第一个清晰度, 预热用同一档以命中同一缓存键。
      schedulePrefetch(id, names[0]);
    }
  }

  out.extra = { ...(out.extra || {}), nodanmu: true };
  return out;
}

async function search(wd, pg) {
  const kw = toStr(wd).trim();
  if (!kw) return { list: [] };
  const page = Number.parseInt(pg, 10) > 0 ? Number.parseInt(pg, 10) : 1;
  const resp = await apiFetch(`/search?wd=${encodeURIComponent(kw)}&pg=${page}`);
  // 上游 hongguo 搜索偶发返回 list=null, 兜底为 []
  const list = parseVodList((resp && Array.isArray(resp.list) ? resp.list : []));
  const pageLimit = 18;
  const looksFull = list.length >= pageLimit;
  return {
    parse: 0,
    jx: 0,
    page,
    limit: pageLimit,
    // 上游 pagecount/total 会返回 Long.MAX_VALUE, 客户端解析会异常, 这里按当前页兜底
    pagecount: looksFull ? page + 1 : page,
    total: looksFull ? (page + 1) * pageLimit : (page - 1) * pageLimit + list.length,
    list,
  };
}

const meta = {
  key: "manjuhongguo",
  name: "[短]红果短剧",
  type: 4,
  api: "/video/manjuhongguo",
  searchable: 1,
  quickSearch: 1,
  filterable: 1,
  changeable: 0,
};

module.exports = async (app, opt) => {
  app.get(meta.api, async (req) => {
    const q = req.query || {};
    const { ac, t, pg, wd, play: playId, ids, ext } = q;
    const filters = decodeExt(ext);
    try {
      if (playId) return await play(playId, req);
      if (wd) return await search(wd, pg);
      if (ids) return await detail([String(ids)]);
      if (t) return await category(t, pg || "1", filters);
      return await home(req);
    } catch (e) {
      app.log && app.log.error && app.log.error(`[漫剧|小红] ${e && e.message || e}`);
      return { list: [] };
    }
  });

  app.get(`${meta.api}/stream`, serveStream);

  opt.sites.push(meta);
};
