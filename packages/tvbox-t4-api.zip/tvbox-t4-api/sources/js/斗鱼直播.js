const crypto = require("crypto");
const axios = require("axios");
const https = require("https");

const httpsAgent = new https.Agent({
    keepAlive: true,
    keepAliveMsecs: 1000,
    maxSockets: 50,
    maxFreeSockets: 10,
    scheduling: 'lifo',
    rejectUnauthorized: false
});

const axiosInstance = axios.create({
    httpsAgent,
    timeout: 10000,
    headers: {
        'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1',
        'Referer': 'https://www.douyu.com/',
        'Content-Type': 'application/x-www-form-urlencoded'
    }
});

// 斗鱼分类映射
const CLASSES = [
    { type_id: "yqk", type_name: "娱乐天地" },
    { type_id: "LOL", type_name: "网游竞技" },
    { type_id: "TVgame", type_name: "单机热游" },
    { type_id: "wzry", type_name: "手游休闲" },
    { type_id: "yz", type_name: "颜值" },
    { type_id: "smkj", type_name: "科技文化" },
    { type_id: "yiqiwan", type_name: "语音互动" },
    { type_id: "yyzs", type_name: "语音直播" },
    { type_id: "znl", type_name: "正能量" }
];

const CATEGORY_MAP = {
    'yqk': 'yl',
    'LOL': 'PCgame', 
    'TVgame': 'djry',
    'wzry': 'syxx',
    'yz': 'yz',
    'smkj': 'kjwh',
    'yiqiwan': 'yp',
    'yyzs': 'voice',
    'znl': 'znl'
};

const cache = {
    data: new Map(),
    ttl: {
        category: 300000,    // 5分钟
        detail: 600000,      // 10分钟  
        play: 300000,        // 5分钟
        search: 60000        // 1分钟
    },
    get: (key) => {
        const item = cache.data.get(key);
        if (!item) return null;
        if (Date.now() > item.expire) {
            cache.data.delete(key);
            return null;
        }
        return item.data;
    },
    set: (key, data, type = 'category') => {
        cache.data.set(key, {
            data,
            expire: Date.now() + cache.ttl[type]
        });
        if (cache.data.size > 200) cache.data.clear();
    }
};

// 核心加密函数 - 对应PHP中的签名算法
const generateDouyuSignature = async (roomId) => {
    const did = "10000000000000000000000000001501";
    const tt = Math.floor(Date.now() / 1000);
    
    try {
        // A. 获取动态加密脚本参数
        const encRes = await axiosInstance.get(
            `https://www.douyu.com/wgapi/livenc/liveweb/websec/getEncryption?did=${did}`,
            { headers: { 'Referer': `https://www.douyu.com/${roomId}` } }
        );
        
        const encData = encRes.data;
        if (!encData || encData.error !== 0) return null;

        const sec = encData.data;
        
        // B. 实现斗鱼 MD5 签名逻辑 (对应PHP的计算)
        let current = sec.rand_str;
        for (let i = 0; i < sec.enc_time; i++) {
            current = crypto.createHash('md5').update(current + sec.key).digest('hex');
        }
        const auth = crypto.createHash('md5').update(current + sec.key + roomId + tt).digest('hex');

        // C. 请求真实 H5 流地址
        const postData = {
            'v': '22032021',
            'did': did,
            'tt': tt,
            'auth': auth,
            'enc_data': sec.enc_data
        };

        const streamRes = await axiosInstance.post(
            `https://www.douyu.com/lapi/live/getH5PlayV1/${roomId}`,
            new URLSearchParams(postData).toString(),
            { headers: { 'Referer': `https://www.douyu.com/${roomId}` } }
        );

        const streamData = streamRes.data;
        if (!streamData || streamData.error !== 0) return null;

        return streamData.data.rtmp_url + '/' + streamData.data.rtmp_live;
        
    } catch (error) {
        console.error('斗鱼签名生成失败:', error);
        return null;
    }
};

const _home = async ({ filter }) => {
    return {
        class: CLASSES,
        filters: {} // 斗鱼直播不需要筛选器
    };
};

const _category = async ({ id, page, filters = {} }) => {
    const pg = parseInt(page || 1);
    const cacheKey = `douyu_category_${id}_${pg}`;
    
    const cached = cache.get(cacheKey);
    if (cached) return cached;

    try {
        const url = `https://m.douyu.com/api/room/list?page=${pg}&type=${id}`;
        const response = await axiosInstance.get(url);
        const data = response.data;
        
        let list = [];
        if (data.data && data.data.list) {
            list = data.data.list.map(item => ({
                vod_id: item.rid,
                vod_name: item.roomName,
                vod_pic: item.roomSrc,
                vod_remarks: `🔥${item.hn} | ${item.nickname}`,
                style: { type: "rect", ratio: 1.33 }
            }));
        }

        const result = {
            page: pg,
            pagecount: 99,
            limit: 20,
            total: 999,
            list: list
        };

        cache.set(cacheKey, result, 'category');
        return result;
        
    } catch (error) {
        console.error('获取分类列表失败:', error);
        return { list: [], page: pg, pagecount: 0 };
    }
};

const _detail = async ({ id }) => {
    const ids = Array.isArray(id) ? id : [id];
    const results = [];
    for (const roomId of ids) {
        try {
            // 获取直播间基本信息
            const roomUrl = `https://m.douyu.com/api/room/info?rid=${roomId}`;
            const roomRes = await axiosInstance.get(roomUrl);
            const roomData = roomRes.data;
            
            // 验证数据结构
            if (!roomData.data || !roomData.data.roomInfo) {
                console.error(`房间 ${roomId} 数据格式错误:`, roomData);
                continue;
            }
            
            const roomInfo = roomData.data.roomInfo;
            const seoInfo = roomData.data.seoInfo || {};
            
            // 构建视频信息
            const vod_name = roomInfo.roomName || `直播间: ${roomId}`;
            const vod_content = [
                '💃💃颖宝为您推荐斗鱼直播',
                '',
                `主播：${roomInfo.nickname}`,
                `热度：${roomInfo.hn}`,
                `分类：${roomInfo.cate2Name || '未知'}`,
                `标题：${vod_name}`,
                roomInfo.notice ? `公告：${roomInfo.notice}` : '',
                roomInfo.isLive ? '🔴 正在直播' : '⚫ 未开播'
            ].filter(Boolean).join('\n');
            
            const video = {
                vod_id: roomId,
                vod_name: vod_name,
                vod_pic: roomInfo.roomSrc,
                vod_content: vod_content,
                vod_play_from: "斗鱼直播",
                vod_play_url: `直播流$${roomId}`,
                // 额外信息
                vod_remarks: `🔥${roomInfo.hn} | ${roomInfo.nickname}`,
                vod_tag: roomInfo.cate2Name,
                vod_actor: roomInfo.nickname,
                vod_director: roomInfo.nickname,
                vod_year: new Date(roomInfo.showTime * 1000).getFullYear().toString()
            };
            
            results.push(video);
        } catch (error) {
            console.error(`获取直播间 ${roomId} 详情失败:`, error.message);
        }
    }
    return { list: results };
};

const _search = async ({ page, quick, wd }) => {
    const pg = parseInt(page || 1);
    if (!wd) return { list: [], page: pg, pagecount: 0 };

    const cacheKey = `douyu_search_${wd}_${pg}`;
    const cached = cache.get(cacheKey);
    if (cached) return cached;

    try {
        const offset = (pg - 1) * 20;
        const url = `https://m.douyu.com/api/search/liveRoom?sk=${encodeURIComponent(wd)}&offset=${offset}&limit=20&did=10000000000000000000000000001501`;
        
        const response = await axiosInstance.get(url);
        const data = response.data;

        let list = [];
        if (data.data && data.data.list) {
            list = data.data.list.map(item => ({
                vod_id: item.rid,
                vod_name: item.roomName,
                vod_pic: item.roomSrc,
                vod_remarks: item.nickname
            }));
        }

        const result = { list: list };
        cache.set(cacheKey, result, 'search');
        return result;
        
    } catch (error) {
        console.error('搜索失败:', error);
        return { list: [], page: pg, pagecount: 0 };
    }
};

const _play = async ({ flag, flags, id }) => {
    try {
        const playUrl = await generateDouyuSignature(id);
        
        if (!playUrl) {
            return { parse: 0, url: '' };
        }

        const playHeaders = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Referer": "https://www.douyu.com/",
            "Accept": "*/*",
            "Accept-Encoding": "identity"
        };
        
        return { 
            parse: 0, // 不解析，直接播放
            url: playUrl,
            header: playHeaders
        };
    } catch (error) {
        console.error("播放错误:", error);
        return { parse: 0, url: '' };
    }
};

const meta = {
    key: "DouyuLive",
    name: "斗鱼直播[官]",
    type: 4, // 直播类型
    api: "/video/DouyuLive",
    searchable: 1,
    quickSearch: 0, // 直播不支持快速搜索
    playable: 1,
    changeable: 0
};

module.exports = async (app, opt) => {
    app.get(meta.api, async (req, reply) => {
        const { extend, filter, t, ac, pg, ext, ids, play, wd, quick } = req.query;
        
        if (play) {
            return await _play({ id: play });
        } else if (wd) {
            return await _search({ page: parseInt(pg || "1"), quick: quick || false, wd });
        } else if (!ac) {
            return await _home({ filter: filter ?? false });
        } else if (ac === "detail") {
            if (t) {
                return await _category({ 
                    id: t, 
                    page: parseInt(pg || "1"), 
                    filters: {} 
                });
            } else if (ids) {
                return await _detail({ id: ids.split(",").map(v => v.trim()) });
            }
        }
        return { code: 400, msg: "参数错误" };
    });
    opt.sites.push(meta);
};