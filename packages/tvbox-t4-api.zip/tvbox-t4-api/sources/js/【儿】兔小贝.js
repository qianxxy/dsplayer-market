/**
 * 兔小贝[儿] - Fastify T4 JS 源
 * 站点：https://www.tuxiaobei.com
 */

const axios = require("axios");
const http = require("http");
const https = require("https");
const cheerio = require("cheerio");

const _http = axios.create({
  timeout: 15000,
  httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
  httpAgent: new http.Agent({ keepAlive: true }),
  responseType: "text",
  maxRedirects: 5,
  validateStatus: () => true,
});

const SITE_CONFIG = {
  title: "[儿]兔小贝",
  host: "https://www.tuxiaobei.com",
  debug: true,
  searchable: 2,
  quickSearch: 0,
  filterable: 0,
  headers: {
    "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9",
  },
  PAGE_LIMIT: 20,
};

const CLASSES = [
  { type_id: "2", type_name: "儿歌" },
  { type_id: "3", type_name: "故事" },
  { type_id: "4", type_name: "国学" },
  { type_id: "25", type_name: "启蒙" },
];

let log = () => {};
const safeStr = (v) => (v == null ? "" : String(v).trim());
const pageNumber = (v) => { const n = parseInt(String(v || "1"), 10); return n > 0 ? n : 1; };
const fullUrl = (p) => !p ? "" : /^https?:\/\//i.test(p) ? p : SITE_CONFIG.host + (p.startsWith("/") ? p : "/" + p);
const extractVideoId = (href) => { const m = safeStr(href).match(/\/play\/(\w+)/); return m ? m[1] : safeStr(href); };

const _home = async (filter) => {
  return { class: CLASSES, filters: {}, list: [] };
};

const _category = async (tid, pg) => {
  const cid = safeStr(tid) || "2";
  const page = pageNumber(pg);
  const url = `${SITE_CONFIG.host}/list/mip-data?typeId=${cid}&page=${page}&callback=`;
  try {
    const res = await _http.get(url, { headers: SITE_CONFIG.headers, responseType: "text" });
    // API 返回 JSONP 格式: ({...});，提取 { 到 } 之间的纯 JSON
    let raw = typeof res.data === "string" ? res.data : String(res.data || "");
    const start = raw.indexOf("{");
    const end = raw.lastIndexOf("}");
    if (start < 0 || end < 0) throw new Error("JSONP 解析失败");
    const json = JSON.parse(raw.substring(start, end + 1));
    const items = Array.isArray(json?.data?.items) ? json.data.items : [];
    const list = items.map((it) => ({
      vod_id: safeStr(it.video_id),
      vod_name: safeStr(it.name),
      vod_pic: safeStr(it.image),
      vod_remarks: safeStr(it.duration_string),
    }));
    return { list, page, pagecount: list.length >= SITE_CONFIG.PAGE_LIMIT ? 9999 : page, limit: SITE_CONFIG.PAGE_LIMIT, total: 999999 };
  } catch (e) {
    return { list: [], page, pagecount: 1, limit: SITE_CONFIG.PAGE_LIMIT, total: 0 };
  }
};

const _detail = async (ids) => {
  const idList = Array.isArray(ids) ? ids : [ids];
  const list = [];
  for (const rawId of idList) {
    const id = safeStr(rawId);
    if (!id) continue;
    const vid = extractVideoId(id);
    const detailUrl = `${SITE_CONFIG.host}/play/${vid}`;
    try {
      const res = await _http.get(detailUrl, { headers: SITE_CONFIG.headers, responseType: "text" });
      const html = typeof res.data === "string" ? res.data : String(res.data || "");
      const $ = cheerio.load(html);
      const title = $("h1").text().trim() || $(".title").first().text().trim() || vid;
      const pic = $("mip-img").first().attr("src") || $("img").first().attr("src") || "";
      const content = $(".content,.desc,.summary,.text-collapse").first().text().trim();
      const videoSrc = $("#videoWrap").attr("video-src") || $("video").first().attr("src") || "";
      list.push({
        vod_id: vid, vod_name: title, vod_pic: pic, vod_content: content,
        vod_play_from: "兔小贝",
        vod_play_url: "播放$" + (videoSrc || detailUrl),
      });
    } catch (e) {
      list.push({ vod_id: vid, vod_name: vid, vod_play_from: "兔小贝", vod_play_url: "播放$" + detailUrl });
    }
  }
  return { list };
};

const _search = async (pg, quick, wd) => {
  const page = pageNumber(pg);
  const keyword = safeStr(wd);
  if (!keyword) return { list: [], page, pagecount: 1, limit: 10, total: 0 };
  const url = `${SITE_CONFIG.host}/search/index?key=${encodeURIComponent(keyword)}&page=${page}`;
  try {
    const res = await _http.get(url, { headers: SITE_CONFIG.headers, responseType: "text" });
    const html = typeof res.data === "string" ? res.data : String(res.data || "");
    const $ = cheerio.load(html);
    const list = [];
    $(".list-con .items, .list-con .item").each((_, el) => {
      const $el = $(el);
      const title = $el.find(".text").text().trim() || $el.find(".title").text().trim() || $el.find("a").text().trim();
      const pic = $el.find("mip-img").attr("src") || $el.find("img").attr("src") || "";
      const remarks = $el.find(".time").text().trim() || $el.find(".all").text().trim() || "";
      const href = $el.find("a").attr("href") || "";
      if (!title || !href) return;
      list.push({ vod_id: extractVideoId(href), vod_name: title, vod_pic: pic, vod_remarks: remarks });
    });
    return { list, page, pagecount: list.length ? 9999 : page, limit: 10, total: 999999 };
  } catch (e) {
    return { list: [], page, pagecount: 1, limit: 10, total: 0 };
  }
};

const _play = async (flag, id) => {
  const playId = safeStr(id);
  if (!playId) return { parse: 0, url: "" };
  if (/^https?:\/\/.+\.(mp4|m3u8?|flv|avi|mkv|ts|mov|wmv|webm|m4v)/i.test(playId)) {
    return { parse: 0, url: playId, header: SITE_CONFIG.headers };
  }
  const detailUrl = fullUrl(playId);
  try {
    const res = await _http.get(detailUrl, { headers: SITE_CONFIG.headers, responseType: "text" });
    const html = typeof res.data === "string" ? res.data : String(res.data || "");
    const $ = cheerio.load(html);
    const videoSrc = $("#videoWrap").attr("video-src") || $("video").first().attr("src") || "";
    if (videoSrc) return { parse: 0, url: videoSrc, header: SITE_CONFIG.headers };
    return { parse: 1, url: detailUrl, header: SITE_CONFIG.headers };
  } catch (e) {
    return { parse: 1, url: detailUrl, header: SITE_CONFIG.headers };
  }
};

const meta = {
  key: "tuxiaobei", name: SITE_CONFIG.title, type: 4, api: "/video/tuxiaobei",
  searchable: 2, quickSearch: 0, changeable: 0, filterable: 0,
};

module.exports = async (app, opt) => {
  const flog = app?.log?.info?.bind(app?.log);
  log = SITE_CONFIG.debug ? (...a) => (flog || console.log)(`[兔小贝] ${a.join(" ")}`) : () => {};
  app.get(meta.api, async (req) => {
    const { filter, t, ac, pg, ids, flag, play, wd, quick } = req.query;
    try {
      if (play) return await _play(flag || "", play);
      if (wd) return await _search(parseInt(pg || "1", 10), quick === "true" || quick === "1", wd);
      if (!ac) return await _home(filter ?? false);
      if (ac === "detail") {
        if (t) return await _category(t, parseInt(pg || "1", 10));
        if (ids) return await _detail(ids.split(",").map(s => s.trim()).filter(Boolean));
      }
    } catch (e) {
      return { error: e.message };
    }
    return req.query;
  });
  if (opt && Array.isArray(opt.sites)) opt.sites.push(meta);
};
