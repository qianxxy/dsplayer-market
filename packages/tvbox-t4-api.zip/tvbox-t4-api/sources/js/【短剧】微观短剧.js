"use strict";

const axios = require("axios");
const crypto = require("node:crypto");

const API_BASE = "https://api.drama.9ddm.com/drama/home";
const SESSION_URL = "https://api.drama.9ddm.com/drama/session/create";
const RSA_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAt9edr+3ZR+FbrygKPI/pnueW/eJqW1Wg/Smd9JpnKy44zqnyMebVdhXyTh2g1AlaaCPMz2idaybz2scs7IL9fWyHxGI89e3/VO7qyyZMcuw3yiy9ZNysNdF565AkRhBReejA3luQr4DZn5uzieL90cLr3SO99uHNJEUswPz25NnWVvNTBiQa8QeQeoA6FcxL4/6jLdmxEg46FQZL+DDqUit2/yf6u1FxC+ChAqE7WuNKFaisONnCURDzGcLOoiNNM2fV84jEaVVfnw0JAw96t6+p5DjLQhw/2TpT1eqc3ufDCnzQQfaIfxz7JxSv/bWThySCWLIbhbhy1sqi3FzbhQIDAQAB";
const DEVICE_ID = "2a22636e7618231db8630ea84f89be202";
const DEVICE_NAME = "V2238A";
let sessionId = "";
let sessionKey = null;

const meta = { key: "duanjuweiguan", name: "[短]微观短剧", type: 4, api: "/video/duanjuweiguan", searchable: 1, quickSearch: 1, filterable: 1, changeable: 0 };
const subjects = ["全部", "逆袭", "都市", "古装", "家庭", "复仇", "动漫", "甜宠", "重生", "战神", "神医", "萌宝", "豪门", "悬疑", "穿越", "赘婿"];

function common() { return { app_launch_way: "icon", channel: "xiaomi", device_type: "pad", is_first_24h: "false", device_name: DEVICE_NAME, device_owning_firm: "vivo", screen_height: "1080", default_homepage: "drama_library", screen_width: "1920", density: "1.75", version_code: "2001", clientInfo: DEVICE_ID, version_name: "2.0.01", is_first_day: "false", av: "v1", os_type: "1", font_scale: "default" }; }
function nonce() { return crypto.randomUUID().replace(/-/g, ""); }
function query(v) { return new URLSearchParams(v).toString(); }
function pageNo(v) { const n = Number.parseInt(v, 10); return Number.isFinite(n) && n > 0 ? n : 1; }
function decodeExt(ext) { if (!ext) return {}; try { return JSON.parse(Buffer.from(String(ext), "base64").toString("utf8")) || {}; } catch { return {}; } }

async function init() {
  if (sessionId && sessionKey) return;
  const pair = crypto.generateKeyPairSync("ec", { namedCurve: "prime256v1" });
  const publicDer = pair.publicKey.export({ type: "spki", format: "der" }).toString("base64");
  const serverKey = crypto.createPublicKey({ key: Buffer.from(RSA_PUBLIC_KEY, "base64"), format: "der", type: "spki" });
  const params = { encryptedClientPublicKey: crypto.publicEncrypt({ key: serverKey, padding: crypto.constants.RSA_PKCS1_PADDING }, Buffer.from(publicDer, "utf8")).toString("base64"), nonce: nonce(), timestamp: String(Date.now()), deviceId: DEVICE_ID, deviceName: DEVICE_NAME, osType: "1", ...common() };
  const res = await axios.post(`${SESSION_URL}?${query(params)}`, null, { headers: { "User-Agent": "okhttp/5.1.0", "x-mi-xprotocol": "2", "x-mi-xversion": "2.4" }, timeout: 15000, responseType: "json" });
  const data = res.data && res.data.data || {};
  if (!data.sessionId || !data.serverEphemeralPublicKey) throw new Error("微观会话初始化失败");
  const remoteKey = crypto.createPublicKey({ key: Buffer.from(data.serverEphemeralPublicKey, "base64"), format: "der", type: "spki" });
  sessionId = data.sessionId;
  sessionKey = crypto.diffieHellman({ privateKey: pair.privateKey, publicKey: remoteKey });
}

function sign(queryParams, bodyParams = null) {
  const timestamp = String(Date.now());
  const random = nonce();
  const all = { ...(queryParams || {}), ...(bodyParams || {}) };
  const source = Object.keys(all).sort().map((k) => `${k}${all[k] ?? ""}`).join("") + timestamp + random;
  const hmacKey = Buffer.from(Buffer.from(sessionKey).toString("base64"), "utf8");
  return { value: crypto.createHmac("sha256", hmacKey).update(source, "utf8").digest("hex"), timestamp, nonce: random };
}

function headers(sig, json = false) {
  const h = { "User-Agent": "okhttp/5.1.0", "x-session-id": sessionId, "x-sign": sig.value, "x-timestamp": sig.timestamp, "x-nonce": sig.nonce, "x-mi-xprotocol": "2", "x-mi-xversion": "2.4" };
  if (json) h["Content-Type"] = "application/json; charset=UTF-8";
  return h;
}

async function searchApi(page, word, subject) {
  await init();
  const base = common();
  const stringBody = { audience: "全部", order: "最热", page: String(page), pageSize: "30", searchWord: word, sessionHistory: "[]", shortPlayType: "全部", subject };
  const body = { audience: "全部", order: "最热", page: Number(page), pageSize: 30, searchWord: word, sessionHistory: [], shortPlayType: "全部", subject };
  const sig = sign(base, stringBody);
  const res = await axios.post(`${API_BASE}/searchV2?${query(base)}`, JSON.stringify(body), { headers: headers(sig, true), timeout: 15000, responseType: "json" });
  return res.data || {};
}

function cards(data) {
  const parsed = typeof data === "string" ? JSON.parse(data) : data;
  return (parsed.data || []).map((v) => ({ vod_id: String(v.oneId || ""), vod_name: String(v.title || ""), vod_pic: String(v.horzPoster || ""), vod_remarks: String(v.episodeCount || "") })).filter((v) => v.vod_id && v.vod_name);
}

async function detail(id) {
  await init();
  const params = { oneId: id, page: "1", pageSize: "10", userId: "0", queryAll: "true", ...common() };
  const sig = sign(params);
  const res = await axios.get(`${API_BASE}/shortVideoDetail?${query(params)}`, { headers: headers(sig), timeout: 15000, responseType: "json" });
  const v = res.data || {};
  const urls = (v.data || []).filter((e) => Array.isArray(e.videoClarityList) && e.videoClarityList.length).map((e) => `${e.playOrder}$${Buffer.from(JSON.stringify(e.videoClarityList), "utf8").toString("base64")}`);
  return { list: [{ vod_id: id, vod_name: String(v.title || ""), vod_pic: String(v.vertPoster || ""), vod_content: String(v.description || ""), vod_play_from: "微观", vod_play_url: urls.join("#") }] };
}

function play(id) {
  const rows = JSON.parse(Buffer.from(String(id), "base64").toString("utf8"));
  const urls = [];
  for (const row of rows) if (row.url) urls.push(String(row.name || "播放"), String(row.url));
  if (!urls.length) throw new Error("播放地址为空");
  return { parse: 0, url: urls, header: { "User-Agent": "okhttp/5.1.0" }, extra: { nodanmu: true } };
}

module.exports = async (app, opt) => {
  app.get(meta.api, async (req) => {
    const q = req.query || {};
    try {
      if (q.play) return play(q.play);
      if (q.ids) return await detail(String(q.ids));
      if (q.wd) return { page: pageNo(q.pg), pagecount: 1, list: cards(await searchApi(pageNo(q.pg), String(q.wd).trim(), "全部")) };
      if (q.t) { const page = pageNo(q.pg); const ext = decodeExt(q.ext); const list = cards(await searchApi(page, "", ext.cateId || q.t || "全部")); return { page, pagecount: list.length < 30 ? page : page + 1, limit: 30, total: 0, list }; }
      return { class: subjects.map((v) => ({ type_id: v, type_name: v })), filters: {} };
    } catch (e) { app.log && app.log.error && app.log.error(`[微观短剧] ${e.message || e}`); return { list: [] }; }
  });
  opt.sites.push(meta);
};
