const axios = require('axios');
const http = require('http');
const https = require('https');
const crypto = require('crypto');

const HOST = 'https://m.jiabaide.cn';
const UA = 'Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.91 Mobile Safari/537.36';
const SIGN_KEY = 'cb808529bae6b6be45ecfab29a4889bc';
const PAGE_SIZE = 30;
const VOD_TOKEN = 'qbt859121210qbt';

const httpClient = axios.create({
  timeout: 15000,
  httpAgent: new http.Agent({ keepAlive: true }),
  httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
  validateStatus: s => s >= 200 && s < 500,
});

function md5(s) {
  return crypto.createHash('md5').update(String(s)).digest('hex');
}

function sha1(s) {
  return crypto.createHash('sha1').update(String(s)).digest('hex');
}

function signedHeaders(params = {}) {
  const t = String(Date.now());
  const signParams = { ...params, key: SIGN_KEY, t };
  const queryStr = Object.keys(signParams).map(k => `${k}=${signParams[k] ?? ''}`).join('&');
  return {
    'User-Agent': UA,
    'Referer': HOST,
    't': t,
    'sign': sha1(md5(queryStr)),
  };
}

function buildUrl(path, params = null) {
  if (!params || Object.keys(params).length === 0) return HOST + path;
  return `${HOST}${path}?${new URLSearchParams(params).toString()}`;
}

async function apiGet(path, params = {}) {
  const url = buildUrl(path, params);
  const res = await httpClient.get(url, { headers: signedHeaders(params) });
  if (res.status < 200 || res.status >= 300) {
    throw new Error(`HTTP ${res.status}: ${url}`);
  }
  return typeof res.data === 'string' ? JSON.parse(res.data || '{}') : (res.data || {});
}

function pageResult(list, pg, total, size = PAGE_SIZE, pageCount = 0) {
  const page = Math.max(parseInt(pg) || 1, 1);
  const totalNum = parseInt(total) || list.length || 0;
  const explicitPageCount = parseInt(pageCount) || 0;
  const pagecount = explicitPageCount || (totalNum > 0 ? Math.ceil(totalNum / size) : (list.length ? page + 1 : page));
  return { list, page, pagecount, limit: size, total: totalNum };
}

function vodItem(it = {}) {
  return {
    vod_id: String(it.vodId ?? it.vod_id ?? ''),
    vod_name: it.vodName ?? it.vod_name ?? '',
    vod_pic: it.vodPic ?? it.vod_pic ?? '',
    vod_remarks: it.vodRemarks ?? it.vod_remarks ?? '',
  };
}

async function getHome() {
  const [typeJson, filterJson, hotJson] = await Promise.all([
    apiGet('/api/mw-movie/anonymous/get/filer/type').catch(() => ({})),
    apiGet('/api/mw-movie/anonymous/v1/get/filer/list').catch(() => ({})),
    apiGet('/api/mw-movie/anonymous/home/hotSearch').catch(() => ({})),
  ]);

  const typeArr = typeJson.data || [];
  const filterData = filterJson.data || {};
  const classes = typeArr.map(it => ({
    type_id: String(it.typeId),
    type_name: it.typeName,
  })).filter(it => it.type_id && it.type_name);

  const nameMap = {
    typeList: { key: 'type', name: '类型' },
    plotList: { key: 'class', name: '剧情' },
    districtList: { key: 'area', name: '地区' },
    languageList: { key: 'lang', name: '语言' },
    yearList: { key: 'year', name: '年份' },
  };

  const filters = {};
  for (const cls of classes) {
    const tid = cls.type_id;
    const row = [];
    for (const apiKey of Object.keys(nameMap)) {
      const arr = filterData?.[tid]?.[apiKey];
      if (!Array.isArray(arr) || arr.length === 0) continue;
      const cfg = nameMap[apiKey];
      row.push({
        key: cfg.key,
        name: cfg.name,
        value: [
          { n: '全部', v: '' },
          ...arr.map(v => ({
            n: v.itemText,
            v: apiKey === 'typeList' ? String(v.itemValue ?? '') : String(v.itemText ?? ''),
          })).filter(v => v.n !== undefined),
        ],
      });
    }
    row.push({
      key: 'by',
      name: '排序',
      value: [
        { n: '最近更新', v: '1' },
        { n: '添加时间', v: '2' },
        { n: '人气高低', v: '3' },
        { n: '评分高低', v: '4' },
      ],
    });
    filters[tid] = row;
  }

  const list = (hotJson.data || []).slice(0, 20).map(vodItem);
  return { class: classes, filters, list, page: 1, pagecount: 1, total: list.length };
}

async function getCategory(tid, pg = 1, extend = {}) {
  const params = {
    area: extend.area || '',
    lang: extend.lang || '',
    pageNum: String(Math.max(parseInt(pg) || 1, 1)),
    pageSize: String(PAGE_SIZE),
    sort: extend.by || extend.sort || '1',
    sortBy: '1',
    type: extend.type || '',
    type1: String(tid),
    v_class: extend.class || '',
    year: extend.year || '',
  };
  const json = await apiGet('/api/mw-movie/anonymous/video/list', params).catch(() => ({}));
  const data = json.data || {};
  const list = (data.list || []).map(it => ({
    ...vodItem(it),
    vod_remarks: [it.vodRemarks, it.vodDoubanScore].filter(v => v !== undefined && v !== null && v !== '').join('_'),
  }));
  return pageResult(list, pg, data.totalCount || data.total || 0, data.pageSize || PAGE_SIZE, data.totalPage || 0);
}

async function getDetail(ids) {
  const id = Array.isArray(ids) ? ids[0] : String(ids || '').split(',')[0];
  if (!id) return { list: [] };
  const json = await apiGet('/api/mw-movie/anonymous/video/detail', { id }).catch(() => ({}));
  const kvod = json.data;
  if (!kvod) return { list: [] };

  const episodes = [];
  for (const it of kvod.episodeList || []) {
    const name = it.name || it.title || `第${episodes.length + 1}集`;
    const nid = it.nid ?? it.id ?? '';
    if (nid !== '') episodes.push(`${name}$${kvod.vodId}@${nid}`);
  }

  const vod = {
    vod_id: String(kvod.vodId ?? id),
    vod_name: kvod.vodName || '',
    vod_pic: kvod.vodPic || '',
    type_name: kvod.vodClass || '',
    vod_year: kvod.vodYear || '',
    vod_area: kvod.vodArea || '',
    vod_remarks: kvod.vodRemarks || '',
    vod_actor: kvod.vodActor || '',
    vod_director: kvod.vodDirector || '',
    vod_content: String(kvod.vodContent || '').replace(/<[^>]+>/g, '').trim(),
    vod_play_from: '金牌线路$$$金牌代理',
    vod_play_url: `${episodes.join('#')}$$$${episodes.map(v => v.replace('$', '$proxy@')).join('#')}`,
  };
  return { list: [vod] };
}

async function doSearch(wd, pg = 1) {
  const params = {
    keyword: wd || '',
    pageNum: String(Math.max(parseInt(pg) || 1, 1)),
    pageSize: String(PAGE_SIZE),
  };
  const json = await apiGet('/api/mw-movie/anonymous/video/searchByWordPageable', params).catch(() => ({}));
  const data = json.data || {};
  const rawList = (data.list || []).map(vodItem);
  // 完整搜索词匹配：API 做的是分词模糊匹配，这里二次过滤只保留片名包含完整搜索词的
  const kw = (wd || '').replace(/\s+/g, '').trim();
  const list = kw
    ? rawList.filter(it => (it.vod_name || '').replace(/\s+/g, '').includes(kw))
    : rawList;
  return pageResult(list, pg, data.totalCount || data.total || 0, data.pageSize || PAGE_SIZE, data.totalPage || 0);
}

function b64u(value) {
  return Buffer.from(String(value || ''), 'utf8').toString('base64url');
}

function unb64u(value) {
  try { return Buffer.from(String(value || ''), 'base64url').toString('utf8'); } catch (_) { return ''; }
}

function requestBase(req) {
  const proto = String(req?.headers?.['x-forwarded-proto'] || 'http').split(',')[0].trim() || 'http';
  const host = String(req?.headers?.['x-forwarded-host'] || req?.headers?.host || '').split(',')[0].trim();
  return host ? `${proto}://${host}` : '';
}

function requestToken(req) {
  return String(req?.query?.token || VOD_TOKEN).trim();
}

function proxyUrl(req, targetUrl, type = '') {
  const token = requestToken(req);
  const qs = new URLSearchParams({ url: b64u(targetUrl) });
  if (type) qs.set('type', type);
  if (token) qs.set('token', token);
  const path = `/video/jinpai/proxy?${qs.toString()}`;
  return requestBase(req) ? requestBase(req) + path : path;
}

function absolutizeUrl(url, baseUrl) {
  const value = String(url || '').trim();
  if (!value) return '';
  if (/^https?:\/\//i.test(value)) return value;
  if (value.startsWith('//')) return `https:${value}`;
  try { return new URL(value, baseUrl).toString(); } catch (_) { return value; }
}

function rewriteM3u8(body, baseUrl, req) {
  return String(body || '').split(/\r?\n/).map(line => {
    const trimmed = line.trim();
    if (!trimmed) return line;
    if (trimmed.startsWith('#')) {
      return line.replace(/URI="([^"]+)"/g, (_, u) => `URI="${proxyUrl(req, absolutizeUrl(u, baseUrl), 'key')}"`);
    }
    const target = absolutizeUrl(trimmed, baseUrl);
    return proxyUrl(req, target, /\.m3u8(\?|$)/i.test(target) ? 'm3u8' : 'media');
  }).join('\n');
}

async function proxy(req, reply) {
  const targetUrl = unb64u(req.query?.url);
  const type = String(req.query?.type || '').toLowerCase();
  if (!/^https?:\/\//i.test(targetUrl)) {
    if (reply?.code) reply.code(400);
    return 'bad url';
  }
  const isM3u8 = type === 'm3u8' || /\.m3u8(\?|$)/i.test(targetUrl);
  const headers = {
    'User-Agent': UA,
    'Referer': HOST,
    'Origin': HOST,
    'Accept': isM3u8 ? 'application/vnd.apple.mpegurl,application/x-mpegURL,*/*' : '*/*',
  };
  if (req.headers?.range && !isM3u8) headers.Range = req.headers.range;
  try {
    const res = await httpClient.get(targetUrl, {
      responseType: isM3u8 ? 'text' : 'arraybuffer',
      headers,
      timeout: isM3u8 ? 15000 : 30000,
    });
    if (res.status < 200 || res.status >= 300) {
      if (reply?.code) reply.code(res.status || 502);
      return `proxy status ${res.status}`;
    }
    if (reply?.header) {
      reply.header('Access-Control-Allow-Origin', '*');
      reply.header('Cache-Control', 'no-store');
    }
    if (isM3u8) {
      if (reply?.type) reply.type('application/vnd.apple.mpegurl; charset=utf-8');
      return rewriteM3u8(typeof res.data === 'string' ? res.data : Buffer.from(res.data || '').toString('utf8'), targetUrl, req);
    }
    if (reply?.code && res.status === 206) reply.code(206);
    if (reply?.header) {
      reply.header('Content-Type', res.headers?.['content-type'] || (type === 'key' ? 'application/octet-stream' : 'video/mp2t'));
      for (const h of ['content-length', 'content-range', 'accept-ranges']) {
        if (res.headers?.[h]) reply.header(h, res.headers[h]);
      }
    }
    return Buffer.from(res.data || []);
  } catch (e) {
    if (reply?.code) reply.code(502);
    return `proxy error: ${e.message}`;
  }
}

async function getPlay(id, req) {
  try {
    let useProxy = false;
    let realId = String(id || '');
    if (realId.startsWith('proxy@')) {
      useProxy = true;
      realId = realId.slice('proxy@'.length);
    }
    const [sid, nid] = realId.split('@');
    if (!sid || !nid) return { parse: 0, jx: 0, url: '', header: { 'User-Agent': UA } };
    const params = { clientType: '3', id: sid, nid };
    const json = await apiGet('/api/mw-movie/anonymous/v2/video/episode/url', params).catch(() => ({}));
    const list = json?.data?.list || [];
    const playUrl = list[0]?.url || '';
    const finalUrl = useProxy && playUrl ? proxyUrl(req, playUrl, /\.m3u8(\?|$)/i.test(playUrl) ? 'm3u8' : 'media') : playUrl;
    return { parse: 0, jx: 0, url: finalUrl, header: { 'User-Agent': UA } };
  } catch (e) {
    return { parse: 0, jx: 0, url: '', header: { 'User-Agent': UA } };
  }
}

function parseExtend(raw) {
  if (!raw) return {};
  if (typeof raw === 'object') return raw;
  const candidates = [String(raw)];
  try { candidates.push(decodeURIComponent(String(raw))); } catch (_) {}
  try { candidates.push(Buffer.from(String(raw), 'base64').toString('utf8')); } catch (_) {}
  try { candidates.push(Buffer.from(String(raw).replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8')); } catch (_) {}
  for (const s of candidates) {
    const v = String(s || '').trim();
    if (!v || (!v.startsWith('{') && !v.startsWith('['))) continue;
    try {
      const obj = JSON.parse(v);
      return obj && typeof obj === 'object' ? obj : {};
    } catch (_) {}
  }
  return {};
}

async function handle(req) {
  const q = req.query || {};
  const ac = q.ac;
  const pg = Math.max(parseInt(q.pg) || 1, 1);
  const extJson = parseExtend(q.ext || q.extend || q.f);

  const isPlay = !!q.play || ac === 'play' || (!!q.flag && !!q.id);
  const wd = q.wd || q.key || q.keyword;
  const tid = q.t || q.type_id;
  const ids = q.ids || (q.id && !isPlay && !tid ? q.id : '');
  const ext = {
    ...extJson,
    area: q.area ?? extJson.area ?? '',
    lang: q.lang ?? extJson.lang ?? '',
    type: q.type ?? extJson.type ?? '',
    class: q.class ?? q.v_class ?? extJson.class ?? '',
    year: q.year ?? extJson.year ?? '',
    by: q.by ?? q.sort ?? extJson.by ?? extJson.sort ?? '',
    sort: q.sort ?? extJson.sort ?? '',
  };

  if (isPlay) return await getPlay(q.play || q.id, req);
  // 有些壳子分类请求会带 ac=detail&t=分类ID；只有明确传 ids/id 时才走详情。
  if (ids) return await getDetail(ids);
  if (wd) return await doSearch(wd, pg);
  if (tid && String(tid) !== '0') return await getCategory(tid, pg, ext);
  return await getHome();
}

module.exports = async (app, opt) => {
  const path = '/video/jinpai';
  app.get(path, async (req) => await handle(req));
  app.get('/video/金牌', async (req) => await handle(req));
  app.get(`${path}/proxy`, proxy);
  app.get('/video/金牌/proxy', proxy);

  opt.sites.push({
    key: 'jinpai',
    name: '[纯]金牌',
    type: 4,
    api: path,
    searchable: 1,
    quickSearch: 1,
    filterable: 1,
    changeable: 0,
    ext: '',
  });
};
