"use strict"; module.exports = require("./appv7-client").createRoute({ key: "appv7dashixiong", name: "[影]师兄秒播", configKey: "AppV7Dsx" });
