"use strict"; module.exports = require("./appv7-client").createRoute({ key: "appv7xianyu", name: "[影]咸鱼秒播", configKey: "AppV7Xy" });
