/**
 * 咪视界直播 - T4 插件
 * 基于本地 127.0.0.1:3330 咪视界直播源聚合后台
 * 首页/全部直播 = 按分类聚合; 分类页 = 频道展开(不聚合, 多源=多线路)
 */
"use strict";
const axios = require("axios");
const http = require("http");
const https = require("https");

const API_HOST = "http://127.0.0.1:3330";

const axiosInstance = axios.create({
    timeout: 10000,
    httpAgent: new http.Agent({ keepAlive: true }),
    headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'application/json, text/plain, */*'
    }
});

const cache = {
    data: new Map(),
    ttl: { home: 60000, category: 30000 },
    get(key) {
        const it = cache.data.get(key);
        if (!it) return null;
        if (Date.now() > it.expire) { cache.data.delete(key); return null; }
        return it.data;
    },
    set(key, data, type) {
        cache.data.set(key, { data, expire: Date.now() + (cache.ttl[type] || 60000) });
        if (cache.data.size > 500) cache.data.clear();
    }
};

const groupStore = new Map();   // group_分类名 -> 聚合条目
const channelStore = new Map(); // ch_频道名  -> 频道条目

async function apiGet(params) {
    const url = API_HOST + '/?' + new URLSearchParams(params).toString();
    const res = await axiosInstance.get(url);
    return res.data;
}

/** 规范化分类名: 去掉所有空白(含全角空格), 防止同分类被拆成两组 */
function norm(s) {
    return String(s || '').replace(/[\s\u3000\u00a0]+/g, '').trim();
}

/** 从 频道名$URL 提取直链(取最后一段) */
function extractUrl(u) {
    const s = String(u || '');
    return s.includes('$') ? s.split('$').pop() : s;
}

/**
 * 按分类聚合(首页/全部直播用):
 *   vod_name=分类名, 线路=分类名, 选集=频道名
 */
function buildByGroup(rawList) {
    const groups = new Map(); // 分类名 -> Map(频道名 -> Set(url))
    for (const it of rawList || []) {
        const g = norm(it.vod_remarks) || '默认频道';
        const name = (it.vod_name || '').trim();
        if (!name) continue;
        const url = extractUrl(it.vod_play_url);
        if (!url) continue;
        if (!groups.has(g)) groups.set(g, new Map());
        const chMap = groups.get(g);
        if (!chMap.has(name)) chMap.set(name, new Set());
        chMap.get(name).add(url);
    }
    const list = [];
    for (const [g, chMap] of groups) {
        const names = [...chMap.keys()];
        let firstLogo = '';
        for (const name of names) {
            const src = rawList.find(it => norm(it.vod_remarks) === g && (it.vod_name || '').trim() === name);
            if (src && src.vod_pic) { firstLogo = src.vod_pic; break; }
        }
        let maxLines = 1;
        for (const urls of chMap.values()) maxLines = Math.max(maxLines, urls.size);
        maxLines = Math.min(maxLines, 5);
        const urlsPerLine = [];
        for (let i = 0; i < maxLines; i++) {
            const line = [];
            for (const [name, urls] of chMap) {
                const arr = [...urls];
                line.push(name + '$' + (arr[i] || arr[arr.length - 1]));
            }
            urlsPerLine.push(line.join('#'));
        }
        const agg = {
            vod_id: 'group_' + g,
            vod_name: g,
            vod_pic: firstLogo,
            vod_remarks: names.length + '个频道',
            vod_play_from: g,
            vod_play_url: urlsPerLine.join('$$$'),
            vod_content: '分类:' + g + '，共 ' + names.length + ' 个频道'
        };
        groupStore.set('group_' + g, agg);
        list.push(agg);
    }
    return list;
}

/**
 * 频道展开(分类页/搜索用, 不聚合):
 *   每条频道一个 vod, 同频道多源 = 单线路多选集
 */
function buildByChannel(rawList) {
    const chans = new Map(); // 频道名 -> {urls, pic, group}
    for (const it of rawList || []) {
        const name = (it.vod_name || '').trim();
        if (!name) continue;
        const url = extractUrl(it.vod_play_url);
        if (!url) continue;
        if (!chans.has(name)) chans.set(name, { urls: [], pic: '', group: norm(it.vod_remarks) || '直播' });
        const ch = chans.get(name);
        if (!ch.urls.includes(url)) ch.urls.push(url);
        if (!ch.pic && it.vod_pic) ch.pic = it.vod_pic;
    }
    const list = [];
    for (const [name, ch] of chans) {
        const urls = ch.urls.slice(0, 5); // 源上限 5
        const ln = ch.group || '直播';
        const agg = {
            vod_id: 'ch_' + name,
            vod_name: name,
            vod_pic: ch.pic,
            vod_remarks: urls.length + '源',
            vod_play_from: ln,   // 线路只显示一个频道名
            vod_play_url: urls.map(u => name + '$' + u).join('#'), // 选集=该频道的线路聚合
            vod_content: '频道:' + name + '，共 ' + urls.length + ' 个源'
        };
        channelStore.set('ch_' + name, agg);
        list.push(agg);
    }
    return list;
}

async function home() {
    const ck = 'home';
    let data = cache.get(ck);
    if (data) return data;
    const raw = await apiGet({});
    // 分类列表(去重)
    const classes = [{ type_id: 'all', type_name: '全部直播' }];
    const seen = new Set(['all']);
    for (const c of raw.class || []) {
        if (c.type_id && c.type_name && !seen.has(c.type_id)) {
            seen.add(c.type_id);
            classes.push(c);
        }
    }
    data = { class: classes, list: buildByGroup(raw.list) };
    cache.set(ck, data, 'home');
    return data;
}

async function category(t, pg) {
    if (t === 'all') return home();
    const ck = 'cat_' + t;
    let data = cache.get(ck);
    if (data) return data;
    const target = norm(t).replace(/^group_/, '');
    const raw = await apiGet({});
    const sub = (raw.list || []).filter(it => norm(it.vod_remarks) === target);
    // 全部直播/推荐保持聚合原逻辑，其他分类直接展开频道
    const list = (target === '推荐') ? buildByGroup(sub) : buildByChannel(sub);
    data = { page: 1, pagecount: 1, limit: 999, total: list.length, list };
    cache.set(ck, data, 'category');
    return data;
}

async function detail(idList) {
    const list = [];
    for (const rawId of idList) {
        const key = String(rawId || '');
        let agg = groupStore.get(key) || channelStore.get(key);
        if (!agg) {
            const raw = await apiGet({});
            if (key.startsWith('group_')) {
                agg = buildByGroup(raw.list).find(x => x.vod_id === key);
            } else {
                const name = key.replace(/^ch_/, '');
                agg = buildByChannel(raw.list.filter(it => (it.vod_name || '').trim() === name)).find(x => x.vod_id === key);
            }
        }
        if (agg) list.push(agg);
    }
    return { list };
}

async function play(flag, id) {
    // id = 频道名$URL, 取第一个 $ 之后的 URL
    let url = String(id || '');
    if (url.includes('$')) url = url.split('$').slice(1).join('$');
    if (!url) return { parse: 0, url: '' };
    return { parse: 0, url };
}

async function search(wd, pg) {
    if (!wd) return { list: [] };
    const raw = await apiGet({ wd });
    const list = buildByChannel(raw.list);
    return { page: 1, pagecount: 1, limit: 999, total: list.length, list, parse: 0, jx: 0 };
}

const meta = {
    key: "mishijie_zhibo2",
    name: "咪视界直播2[+]",
    type: 4,
    api: "/video/mishijie2",
    searchable: 1,
    quickSearch: 1,
    filterable: 0,
    changeable: 0,
};

module.exports = async (app, opt) => {
    app.get(meta.api, async (req) => {
        const q = req.query || {};
        const { ac, t, pg, wd, play: playId, ids } = q;
        try {
            if (playId) return await play(q.flag, playId);
            if (wd) return await search(wd, pg);
            if (ids) return await detail([String(ids)]);
            if (t) return await category(t, pg || "1");
            if (ac === "list") return await category("all", pg || "1");
            return await home();
        } catch (e) {
            app.log && app.log.error && app.log.error(`[咪视界] ${e && e.message || e}`);
            return { list: [] };
        }
    });

    opt.sites.push(meta);
};