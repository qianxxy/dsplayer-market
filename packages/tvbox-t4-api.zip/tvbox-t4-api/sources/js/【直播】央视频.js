/**
 * 央視頻 - Fastify T4 JS 直播源
 * ============================================================================
 * 站点：https://www.yangshipin.cn
 *
 * 频道列表：内置 yangshipin.json 静态数据（61 个频道，含央视+卫视）
 * 播放：WASM keygen + AES cKey + 多步认证获取 HLS 直播流
 * 参考：【直播】看潮州.js 的标准 T4 VOD 格式
 * ============================================================================
 */

const axios = require("axios");
const http = require("http");
const https = require("https");
const crypto = require("crypto");

// ==================== HTTP 客户端 ====================
const _http = axios.create({
  timeout: 15 * 1000,
  httpsAgent: new https.Agent({
    keepAlive: true,
    rejectUnauthorized: false,
    secureOptions: crypto.constants.SSL_OP_LEGACY_SERVER_CONNECT
      | crypto.constants.SSL_OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION,
  }),
  httpAgent: new http.Agent({ keepAlive: true }),
  maxRedirects: 5,
});

// ==================== 配置 ====================
const CONFIG = {
  key: "YangshiLive",
  name: "[直播]央視頻",
  api: "/video/YangshiLive",
  debug: true,
  host: "https://www.yangshipin.cn",
  playerUrl: "https://player-api.yangshipin.cn/v1/player/",
  openTokenUrl: "https://h5access.yangshipin.cn/web/open/token",
  keygenUrl: "https://s.yangshipin.cn/CCTVVideo/cctvh5-openapicore/keygen_bg.wasm",
  ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36",
  yspAppId: "519748109",
  appVersion: "V1.0.0",
  platform: "5910204",
  authSalt: "n@7QKk%YeSjfw%22",
  requestSalt: "0f$IVHi9Qno?G",
  openVappId: "59306155",
  openVsecret: "b42702bf7309a179d102f3d51b1add2fda0bc7ada64cb801",
  ticketSuffix: "bSCz8SqH8T",
  playCacheSeconds: 60,
};

const TICKET_KEYSTREAM = Buffer.from(
  "6a70e9ac007ccc384c28a88dfd2211decb66494bca83bd6178f85732b2eacc959" +
    "4e4e5ab720ec3a43e87b3c72b86192ff0dfea8fa8f47794d8792668438c",
  "hex"
);

// ==================== Logo 映射（央视频 CDN，imageMogr2 放大到 640x320）====================
const _L = (dir, hash) =>
  `https://resources.yangshipin.cn/assets/oms/image/${dir}/${hash}.png?imageMogr2/thumbnail/640x320/format/png`;
const _L06 = (h) => _L("202306", h);
const _L11 = (h) => _L("202411", h);
const _L12 = (h) => _L("202412", h);
const _L03 = (h) => _L("202503", h);
const _L09 = (h) => _L("202309", h);

const LOGO_MAP = {
  // 央视频道
  "CCTV1": _L06("d57905b93540bd15f0c48230dbbbff7ee0d645ff539e38866e2d15c8b9f7dfcd"),
  "CCTV2": _L06("20115388de0207131af17eac86c33049b95d69eaff064e55653a1b941810a006"),
  "CCTV3": _L06("7b7a65c712450da3deb6ca66fbacf4f9aee00d3f20bd80eafb5ada01ec63eb3a"),
  "CCTV4": _L06("f357e58fdbcc076a3d65e1f958c942b2e14f14342c60736ceed98b092d35356a"),
  "CCTV5": _L06("0a6a7138952675983a3d854df7688557b286d59aa06166edae51506f9204d655"),
  "CCTV5+": _L06("0a6a7138952675983a3d854df7688557b286d59aa06166edae51506f9204d655"),
  "CCTV6": _L06("741515efda91f03f455df8a7da4ee11fa9329139c276435cf0a9e2af398d5bf2"),
  "CCTV7": _L06("b29af94e295ebdf646cefb68122c429b9cd921f498ca20d2d8070252536f9ff9"),
  "CCTV8": _L06("ad51de94426a0ba039e6dd6a8534ea98ecc813a6176bde87b4f18cc34d6d7590"),
  "CCTV9": _L06("2ed1b4deeca179d5db806bb941790f82eb92a1b7299c1c38fe027f95a5caee5e"),
  "CCTV10": _L06("aa6157ec65188cd41826e5a2f088c3d6d153205f5f6428258d12c59999e221aa"),
  "CCTV11": _L06("ed12ed7c7a1034dae4350011fe039284c5d5a836506b28c9e32e3c75299625c0"),
  "CCTV12": _L06("484083cffaa40df7e659565e8cb4d1cc740158a185512114167aa21fa0c59240"),
  "CCTV13": _L06("266da7b43c03e2312186b4a999e0f060e8f15b10d2cc2c9aa32171819254cf1a"),
  "CCTV14": _L06("af6b603896938dc346fbb16abfc63c12cba54b0ec9d18770a15d347d115f12d5"),
  "CCTV15": _L06("2ceee92188ef684efe0d8b90839c4f3ad450d179dc64d59beff417059453af47"),
  "CCTV16-HD": _L06("53793fa7bacd3a93ff6dc5d2758418985e1f952a316c335d663b572d8bdcd74d"),
  "CCTV16(4K）": _L06("53793fa7bacd3a93ff6dc5d2758418985e1f952a316c335d663b572d8bdcd74d"),
  "CCTV17": _L06("ddef563072f8bad2bea5b9e52674cb7b4ed50efb20c26e61994dfbdf05c1e3c0"),
  "CCTV4K": _L06("3e9d06fd7244d950df5838750f1c6ac3456e172b51caca2c16d2282125b111e8"),
  "CCTV8K": _L03("df543dd2e337be8bf6aa06342d8d790992f7ae47b89403606253436e40409031"),
  // CGTN
  "CGTN": _L06("a72dff758ca1c17cd0ecc8cedc11b893d208f409d5e6302faa0e9d298848abc3"),
  "CGTN法语频道": _L06("a72dff758ca1c17cd0ecc8cedc11b893d208f409d5e6302faa0e9d298848abc3"),
  "CGTN俄语频道": _L06("bf0a820893cbaf20dd0333e27042e1ef9c8806e5b602b6a8c95af399db0bc77a"),
  "CGTN阿拉伯语频道": _L06("2e44e2aa3e7a1cedf07fd0ae59fe69e86a60a2632660a006e3e9e7397b2d107e"),
  "CGTN西班牙语频道": _L09("7c337e3dbe64402ec7e4678a619a4a6d95144e42f35161181ff78e143b7cf67a"),
  "CGTN外语纪录频道": _L09("74d3ac436a7e374879578de1d87a941fbf566d39d5632b027c5097891ed32bd5"),
  // 卫视
  "北京卫视": _L06("f4f23633c578beea49a3841d88d3490100f029ee349059fa532869db889872c5"),
  "江苏卫视": _L06("380ad685c0c1d5b2c902246b8d2df6d3f9b45e2837abcfe493075bbded597a31"),
  "东方卫视": _L06("9bd372ca292a82ce3aa08772b07efc4af1f85c21d1f268ea33440c49e9a0a488"),
  "浙江卫视": _L06("a66c836bd98ba3e41a2e9a570d4b9c50dedc6839e9de333e2e78212ad505f37e"),
  "湖南卫视": _L06("4120e89d3079d08aa17d382f69a2308ec70839b278367763c34a34666c75cb88"),
  "湖北卫视": _L06("7a6be5a2bb1dc53a945c016ff1f525dc4a84c51db371c15c89aa55404b0ba784"),
  "广东卫视": _L06("28886880a4dc0f06fb7e0a528a1def0591d61a65870e29176ede0cc92033bbfd"),
  "广西卫视": _L06("54b7e97cb816bb223fe05f3fc44da2c7820eb66e8550c19d23100f2c414ecc38"),
  "黑龙江卫视": _L06("d8273ae9be698ce2db21f5b886ecac95a73429593f93713c60ed8c12c38bf0d3"),
  "海南卫视": _L06("6e060391fde0469801fc3d84dbf204b4f8d650d251f17d7595a6964c0bb99e81"),
  "重庆卫视": _L06("657651f411de2673d1770d9a78b44c1265704f7468cc41d4be7f51d630768494"),
  "深圳卫视": _L06("d59fec04c902e3581c617136d02d4b9b8c4cbe64272781ddd3525e80c823edb7"),
  "四川卫视": _L06("3276a414ae0eaa0f116f2045cd913367967d0c7c1e978e8621ac3879436c6ed7"),
  "河南卫视": _L06("74925962148a6d31c85808b6cd4e444c2a54bab393d2c5fc85e960b50e22fa86"),
  "福建东南卫视": _L06("3208fe6564a293c21b711333fb3edb05bb5b406cff840573c9a8d839680a1579"),
  "贵州卫视": _L06("4eb45f4781d33d872af027dc01c941559aab55667dd99cc5c22bef7037807b13"),
  "江西卫视": _L06("3c760d0d00463855890e8a1864ea4a6b6dd66b90c29b4ac714a4b17c16519871"),
  "辽宁卫视": _L06("ac4ed6058a87c101ae7147ebc38905d0cae047fb73fd277ee5049b84f52bda36"),
  "安徽卫视": _L06("f35fa04b51b1ee4984b03578b65403570868ebca03c6c01e11b097f999a58d9b"),
  "河北卫视": _L06("d545becdc81c60197b08c7f47380705e4665ed3fe55efc8b855e486f6e655378"),
  "山东卫视": _L06("22d403f07a7cf5410b3ad3ddb65a11aa229a32475fac213f5344c9f0ec330ca1"),
  "天津卫视": _L11("2642bf96eaf49fdc6b08db2cf6a3d8a7c30824bbcc199985e70e8b8846c5d14d"),
  "吉林卫视": _L11("cfe6b0f01c7e381471b774f5a9f615e1bb70b946ad658da9ed6fcae28d752881"),
  "陕西卫视": _L11("b63ce6fd91a92076273ea2d4679bfbe367ece51a114b54b79a66bc8de5831fa0"),
  "甘肃卫视": _L11("b63ce6fd91a92076273ea2d4679bfbe367ece51a114b54b79a66bc8de5831fa0"),
  "宁夏卫视": _L11("8392c1ee75dca2a13f6dc0efa37519be4284764fecd65415a1a9f55b11534c5b"),
  "内蒙古卫视": _L11("fe60396ae9ead3125d763146d8bc1e9b51ed8e19e8dc61600e28cc0b2f2d28c7"),
  "云南卫视": _L11("907600c544719ffdaa6b6fa177d91b530dc9ce38e3dfd43a14ea7c805a7df97d"),
  "山西卫视": _L11("d9fe4441f6adcfe9fd7ee2e45bf46d2a355b0fa48ff10dbba12978d2f8cf9780"),
  "青海卫视": _L11("182e779878c85642049514a6e033f6be41aa8bf5f489fadc6f63dfc50863c36d"),
  "西藏卫视": _L11("37f9668cded5cc19848cfe7dcaf717de4acc47667dde656ba2646aba372eebbe"),
  "中国教育电视台1频道": _L12("2b9301a4795c7f23b7ec7ed651d8c7df002ce8c608168970485999b03d29f783"),
  "新疆卫视": _L12("005fd504f809ab28ec8cdd5d34d3886f0611ddefa20ebcc0f3f7dc176ad528c7"),
};

// ==================== 内置频道列表 ====================
const CHANNELS = [
  { name: "CCTV1", pid: "600001859", cnlid: "2024078201", type: "yangshi", vip: false },
  { name: "CCTV2", pid: "600001800", cnlid: "2024075401", type: "yangshi", vip: false },
  { name: "CCTV3", pid: "600001801", cnlid: "2024068501", type: "yangshi", vip: false },
  { name: "CCTV4", pid: "600001814", cnlid: "2029797101", type: "yangshi", vip: false },
  { name: "CCTV5", pid: "600001818", cnlid: "2024078401", type: "yangshi", vip: false },
  { name: "CCTV5+", pid: "600001817", cnlid: "2024078001", type: "yangshi", vip: false },
  { name: "CCTV6", pid: "600108442", cnlid: "2013693901", type: "yangshi", vip: false },
  { name: "CCTV7", pid: "600004092", cnlid: "2024072001", type: "yangshi", vip: false },
  { name: "CCTV8", pid: "600001803", cnlid: "2029793001", type: "yangshi", vip: false },
  { name: "CCTV9", pid: "600004078", cnlid: "2024078601", type: "yangshi", vip: false },
  { name: "CCTV10", pid: "600001805", cnlid: "2024078701", type: "yangshi", vip: false },
  { name: "CCTV11", pid: "600001806", cnlid: "2027248701", type: "yangshi", vip: false },
  { name: "CCTV12", pid: "600001807", cnlid: "2027248801", type: "yangshi", vip: false },
  { name: "CCTV13", pid: "600001811", cnlid: "2029797201", type: "yangshi", vip: false },
  { name: "CCTV14", pid: "600001809", cnlid: "2027248901", type: "yangshi", vip: false },
  { name: "CCTV15", pid: "600001815", cnlid: "2027249001", type: "yangshi", vip: false },
  { name: "CCTV16-HD", pid: "600098637", cnlid: "2027249101", type: "yangshi", vip: false },
  { name: "CCTV16(4K）", pid: "600099502", cnlid: "2027249301", type: "yangshi", vip: false },
  { name: "CCTV17", pid: "600001810", cnlid: "2027249401", type: "yangshi", vip: false },
  { name: "CCTV4K", pid: "600002264", cnlid: "2029810301", type: "yangshi", vip: false },
  { name: "CCTV8K", pid: "600156816", cnlid: "2026774101", type: "yangshi", vip: false },
  { name: "CGTN", pid: "600014550", cnlid: "2024181701", type: "yangshi", vip: false },
  { name: "CGTN法语频道", pid: "600084704", cnlid: "2024181801", type: "yangshi", vip: false },
  { name: "CGTN俄语频道", pid: "600084758", cnlid: "2024181901", type: "yangshi", vip: false },
  { name: "CGTN阿拉伯语频道", pid: "600084782", cnlid: "2024182001", type: "yangshi", vip: false },
  { name: "CGTN西班牙语频道", pid: "600084744", cnlid: "2024182101", type: "yangshi", vip: false },
  { name: "CGTN外语纪录频道", pid: "600084781", cnlid: "2024182301", type: "yangshi", vip: false },
  { name: "北京卫视", pid: "600002309", cnlid: "2024052703", type: "weishi", vip: false },
  { name: "江苏卫视", pid: "600002521", cnlid: "2024171103", type: "weishi", vip: false },
  { name: "东方卫视", pid: "600002483", cnlid: "2024054503", type: "weishi", vip: false },
  { name: "浙江卫视", pid: "600002520", cnlid: "2024054703", type: "weishi", vip: false },
  { name: "湖南卫视", pid: "600002475", cnlid: "2024054803", type: "weishi", vip: false },
  { name: "湖北卫视", pid: "600002508", cnlid: "2024171203", type: "weishi", vip: false },
  { name: "广东卫视", pid: "600002485", cnlid: "2024060903", type: "weishi", vip: false },
  { name: "广西卫视", pid: "600002509", cnlid: "2024060703", type: "weishi", vip: false },
  { name: "黑龙江卫视", pid: "600002498", cnlid: "2029797003", type: "weishi", vip: false },
  { name: "海南卫视", pid: "600002506", cnlid: "2024055603", type: "weishi", vip: false },
  { name: "重庆卫视", pid: "600002531", cnlid: "2024061103", type: "weishi", vip: false },
  { name: "深圳卫视", pid: "600002481", cnlid: "2024061303", type: "weishi", vip: false },
  { name: "四川卫视", pid: "600002516", cnlid: "2024061403", type: "weishi", vip: false },
  { name: "河南卫视", pid: "600002525", cnlid: "2029797303", type: "weishi", vip: false },
  { name: "福建东南卫视", pid: "600002484", cnlid: "2024061503", type: "weishi", vip: false },
  { name: "贵州卫视", pid: "600002490", cnlid: "2024061603", type: "weishi", vip: false },
  { name: "江西卫视", pid: "600002503", cnlid: "2024061703", type: "weishi", vip: false },
  { name: "辽宁卫视", pid: "600002505", cnlid: "2024171303", type: "weishi", vip: false },
  { name: "安徽卫视", pid: "600002532", cnlid: "2024171403", type: "weishi", vip: false },
  { name: "河北卫视", pid: "600002493", cnlid: "2024171503", type: "weishi", vip: false },
  { name: "山东卫视", pid: "600002513", cnlid: "2029787903", type: "weishi", vip: false },
  { name: "天津卫视", pid: "600152137", cnlid: "2019927003", type: "weishi", vip: false },
  { name: "吉林卫视", pid: "600190405", cnlid: "2025561503", type: "weishi", vip: false },
  { name: "陕西卫视", pid: "600190400", cnlid: "2029795103", type: "weishi", vip: false },
  { name: "甘肃卫视", pid: "600190408", cnlid: "2025561703", type: "weishi", vip: false },
  { name: "宁夏卫视", pid: "600190737", cnlid: "2025608503", type: "weishi", vip: false },
  { name: "内蒙古卫视", pid: "600190401", cnlid: "2025561203", type: "weishi", vip: false },
  { name: "云南卫视", pid: "600190402", cnlid: "2025561303", type: "weishi", vip: false },
  { name: "山西卫视", pid: "600190407", cnlid: "2025560803", type: "weishi", vip: false },
  { name: "青海卫视", pid: "600190406", cnlid: "2025559103", type: "weishi", vip: false },
  { name: "西藏卫视", pid: "600190403", cnlid: "2025558003", type: "weishi", vip: false },
  { name: "中国教育电视台1频道", pid: "600171827", cnlid: "2022823801", type: "weishi", vip: false },
  { name: "新疆卫视", pid: "600152138", cnlid: "2019927403", type: "weishi", vip: false },
];

// ==================== 日志 ====================
let log = () => {};

// ==================== 工具函数 ====================
const safeStr = (v) => (v == null ? "" : String(v).trim());
const chId = (ch) => `${ch.pid}_${ch.cnlid}`;

function md5(value) {
  return crypto.createHash("md5").update(value, "utf8").digest("hex");
}

function randText(n = 10) {
  const a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let r = "";
  for (let i = 0; i < n; i++) r += a[Math.floor(Math.random() * a.length)];
  return r;
}

function canonical(params) {
  return Object.keys(params).sort().map((k) => `${k}=${params[k]}`).join("&");
}

function sign(params, salt) {
  return md5(canonical(params) + salt);
}

function base36(value) {
  const a = "0123456789abcdefghijklmnopqrstuvwxyz";
  let r = "";
  if (value === 0) return "0";
  while (value > 0) { r = a[value % 36] + r; value = Math.floor(value / 36); }
  return r;
}

function ticket(pid, ts, guid) {
  const payload = Buffer.from(
    `${pid}&${ts}&${guid}&${CONFIG.yspAppId}&${CONFIG.ticketSuffix}`, "utf8"
  );
  const out = Buffer.alloc(payload.length);
  for (let i = 0; i < payload.length; i++) out[i] = payload[i] ^ TICKET_KEYSTREAM[i];
  return out.toString("hex");
}

function ckey(cnlid, ts, guid) {
  const raw = `|${cnlid}|${ts}|mg3c3b04ba|${CONFIG.appVersion}|${guid}|${CONFIG.platform}|https://www.yangshipin.c|mozilla/5.0 (windows nt ||Mozilla|Netscape|Win32|`;
  let val = 0;
  for (const c of raw) val = (val * 32 - val + c.charCodeAt(0)) >>> 0;
  if (val >= 0x80000000) val -= 0x100000000;
  const source = Buffer.from(`|${val}${raw}`, "utf8");
  const key = Buffer.from("48e5918a74ae21c972b90cce8af6c8be", "hex");
  const iv = Buffer.from("9a7e7d23610266b1d9fbf98581384d92", "hex");
  const cipher = crypto.createCipheriv("aes-128-cbc", key, iv);
  return "--01" + Buffer.concat([cipher.update(source), cipher.final()]).toString("hex").toUpperCase();
}

// ==================== WASM Keygen ====================
let wasmInstance = null, wasmMemory = null;
const wasmState = {}, wasmHeap = {};
let nextHandle = 132;

async function loadWasm() {
  if (wasmInstance) return wasmInstance;
  log("🔑", "下载 WASM keygen...");
  const resp = await _http.get(CONFIG.keygenUrl, {
    headers: { "User-Agent": CONFIG.ua },
    responseType: "arraybuffer",
    timeout: 15 * 1000,
    validateStatus: () => true,
  });
  if (resp.status !== 200) throw new Error(`WASM 下载失败: HTTP ${resp.status}`);
  const wasmBuf = Buffer.from(resp.data);
  if (wasmBuf.slice(0, 4).toString() !== "\0asm") throw new Error("无效 WASM");

  function getText(p, l) { return Buffer.from(wasmMemory.buffer, p, l).toString("utf8"); }

  const importObject = {
    wbg: {
      "__wbg_get_9c1840f7ecd81363": function (p, l) {
        const path = getText(p, l);
        const prefix = "cctvh5openapi.state.";
        let val = "";
        if (path.startsWith(prefix)) val = wasmState[path.substring(prefix.length)] || "";
        else if (path === "window.location.host") val = "www.yangshipin.cn";
        else if (path === "window.location.protocol") val = "https:";
        const h = nextHandle++; wasmHeap[h] = String(val); return h;
      },
      "__wbindgen_string_get": function (output, handle) {
        const payload = Buffer.from(wasmHeap[handle] || "", "utf8");
        const ptr = wasmInstance.exports.__wbindgen_malloc(payload.length, 1);
        const mem = Buffer.from(wasmMemory.buffer);
        payload.copy(mem, ptr);
        mem.writeInt32LE(ptr, output);
        mem.writeInt32LE(payload.length, output + 4);
      },
      "__wbindgen_object_drop_ref": function (h) { delete wasmHeap[h]; },
    },
  };

  const mod = await WebAssembly.instantiate(wasmBuf, importObject);
  wasmInstance = mod.instance;
  wasmMemory = wasmInstance.exports.memory;
  log("🔑", "WASM keygen 加载完成 ✅");
  return wasmInstance;
}

function wasmCall(name, state) {
  Object.assign(wasmState, state);
  const inst = wasmInstance;
  const out = inst.exports.__wbindgen_add_to_stack_pointer(-16);
  inst.exports[name](out);
  const mem = Buffer.from(wasmMemory.buffer);
  const ptr = mem.readInt32LE(out);
  const len = mem.readInt32LE(out + 4);
  const result = Buffer.from(wasmMemory.buffer, ptr, len).toString("utf8");
  if (ptr) inst.exports.__wbindgen_free(ptr, len, 1);
  inst.exports.__wbindgen_add_to_stack_pointer(16);
  return result;
}

// ==================== 播放解析 ====================
const playCache = new Map();

const resolveStream = async (pid, cnlid) => {
  pid = String(pid); cnlid = String(cnlid);
  if (!/^\d+$/.test(pid) || !/^\d+$/.test(cnlid)) throw new Error("无效频道ID");

  const cacheKey = `${pid}_${cnlid}`;
  const cached = playCache.get(cacheKey);
  if (cached && Date.now() < cached.expiry) return cached.url;

  await loadWasm();

  const guid = `${base36(Date.now())}_${randText(11)}`;
  const cookieStr = `guid=${guid}; versionName=99.99.99; versionCode=999999; vplatform=109; platformVersion=Chrome; deviceModel=148; newLogin=1; nseqId=1`;

  const commonHeaders = {
    Origin: CONFIG.host, Referer: CONFIG.host + "/", "User-Agent": CONFIG.ua,
    "sec-ch-ua": '"Chromium";v="148", "Not=A?Brand";v="24"',
    "sec-ch-ua-mobile": "?0", "sec-ch-ua-platform": '"Windows"',
    yspappid: CONFIG.yspAppId, Cookie: cookieStr,
  };

  // 1. Auth
  log("▶️", `[${pid}] Auth...`);
  const authParams = { pid, guid, appid: "ysp_pc", rand_str: randText() };
  authParams.signature = sign(authParams, CONFIG.authSalt);
  const authRes = await _http.post(CONFIG.playerUrl + "auth", new URLSearchParams(authParams).toString(), {
    headers: { ...commonHeaders, "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8" },
    validateStatus: () => true,
  });
  if (authRes.status !== 200) throw new Error(`Auth HTTP ${authRes.status}`);
  const authToken = authRes.data?.data?.token;
  const authTs = authRes.data?.data?.ts;
  if (!authToken) throw new Error(authRes.data?.msg || "auth 失败");
  log("▶️", `[${pid}] Auth OK`);

  // 2. SDK headers
  const ts = String(Math.floor(Date.now() / 1000 + 0.5));
  const params = {
    cnlid, livepid: pid, stream: "2", guid,
    cKey: ckey(cnlid, ts, guid),
    adjust: 1, sphttps: "1", platform: CONFIG.platform, cmd: "2",
    encryptVer: "8.1", dtype: "1", devid: "devid", otype: "ojson",
    appVer: CONFIG.appVersion, app_version: CONFIG.appVersion,
    channel: "ysp_tx", defn: "fhd",
  };

  const sdkInput = md5(canonical(params));
  const seqId = "1";
  const requestId = `999999${randText()}${Date.now()}`;
  const composite = `${sdkInput}-${guid}-${seqId}-${requestId}`;

  const state = {
    guid, token: "", yspappid: CONFIG.yspAppId, input: "",
    ts: String(Date.now()), version: "v1", query: "object",
  };

  const tokenRnd = wasmCall("get_token_rnd", state);
  const tokenRes = await _http.get(CONFIG.openTokenUrl, {
    params: { yspappid: CONFIG.yspAppId, guid, vappid: CONFIG.openVappId, vsecret: CONFIG.openVsecret, raw: 1, version: "v1", ts: state.ts, rnd: tokenRnd },
    headers: { "User-Agent": CONFIG.ua, Referer: CONFIG.host + "/" },
    validateStatus: () => true,
  });
  if (tokenRes.status !== 200) throw new Error(`OpenToken HTTP ${tokenRes.status}`);
  const openToken = tokenRes.data?.data?.token;
  if (!openToken) throw new Error(tokenRes.data?.msg || "open token 失败");

  state.token = openToken;
  state.input = composite;
  const sdkSig = wasmCall("get_signature", state) + "-" + composite;

  // 3. get_live_info
  log("▶️", `[${pid}] get_live_info...`);
  params.rand_str = randText();
  params.signature = sign(params, CONFIG.requestSalt);

  const liveRes = await _http.post(CONFIG.playerUrl + "get_live_info", params, {
    headers: {
      ...commonHeaders, "Content-Type": "application/json;charset=UTF-8",
      yspPlayerToken: String(authToken), yspticket: ticket(pid, String(authTs), guid),
      yspsdkinput: sdkInput, yspsdksign: sdkSig, seqId, "request-id": requestId,
      yspappid: CONFIG.yspAppId,
    },
    validateStatus: () => true,
  });

  if (liveRes.status !== 200) throw new Error(`Live HTTP ${liveRes.status}`);
  if (liveRes.data?.code !== 0) throw new Error(liveRes.data?.msg || "直播不可用");
  const liveData = liveRes.data?.data || {};
  if (liveData.iretcode && liveData.iretcode !== 0) throw new Error(liveData.errinfo || "频道不可用");

  const candidates = liveData.backurl_list || [];
  const locations = candidates.map((c) => c.url).filter(Boolean);
  locations.push(liveData.playurl);

  for (const loc of locations) {
    if (typeof loc === "string" && loc.startsWith("https://")) {
      log("✅", `[${pid}] 直播流:`, loc.substring(0, 60) + "...");
      playCache.set(cacheKey, { url: loc, expiry: Date.now() + CONFIG.playCacheSeconds * 1000 });
      return loc;
    }
  }
  throw new Error("未获取到直播流");
};

// ==================== 路由注册 ====================
const meta = {
  key: CONFIG.key,
  name: CONFIG.name,
  type: 4,
  api: CONFIG.api,
  searchable: 0,
  quickSearch: 0,
  filterable: 0,
  changeable: 0,
};

module.exports = async (app, opt) => {
  const fastifyLog = app?.log?.info?.bind(app?.log);
  log = CONFIG.debug
    ? (...args) => {
        const msg = args.map((a) => (typeof a === "object" ? JSON.stringify(a) : String(a))).join(" ");
        (fastifyLog || console.log)(`[央視頻] ${msg}`);
      }
    : () => {};

  app.get(meta.api, async (req, res) => {
    const { ac, t, ids, play, filter } = req.query;
    try {
      // 播放：解析直播流地址
      if (play) {
        // play 格式: pid_cnlid
        const parts = safeStr(play).split("_");
        const pid = parts[0] || "";
        const cnlid = parts[1] || "";
        const url = await resolveStream(pid, cnlid);
        res.send({ parse: 0, jx: 0, playUrl: "", url, header: { "User-Agent": CONFIG.ua, "Referer": CONFIG.host + "/" } });
        return;
      }

      // 首页：分类 + 频道列表
      if (!ac) {
        const list = CHANNELS.map((ch) => ({
          vod_id: chId(ch),
          vod_name: ch.name,
          vod_pic: LOGO_MAP[ch.name] || "",
          vod_remarks: "直播",
        }));
        res.send({
          class: [
            { type_id: "yangshi", type_name: "央视频道" },
            { type_id: "weishi", type_name: "卫视频道" },
          ],
          list: String(filter) === "false" ? list : [],
        });
        return;
      }

      // 分类：按频道组筛选
      if (ac === "detail") {
        if (t) {
          const filtered = (t === "yangshi" || t === "weishi")
            ? CHANNELS.filter((ch) => ch.type === t)
            : CHANNELS;
          const list = filtered.map((ch) => ({
            vod_id: chId(ch),
            vod_name: ch.name,
            vod_pic: LOGO_MAP[ch.name] || "",
            vod_remarks: "直播",
          }));
          res.send({ list, page: 1, pagecount: 1, limit: list.length, total: list.length });
          return;
        }
        // 详情：频道 + 播放地址
        if (ids) {
          const id = String(ids).split(",")[0].trim();
          const ch = CHANNELS.find((c) => chId(c) === id) || CHANNELS[0];
          res.send({
            list: [{
              vod_id: chId(ch),
              vod_name: ch.name,
              vod_pic: LOGO_MAP[ch.name] || "",
              vod_remarks: "直播",
              vod_content: "央视频直播源",
              vod_play_from: "央视频",
              vod_play_url: `${ch.name}$${chId(ch)}`,
            }],
          });
          return;
        }
      }

      res.send(req.query);
    } catch (e) {
      log("❌", "错误", e.message);
      res.status(500).send({ code: 500, msg: e.message });
    }
  });

  opt.sites.push(meta);
  log("🚀", meta.name, "加载完成");
};
