"use strict"; module.exports = require("./appv7-client").createRoute({ key: "appv7xiaoyouzi", name: "[影]柚子秒播", configKey: "AppV7Xyz" });
