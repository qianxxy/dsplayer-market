const axios = require("axios");
const http = require("http");
const https = require("https");
const cheerio = require("cheerio");
const crypto = require("crypto");

const _http = axios.create({
    timeout: 15 * 1000,
    proxy: false,
    validateStatus: () => true,
    httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
    httpAgent: new http.Agent({ keepAlive: true }),
});

const config = {
    host: 'http://www.viptv01.com',
    verifyApi: (process.env.TVB_VERIFY_API || process.env.DDDDOCR_API || 'http://192.168.50.210:28000').replace(/\/$/, ''),
    headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    }
};

const store = { init: false, log: null, cookie: "" };

function md5(text) {
    return crypto.createHash("md5").update(String(text || ""), "utf8").digest("hex");
}

function stringtoHex(acSTR) {
    let val = "";
    for (let i = 0; i <= acSTR.length - 1; i++) val += parseInt(acSTR.charCodeAt(i)) + 1;
    return val;
}

function mergeCookie(oldCookie, setCookie) {
    const jar = {};
    String(oldCookie || "").split(";").map(s => s.trim()).filter(Boolean).forEach(kv => {
        const p = kv.indexOf("=");
        if (p > 0) jar[kv.slice(0, p)] = kv.slice(p + 1);
    });
    const arr = Array.isArray(setCookie) ? setCookie : (setCookie ? [setCookie] : []);
    arr.forEach(c => {
        const first = String(c).split(";")[0];
        const p = first.indexOf("=");
        if (p > 0) jar[first.slice(0, p)] = first.slice(p + 1);
    });
    return Object.entries(jar).map(([k, v]) => `${k}=${v}`).join("; ");
}

function isVerifyPage(html) {
    const text = String(html || "");
    return text.includes("滑动验证") || text.includes("huadong_") || text.includes("yanzheng_huadong.php");
}

async function requestWithVerify(url, options = {}, retry = true) {
    const headers = { ...config.headers, ...(options.headers || {}) };
    if (store.cookie) headers.Cookie = store.cookie;
    let res = await _http.get(url, { ...options, headers });
    store.cookie = mergeCookie(store.cookie, res.headers?.["set-cookie"]);

    if (retry && (res.status === 403 || isVerifyPage(res.data))) {
        const ok = await passSliderVerify(res.data);
        if (ok) {
            const retryHeaders = { ...headers, Cookie: store.cookie };
            res = await _http.get(url, { ...options, headers: retryHeaders });
            store.cookie = mergeCookie(store.cookie, res.headers?.["set-cookie"]);
        }
    }
    return res;
}

async function tryExternalVerify(pageHtml) {
    // 预留给 28000 这类本地过验证服务：若服务提供 cookie/headers，可直接接入。
    // 当前主逻辑会优先本地计算站点滑块签名，不依赖图片 OCR。
    if (!config.verifyApi) return false;
    try {
        const res = await _http.post(`${config.verifyApi}/verify`, {
            url: config.host,
            html: String(pageHtml || ""),
            cookie: store.cookie,
            type: "tvb_huadong"
        }, { headers: { "Content-Type": "application/json", ...config.headers }, timeout: 8000 });
        const data = typeof res.data === "object" ? res.data : {};
        const cookie = data.cookie || data.cookies || data.data?.cookie || data.data?.cookies;
        if (cookie) {
            store.cookie = mergeCookie(store.cookie, String(cookie).split(/;\s*/).map(x => x));
            return true;
        }
    } catch (_) {}
    return false;
}

async function passSliderVerify(html) {
    try {
        if (await tryExternalVerify(html)) return true;

        const scriptPath = (String(html || "").match(/src=["']([^"']*huadong_[^"']+\.js\?id=\d+)["']/i) || [])[1];
        if (!scriptPath) return false;
        const scriptUrl = scriptPath.startsWith("http") ? scriptPath : `${config.host}${scriptPath}`;
        const jsRes = await _http.get(scriptUrl, { headers: { ...config.headers, Cookie: store.cookie, Referer: config.host + "/" } });
        store.cookie = mergeCookie(store.cookie, jsRes.headers?.["set-cookie"]);
        const js = String(jsRes.data || "");
        const key = (js.match(/key\s*=\s*["']([^"']+)["']/) || [])[1];
        const value = (js.match(/value\s*=\s*["']([^"']+)["']/) || [])[1];
        const verifyPath = (js.match(/c\.get\(["']([^"']*yanzheng_huadong\.php\?[^"']*)["']\s*\+/) || [])[1]
            || (js.match(/([\w_\/.-]*yanzheng_huadong\.php\?type=[^"']+)&key=/) || [])[1];
        if (!key || !value || !verifyPath) return false;

        const verifyUrl = verifyPath.includes("&key=")
            ? `${config.host}${verifyPath}${encodeURIComponent(key)}&value=${md5(stringtoHex(value))}`
            : `${config.host}${verifyPath}&key=${encodeURIComponent(key)}&value=${md5(stringtoHex(value))}`;
        const verifyRes = await _http.get(verifyUrl, { headers: { ...config.headers, Cookie: store.cookie, Referer: config.host + "/" } });
        store.cookie = mergeCookie(store.cookie, verifyRes.headers?.["set-cookie"]);
        store.log?.info?.(`[TVB云播] 滑块验证完成 status=${verifyRes.status}`);
        return verifyRes.status >= 200 && verifyRes.status < 400;
    } catch (e) {
        store.log?.warn?.(`[TVB云播] 滑块验证失败: ${e.message}`);
        return false;
    }
}

const getClasses = () => {
    return [
        { type_id: "1", type_name: "电影" },
        { type_id: "2", type_name: "电视剧" },
        { type_id: "3", type_name: "综艺" },
        { type_id: "4", type_name: "动漫" },
        { type_id: "16", type_name: "日韩剧" },
        { type_id: "13", type_name: "国产剧" },
        { type_id: "15", type_name: "欧美剧" },
        { type_id: "14", type_name: "港台剧" }
    ];
};

const getCategoryList = async (tid, pg = 1) => {
    try {
        const url = `${config.host}/vod/show/id/${tid}/page/${pg}.html`;
        const response = await requestWithVerify(url);
        const $ = cheerio.load(response.data);
        const list = [];

        $('.myui-vodlist__box').each((_, element) => {
            const $el = $(element);
            const $a = $el.find('a.myui-vodlist__thumb');
            const href = $a.attr('href');
            const title = $a.attr('title') || $a.attr('alt') || $el.text().trim();
            if (!href || !title) return;
            list.push({
                vod_id: href,
                vod_name: title,
                vod_pic: $a.attr('data-original') || $a.attr('data-src') || $a.attr('src'),
                vod_remarks: $el.find('.tag,.pic-text,.text-right').first().text().trim()
            });
        });

        return { list, page: Number(pg) || 1, pagecount: list.length ? 999 : 0, limit: 20 };
    } catch (error) {
        store.log?.warn?.(`[TVB云播] 分类失败: ${error.message}`);
        return { list: [], page: pg, pagecount: 0 };
    }
};

const getDetail = async (id) => {
    try {
        const url = id.startsWith('http') ? id : config.host + id;
        const response = await requestWithVerify(url);
        const $ = cheerio.load(response.data);

        const vod = {
            vod_id: id,
            vod_name: $('h1.title').text().trim() || $('h1').first().text().trim(),
            vod_pic: $('.lazyload').attr('data-original') || $('.lazyload').attr('data-src') || $('.lazyload').attr('src'),
            vod_type: $('.data:eq(0) a:eq(1)').text(),
            vod_year: $('.data:eq(0) a:eq(2)').text(),
            vod_area: $('.data:eq(0) a:eq(0)').text(),
            vod_content: $(".text-collapse span,.content,.desc").first().text().trim(),
            vod_play_from: [],
            vod_play_url: []
        };

        $('.myui-panel__head h3').each((i, el) => {
            const from = $(el).text().trim() || `线路${i + 1}`;
            if (/热门资讯|热播|猜你喜欢/.test(from)) return;
            const urls = [];
            $(`.myui-content__list:eq(${i}) li a`).each((_, a) => {
                const name = $(a).text().trim();
                const href = $(a).attr('href');
                if (name && href) urls.push(name + "$" + href);
            });
            if (urls.length) {
                vod.vod_play_from.push(from.replace(/播放列表/g, '').trim() || `线路${i + 1}`);
                vod.vod_play_url.push(urls.join('#'));
            }
        });

        vod.vod_play_from = vod.vod_play_from.join('$$$');
        vod.vod_play_url = vod.vod_play_url.join('$$$');

        return vod;
    } catch (error) {
        store.log?.warn?.(`[TVB云播] 详情失败: ${error.message}`);
        return null;
    }
};

const getPlayUrl = async (id) => {
    try {
        const url = id.startsWith('http') ? id : config.host + id;
        const response = await requestWithVerify(url);
        const playerMatch = String(response.data || '').match(/var\s+player_\w+\s*=\s*(\{.*?\})\s*</s)
            || String(response.data || '').match(/player_.*?=\s*(\{.*?\})\s*</s);
        if (playerMatch) {
            let playerDate = JSON.parse(playerMatch[1]);
            let playUrl = playerDate.url;

            if (playerDate.encrypt == '1') {
                playUrl = unescape(playUrl);
            } else if (playerDate.encrypt == '2') {
                playUrl = unescape(Buffer.from(playUrl, 'base64').toString());
            }

            return { parse: 0, url: playUrl, header: config.headers };
        }
        return { parse: 1, url };
    } catch (error) {
        store.log?.warn?.(`[TVB云播] 播放失败: ${error.message}`);
        return { parse: 1, url: id };
    }
};

const search = async (wd, pg = 1) => {
    try {
        const url = `${config.host}/vod/search/page/${pg}/wd/${encodeURIComponent(wd)}.html`;
        const response = await requestWithVerify(url);
        const $ = cheerio.load(response.data);
        const list = [];
        $('.myui-vodlist__box,.myui-vodlist__media').each((_, element) => {
            const $el = $(element);
            const $a = $el.find('a[href*="/vod/detail/"]').first().length ? $el.find('a[href*="/vod/detail/"]').first() : $el.find('a').first();
            const href = $a.attr('href');
            const title = $a.attr('title') || $el.find('.title').text().trim() || $a.text().trim();
            if (!href || !title) return;
            list.push({
                vod_id: href,
                vod_name: title,
                vod_pic: $a.attr('data-original') || $el.find('img').attr('data-original') || $el.find('img').attr('src'),
                vod_remarks: $el.find('.tag,.pic-text,.text-muted').first().text().trim()
            });
        });
        return { list, page: Number(pg) || 1, pagecount: list.length ? 999 : 0 };
    } catch (e) {
        store.log?.warn?.(`[TVB云播] 搜索失败: ${e.message}`);
        return { list: [], page: pg, pagecount: 0 };
    }
};

const handleT4Request = async (req) => {
    const { ac, t, ids, play, pg, wd } = req.query;

    if (play) return await getPlayUrl(play);
    if (ids) {
        const detail = await getDetail(ids);
        return { list: detail ? [detail] : [] };
    }
    if (wd || ac === 'search') return await search(wd || '', pg || 1);
    if (t) return await getCategoryList(t, pg || 1);
    if (!ac || ac === 'class') return { class: getClasses() };

    return { list: [] };
};

const meta = {
    key: "tvb_yunbao",
    name: "[纯]TVB云播",
    type: 4,
    api: "/video/tvb_yunbao",
    searchable: 1,
    quickSearch: 0,
    filterable: 0
};

module.exports = async (app, opt) => {
    app.get(meta.api, async (req, reply) => {
        if (!store.init) {
            store.log = req.server.log;
            store.init = true;
        }
        try {
            return await handleT4Request(req);
        } catch (error) {
            store.log?.error?.(`[TVB云播] 请求失败: ${error.message}`);
            return { error: 'Internal Server Error' };
        }
    });
    opt.sites.push(meta);
};
