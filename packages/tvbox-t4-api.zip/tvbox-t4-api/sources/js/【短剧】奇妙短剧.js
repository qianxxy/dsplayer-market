"use strict";

const axios = require("axios");
const crypto = require("node:crypto");

const CONFIG_URL = "https://neptune.qmplaylet.com/playlet-domain-android.json";
const SIGN_KEY = "d3dGiJc651gSQ8w1";
let siteUrl = "";
let playUrl = "";

const meta = { key: "duanjuqimiao", name: "[短]奇妙短剧", type: 4, api: "/video/duanjuqimiao", searchable: 1, quickSearch: 1, filterable: 1, changeable: 0 };

function md5(v) { return crypto.createHash("md5").update(`${v}${SIGN_KEY}`, "utf8").digest("hex"); }
function pageNo(v) { const n = Number.parseInt(v, 10); return Number.isFinite(n) && n > 0 ? n : 1; }
function decodeExt(ext) { if (!ext) return {}; try { return JSON.parse(Buffer.from(String(ext), "base64").toString("utf8")) || {}; } catch { return {}; } }
function query(obj) { return new URLSearchParams(obj).toString(); }
function signedParams(obj) { const out = { ...obj }; out.sign = md5(Object.keys(out).sort().map((k) => `${k}=${out[k] ?? ""}`).join("")); return out; }

function qmParams() {
  const data = { static_score: "0.8", uuid: "00000000-6f7c-e347-0000-000000000000", "device-id": "202504012213236fa2ed536aed584e0cc8a6a09fe2f2d4016cdc5bc74f2d5f", mac: "", sourceuid: "9494817a02a93435", "refresh-type": "0", model: "M2012K10C", "wlb-imei": "", "client-id": "6bcc46919d10d06a", brand: "Redmi", oaid: "", "oaid-no-cache": "", "sys-ver": "11", "trusted-id": "", "phone-level": "H", imei: "", "wlb-uid": "6bcc46919d10d06a", "session-id": String(Date.now()) };
  const mapNum = ["M", "U", "l", "E", "r", "Y", "W", "b", "d", "J"];
  const mapUpper = "9saI0oy_HGitgNA8Fk3hfRqC4p";
  const mapLower = "mBOuc6Kx5T-2zSZ1VvjQ7DwnLe";
  let out = "";
  for (const ch of Buffer.from(JSON.stringify(data), "utf8").toString("base64")) {
    const n = ch.charCodeAt(0);
    out += n === 43 ? "P" : n === 47 ? "X" : n >= 48 && n <= 57 ? mapNum[n - 48] : n >= 65 && n <= 90 ? mapUpper[n - 65] : n >= 97 && n <= 122 ? mapLower[n - 97] : ch;
  }
  return out;
}

function headers() {
  const qm = qmParams();
  return { authorization: "", reg: "", "is-white": "", "user-agent": "webviewversion/0", "net-env": "1", channel: "va-vivo_lf", platform: "android", "application-id": "com.duoduo.read", "app-version": "10001", "qm-params": qm, "no-permiss": "3", sign: md5(`AUTHORIZATION=app-version=10001application-id=com.duoduo.readchannel=va-vivo_lfis-white=net-env=1platform=androidqm-params=${qm}reg=`) };
}

async function get(url, customHeaders = headers()) { const res = await axios.get(url, { headers: customHeaders, timeout: 15000, responseType: "json" }); return res.data || {}; }
async function init() { if (siteUrl && playUrl) return; const data = await get(CONFIG_URL, headers()); siteUrl = data.data && data.data.bc || ""; playUrl = data.data && data.data.ks || ""; if (!siteUrl || !playUrl) throw new Error("奇妙域名初始化失败"); }

function cleanName(v) { return String(v || "").replace(/<[^>]*>/g, "").trim(); }
function cards(rows) { return (rows || []).map((v) => ({ vod_id: String(v.playlet_id || v.id || ""), vod_name: cleanName(v.title), vod_pic: String(v.image_link || ""), vod_remarks: v.total_episode_num ? `${v.total_episode_num}集` : String(v.total_num || "") })).filter((v) => v.vod_id && v.vod_name); }

async function home() {
  await init();
  const data = await get(`${siteUrl}/api/v1/playlet/index?${query(signedParams({ tag_id: "0", playlet_privacy: "1", operation: "1" }))}`);
  const classes = (data.data && data.data.tag_items || []).map((v) => ({ type_id: String(v.tag_id || ""), type_name: String(v.tag_name || "") })).filter((v) => v.type_id && v.type_name);
  return { class: classes, filters: {} };
}

async function category(id, pg, ext) {
  await init();
  const page = pageNo(pg);
  const params = signedParams({ tag_id: ext.cateId || id || "0", playlet_privacy: "1", operation: "1", next_id: String(page) });
  const data = await get(`${siteUrl}/api/v1/playlet/index?${query(params)}`);
  const list = cards(data.data && data.data.list || []);
  return { page, pagecount: list.length >= 96 ? page + 1 : page, limit: 96, total: 0, list };
}

async function detail(id) {
  await init();
  const data = await get(`${playUrl}/player/api/v1/playlet/info?${query(signedParams({ playlet_id: id }))}`);
  const v = data.data || {};
  const urls = (v.play_list || []).filter((e) => e.video_url).map((e) => `${e.sort}$${e.video_url}`);
  return { list: [{ vod_id: id, vod_name: String(v.title || ""), vod_pic: String(v.image_link || ""), vod_content: String(v.intro || ""), vod_play_from: "奇妙", vod_play_url: urls.join("#") }] };
}

async function search(wd, pg) {
  await init();
  const page = pageNo(pg);
  const params = signedParams({ extend: "", page: String(page), wd: String(wd || "").trim(), read_preference: "0", track_id: `6bcc46919d10d06a${Date.now()}` });
  const data = await get(`${siteUrl}/api/v1/playlet/search?${query(params)}`);
  return { page, list: cards(data.data && data.data.list || []) };
}

module.exports = async (app, opt) => {
  app.get(meta.api, async (req) => {
    const q = req.query || {};
    try {
      if (q.play) return { parse: 0, url: String(q.play), header: { "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 11; M2012K10C Build/RP1A.200720.011)" }, extra: { nodanmu: true } };
      if (q.wd) return await search(q.wd, q.pg);
      if (q.ids) return await detail(String(q.ids));
      if (q.t) return await category(String(q.t), q.pg, decodeExt(q.ext));
      return await home();
    } catch (e) { app.log && app.log.error && app.log.error(`[奇妙短剧] ${e.message || e}`); return { list: [] }; }
  });
  opt.sites.push(meta);
};
