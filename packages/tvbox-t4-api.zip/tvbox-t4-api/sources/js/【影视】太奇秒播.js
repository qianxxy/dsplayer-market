"use strict"; module.exports = require("./appv7-client").createRoute({ key: "appv7mengtaiqi", name: "[影]太奇秒播", configKey: "AppV7Mtq" });
