const axios = require('axios')
const http = require('http')
const https = require('https')
const cheerio = require('cheerio')
const crypto = require('crypto')

const HOST = 'https://www.rebozj.art'
const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148'
const LIMIT = 24
const PAN_KEYS = ['quark', 'uc', 'baidu', 'aliyun', 'xunlei', 'tianyi', '115', '123']
const driveCache = new Map()

const meta = {
  key: 'rebozj',
  name: '[纯]热播之家',
  type: 4,
  api: '/video/rebozj',
  searchable: 1,
  quickSearch: 1,
  filterable: 1,
  changeable: 0,
}

const classes = [
  { type_id: '1', type_name: '电影' },
  { type_id: '2', type_name: '电视剧' },
  { type_id: '3', type_name: '纪录片' },
  { type_id: '4', type_name: '动漫' },
  { type_id: '5', type_name: '综艺' },
  { type_id: '6', type_name: '动作' },
  { type_id: '7', type_name: '喜剧' },
  { type_id: '8', type_name: '爱情' },
  { type_id: '9', type_name: '科幻' },
  { type_id: '10', type_name: '恐怖' },
  { type_id: '11', type_name: '剧情' },
  { type_id: '12', type_name: '战争' },
  { type_id: '13', type_name: '国产剧' },
  { type_id: '14', type_name: '港台剧' },
  { type_id: '15', type_name: '日韩剧' },
  { type_id: '16', type_name: '海外剧' },
  { type_id: '24', type_name: '国产动漫' },
  { type_id: '25', type_name: '日韩动漫' },
  { type_id: '26', type_name: '港台动漫' },
  { type_id: '27', type_name: '欧美动漫' },
  { type_id: '17', type_name: '大陆综艺' },
  { type_id: '18', type_name: '港台综艺' },
  { type_id: '20', type_name: '日韩综艺' },
  { type_id: '21', type_name: '欧美综艺' },
]

const filters = Object.fromEntries(classes.map((c) => [c.type_id, []]))

const httpClient = axios.create({
  timeout: 15000,
  httpAgent: new http.Agent({ keepAlive: true }),
  httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
  headers: { 'User-Agent': UA, Referer: `${HOST}/`, Origin: HOST },
})

const cleanText = (s = '') => String(s).replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim()
const absUrl = (u = '') => !u ? '' : /^https?:\/\//i.test(u) ? u : new URL(u, HOST).toString()
const safePage = (page) => Math.max(1, parseInt(page || '1', 10) || 1)
const decodeExt = (ext) => {
  if (!ext) return {}
  try { return JSON.parse(Buffer.from(String(ext), 'base64').toString('utf8')) || {} } catch (_) {}
  try { return JSON.parse(String(ext)) || {} } catch (_) { return {} }
}

async function fetchHtml(url, options = {}) {
  const { data } = await httpClient.request({ url: absUrl(url), method: 'GET', ...options })
  return String(data || '')
}

function parseList($, root) {
  const list = []
  $(root || '.stui-vodlist__box').each((_, el) => {
    const box = $(el)
    const thumb = box.is('a[href]') ? box : box.find('a.stui-vodlist__thumb[href],a[href*="/detail/"]').first()
    const href = thumb.attr('href') || ''
    const name = cleanText(thumb.attr('title') || thumb.find('img').attr('alt') || box.find('.title a,h4 a,a[href*="/detail/"]').first().text())
    if (!href || !name || !/\/detail\//.test(href)) return
    const pic = thumb.attr('data-original') || thumb.attr('data-src') || thumb.find('img').attr('data-original') || thumb.find('img').attr('data-src') || thumb.find('img').attr('src') || box.find('img').attr('data-original') || box.find('img').attr('src') || ''
    const remarks = cleanText(box.find('.pic-text,.score,.text-right,.remarks').first().text())
    list.push({
      vod_id: absUrl(href),
      vod_name: name,
      vod_pic: absUrl(pic),
      vod_remarks: remarks,
    })
  })
  const seen = new Set()
  return list.filter((item) => {
    if (seen.has(item.vod_id)) return false
    seen.add(item.vod_id)
    return true
  })
}

function fieldFromText(text, label) {
  const re = new RegExp(`${label}[:：]\\s*([^\\n/]+)`, 'i')
  const m = cleanText(text).match(re)
  return m ? cleanText(m[1]) : ''
}

function panTypeFromFlag(flag = '') {
  const s = String(flag).toLowerCase()
  if (s.includes('quark') || s.includes('夸克')) return 'quark'
  if (s.includes('baidu') || s.includes('百度')) return 'baidu'
  if (s.includes('uc')) return 'uc'
  if (s.includes('ali') || s.includes('阿里')) return 'aliyun'
  if (s.includes('xunlei') || s.includes('迅雷')) return 'xunlei'
  if (s.includes('tianyi') || s.includes('189') || s.includes('天翼')) return 'tianyi'
  if (s.includes('115')) return '115'
  if (s.includes('123')) return '123'
  return s || 'pan'
}

function isPanUrl(url = '') {
  return /pan\.|quark|baidu|aliyun|xunlei|uc\.cn|115|123pan/i.test(String(url || ''))
}

function isPanFlag(flag = '') {
  return /(网盘|夸克|quark|百度|baidu|uc|阿里|aliyun|迅雷|xunlei|天翼|tianyi|115|123)/i.test(String(flag || ''))
}

function cacheDriveLine({ vodId, flag, lineUrl, driveIndex }) {
  const f = String(flag || '')
  if (vodId || f) driveCache.set(`${vodId || ''}@@${f}`, driveIndex)
  for (const part of String(lineUrl || '').split('#')) {
    const playId = part.includes('$') ? part.substring(part.indexOf('$') + 1) : part
    if (playId) driveCache.set(playId, driveIndex)
  }
}

function collectDrives(req, opt) {
  const candidates = [req?.server?.drives, opt?.server?.drives, opt?.drives, opt?.app?.drives]
  for (const item of candidates) {
    if (Array.isArray(item) && item.length) return item
  }
  return []
}

async function resolvePanLine({ drives, shareUrl, title, flag, vodId }) {
  const content = `${title || ''}
${shareUrl}`.trim()
  for (let i = 0; i < drives.length; i++) {
    const d = drives[i]
    try {
      if (typeof d?.matchShare === 'function' && !d.matchShare(content) && !d.matchShare(shareUrl)) continue
      if (typeof d?.getVod !== 'function') continue
      const vod = await d.getVod(content) || await d.getVod(shareUrl)
      if (!vod?.vod_play_url) continue
      const urls = String(vod.vod_play_url).split('$$$').filter(Boolean)
      if (!urls.length) continue
      const froms = String(vod.vod_play_from || '').split('$$$').filter(Boolean)
      const flags = urls.map((_, idx) => froms[idx] || flag || panTypeFromFlag(flag))
      urls.forEach((lineUrl, idx) => cacheDriveLine({ vodId, flag: flags[idx], lineUrl, driveIndex: i }))
      driveCache.set(`${vodId || shareUrl}@@${panTypeFromFlag(flag)}@@${shareUrl}`, i)
      return { flags, urls, driveIndex: i }
    } catch (_) {}
  }
  return { flags: [flag || panTypeFromFlag(flag)], urls: [`网盘链接$${shareUrl}`] }
}


async function homeContent() {
  const html = await fetchHtml('/')
  const $ = cheerio.load(html)
  const list = parseList($).slice(0, LIMIT)
  return { class: classes, filters, list, page: 1, pagecount: 1, limit: LIMIT, total: list.length }
}

async function categoryContent({ id, page }) {
  const pg = safePage(page)
  const url = pg > 1 ? `/show/${id || '1'}--------${pg}---.html` : `/show/${id || '1'}-----------.html`
  const html = await fetchHtml(url)
  const $ = cheerio.load(html)
  const list = parseList($)
  return { list, page: pg, pagecount: list.length >= 12 ? pg + 1 : pg, limit: LIMIT, total: 0 }
}

async function searchContent({ wd, page, quick }) {
  const pg = safePage(page)
  const kw = encodeURIComponent(String(wd || '').trim())
  const url = pg > 1 ? `/search/${kw}----------${pg}---.html` : `/search/${kw}-------------.html`
  const html = await fetchHtml(url)
  const $ = cheerio.load(html)
  const list = parseList($).slice(0, quick ? 10 : LIMIT)
  return { list, page: pg, pagecount: list.length >= 12 ? pg + 1 : pg, limit: LIMIT, total: 0 }
}


function decodePlayerUrl(player = {}) {
  let url = String(player.url || '')
  try {
    if (String(player.encrypt) === '1') return decodeURIComponent(unescape(url))
    if (String(player.encrypt) === '2') return decodeURIComponent(unescape(Buffer.from(url, 'base64').toString('binary')))
  } catch (_) {}
  return url
}

function extractArtConstants(html) {
  const pick = (name) => {
    const m = String(html).match(new RegExp(`const\\s+${name}\\s*=\\s*"([^"]*)"`))
    return m ? m[1] : ''
  }
  return {
    playPageUrl: pick('playPageUrl'),
    secretKeySeed: pick('secretKeySeed'),
  }
}

async function tryResolveArtPlayer(player, referer) {
  const playUrl = decodePlayerUrl(player)
  if (!playUrl || isPanUrl(playUrl)) return ''
  const from = String(player.from || '')
  const playerPath = from === '1080zyk' ? '/m3u8/f-player/' : '/static/player/artplayer/'
  const artUrl = `${HOST}${playerPath}?url=${encodeURIComponent(playUrl)}&next=${player.link_next ? encodeURIComponent(absUrl(player.link_next)) : ''}`
  try {
    const html = await fetchHtml(artUrl, { headers: { Referer: referer || `${HOST}/`, 'User-Agent': UA } })
    const c = extractArtConstants(html)
    if (!c.playPageUrl || !c.secretKeySeed) return ''
    const t = Math.floor(Date.now() / 1000)
    const params = { vkey: c.playPageUrl, code: c.secretKeySeed, t, signature: crypto.createHash('md5').update(String(t)).digest('hex') }
    const apiCandidates = ['/api.php', '/api/player.php', '/static/player/artplayer/api.php', '/static/player/api.php']
    for (const api of apiCandidates) {
      try {
        const { data } = await httpClient.post(`${HOST}${api}`, params, {
          headers: {
            'User-Agent': UA,
            Referer: artUrl,
            Origin: HOST,
            'Content-Type': 'application/json',
            Accept: 'application/json, text/plain, */*',
          },
          timeout: 10000,
        })
        const obj = typeof data === 'string' ? JSON.parse(data) : data
        const retUrl = obj?.url || obj?.data?.url || obj?.playUrl || obj?.m3u8
        if (retUrl) return decodePlayerUrl({ url: String(retUrl), encrypt: obj?.encrypt || 0 })
      } catch (_) {}
    }
  } catch (_) {}
  return ''
}

function extractPlayerJson(html) {
  const m = String(html).match(/var\s+player_\w+\s*=\s*(\{[\s\S]*?\})\s*<\/script>/)
  if (!m) return null
  try { return JSON.parse(m[1]) } catch (_) { return null }
}

async function mapLimit(items, limit, worker) {
  const ret = new Array(items.length)
  let next = 0
  const runners = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (next < items.length) {
      const i = next++
      ret[i] = await worker(items[i], i)
    }
  })
  await Promise.all(runners)
  return ret
}

async function detailContent({ ids, drives }) {
  const html = await fetchHtml(ids)
  const $ = cheerio.load(html)
  const detail = $('.stui-content__detail').first()
  const allText = cleanText(detail.text())
  const title = cleanText(detail.find('h1').first().text() || $('h1').first().text() || $('title').text().split('-')[0])
  const pic = absUrl($('.stui-content__thumb img').attr('data-original') || $('.stui-content__thumb img').attr('data-src') || $('.stui-content__thumb img').attr('src') || $('img.lazyload').first().attr('data-original') || '')
  const vod = {
    vod_id: ids,
    vod_name: title,
    vod_pic: pic,
    vod_remarks: cleanText(detail.find('.pic-text,.data').first().text()) || fieldFromText(allText, '豆瓣评分'),
    type_name: fieldFromText(allText, '类型'),
    vod_year: fieldFromText(allText, '年份'),
    vod_area: fieldFromText(allText, '地区'),
    vod_actor: fieldFromText(allText, '主演'),
    vod_director: fieldFromText(allText, '导演'),
    vod_content: cleanText($('.detail').first().text().replace(/^简介[:：]?/, '')) || fieldFromText(allText, '简介'),
  }

  const playFrom = []
  const playUrl = []
  const panes = $('div.tab-pane[id^="playlist"]').toArray()
  for (let idx = 0; idx < panes.length; idx++) {
    const pane = $(panes[idx])
    const pid = pane.attr('id')
    const nav = $(`a[href="#${pid}"]`).first()
    const flagName = cleanText(nav.text()) || `线路${idx + 1}`
    const type = panTypeFromFlag(flagName)
    const links = pane.find('a[href*="/play/"]').toArray()
    const isPanLine = PAN_KEYS.includes(type) || isPanFlag(flagName)

    if (!isPanLine) {
      const episodes = links.map((a, i) => {
        const epName = cleanText($(a).text()) || `第${i + 1}集`
        return `${epName}$${absUrl($(a).attr('href'))}`
      }).filter(Boolean)
      if (episodes.length) {
        playFrom.push(flagName)
        playUrl.push(episodes.join('#'))
      }
      continue
    }

    const panResults = await mapLimit(links, 4, async (a, i) => {
      const epName = cleanText($(a).text()) || `第${i + 1}集`
      const playPage = absUrl($(a).attr('href'))
      try {
        const ph = await fetchHtml(playPage)
        const player = extractPlayerJson(ph)
        const realUrl = player?.url ? String(player.url) : ''
        if (realUrl) {
          const resolved = await resolvePanLine({ drives, shareUrl: realUrl, title, flag: flagName, vodId: ids })
          if (resolved?.urls?.length && !resolved.urls[0].startsWith('网盘链接$')) {
            return { resolved }
          }
          return { episode: `${epName}$${realUrl}` }
        }
      } catch (_) {}
      return { episode: `${epName}$${playPage}` }
    })

    const episodes = []
    for (const item of panResults) {
      if (item?.resolved) {
        item.resolved.urls.forEach((lineUrl, lineIdx) => {
          playFrom.push(item.resolved.flags?.[lineIdx] || flagName)
          playUrl.push(lineUrl)
        })
      } else if (item?.episode) {
        episodes.push(item.episode)
      }
    }
    if (episodes.length) {
      playFrom.push(flagName)
      playUrl.push(episodes.join('#'))
    }
  }

  vod.vod_play_from = playFrom.join('$$$') || '默认'
  vod.vod_play_url = playUrl.join('$$$') || `详情页$${ids}`
  return { list: [vod] }
}

async function playContent({ id, flag, drives }) {
  const input = String(id || '')
  const panFlag = panTypeFromFlag(flag)
  const shouldUseDrive = isPanUrl(input) || isPanFlag(flag) || driveCache.has(input)
  if (shouldUseDrive) {
    const cachedIndexes = []
    if (driveCache.has(input)) cachedIndexes.push(driveCache.get(input))
    for (const [key, idx] of driveCache.entries()) {
      if ((key.includes(input) || key.endsWith(`@@${String(flag || '')}`)) && !cachedIndexes.includes(idx)) cachedIndexes.push(idx)
    }
    for (const idx of cachedIndexes) {
      if (drives[idx]?.play) {
        try {
          const ret = await drives[idx].play(input, panFlag)
          if (ret) return ret
        } catch (_) {}
      }
    }
    for (const d of drives) {
      try {
        if (isPanUrl(input) && typeof d?.matchShare === 'function' && !d.matchShare(input)) continue
        if (typeof d?.play === 'function') {
          const ret = await d.play(input, panFlag)
          if (ret) return ret
        }
      } catch (_) {}
    }
    if (isPanUrl(input)) return { parse: 0, jx: 0, url: `push://${input}` }
  }

  if (/\/play\//.test(input)) {
    const html = await fetchHtml(input)
    const player = extractPlayerJson(html)
    if (player?.url) {
      const decodedUrl = decodePlayerUrl(player)
      if (isPanUrl(decodedUrl)) return await playContent({ id: decodedUrl, flag: player.from || flag, drives })
      if (/\.(m3u8|mp4|flv|m4s)(\?|$)/i.test(decodedUrl)) {
        return { parse: 0, jx: 0, url: decodedUrl, header: { 'User-Agent': UA, Referer: input, Origin: HOST } }
      }
      const directUrl = await tryResolveArtPlayer({ ...player, url: decodedUrl }, input)
      if (directUrl && /^(https?:)?\/\//i.test(directUrl)) {
        return { parse: 0, jx: 0, url: absUrl(directUrl), header: { 'User-Agent': UA, Referer: input, Origin: HOST } }
      }
      const playerPath = String(player.from || '') === '1080zyk' ? '/m3u8/f-player/' : '/static/player/artplayer/'
      const artUrl = `${HOST}${playerPath}?url=${encodeURIComponent(decodedUrl)}&next=${player.link_next ? encodeURIComponent(absUrl(player.link_next)) : ''}`
      return { parse: 1, jx: 1, url: artUrl, header: { 'User-Agent': UA, Referer: input } }
    }
  }

  const url = absUrl(input)
  if (/\.(m3u8|mp4|flv|m4s)(\?|$)/i.test(url)) {
    return { parse: 0, jx: 0, url, header: { 'User-Agent': UA, Referer: HOST, Origin: HOST } }
  }
  return { parse: 1, jx: 1, url, header: { 'User-Agent': UA, Referer: HOST } }
}


module.exports = async (app, opt = {}) => {
  app.get(meta.api, async (req) => {
    const { ac, t, pg, ids, id, wd, play, flag, quick, ext, extend } = req.query || {}
    const drives = collectDrives(req, opt)
    try {
      if (play) return await playContent({ id: play, flag, drives })
      if (ids || id) return await detailContent({ ids: ids || id, drives })
      if (wd) return await searchContent({ wd, page: safePage(pg), quick: quick === '1' || quick === 'true' || quick === true })
      if (t || ac === 'detail') return await categoryContent({ id: t, page: safePage(pg), filters: decodeExt(ext || extend) })
      return await homeContent()
    } catch (e) {
      return { list: [], page: 1, pagecount: 1, limit: LIMIT, total: 0, error: e.message }
    }
  })
  opt.sites.push(meta)
}
