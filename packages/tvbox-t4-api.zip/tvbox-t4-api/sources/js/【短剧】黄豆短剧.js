/**
 * 黄豆短剧 (huangdou) — T4 插件
 * 站点: https://cocoaview.cc/ (Flutter Web, AES-256-CBC+gzip 加密 API)
 * 契约: sign = md5("Dart|sid|rid|time|url去协议")+"-"+time
 *       key  = HMAC-SHA256(pwd, hex_decode(rid.replace('-','')))
 *       body = IV(16B) + AES-CBC(gzip({token,deviceId,data}))
 *       resp = IV(16B) + AES-CBC(gzip(json))
 * VIP: m3u8 端点 /api/drama/hls/{id}/{seq}/play.m3u8?line=free 不校验 VIP
 */
"use strict";
const crypto = require("node:crypto");
const zlib = require("node:zlib");
const axios = require("axios");

// ============================================================================
// 常量与加密层
// ============================================================================
const HOSTS = [
  "https://cocoaview.cc",
  "https://ferncider.cc",
  "https://onyxripple.cc",
  "https://larkgarden.top",
  "https://larksummit.icu",
  "https://hdmgdj.com", // 容器直连 ECONNREFUSED, 仅作末位兜底
];
const PW_WEB = "7961beb44246e3012ce228d6b5ced05a";
const DEVICE_ID = crypto.randomUUID();
const SESSION_ID = crypto.randomUUID().replace(/-/g, "");
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36";

let apiBase = HOSTS[0];

function hmacKey(requestId) {
  return crypto
    .createHmac("sha256", Buffer.from(PW_WEB, "utf8"))
    .update(Buffer.from(String(requestId).replace(/-/g, ""), "hex"))
    .digest();
}

function buildHeaders(pathUrl) {
  const requestId = crypto.randomUUID();
  const time = String(Math.floor(Date.now() / 1000));
  const urlStripped = String(pathUrl).replace(/^https?:\/\//, "");
  const plain = `Dart|${SESSION_ID}|${requestId}|${time}|${urlStripped}`;
  const sign = crypto.createHash("md5").update(plain, "utf8").digest("hex") + "-" + time;
  return {
    "content-type": "application/x-www-form-urlencoded",
    "deviceType": "web",
    "requestId": requestId,
    "sessionId": SESSION_ID,
    "sign": sign,
    "time": time,
    "version": "2.0.0",
    "user-agent": UA,
    "origin": apiBase,
    "referer": apiBase + "/",
  };
}

function encryptBody(obj, requestId) {
  const gz = zlib.gzipSync(Buffer.from(JSON.stringify(obj), "utf8"));
  const iv = crypto.randomBytes(16);
  const c = crypto.createCipheriv("aes-256-cbc", hmacKey(requestId), iv);
  return Buffer.concat([iv, c.update(gz), c.final()]);
}

function decryptBody(body, requestId) {
  const buf = Buffer.isBuffer(body) ? body : Buffer.from(body);
  const d = crypto.createDecipheriv("aes-256-cbc", hmacKey(requestId), buf.slice(0, 16));
  const dec = Buffer.concat([d.update(buf.slice(16)), d.final()]);
  let out;
  try { out = zlib.gunzipSync(dec).toString("utf8"); }
  catch { out = dec.toString("utf8"); }
  return JSON.parse(out);
}

async function api(path, data) {
  let lastErr = null;
  for (const host of [apiBase, ...HOSTS.filter((h) => h !== apiBase)]) {
    try {
      const url = host + path;
      const headers = buildHeaders(url);
      const body = encryptBody({ token: "", deviceId: DEVICE_ID, data: data || {} }, headers.requestId);
      const res = await axios.post(url, body, {
        headers,
        responseType: "arraybuffer",
        transformResponse: [(x) => x],
        timeout: 20000,
      });
      const json = decryptBody(Buffer.from(res.data), headers.requestId);
      if (json && (json.status === "y" || json.status === undefined)) {
        apiBase = host; // 记住可用域名
        return json.data !== undefined ? json.data : json;
      }
      lastErr = new Error(json && json.error ? `${json.error}(${json.errorCode})` : "响应异常");
      if (json && json.errorCode === 2002) break; // token 失效换域名无意义
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr || new Error("全部域名请求失败");
}

// ============================================================================
// 业务层
// ============================================================================
const PAGE_SIZE = 20;

function toStr(v, fallback = "") {
  return v == null || v === "" ? String(fallback || "") : String(v);
}

function mapListItem(it) {
  if (!it) return null;
  const id = toStr(it.drama_id || it.id);
  const name = toStr(it.name);
  if (!id || !name) return null;
  return {
    vod_id: id,
    vod_name: name,
    vod_pic: toStr(it.img || it.img_x || it.img_y),
    vod_remarks: it.episode_count ? `${it.episode_count}集` : toStr(it.corner),
  };
}

function decodeExt(ext) {
  if (!ext) return {};
  try {
    return JSON.parse(Buffer.from(String(ext), "base64").toString("utf8")) || {};
  } catch { return {}; }
}

// 分类缓存（含 filters）: { tabs: [{id,name,code,filter:{cat_id,order}}] }
let navCache = { ts: 0, tabs: [] };

async function loadNav(force) {
  if (!force && navCache.tabs.length && Date.now() - navCache.ts < 30 * 60 * 1000) return navCache.tabs;
  const data = await api("/api/drama/navList", { position: "", with_filters: "1" });
  const tabs = [];
  for (const cat of (data && data.list) || []) {
    const gid = toStr(cat.id);
    const gname = toStr(cat.name);
    if (!gid || !gname) continue;
    const fArr = (cat.filters || [])
      .map((f) => {
        if (!f || !f.filter) return null;
        const cid = toStr(f.filter.cat_id);
        const ord = toStr(f.filter.order);
        if (!cid && !ord) return null; // 两者都空才丢弃(纯推荐 order 保留)
        return { n: toStr(f.name), v: cid + "|" + ord };
      })
      .filter(Boolean);
    tabs.push({ id: gid, name: gname, code: toStr(cat.code), subs: fArr });
  }
  navCache = { ts: Date.now(), tabs };
  return tabs;
}

async function home() {
  const tabs = await loadNav(true).catch(() => []);
  const classes = tabs.map((t) => ({ type_id: t.id, type_name: t.name }));
  const filters = {};
  for (const t of tabs) {
    filters[t.id] = [
      { key: "sub", name: "", init: t.subs[0] ? t.subs[0].v : "", value: [{ n: "全部", v: "|" }, ...t.subs] },
    ];
  }
  // 首页列表: 取第一个可用 tab 的热榜
  let list = [];
  try {
    const first = tabs[0] && tabs[0].subs[0];
    const r = await api("/api/drama/list", {
      page: "1", page_size: String(PAGE_SIZE),
      cat_id: first ? first.v.split("|")[0] : "", order: first ? first.v.split("|")[1] || "" : "",
    });
    list = (r.list || []).map(mapListItem).filter(Boolean);
  } catch { list = []; }
  return {
    class: classes,
    filters,
    list,
    page: 1, pagecount: 1, limit: PAGE_SIZE, total: list.length,
  };
}

async function category(id, page, ext) {
  const pg = Math.max(1, parseInt(page, 10) || 1);
  // ext: {sub: "cat_id|order"} → 解出子分类
  const tabs = await loadNav().catch(() => []);
  const tab = tabs.find((t) => t.id === toStr(id));
  const fval = toStr(ext && (ext.sub || ext["1"]));
  let catId = "", order = "";
  if (fval) { const p = fval.split("|"); catId = p[0] || ""; order = p[1] || ""; }
  else if (tab && tab.subs[0]) { const p = tab.subs[0].v.split("|"); catId = p[0] || ""; order = p[1] || ""; }
  const r = await api("/api/drama/list", {
    page: String(pg), page_size: String(PAGE_SIZE), cat_id: catId, order,
  });
  const list = (r.list || []).map(mapListItem).filter(Boolean);
  const full = list.length >= PAGE_SIZE;
  return {
    page: pg, pagecount: full ? pg + 1 : pg, limit: PAGE_SIZE,
    total: full ? (pg + 1) * PAGE_SIZE : (pg - 1) * PAGE_SIZE + list.length,
    list,
  };
}

async function detail(idList) {
  const out = [];
  for (const rawId of Array.isArray(idList) ? idList : [idList]) {
    const id = toStr(rawId);
    if (!id) continue;
    const d = await api("/api/drama/detail", { id });
    const info = d || {};
    const episodes = Array.isArray(info.episodes) ? info.episodes : [];
    // playId = "hd_{drama_id}_{seq}" (避免竖线,客户端可能把|当线路分隔符); 集 id 服务端不认(实测), 用 drama_id+seq 播放
    // 统一集名: API name 不规整(如"2"/空), 含"第N集"或纯数字时重写为"第N集", 其他特殊名(预告/花絮)保留
    const normEpName = (ep) => {
      const raw = toStr(ep.name).trim();
      if (!raw || /^(第\s*\d+\s*集|\d+)$/.test(raw)) return `第${ep.seq}集`;
      return raw;
    };
    const playUrl = episodes
      .map((ep) => `${normEpName(ep)}$hd_${id}_${toStr(ep.seq)}`)
      .join("#");
    out.push({
      vod_id: id,
      vod_name: toStr(info.name),
      vod_pic: toStr(info.img || info.img_x || info.img_y),
      vod_remarks: info.episode_count ? `${info.episode_count}集` : "",
      type_name: toStr(info.category),
      vod_content: toStr(info.description),
      vod_play_from: toStr(info.name, "播放"),
      vod_play_url: playUrl,
    });
  }
  return { list: out };
}

async function play(flag, id) {
  // id = "hd_{drama_id}_{seq}"  性能优化: 免费端点实测不校验VIP/sig, 直接拼URL零耗时起播;
  // 不再调 /api/drama/play (实测 5.5s 且 VIP 剧必败), 镜像域名作备用线路
  const m = /^hd_(.+)_(\d+)$/.exec(String(id));
  if (!m) throw new Error("playId 格式错误");
  const dramaId = m[1], seq = m[2];
  const lines = [apiBase, ...HOSTS.filter((h) => h !== apiBase).slice(0, 2)]
    .map((host, i) => ({
      name: i === 0 ? "主线路" : "备用" + i,
      url: `${host}/api/drama/hls/${dramaId}/${seq}/play.m3u8?line=free`,
    }));
  const primary = lines[0].url;
  return {
    parse: 0, jx: 0,
    url: primary,
    playUrl: "", play_url: "",
    header: { "user-agent": UA, referer: apiBase + "/" },
    headers: { "user-agent": UA, referer: apiBase + "/" },
    flag,
    urls: lines, playUrls: lines, play_urls: lines,
    qualitys: lines, qualities: lines,
    qualityUrl: primary, quality_url: primary,
    defaultUrl: primary, default_url: primary,
    currentUrl: primary, current_url: primary,
    extra: { nodanmu: true },
  };
}

async function search(wd, pg) {
  const kw = toStr(wd).trim();
  if (!kw) return { list: [] };
  const page = Math.max(1, parseInt(pg, 10) || 1);
  const r = await api("/api/drama/list", {
    page: String(page), page_size: String(PAGE_SIZE), keywords: kw,
  });
  const list = (r.list || []).map(mapListItem).filter(Boolean);
  const full = list.length >= PAGE_SIZE;
  return {
    parse: 0, jx: 0,
    page, limit: PAGE_SIZE,
    pagecount: full ? page + 1 : page,
    total: full ? (page + 1) * PAGE_SIZE : (page - 1) * PAGE_SIZE + list.length,
    list,
  };
}

const meta = {
  key: "huangdouduanju",
  name: "[短]黄豆短剧",
  type: 4,
  api: "/video/huangdouduanju",
  searchable: 1,
  quickSearch: 1,
  filterable: 1,
  changeable: 0,
};

module.exports = async (app, opt) => {
  app.get(meta.api, async (req) => {
    const q = req.query || {};
    const { ac, t, pg, wd, play: playId, ids, ext, flag } = q;
    const filters = decodeExt(ext);
    try {
      if (playId) return await play(flag, playId);
      if (wd) return await search(wd, pg);
      if (ids) return await detail([String(ids)]);
      if (t) return await category(t, pg || "1", filters);
      if (ac === "list") return await category("1", pg || "1", filters);
      return await home();
    } catch (e) {
      app.log && app.log.error && app.log.error(`[黄豆短剧] ${e && e.message || e}`);
      return { list: [] };
    }
  });

  opt.sites.push(meta);
};
