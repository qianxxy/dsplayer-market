"use strict"; module.exports = require("./appv7-client").createRoute({ key: "appv7xiaoningmeng", name: "[影]柠檬秒播", configKey: "AppV7Xnm" });
