const axios = require('axios');
const CryptoJS = require('crypto-js');
const http = require('http');
const https = require('https');

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36';
const HEADERS = {
  'User-Agent': UA,
  'Accept': 'application/json, text/plain, */*',
  'Referer': 'https://live.huya.com/'
};

const _http = axios.create({
  timeout: 15000,
  httpAgent: new http.Agent({ keepAlive: true }),
  httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
  validateStatus: s => s >= 200 && s < 500
});

const API_LIST = 'https://live.huya.com/liveHttpUI/getTmpLiveList';
const API_ROOM = 'https://mp.huya.com/cache.php?m=Live&do=profileRoom&roomid=';
const PAGE_SIZE = 120;
const MAX_PAGE = 4;
const LIST_TTL = 8 * 60 * 1000;
const PLAY_TTL = 5 * 60 * 1000;
const DEFAULT_PIC = 'https://a.msstatic.com/huya/main3/widget/header/img/logo.png';

const CATES = [
  { type_id: '2067|2213', type_name: '虎牙.电影' },
  { type_id: '2079|2227', type_name: '虎牙.电视剧' },
  { type_id: '6871|6767', type_name: '虎牙.最新' },
  { type_id: '6879|6775', type_name: '虎牙.up主' },
  { type_id: '1011|1137', type_name: '虎牙.综艺s' },
  { type_id: '6861|6761', type_name: '虎牙.动漫' }
];

const FILTER_NAMES = new Set(['欢迎来到我的直播间', '我是一颗小虎牙']);
const REPLACE_RULES = [
  ['周星驰', ['星爷', '周星驰', '周星星']],
  ['林正英', ['英叔', '林正英']],
  ['王晶', ['王晶']],
  ['周润发', ['发哥', '周润发']],
  ['刘德华', ['华仔', '刘德华']],
  ['成龙', ['成龙']],
  ['007电影', ['邦德']],
  ['梁家辉', ['梁家辉']],
  ['洪金宝', ['洪金宝·']]
];

const store = {
  init: false,
  log: console,
  listCache: new Map(),
  playCache: new Map()
};

function safeString(v) {
  if (v === null || v === undefined || v === 'null') return '';
  return String(v).trim();
}

function cleanName(name) {
  const raw = safeString(name).replace(/\s+/g, ' ');
  if (!raw) return '';
  for (const [target, keys] of REPLACE_RULES) {
    if (keys.some(k => raw.toLowerCase().includes(String(k).toLowerCase()))) return target;
  }
  return raw;
}

async function requestJson(url, headers = HEADERS) {
  const res = await _http.get(url, { headers });
  const data = res.data;
  if (typeof data === 'object') return data;
  if (!data) return null;
  try { return JSON.parse(data); } catch (e) { return null; }
}

function getClasses() {
  return CATES.map(x => ({ type_id: x.type_id, type_name: x.type_name }));
}

function getCate(tid) {
  const id = safeString(tid || CATES[0].type_id);
  return CATES.find(x => x.type_id === id) || CATES[0];
}

function cacheGet(map, key, ttl) {
  const hit = map.get(key);
  if (!hit) return null;
  if (Date.now() - hit.time > ttl) {
    map.delete(key);
    return null;
  }
  return hit.data;
}

function cacheSet(map, key, data) {
  map.set(key, { time: Date.now(), data });
  return data;
}

async function getCategory(tid, pg) {
  const page = Math.max(parseInt(pg || '1', 10) || 1, 1);
  const cate = getCate(tid);
  const cacheKey = `${cate.type_id}:${page}`;
  const cached = cacheGet(store.listCache, cacheKey, LIST_TTL);
  if (cached) return cached;

  const [iTmpId, iLibId] = cate.type_id.split('|');
  const list = [];

  for (let i = page; i < page + MAX_PAGE; i++) {
    const url = `${API_LIST}?iTmpId=${encodeURIComponent(iTmpId)}&iPageNo=${i}&iPageSize=${PAGE_SIZE}&iLibId=${encodeURIComponent(iLibId)}&iGid=2135`;
    try {
      const json = await requestJson(url);
      const rows = json && Array.isArray(json.vList) ? json.vList : [];
      if (!rows.length) break;

      for (const item of rows) {
        const roomId = safeString(item.lProfileRoom || item.lRoomId || item.profileRoom);
        const rawName = safeString(item.sIntroduction || item.sNick || item.sRoomName);
        if (!roomId || !rawName || FILTER_NAMES.has(rawName)) continue;
        const name = cleanName(rawName);
        const pic = safeString(item.sScreenshot || item.sAvatar180 || item.sCover) || DEFAULT_PIC;
        list.push({
          vod_id: roomId,
          vod_name: name,
          vod_pic: pic,
          type_name: cate.type_name,
          vod_remarks: safeString(item.sGameFullName) || cate.type_name
        });
      }

      if (Number(json.iTotal || 0) === 0 || rows.length < PAGE_SIZE) break;
    } catch (e) {
      store.log.error && store.log.error(`[虎牙一起看] list failed ${url}: ${e.message}`);
    }
  }

  const result = {
    page,
    pagecount: list.length >= PAGE_SIZE ? page + 1 : page,
    limit: PAGE_SIZE,
    total: list.length,
    list
  };
  return cacheSet(store.listCache, cacheKey, result);
}

async function getRoomData(roomId) {
  const json = await requestJson(API_ROOM + encodeURIComponent(roomId), {
    ...HEADERS,
    'Referer': `https://www.huya.com/${roomId}`
  });
  const data = json && json.data;
  if (!data) throw new Error(`${roomId} id错误或未开播`);
  return data;
}

function parseBitRates(data) {
  const liveData = data.liveData || {};
  let bitRateInfo = [];
  try {
    if (typeof liveData.bitRateInfo === 'string' && liveData.bitRateInfo) bitRateInfo = JSON.parse(liveData.bitRateInfo);
    else if (Array.isArray(liveData.bitRateInfo)) bitRateInfo = liveData.bitRateInfo;
  } catch (e) {
    bitRateInfo = [];
  }
  if (!bitRateInfo.length) bitRateInfo = [{ iBitRate: 0, sDisplayName: '原画' }];
  bitRateInfo.sort((a, b) => {
    const ar = Number(a.iBitRate || 0);
    const br = Number(b.iBitRate || 0);
    if (ar === 0) return -1;
    if (br === 0) return 1;
    return br - ar;
  });
  return bitRateInfo;
}

function buildPlayList(roomId, data) {
  return parseBitRates(data).map(r => {
    const ratio = Number(r.iBitRate || 0);
    const name = safeString(r.sDisplayName) || (ratio === 0 ? '原画' : `${ratio}K`);
    return `${name}$${roomId}_${ratio}`;
  }).join('#');
}

async function getDetail(ids) {
  const idList = Array.isArray(ids) ? ids : safeString(ids).split(',').filter(Boolean);
  const list = [];

  for (const rawId of idList) {
    const roomId = safeString(rawId);
    if (!roomId) continue;
    try {
      const data = await getRoomData(roomId);
      const profileInfo = data.profileInfo || {};
      const liveData = data.liveData || {};
      const name = safeString(liveData.introduction || profileInfo.introduction || liveData.contentIntro || profileInfo.nick) || `虎牙房间 ${roomId}`;
      const pic = safeString(liveData.screenshot || profileInfo.avatar180) || DEFAULT_PIC;
      const online = Number(liveData.totalCount || profileInfo.activityCount || 0);
      const playList = buildPlayList(roomId, data);
      list.push({
        vod_id: roomId,
        vod_name: name,
        vod_pic: pic,
        type_name: safeString(liveData.gameFullName) || '虎牙一起看',
        vod_remarks: online ? `${online.toLocaleString()}人在线` : '直播',
        vod_content: `房间ID: ${roomId}\n主播: ${safeString(profileInfo.nick)}\n分类: ${safeString(liveData.gameFullName) || '虎牙一起看'}`,
        vod_play_from: '虎牙',
        vod_play_url: playList || `原画$${roomId}_0`
      });
    } catch (e) {
      list.push({
        vod_id: roomId,
        vod_name: `虎牙房间 ${roomId}`,
        vod_pic: DEFAULT_PIC,
        type_name: '虎牙一起看',
        vod_remarks: '直播',
        vod_content: '虎牙一起看实时直播',
        vod_play_from: '虎牙',
        vod_play_url: `原画$${roomId}_0`
      });
    }
  }
  return { list, page: 1, pagecount: 1, total: list.length };
}

function buildSignedUrls(data, roomId, ratio) {
  const uid = safeString(data.profileInfo && data.profileInfo.uid) || '0';
  const streamList = data.stream && Array.isArray(data.stream.baseSteamInfoList) ? data.stream.baseSteamInfoList : [];
  const cdnNameMap = { AL: '阿里线路', TX: '腾讯线路', HW: '华为线路', HS: '火山线路', HY: '虎牙线路' };
  const urlArray = [];

  for (const streamInfo of streamList) {
    const streamName = safeString(streamInfo.sStreamName);
    const srcUrl = safeString(streamInfo.sFlvUrl) || 'http://al.flv.huya.com/src';
    if (!streamName) continue;

    let host = 'al.flv.huya.com';
    try { host = new URL(srcUrl.replace(/^http:/i, 'https:')).hostname || host; } catch (e) {}

    const cdnType = safeString(streamInfo.sCdnType);
    const cdnName = cdnNameMap[cdnType] || (cdnType ? `${cdnType}线路` : `线路${urlArray.length / 2 + 1}`);
    const seqid = String(parseInt(uid, 10) + Date.now());
    const ctype = 'huya_adr';
    const t = '102';
    const wsTime = Math.floor(Date.now() / 1000 + 21600).toString(16);
    const ss = CryptoJS.MD5(`${seqid}|${ctype}|${t}`).toString();
    const wsSecret = CryptoJS.MD5(`DWq8BcJ3h6DJt6TY_${uid}_${streamName}_${ss}_${wsTime}`).toString();
    const playUrl = `https://${host}/src/${streamName}.flv?wsSecret=${wsSecret}&wsTime=${wsTime}&ctype=${ctype}&seqid=${seqid}&uid=${uid}&fs=bgct&ver=1&t=${t}&ratio=${ratio}`;
    urlArray.push(cdnName, playUrl);
  }
  return urlArray;
}

async function playUrl(id) {
  const raw = safeString(id);
  if (!raw) return { parse: 0, jx: 0, url: '', msg: '空房间ID' };
  const [roomId, ratioRaw] = raw.split('_');
  const ratio = safeString(ratioRaw || '0') || '0';
  const cacheKey = `${roomId}_${ratio}`;
  const cached = cacheGet(store.playCache, cacheKey, PLAY_TTL);
  if (cached) return cached;

  const data = await getRoomData(roomId);
  const urls = buildSignedUrls(data, roomId, ratio);
  const result = {
    parse: 0,
    jx: 0,
    url: urls.length ? urls : '',
    header: {
      'User-Agent': 'Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 Chrome/81.0.4044.138 Mobile Safari/537.36',
      'Referer': 'https://m.huya.com/'
    }
  };
  return cacheSet(store.playCache, cacheKey, result);
}

async function search(wd) {
  const key = safeString(wd).toLowerCase();
  if (!key) return { list: [], page: 1, pagecount: 1, total: 0 };
  const all = [];
  for (const cate of CATES) {
    const res = await getCategory(cate.type_id, 1);
    all.push(...res.list.filter(x => safeString(x.vod_name).toLowerCase().includes(key)));
  }
  return { list: all, page: 1, pagecount: 1, total: all.length };
}

async function handleT4Request(req) {
  const { ac, t, ids, play, pg, wd } = req.query || {};
  if (play) return await playUrl(play);
  if (wd) return await search(wd);
  if (ids) return await getDetail(ids);

  if (ac === 'detail' && t !== undefined) return await getCategory(t, pg);

  if (!ac || ac === 'class') {
    const classes = getClasses();
    if (ac === 'class') return { class: classes };
    const result = await getCategory(classes[0].type_id, 1);
    return { class: classes, list: result.list, page: 1, pagecount: result.pagecount, total: result.total };
  }

  return { list: [], page: 1, pagecount: 1, total: 0 };
}

const meta = {
  key: 'huyayiqikan',
  name: '虎牙一起看[官]',
  type: 4,
  api: '/video/huyayiqikan',
  searchable: 1,
  quickSearch: 0,
  filterable: 0,
  changeable: 1,
  // 竖版卡片，影视壳移动端更容易显示为一页三列
  style: { type: 'rect', ratio: 0.75 }
};

async function init(server) {
  if (store.init) return;
  store.log = server.log || console;
  store.init = true;
}

module.exports = async (app, opt) => {
  app.get(meta.api, async (req, reply) => {
    if (!store.init) await init(req.server);
    try {
      return await handleT4Request(req);
    } catch (e) {
      req.server.log.error(e);
      return { list: [], code: -1, msg: e.message };
    }
  });
  opt.sites.push(meta);
};
