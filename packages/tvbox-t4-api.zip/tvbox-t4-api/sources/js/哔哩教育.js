const axios = require("axios");
const CryptoJS = require("crypto-js");
const { create } = require("xmlbuilder2");

// ==========================================
//          配置区 - 请按需填写
// ==========================================
const BILI_COOKIE = "";
const BILI_HEADERS = {
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
  "Referer": "https://www.bilibili.com",
  "Cookie": BILI_COOKIE
};

const isLoggedIn = () => BILI_COOKIE && BILI_COOKIE.includes("SESSDATA=");

// ==========================================
//      MPD 生成函数
// ==========================================
const getMpd = (dash, query) => {
  store.log.info(query);
  
  const root = create({ version: '1.0', encoding: 'UTF-8' })
    .ele('MPD', {
      'xmlns': 'urn:mpeg:dash:schema:mpd:2011',
      'profiles': 'urn:mpeg:dash:profile:isoff-on-demand:2011',
      'type': 'static',
      'minBufferTime': 'PT1.5S',
      'mediaPresentationDuration': `PT${dash.duration}S`
    })
    .ele('Period');

  if (dash.video) {
    let targetVideos = dash.video.filter(v => v.codecid === 7 || (v.codecs && v.codecs.startsWith('avc')));
    
    if (targetVideos.length === 0) {
      targetVideos = dash.video;
    }
    
    targetVideos.sort((a, b) => {
      if (b.id !== a.id) return b.id - a.id;
      if (b.bandwidth !== a.bandwidth) return (b.bandwidth || 0) - (a.bandwidth || 0);
      return (b.width || 0) - (a.width || 0);
    });
    
    if (targetVideos.length > 0) {
      dash.video = [targetVideos[0]];
    }
    
    const adaptionSet = root.ele('AdaptationSet', {
      'mimeType': 'video/mp4', 'contentType': 'video',
      'subsegmentAlignment': 'true', 'subsegmentStartsWithSAP': '1'
    });
    
    dash.video.forEach((video, index) => {
      const representation = adaptionSet.ele('Representation', {
        'id': video.id,
        'codecs': video.codecs || 'avc1.64001E',
        'bandwidth': video.bandwidth,
        'width': video.width,
        'height': video.height,
        'frameRate': video.frame_rate
      });
      
      if (query.isEscape == "true") {
        video.baseUrl = video.baseUrl.replaceAll('&', '&amp;');
        representation.ele('BaseURL').dat(video.baseUrl).up();
      } else {
        representation.ele('BaseURL').txt(video.baseUrl || video.base_url).up();
      }
      
      if (video.SegmentBase?.Initialization) {
        representation.ele('SegmentBase', { 'indexRange': video.SegmentBase.indexRange })
          .ele('Initialization', { 'range': video.SegmentBase.Initialization }).up().up();
      }
    });
  }

  if (dash.audio) {
    const adaptionSet = root.ele('AdaptationSet', {
      'mimeType': 'audio/mp4', 'contentType': 'audio',
      'subsegmentAlignment': 'true', 'subsegmentStartsWithSAP': '1'
    });
    
    dash.audio.forEach((audio, index) => {
      const representation = adaptionSet.ele('Representation', {
        'id': audio.id, 'codecs': audio.codecs || 'mp4a.40.2', 'bandwidth': audio.bandwidth
      });
      
      if (query.isEscape == "true") {
        audio.baseUrl = audio.baseUrl.replaceAll('&', '&amp;');
        representation.ele('BaseURL').dat(audio.baseUrl).up();
      } else {
        representation.ele('BaseURL').txt(audio.baseUrl || audio.base_url).up();
      }
      
      if (audio.SegmentBase?.Initialization) {
        representation.ele('SegmentBase', { 'indexRange': audio.SegmentBase.indexRange })
          .ele('Initialization', { 'range': audio.SegmentBase.Initialization }).up().up();
      }
    });
  }
  
  return root.end({ prettyPrint: true });
};

// ==========================================
//          辅助函数
// ==========================================
const fixCover = (url) => {
  if (!url) return "";
  if (url.startsWith("//")) return "https:" + url;
  return url;
};

const formatDuration = (seconds) => {
  if (seconds <= 0) return '00:00';
  const minutes = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
};

const formatSearchDuration = (duration) => {
  const parts = duration.split(':');
  if (parts.length === 2) return duration;
  return '00:00';
};


const cleanHtmlText = (text) => {
  if (!text) return "";
  return String(text)
    .replace(/<[^>]+>/g, "")
    .replace(/&quot;/g, '"')
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .trim();
};

const getWbiKeys = async () => {
  const { data } = await axios.get("https://api.bilibili.com/x/web-interface/nav", { headers: BILI_HEADERS });
  const wbiImg = data?.data?.wbi_img || {};
  const imgUrl = wbiImg.img_url || "";
  const subUrl = wbiImg.sub_url || "";
  return {
    img_key: imgUrl.split("/").pop().split(".")[0],
    sub_key: subUrl.split("/").pop().split(".")[0],
  };
};

const encWbi = (params, keys) => {
  const mixinKeyEncTab = [
    46, 47, 18, 2, 53, 8, 23, 32,
    15, 50, 10, 31, 58, 3, 45, 35,
    27, 43, 5, 49, 33, 9, 42, 19,
    29, 28, 14, 39, 12, 38, 41, 13,
    37, 48, 7, 16, 24, 55, 40, 61,
    26, 17, 0, 1, 60, 51, 30, 4,
    22, 25, 54, 21, 56, 59, 6, 63,
    57, 62, 11, 36, 20, 52, 44,
  ];
  const raw = `${keys.img_key || ""}${keys.sub_key || ""}`;
  const mixinKey = mixinKeyEncTab.map(i => raw[i] || "").join("").slice(0, 32);
  const nextParams = { ...params, wts: Math.floor(Date.now() / 1000) };
  const query = Object.keys(nextParams)
    .sort()
    .map(k => `${encodeURIComponent(k)}=${encodeURIComponent(nextParams[k])}`)
    .join("&");
  const wRid = CryptoJS.MD5(query + mixinKey).toString();
  return `${query}&w_rid=${wRid}`;
};

const parseExtend = (ext) => {
  if (!ext) return {};
  if (typeof ext === 'object') return ext;
  const raw = String(ext).trim();
  const tries = [raw];
  try { tries.push(decodeURIComponent(raw)); } catch {}
  try { tries.push(Buffer.from(raw, 'base64').toString()); } catch {}
  try { tries.push(Buffer.from(raw.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString()); } catch {}
  for (const value of tries) {
    if (!value) continue;
    try {
      const obj = JSON.parse(value);
      if (obj && typeof obj === 'object') return obj;
    } catch {}
  }
  return {};
};

function getRequestInfo(request) {
  const rawHeaders = request.raw?.rawHeaders || [];
  store.log.info(rawHeaders);
  
  const getHeader = (key) => {
    const index = rawHeaders.indexOf(key);
    return index !== -1 ? rawHeaders[index + 1] : null;
  };
  
  const host = getHeader('Host') || getHeader('host');
  const userAgent = getHeader('User-Agent') || getHeader('user-agent');
  const protocol = getHeader('X-Forwarded-Proto') || 'http';
  
  return {
    fullUrl: `${protocol}://${host}`,
    userAgent: userAgent || ""
  };
}

// ==========================================
//          生成filters配置的辅助函数
// ==========================================
const generateFilters = (subjects) => {
  const filters = {};
  const versions = ["沪教版", "人教版", "北师大版", "苏教版"];
  
  subjects.forEach(subject => {
    const isSpecialPhysics = subject === "8年级物理";
    const isSpecialChemistry = subject === "9年级化学";
    
    const versionOptions = [
      { n: "全部", v: "0" },
      ...versions.map(v => ({ n: v, v: `${v}${subject}` }))
    ];
    
    if (isSpecialPhysics) {
      versionOptions.splice(4, 0, { n: "教科版", v: `教科版${subject}` });
    }
    if (isSpecialChemistry) {
      versionOptions.splice(2, 0, { n: "鲁教版", v: `鲁教版${subject}` });
    }
    
    filters[subject] = [
      {
        key: "tid",
        name: "分类",
        value: versionOptions
      },
      {
        key: "duration",
        name: "时长",
        value: [
          { n: "全部", v: "0" },
          { n: "60分钟以上", v: "4" },
          { n: "30~60分钟", v: "3" },
          { n: "10~30分钟", v: "2" },
          { n: "10分钟以下", v: "1" }
        ]
      }
    ];
  });
  
  return filters;
};

// ==========================================
//          教育分类定义
// ==========================================
const CLASSES = [
  { type_id: "1年级语文", type_name: "1年级语文" },
  { type_id: "1年级数学", type_name: "1年级数学" },
  { type_id: "1年级英语", type_name: "1年级英语" },
  { type_id: "2年级语文", type_name: "2年级语文" },
  { type_id: "2年级数学", type_name: "2年级数学" },
  { type_id: "2年级英语", type_name: "2年级英语" },
  { type_id: "3年级语文", type_name: "3年级语文" },
  { type_id: "3年级数学", type_name: "3年级数学" },
  { type_id: "3年级英语", type_name: "3年级英语" },
  { type_id: "4年级语文", type_name: "4年级语文" },
  { type_id: "4年级数学", type_name: "4年级数学" },
  { type_id: "4年级英语", type_name: "4年级英语" },
  { type_id: "5年级语文", type_name: "5年级语文" },
  { type_id: "5年级数学", type_name: "5年级数学" },
  { type_id: "5年级英语", type_name: "5年级英语" },
  { type_id: "6年级语文", type_name: "6年级语文" },
  { type_id: "6年级数学", type_name: "6年级数学" },
  { type_id: "6年级英语", type_name: "6年级英语" },
  { type_id: "7年级语文", type_name: "7年级语文" },
  { type_id: "7年级数学", type_name: "7年级数学" },
  { type_id: "7年级英语", type_name: "7年级英语" },
  { type_id: "7年级历史", type_name: "7年级历史" },
  { type_id: "7年级地理", type_name: "7年级地理" },
  { type_id: "7年级生物", type_name: "7年级生物" },
  { type_id: "7年级物理", type_name: "7年级物理" },
  { type_id: "7年级化学", type_name: "7年级化学" },
  { type_id: "8年级语文", type_name: "8年级语文" },
  { type_id: "8年级数学", type_name: "8年级数学" },
  { type_id: "8年级英语", type_name: "8年级英语" },
  { type_id: "8年级历史", type_name: "8年级历史" },
  { type_id: "8年级地理", type_name: "8年级地理" },
  { type_id: "8年级生物", type_name: "8年级生物" },
  { type_id: "8年级物理", type_name: "8年级物理" },
  { type_id: "8年级化学", type_name: "8年级化学" },
  { type_id: "9年级语文", type_name: "9年级语文" },
  { type_id: "9年级数学", type_name: "9年级数学" },
  { type_id: "9年级英语", type_name: "9年级英语" },
  { type_id: "9年级历史", type_name: "9年级历史" },
  { type_id: "9年级地理", type_name: "9年级地理" },
  { type_id: "9年级生物", type_name: "9年级生物" },
  { type_id: "9年级物理", type_name: "9年级物理" },
  { type_id: "9年级化学", type_name: "9年级化学" },
  { type_id: "高一语文", type_name: "高一语文" },
  { type_id: "高一数学", type_name: "高一数学" },
  { type_id: "高一英语", type_name: "高一英语" },
  { type_id: "高一历史", type_name: "高一历史" },
  { type_id: "高一地理", type_name: "高一地理" },
  { type_id: "高一生物", type_name: "高一生物" },
  { type_id: "高一思想政治", type_name: "高一思想政治" },
  { type_id: "高一物理", type_name: "高一物理" },
  { type_id: "高一化学", type_name: "高一化学" },
  { type_id: "高二语文", type_name: "高二语文" },
  { type_id: "高二数学", type_name: "高二数学" },
  { type_id: "高二英语", type_name: "高二英语" },
  { type_id: "高二历史", type_name: "高二历史" },
  { type_id: "高二地理", type_name: "高二地理" },
  { type_id: "高二生物", type_name: "高二生物" },
  { type_id: "高二思想政治", type_name: "高二思想政治" },
  { type_id: "高二物理", type_name: "高二物理" },
  { type_id: "高二化学", type_name: "高二化学" },
  { type_id: "高三语文", type_name: "高三语文" },
  { type_id: "高三数学", type_name: "高三数学" },
  { type_id: "高三英语", type_name: "高三英语" },
  { type_id: "高三历史", type_name: "高三历史" },
  { type_id: "高三地理", type_name: "高三地理" },
  { type_id: "高三生物", type_name: "高三生物" },
  { type_id: "高三思想政治", type_name: "高三思想政治" },
  { type_id: "高三物理", type_name: "高三物理" },
  { type_id: "高三化学", type_name: "高三化学" },
  { type_id: "奥数", type_name: "奥数" },
  { type_id: "奥林匹克物理", type_name: "奥物" },
  { type_id: "奥林匹克化学", type_name: "奥化" },
  { type_id: "高中信息技术", type_name: "高中信息技术" }
];

const ALL_SUBJECTS = CLASSES.map(c => c.type_id);
const FILTERS = generateFilters(ALL_SUBJECTS);

const _home = async ({ filter }) => {
  return {
    class: CLASSES,
    list: [],
    filters: FILTERS
  };
};

const _homeVideo = async () => {
  const url = 'https://api.bilibili.com/x/web-interface/popular?ps=20&pn=1';
  try {
    const { data } = await axios.get(url, { headers: BILI_HEADERS });
    let videos = [];
    if (data.data && data.data.list) {
      videos = data.data.list.map(item => ({
        vod_id: item.aid + "",
        vod_name: item.title.replace(/<[^>]*>/g, ""),
        vod_pic: fixCover(item.pic),
        vod_remarks: formatDuration(item.duration)
      }));
    }
    return { list: videos };
  } catch (e) {
    store.log.error(e);
    return { list: [] };
  }
};

const _category = async ({ id, page, filter, filters }) => {
 page = Math.max(1, parseInt(page) || 1);
 filters = filters || {};
 let keyword = id;
 let duration = 0;
 if (filters.tid && filters.tid !== '0') keyword = filters.tid;
 if (filters.duration && filters.duration !== '0') duration = parseInt(filters.duration) || 0;

 try {
 const keys = await getWbiKeys();
 const query = encWbi({
 search_type: 'video',
 keyword,
 page,
 order: 'totalrank',
 duration
 }, keys);
 const { data } = await axios.get(`https://api.bilibili.com/x/web-interface/wbi/search/type?${query}`, { headers: BILI_HEADERS });
 let videos = [];
 if (data.code === 0 && data.data && data.data.result) {
 videos = data.data.result
 .filter(item => item.type === 'video')
 .map(item => ({
 vod_id: item.aid + "",
 vod_name: cleanHtmlText(item.title),
 vod_pic: fixCover(item.pic),
 vod_remarks: formatSearchDuration(item.duration)
 }));
 }
 const pageCount = data.data?.numPages || 1;
 const total = data.data?.numResults || videos.length;
 return {
 list: videos,
 page: page,
 pagecount: pageCount,
 limit: 20,
 total: total
 };
 } catch (e) {
 store.log.error(e?.response?.data || e.message || e);
 return { list: [] };
 }
};

const _detail = async ({ id }) => {
  const result = { list: [] };
  const ids = Array.isArray(id) ? id : [id];
  
  for (const vid of ids) {
    const url = 'https://api.bilibili.com/x/web-interface/view?aid=' + vid;
    try {
      const { data } = await axios.get(url, { headers: BILI_HEADERS });
      if (data.data) {
        const video = data.data;
        let playUrl = '';
        video.pages.forEach((page, index) => {
          const part = page.part || `第${index + 1}集`;
          playUrl += `${part}$${vid}_${page.cid}#`;
        });
        playUrl = playUrl.replace(/#$/g, '');
        
        const vod = {
          vod_id: vid,
          vod_name: cleanHtmlText(video.title),
          vod_pic: fixCover(video.pic),
          vod_content: video.desc,
          vod_play_from: "B站视频",
          vod_play_url: playUrl
        };
        result.list.push(vod);
      }
    } catch (e) {
      store.log.error(`Error fetching detail for ${vid}`, e);
    }
  }
  return result;
};

const _play = async ({ flag, flags, id, req }) => {
  try {
    const parts = id.split('_');
    if (parts.length < 2) throw new Error("Invalid play id format");
    const avid = parts[0];
    const cid = parts[1];
    
    const loggedIn = isLoggedIn();
    const info = getRequestInfo(req);
    
    const availableQualities = [];
    const qualitySet = new Set();
    
    if (loggedIn) {
      const fullUrl = info.fullUrl;
      const isEscape = !info.userAgent.toLowerCase().includes("okhttp");
      const proxyUrl = `${fullUrl}${meta.api}/proxy?ac=proxy&ids=${avid}_${cid}&type=mpd&qn=127&fnval=4048&fourk=1&isEscape=${isEscape}`;
      
      availableQualities.push({
        name: 'DASH(代理)',
        url: proxyUrl,
        qn: info.userAgent && (info.userAgent.toLowerCase().includes("okhttp") || info.userAgent.toLowerCase().includes("dart")) ? 1000 : 10,
        priority: 10,
        isProxy: true
      });
    }
    
    const qualityNameMap = {
      127: '8K 超高清', 126: '杜比视界', 125: 'HDR 真彩色', 120: '4K 超清',
      116: '1080P60 高帧率', 112: '1080P+ 高码率', 80: '1080P 高清',
      74: '720P60 高帧率', 64: '720P 高清', 32: '480P 清晰', 16: '360P 流畅'
    };
    
    const qualityList = loggedIn
      ? [127, 126, 125, 120, 116, 112, 80, 74, 64, 32, 16]
      : [80, 64, 32, 16];
    
    const headers = {
      ...BILI_HEADERS,
      "Referer": `https://www.bilibili.com/video/av${avid}`
    };
    
    for (const qn of qualityList) {
      const useDash = qn > 116;
      const params = {
        avid,
        cid,
        qn,
        fnval: useDash ? 4048 : 1,
        fourk: qn >= 120 ? 1 : 0,
        ...( !loggedIn ? { try_look: 1 } : {} )
      };
      
      try {
        const { data } = await axios.get('https://api.bilibili.com/x/player/playurl', {
          params,
          headers
        });
        
        if (data.code !== 0 || !data.data) continue;
        
        const r = data.data;
        const actualQn = r.quality || qn;
        
        if (qualitySet.has(actualQn)) continue;
        qualitySet.add(actualQn);
        
        if (r.dash) {
          const bestVideo = r.dash.video?.sort((a,b) => (b.bandwidth||0) - (a.bandwidth||0))[0];
          const bestAudio = r.dash.audio?.sort((a,b) => (b.bandwidth||0) - (a.bandwidth||0))[0];
          
          if (bestVideo && bestAudio) {
            availableQualities.push({
              name: qualityNameMap[actualQn] || `DASH ${bestVideo.width||'?'}p`,
              url: bestVideo.base_url || bestVideo.baseUrl,
              audioUrl: bestAudio.base_url || bestAudio.baseUrl,
              qn: actualQn,
              isDash: true
            });
          }
        } else if (r.durl?.[0]?.url) {
          availableQualities.push({
            name: qualityNameMap[actualQn] || `画质${actualQn}`,
            url: r.durl[0].url,
            qn: actualQn,
            isDash: false
          });
        }
      } catch {}
    }
    
    if (availableQualities.length === 0) throw new Error("无法获取任何可用画质");
    
    availableQualities.sort((a, b) => b.qn - a.qn);
    
    const urlArray = [];
    availableQualities.forEach(q => {
      urlArray.push(q.name);
      urlArray.push(q.url);
    });
    
    const playResponse = {
      parse: 0,
      url: urlArray,
      header: {
        "User-Agent": headers["User-Agent"],
        "Referer": headers["Referer"],
        "Origin": "https://www.bilibili.com"
      },
      danmaku: `https://api.bilibili.com/x/v1/dm/list.so?oid=${cid}`
    };
    
    if (availableQualities[0]?.audioUrl) {
      playResponse.extra = { audio: availableQualities[0].audioUrl };
    }
    
    return playResponse;
    
  } catch (e) {
    store.log.error("Play error:", e.message);
    return { parse: 0, url: "", header: {}, danmaku: "" };
  }
};

const _proxy = async (req, reply) => {
  const id = req.query.ids;
  store.log.info(`[Proxy请求] IP: ${req.ip || '未知'} ids: ${id}`);
  
  if (reply.header) {
    reply.header('Access-Control-Allow-Origin', '*');
    reply.header('Access-Control-Allow-Methods', 'GET, OPTIONS');
    reply.header('Access-Control-Allow-Headers', 'Content-Type, Referer, User-Agent');
  }
  if (req.method === 'OPTIONS') {
    if (reply.code) reply.code(204);
    return reply.send ? reply.send('') : '';
  }
  
  const parts = id.split("_");
  if (parts.length < 2) {
    if (reply.code) reply.code(400);
    return "Invalid id format";
  }
  
  const avid = parts[0];
  const cid = parts[1];
  
  const url = `https://api.bilibili.com/x/player/playurl?avid=${avid}&cid=${cid}&qn=127&fnval=4048&fnver=0&fourk=1`;
  
  try {
    const response = await axios.get(url, { headers: BILI_HEADERS });
    const json = response.data;
    
    if (json.code === 0 && json.data?.dash) {
      const xml = getMpd(json.data.dash, req.query);
      if (reply.header) reply.header('Content-Type', 'application/dash+xml');
      return reply.send ? reply.send(xml) : xml;
    }
    else if (json.code === 0 && json.data?.durl?.[0]?.url) {
      if (reply.redirect) return reply.redirect(json.data.durl[0].url);
      return reply.send ? reply.send(json.data.durl[0].url) : json.data.durl[0].url;
    }
    else {
      store.log.error("Bilibili API error:", json);
      if (reply.code) reply.code(500);
      return JSON.stringify({ error: "API Error", msg: json.message || "未知错误" });
    }
  } catch (e) {
    store.log.error("[Proxy 网络错误]:", e.message);
    if (reply.code) reply.code(500);
    return "Network Error";
  }
};

const _search = async ({ page, quick, wd }) => {
  return await _category({ id: wd, page });
};

const meta = {
  key: "bilibili_edu",
  name: "哔哩教育[官]",
  type: 4,
  api: "/video/bilibili_edu",
  searchable: 1,
  quickSearch: 1,
  changeable: 0,
};

const store = { init: false };

const init = async (server) => {
  if (store.init) return;
  store.log = server.log;
  store.init = true;
};

module.exports = async (app, opt) => {
  app.get(meta.api, async (req, reply) => {
    if (!store.init) await init(req.server);
    
    const { ac, pg, ids, flag, play, wd, t, ext, quick } = req.query;
    
    if (play) {
      return await _play({ flag: flag || "", flags: [], id: play, req });
    }
    if (wd) {
      return await _search({ page: parseInt(pg || "1"), quick: quick || false, wd });
    }
    if (!ac) {
      return await _home({ filter: false });
    }
    if (ac === "detail") {
      if (t) {
        return await _category({
          id: t,
          page: parseInt(pg || "1"),
          filter: false,
          filters: ext ? JSON.parse(Buffer.from(ext, 'base64').toString()) : {}
        });
      }
      if (ids) {
        return await _detail({ id: ids.split(",").map(v => v.trim()).filter(Boolean) });
      }
      return await _homeVideo();
    }
    return req.query;
  });
  
  app.get(`${meta.api}/proxy`, { attachValidation: true }, _proxy);
  
  opt.sites.push(meta);
};