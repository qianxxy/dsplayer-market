const axios = require('axios');
const https = require('https');

// ============================================================================
// 红果短剧 T4 桥源（2026-09-20 按 hongguo.py 适配新站改版）
//  站点改版要点（与 hongguo.py 注释一致）：
//   1) 分类页由 query 式改路径式：/category/<real-drama|ai-drama|comic-drama|comic>
//      题材子类 /category/real-drama/<urban|costume|...>
//      旧写法 ?sort_type=1 / ?background=cate_1 / ?topic=cate_165 / ?setting=cate_36 已 301/404
//   2) loaderData 键：category_page -> category_$（动态路由键），取节点按 key 顺序兜底
//   3) 分类页分页仍 ?page=N（每页 24 条，pagination.totalPages 给总页数）
//   4) 详情 /detail?series_id=xxx 未变（detail_page.seriesDetail.vid_list）
//   5) 搜索由 /search?keyword=x 改路径式 /search/<关键词>（SSR 直出，单页 10 条，无翻页参数）
//   6) 榜单 4 分类走本机 9977 播放桥（/rank?type=&page=）
// ============================================================================

const HOST = 'https://hongguoduanju.com';
const BRIDGE = 'http://127.0.0.1:9977';
const API = '/video/hongguo_bridge';
const UA = 'Mozilla/5.0 (Linux; Android 12; TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36';
const PAGE_SIZE = 24;          // 站点分类页每页 24 条
const SUB_BASE = 'real-drama'; // 题材子分类所在的内容类型

const meta = {
  key: 'hongguo_bridge1',
  name: '[短]红果短剧桥',
  type: 4,
  api: API,
  searchable: 1,
  quickSearch: 1,
  filterable: 0,
  changeable: 0,
};

const http = axios.create({
  timeout: 25000,
  proxy: false,
  maxRedirects: 5,
  httpsAgent: new https.Agent({ keepAlive: true, rejectUnauthorized: false }),
  headers: {
    'User-Agent': UA,
    'Accept-Language': 'zh-CN,zh;q=0.9',
    'Referer': HOST + '/',
  },
  validateStatus: s => s >= 200 && s < 500,
});

const bridgeHttp = axios.create({
  timeout: 120000,
  proxy: false,
  maxRedirects: 0,
  validateStatus: s => s >= 200 && s < 500,
  headers: { 'User-Agent': UA },
});

// ==================== 分类（与 hongguo.py homeContent 完全一致）====================
// 4 榜单（走 9977 桥）在前，后接 4 内容类型 + 12 题材子分类，共 20 个
const RANK_TYPES = [
  ['热播短剧', 'rank:hot-drama'],
  ['热播真人剧', 'rank:hot-real-drama'],
  ['热播AI剧', 'rank:hot-ai-drama'],
  ['热播漫剧', 'rank:hot-comic-drama'],
];
const CAT_PATHS = [
  ['真人剧', 'real-drama'],
  ['AI剧', 'ai-drama'],
  ['漫剧', 'comic-drama'],
  ['漫画', 'comic'],
];
const SUB_CATS = [
  ['都市', 'sub:urban'],
  ['古装', 'sub:costume'],
  ['悬疑', 'sub:suspense'],
  ['爱情', 'sub:romance'],
  ['喜剧', 'sub:comedy'],
  ['逆袭', 'sub:comeback'],
  ['家庭', 'sub:family'],
  ['玄幻', 'sub:fantasy'],
  ['青春', 'sub:youth'],
  ['年代', 'sub:period'],
  ['萌宝', 'sub:cute-kids'],
  ['剧情', 'sub:drama'],
];

const classes = RANK_TYPES.concat(CAT_PATHS, SUB_CATS).map(([type_name, type_id]) => ({ type_id, type_name }));

const cache = new Map();
const CACHE_MS = 5 * 60 * 1000;

function cleanText(v) {
  return String(v || '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/\s+/g, ' ')
    .trim();
}

function pageResult(list, pg, total = 0, pageCount = 0) {
  const page = Math.max(parseInt(pg || '1', 10) || 1, 1);
  const totalNum = Number(total || (list && list.length) || 0);
  const pc = pageCount || (totalNum > 0 ? Math.ceil(totalNum / PAGE_SIZE) : (list.length >= PAGE_SIZE ? page + 1 : page));
  return { list, page, pagecount: Math.max(1, pc), limit: PAGE_SIZE, total: totalNum };
}

// ==================== _ROUTER_DATA 解析（按大括号配对，兼容新站无 window. 前缀）====================
function extractRouterData(html) {
  const text = String(html || '');
  let marker = '_ROUTER_DATA = ';
  let pos = text.indexOf(marker);
  if (pos === -1) {
    marker = 'window._ROUTER_DATA = ';
    pos = text.indexOf(marker);
  }
  if (pos === -1) throw new Error('_ROUTER_DATA not found');
  pos += marker.length;
  while (pos < text.length && ' \t\r\n'.indexOf(text[pos]) >= 0) pos += 1;
  if (text[pos] !== '{') throw new Error('_ROUTER_DATA not JSON object');
  let depth = 1;
  let i = pos + 1;
  let inStr = false;
  let esc = false;
  while (i < text.length && depth > 0) {
    const ch = text[i];
    if (esc) esc = false;
    else if (ch === '\\') esc = true;
    else if (ch === '"') inStr = !inStr;
    else if (!inStr) {
      if (ch === '{') depth += 1;
      else if (ch === '}') depth -= 1;
    }
    i += 1;
  }
  return JSON.parse(text.slice(pos, i));
}

async function routerData(url) {
  const hit = cache.get(url);
  if (hit && Date.now() - hit.t < CACHE_MS) return hit.data;
  const res = await http.get(url, { responseType: 'text' });
  if (res.status < 200 || res.status >= 300) throw new Error(`HTTP ${res.status}: ${url}`);
  const data = extractRouterData(res.data);
  cache.set(url, { t: Date.now(), data });
  return data;
}

// 按 key 顺序取 loaderData 节点；键名再变时按字段兜底（hongguo.py _node 同款）
function pickNode(data, ...keys) {
  const ld = (data || {}).loaderData || {};
  for (const k of keys) {
    const node = ld[k];
    if (node && typeof node === 'object' && !Array.isArray(node)) return node;
  }
  for (const node of Object.values(ld)) {
    if (node && typeof node === 'object' && !Array.isArray(node) && ('recommendList' in node || 'searchList' in node)) return node;
  }
  return {};
}

// ==================== 列表项（hongguo.py _vod 同款）====================
function vodItem(item = {}) {
  const tags = Array.isArray(item.tags) ? item.tags.slice(0, 3).join(' ') : String(item.tags || '');
  const count = item.episode_cnt || (Array.isArray(item.vid_list) ? item.vid_list.length : 0);
  const remark = String(item.episode_right_text || '') || (count ? `全${count}集` : tags);
  return {
    vod_id: String(item.series_id || ''),
    vod_name: cleanText(item.series_name || item.series_title || ''),
    vod_pic: String(item.series_cover || ''),
    vod_remarks: remark,
  };
}

function rankVod(item = {}) {
  const remark = String(item.heat || '') || (item.rank ? `第${item.rank}名` : '');
  return {
    vod_id: String(item.series_id || ''),
    vod_name: cleanText(item.series_name || ''),
    vod_pic: String(item.series_cover || ''),
    vod_remarks: remark,
  };
}

// ==================== 分类页（路径式）====================
// path: sub:urban -> /category/real-drama/urban；其他 -> /category/<path>
async function catItems(path, page = 1) {
  const pg = Math.max(parseInt(page || '1', 10) || 1, 1);
  let p = String(path || '').replace(/^\/+|\/+$/g, '');
  if (!p) p = CAT_PATHS[0][1];
  if (p.startsWith('sub:')) p = SUB_BASE + '/' + p.split(':').slice(1).join(':');
  let url = `${HOST}/category/${p}`;
  if (pg > 1) url += `?page=${pg}`;
  const data = await routerData(url);
  const node = pickNode(data, 'category_$', 'category_page');
  let items = node.recommendList || (node.categoryData && node.categoryData.recommendList) || [];
  if (!Array.isArray(items)) items = [];
  const seen = new Set();
  const out = [];
  for (const it of items) {
    const sid = String((it && it.series_id) || '');
    if (!sid || seen.has(sid)) continue;
    seen.add(sid);
    out.push(it);
  }
  const pag = node.pagination || {};
  return { items: out, pageCount: parseInt(pag.totalPages || 0, 10) || 0, total: parseInt(pag.total || 0, 10) || 0 };
}

// ==================== 榜单（走 9977 桥 /rank）====================
async function rankItems(type, page = 1) {
  const pg = Math.max(parseInt(page || '1', 10) || 1, 1);
  const res = await bridgeHttp.get(`${BRIDGE}/rank`, { params: { type, page: pg } });
  const data = res.data || {};
  if (data.error) throw new Error('榜单桥: ' + data.error);
  const list = Array.isArray(data.list) ? data.list : [];
  return { items: list, pageCount: parseInt(data.pagecount || 1, 10) || 1, total: parseInt(data.total || list.length, 10) || list.length };
}

// ==================== 首页 / 分类 / 详情 / 搜索 ====================
async function _home() {
  let list = [];
  try {
    const r = await catItems(CAT_PATHS[0][1], 1);
    list = r.items.slice(0, 30).map(vodItem).filter(v => v.vod_id && v.vod_name);
  } catch (_) {}
  return { class: classes, list, page: 1, pagecount: 1, total: list.length };
}

async function _category({ id, page }) {
  const pg = Math.max(parseInt(page || '1', 10) || 1, 1);
  const tid = String(id || '').trim() || CAT_PATHS[0][1];
  try {
    if (tid.startsWith('rank:')) {
      const r = await rankItems(tid.split(':').slice(1).join(':'), pg);
      const list = r.items.slice(0, PAGE_SIZE).map(rankVod).filter(v => v.vod_id && v.vod_name);
      return pageResult(list, pg, r.total, r.pageCount);
    }
    const r = await catItems(tid, pg);
    const list = r.items.slice(0, PAGE_SIZE).map(vodItem).filter(v => v.vod_id && v.vod_name);
    return pageResult(list, pg, r.total, r.pageCount);
  } catch (e) {
    return { code: 500, msg: e.message || String(e), list: [], page: pg, pagecount: 1, total: 0 };
  }
}

async function _detail({ ids }) {
  const result = [];
  for (const rawId of ids) {
    const seriesId = String(rawId || '').trim();
    if (!seriesId) continue;
    try {
      const data = await routerData(`${HOST}/detail?series_id=${encodeURIComponent(seriesId)}`);
      const detail = (data.loaderData || {}).detail_page || {};
      const series = detail.seriesDetail || {};
      const vids = (Array.isArray(series.vid_list) ? series.vid_list : []).filter(v => v);
      const episodes = vids.map((vid, idx) => `第${idx + 1}集$${String(vid)}`);
      const tags = Array.isArray(series.tags) ? series.tags.join(',') : String(series.tags || '');
      result.push({
        vod_id: seriesId,
        vod_name: cleanText(series.series_name || series.series_title || '红果短剧'),
        vod_pic: String(series.series_cover || ''),
        type_name: tags,
        vod_remarks: `全${series.episode_cnt || vids.length}集`,
        vod_content: cleanText(series.series_intro || ''),
        vod_play_from: '红果',
        vod_play_url: episodes.join('#'),
      });
    } catch (e) {
      result.push({
        vod_id: seriesId,
        vod_name: `红果短剧 ${seriesId}`,
        vod_play_from: '红果',
        vod_play_url: '',
        vod_content: e.message || String(e),
      });
    }
  }
  return { list: result };
}

// 新站搜索：/search/<关键词>，SSR 直出 searchList（混有演员条目，按 series_id 过滤）
async function _search({ wd, page }) {
  const pg = Math.max(parseInt(page || '1', 10) || 1, 1);
  const key = cleanText(wd);
  if (!key) return pageResult([], pg, 0, 1);
  try {
    const [items] = await Promise.all([searchItems(key)]);
    const list = items.slice(0, 30).map(vodItem).filter(v => v.vod_id && v.vod_name);
    // 站点搜索只有 SSR 单页 10 条，不提供翻页参数 —— 固定单页
    return pageResult(list, 1, list.length, 1);
  } catch (e) {
    return { code: 500, msg: e.message || String(e), list: [], page: pg, pagecount: 1, total: 0 };
  }
}

async function searchItems(key) {
  const data = await routerData(`${HOST}/search/${encodeURIComponent(String(key).trim())}`);
  const node = pickNode(data, 'search_(keyword)/page', 'search_page');
  const raw = Array.isArray(node.searchList) ? node.searchList : [];
  const seen = new Set();
  const out = [];
  for (const it of raw) {
    const vd = Object.assign({}, (it && it.video_data) || {});
    const sid = String(vd.series_id || '');
    if (!sid || seen.has(sid)) continue; // 过滤演员等无 series_id 条目
    seen.add(sid);
    if (!vd.series_name) vd.series_name = vd.series_title || (it && it.name) || '';
    out.push(vd);
  }
  return out;
}

// ==================== 播放（先让桥解成最终 MP4，兜底回桥的 302 /play）====================
async function _play({ id }) {
  const vid = decodeURIComponent(String(id || '').trim());
  if (!/^\d+$/.test(vid)) return { parse: 0, jx: 0, url: '', header: { 'User-Agent': UA } };
  try {
    const res = await bridgeHttp.get(`${BRIDGE}/resolve`, { params: { vid } });
    const finalUrl = (res.data && res.data.url) || '';
    if (finalUrl) {
      return { parse: 0, jx: 0, playUrl: '', url: finalUrl, header: { 'User-Agent': UA } };
    }
  } catch (_) {}
  return {
    parse: 0,
    jx: 0,
    playUrl: '',
    url: `${BRIDGE}/play?vid=${encodeURIComponent(vid)}`,
    header: { 'User-Agent': UA, 'Referer': HOST + '/' },
  };
}

// ==================== 路由注册（对齐 vod-routes/routes/guazi.js）====================
module.exports = async (app, opt) => {
  const handler = async (req) => {
    const q = Object.assign({}, (req && req.query) || {});
    if (req && req.body && typeof req.body === 'object' && Object.keys(req.body).length) q.body = req.body;
    try {
      if (q.play) return await _play({ id: q.play });
      if (q.wd) return await _search({ wd: q.wd, page: q.pg || q.page });
      if (q.ids) return await _detail({ ids: String(q.ids).split(',').map(v => v.trim()).filter(Boolean) });
      // 部分壳子分类请求会带 ac=detail&t=分类ID，有 t 就当分类（t 优先于 ac=detail）
      if (q.t) return await _category({ id: q.t, page: q.pg || q.page });
      if (q.ac === 'detail' && q.id) return await _detail({ ids: [q.id] });
      if (q.ac === 'play' && q.id) return await _play({ id: q.id });
      return await _home();
    } catch (e) {
      return { code: 500, msg: (e && e.message) || String(e), list: [] };
    }
  };

  app.get(meta.api, handler);
  app.post(meta.api, handler);

  if (opt && Array.isArray(opt.sites)) opt.sites.push(meta);
};

module.exports.meta = meta;
