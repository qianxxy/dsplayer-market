/**
 * 央視網 - Fastify T4 JS 直播源
 * ============================================================================
 * 站点：https://tv.cctv.com/live/
 *
 * 频道列表：内置 cctv.json 静态数据（20 个频道）
 * 播放：通过 vdnx.live.cntv.cn API 获取 HLS 直播流
 * 参考：【直播】看潮州.js 的标准 T4 VOD 格式
 * ============================================================================
 */

const axios = require("axios");
const http = require("http");
const https = require("https");
const crypto = require("crypto");

// ==================== HTTP 客户端 ====================
const _http = axios.create({
  timeout: 10 * 1000,
  httpsAgent: new https.Agent({
    keepAlive: true,
    rejectUnauthorized: false,
    secureOptions: crypto.constants.SSL_OP_LEGACY_SERVER_CONNECT
      | crypto.constants.SSL_OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION,
  }),
  httpAgent: new http.Agent({ keepAlive: true }),
  maxRedirects: 5,
});

// ==================== 配置 ====================
const CONFIG = {
  key: "CCTVLive",
  name: "[直播]央視網",
  host: "https://tv.cctv.com",
  api: "/video/CCTVLive",
  debug: true,
  playUrl: "https://vdnx.live.cntv.cn/api/v3/vdn/live",
  playSecret: "a4220a71b31746908fa3e7fdd7a6852a",
  ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36",
};

const _logo = (hash) =>
  `https://resources.yangshipin.cn/assets/oms/image/202306/${hash}.png?imageMogr2/thumbnail/640x320/format/png`;

// ==================== 内置频道列表 ====================
const CHANNELS = [
  { id: "cctv1", name: "CCTV-1 综合", logo: _logo("d57905b93540bd15f0c48230dbbbff7ee0d645ff539e38866e2d15c8b9f7dfcd") },
  { id: "cctv2", name: "CCTV-2 财经", logo: _logo("20115388de0207131af17eac86c33049b95d69eaff064e55653a1b941810a006") },
  { id: "cctv3", name: "CCTV-3 综艺", logo: _logo("7b7a65c712450da3deb6ca66fbacf4f9aee00d3f20bd80eafb5ada01ec63eb3a") },
  { id: "cctv4", name: "CCTV-4 中文国际（亚）", logo: _logo("f357e58fdbcc076a3d65e1f958c942b2e14f14342c60736ceed98b092d35356a") },
  { id: "cctv5", name: "CCTV-5 体育", logo: _logo("0a6a7138952675983a3d854df7688557b286d59aa06166edae51506f9204d655") },
  { id: "cctv5plus", name: "CCTV-5+ 体育赛事", logo: _logo("0a6a7138952675983a3d854df7688557b286d59aa06166edae51506f9204d655") },
  { id: "cctv6", name: "CCTV-6 电影", logo: _logo("741515efda91f03f455df8a7da4ee11fa9329139c276435cf0a9e2af398d5bf2") },
  { id: "cctv7", name: "CCTV-7 国防军事", logo: _logo("b29af94e295ebdf646cefb68122c429b9cd921f498ca20d2d8070252536f9ff9") },
  { id: "cctv8", name: "CCTV-8 电视剧", logo: _logo("ad51de94426a0ba039e6dd6a8534ea98ecc813a6176bde87b4f18cc34d6d7590") },
  { id: "cctvjilu", name: "CCTV-9 紀录", logo: _logo("2ed1b4deeca179d5db806bb941790f82eb92a1b7299c1c38fe027f95a5caee5e") },
  { id: "cctv10", name: "CCTV-10 科教", logo: _logo("aa6157ec65188cd41826e5a2f088c3d6d153205f5f6428258d12c59999e221aa") },
  { id: "cctv11", name: "CCTV-11 戏曲", logo: _logo("ed12ed7c7a1034dae4350011fe039284c5d5a836506b28c9e32e3c75299625c0") },
  { id: "cctv12", name: "CCTV-12 社会与法", logo: _logo("484083cffaa40df7e659565e8cb4d1cc740158a185512114167aa21fa0c59240") },
  { id: "cctv13", name: "CCTV-13 新闻", logo: _logo("266da7b43c03e2312186b4a999e0f060e8f15b10d2cc2c9aa32171819254cf1a") },
  { id: "cctvchild", name: "CCTV-14 少儿", logo: _logo("af6b603896938dc346fbb16abfc63c12cba54b0ec9d18770a15d347d115f12d5") },
  { id: "cctv15", name: "CCTV-15 音乐", logo: _logo("2ceee92188ef684efe0d8b90839c4f3ad450d179dc64d59beff417059453af47") },
  { id: "cctv16", name: "CCTV-16 奥林匹克", logo: _logo("53793fa7bacd3a93ff6dc5d2758418985e1f952a316c335d663b572d8bdcd74d") },
  { id: "cctv17", name: "CCTV-17 农业农村", logo: _logo("ddef563072f8bad2bea5b9e52674cb7b4ed50efb20c26e61994dfbdf05c1e3c0") },
  { id: "cctveurope", name: "CCTV-4 中文国际（欧）", logo: _logo("f357e58fdbcc076a3d65e1f958c942b2e14f14342c60736ceed98b092d35356a") },
  { id: "cctvamerica", name: "CCTV-4 中文国际（美）", logo: _logo("f357e58fdbcc076a3d65e1f958c942b2e14f14342c60736ceed98b092d35356a") },
];

// ==================== 日志 ====================
let log = () => {};

// ==================== 工具 ====================
const safeStr = (v) => (v == null ? "" : String(v).trim());

// ==================== 播放解析 ====================
const resolveStream = async (channelId) => {
  log("▶️", "解析", channelId);

  if (!/^cctv(\d+|5plus|jilu|child|europe|america)$/i.test(channelId)) {
    throw new Error("无效频道ID: " + channelId);
  }

  const timestamp = Date.now();
  const nonce = Math.floor(Math.random() * 901) + 100;
  const digest = crypto
    .createHash("md5")
    .update(`${channelId}${timestamp}${nonce}${CONFIG.playSecret}`)
    .digest("hex");
  const authKey = `${timestamp}-${nonce}-${digest}`;
  const uid = Buffer.from(crypto.randomBytes(18)).toString("base64");

  const res = await _http.get(CONFIG.playUrl, {
    params: { channel: channelId, vn: "1", pdrm: "1", uid, hbss: String(timestamp) },
    headers: {
      "auth-key": authKey,
      Origin: CONFIG.host,
      Referer: CONFIG.host + "/",
      "User-Agent": CONFIG.ua,
      "X-Requested-With": "XMLHttpRequest",
    },
    validateStatus: () => true,
  });

  if (res.status !== 200) throw new Error(`HTTP ${res.status}`);
  const data = res.data;
  if (data.ack !== "yes") throw new Error("频道不可用");

  const manifest = data.manifest || {};
  const backup = data.backup || {};
  const location = manifest.hls_cdrm || backup.hls_cdrm;
  if (!location || !/^https?:\/\//.test(location)) {
    throw new Error("未获取到直播流");
  }

  log("✅", "直播流:", location.substring(0, 60) + "...");
  return location;
};

// ==================== 路由注册 ====================
const meta = {
  key: CONFIG.key,
  name: CONFIG.name,
  type: 4,
  api: CONFIG.api,
  searchable: 0,
  quickSearch: 0,
  filterable: 0,
  changeable: 0,
};

module.exports = async (app, opt) => {
  const fastifyLog = app?.log?.info?.bind(app?.log);
  log = CONFIG.debug
    ? (...args) => {
        const msg = args.map((a) => (typeof a === "object" ? JSON.stringify(a) : String(a))).join(" ");
        (fastifyLog || console.log)(`[央視網] ${msg}`);
      }
    : () => {};

  app.get(meta.api, async (req, res) => {
    const { ac, t, ids, play, filter } = req.query;
    try {
      // 播放：解析直播流地址
      if (play) {
        const channelId = safeStr(play);
        const url = await resolveStream(channelId);
        res.send({ parse: 0, jx: 0, playUrl: "", url, header: { "User-Agent": CONFIG.ua, "Referer": CONFIG.host + "/" } });
        return;
      }

      // 首页：分类 + 频道列表
      if (!ac) {
        const list = CHANNELS.map((ch) => ({
          vod_id: ch.id,
          vod_name: ch.name,
          vod_pic: ch.logo,
          vod_remarks: "直播",
        }));
        res.send({
          class: [{ type_id: "live", type_name: "央视直播" }],
          list: String(filter) === "false" ? list : [],
        });
        return;
      }

      // 分类：频道列表
      if (ac === "detail") {
        if (t) {
          const list = CHANNELS.map((ch) => ({
            vod_id: ch.id,
            vod_name: ch.name,
            vod_pic: ch.logo,
            vod_remarks: "直播",
          }));
          res.send({ list, page: 1, pagecount: 1, limit: list.length, total: list.length });
          return;
        }
        // 详情：频道 + 播放地址
        if (ids) {
          const id = String(ids).split(",")[0].trim();
          const ch = CHANNELS.find((c) => c.id === id) || CHANNELS[0];
          res.send({
            list: [{
              vod_id: ch.id,
              vod_name: ch.name,
              vod_pic: ch.logo,
              vod_remarks: "直播",
              vod_content: "央视网直播源",
              vod_play_from: "央视网",
              vod_play_url: `${ch.name}$${ch.id}`,
            }],
          });
          return;
        }
      }

      res.send(req.query);
    } catch (e) {
      log("❌", "错误", e.message);
      res.status(500).send({ code: 500, msg: e.message });
    }
  });

  opt.sites.push(meta);
  log("🚀", meta.name, "加载完成");
};
