// author: cupid
// 千千音乐 T4 源 - https://music.91q.com （太合音乐 / 千千音乐 Web API）
// 1) 签名：params + appid + timestamp(秒) → key 升序拼 "k=v&…" → md5(raw + SECRET) → sign，全部 GET 传参；
//    成功判定是 errno === 22000（不是 0），响应带 gzip，需自解
// 2) 分类：精选歌单（/v1/tracklist/list，官方 cateId/tagId 等参数实测全部无效 → 拉全量分页后本地按 cateList 过滤）、
//    歌手（/v1/artist/list，area/gender/initial 同样无效 → 只分页）、12 个关键词榜单（/v1/search type=1）
// 3) 详情：歌单 / 歌手 / 专辑 的"剧集列表"就是歌曲列表，四档音质各占一条线路（vod_play_from）；
//    单曲详情同理，一条线路一档音质
// 4) 播放：/v1/song/tracklink 直出 mp3/flac/aac 链接，parse:0 + music_player:1；
//    VIP 曲目 data.path 字段直接缺失（不是空串），只给 data.trail_audio_info.path —— 一个服务端另存的
//    30 秒独立小文件（实测 128K mp3 = 481115B ≈ 470KB，跟 data.size 声明的完整体积 59947598B 无关），
//    档位 3000/320/128/64 全试也一样，所以本地没有任何可解的密文，全曲只能靠账号权益让服务端下发 path；
//    需要时把登录态写进 qianqian.auth.json（详见下方"会员登录态"一节）
// 5) 排障：/video/qianqian?diag=1 返回接口耗时 / 取链 / 登录态 / 缓存 / 最近错误

const http = require('http');
const https = require('https');
const crypto = require('crypto');
const zlib = require('zlib');
const fs = require('fs');
const nodePath = require('path');

const SITE_NAME = '千千音乐';
const BUILD = '20260904-qq2';

let HOST = 'https://music.91q.com';
const ALT_HOSTS = ['https://api-qianqian.taihe.com']; // 前端 js 里的备用域名，同签名同路径
const REFERER = 'https://music.91q.com/';

const APPID = '16073360';
const SECRET = '0b50b02fd0d73a9c4c8c3a781c30845f';

let UA = 'Mozilla/5.0 (Linux; Android 10; TVBox) AppleWebKit/537.36 Chrome/124 Safari/537.36';
let REQ_TIMEOUT = 15000;
let SHOW_VIP = true; // ext 传 {"vip":0} 可只留免费歌曲

const OK_ERRNO = 22000;
const PAGE_SIZE = 20;
const SEARCH_PAGE_SIZE = 50; // 需要过滤 VIP 时多取一些再截断
const TL_PAGE_SIZE = 100; // /v1/tracklist/list 实测 pageSize 上限 100
const TL_MAX_PAGES = 15; // 本地过滤最多翻这么多原始页（总量 1120 条）
const TL_PARALLEL = 4;
const MAX_TRACKS = 200; // 单个详情最多挂多少首

// 音质档位，从高到低。3000 出 flac，320/128 出 mp3，64 出 aac
const RATES = [
  { k: '3000', n: '无损FLAC' },
  { k: '320', n: '极高320K' },
  { k: '128', n: '标准128K' },
  { k: '64', n: '省流64K' },
];

const KEYWORD_CLASSES = [
  ['新歌推荐', '新歌'],
  ['经典金曲', '经典'],
  ['怀旧老歌', '老歌'],
  ['英文歌曲', '英文'],
  ['说唱', '说唱'],
  ['古风', '古风'],
  ['民谣', '民谣'],
  ['摇滚', '摇滚'],
  ['电子音乐', '电子'],
  ['影视原声', '影视'],
  ['轻音乐', '轻音乐'],
  ['热门歌手', '歌手'],
];

// /v1/tracklist/category 的离线快照：接口挂了也要有筛选可用
const CATE_FALLBACK = [
  ['2367', '语种', '2368:华语,2369:欧美,2370:粤语,2371:日语,2372:韩语,2374:小语种'],
  ['2375', '风格', '2376:流行,2377:摇滚,2378:民谣,2379:电子,2380:影视原声,2381:ACG,2383:新世纪,2384:爵士,2385:古典,2386:乡村,2387:说唱,2388:世界音乐,2389:古风,2390:儿歌,2391:朋克,2392:布鲁斯,2393:RnB Soul,2394:金属,2396:英伦,2397:民族,2399:拉丁'],
  ['2400', '情感', '2401:快乐,2402:美好,2403:安静,2405:寂寞,2406:思念,2407:孤独,2408:怀旧,2409:悲伤,2410:感动,2411:治愈,2412:放松,2413:清新,2414:浪漫,2415:兴奋,2416:性感,2417:励志,2455:纯净'],
  ['2418', '场景', '2419:运动,2420:驾驶,2421:学习,2422:工作,2423:清晨,2424:夜晚,2425:午后,2426:游戏,2427:旅行,2428:散步,2429:酒吧,2430:夜店,2431:咖啡厅,2432:地铁,2433:校园,2435:约会,2436:休息,2456:减压'],
  ['2437', '主题', '2438:经典,2439:翻唱,2442:KTV,2444:网络歌曲,2445:器乐,2446:节日,2447:人群,2448:年代'],
];

const KIND_NAME = { song: '单曲', list: '歌单', art: '歌手', alb: '专辑' };

// ---------- 诊断收集 ----------
const DIAG = { errors: [] };

function noteErr(where, e) {
  const msg = e && (e.code || e.message) ? String(e.code || e.message) : String(e);
  DIAG.errors.push({ t: new Date().toISOString().slice(11, 19), where, msg });
  if (DIAG.errors.length > 20) DIAG.errors.shift();
  DIAG.lastAt = Date.now();
  return msg;
}

// 壳子里看不到日志，接口整体失败时用一张占位卡把原因显示在列表上
function recentFail() {
  return DIAG.lastAt && Date.now() - DIAG.lastAt < 20000;
}

function failCard() {
  const last = DIAG.errors[DIAG.errors.length - 1] || {};
  const why = `${last.where || '接口'} ${last.msg || '无数据'}`.trim();
  return {
    vod_id: '__diag__',
    vod_name: `⚠ ${SITE_NAME}取数失败`,
    vod_pic: '',
    vod_remarks: why.slice(0, 60),
  };
}

// ---------- 基础工具 ----------
function intOf(x, def = 0) {
  const n = parseInt(x, 10);
  return Number.isNaN(n) ? def : n;
}

// 名称里出现 $ # | 会破坏 vod_play_url 协议，必须先洗掉
function sanitize(text) {
  return String(text == null ? '' : text)
    .replace(/[$#|]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function fmtDur(sec) {
  const s = Math.max(0, intOf(sec, 0));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${String(m).padStart(2, '0')}:${String(r).padStart(2, '0')}`;
}

// 真实格式只能看直链后缀：接口 format 字段回显的是请求档位，
// VIP 试听链实际是 128K mp3，却仍会被标成 flac
const AUDIO_EXT = ['flac', 'mp3', 'aac', 'm4a', 'wav', 'ape', 'ogg', 'opus'];

function fmtOfUrl(url) {
  const path = String(url || '').split('?')[0].split('#')[0];
  const m = /\.([A-Za-z0-9]{2,5})$/.exec(path);
  const ext = m ? m[1].toLowerCase() : '';
  return AUDIO_EXT.includes(ext) ? ext : '';
}

function stripHtml(text) {
  return String(text == null ? '' : text)
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/[ \t]+/g, ' ')
    .trim();
}

function b64url(buf) {
  return Buffer.from(buf).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function unb64url(text) {
  const s = String(text || '').replace(/-/g, '+').replace(/_/g, '/');
  return Buffer.from(s + '='.repeat((4 - (s.length % 4)) % 4), 'base64');
}

function pack(kind, obj) {
  return kind + ':' + b64url(Buffer.from(JSON.stringify(obj), 'utf8'));
}

// 兼容三种 id：新版 kind:base64、python 版 song:base64({tsid,name})、裸 TSID
function unpack(value) {
  const s = String(value == null ? '' : value).trim();
  const m = /^(song|list|art|alb):(.+)$/.exec(s);
  if (m) {
    const kind = m[1];
    const tail = m[2];
    try {
      const obj = JSON.parse(unb64url(tail).toString('utf8'));
      if (obj && typeof obj === 'object') {
        return {
          kind,
          i: String(obj.i || obj.tsid || obj.id || obj.code || ''),
          n: String(obj.n || obj.name || obj.title || ''),
          a: String(obj.a || ''),
        };
      }
    } catch (e) {
      // 不是 base64/JSON，就当成裸 id
    }
    if (/^[A-Za-z0-9_-]+$/.test(tail)) return { kind, i: tail, n: '', a: '' };
  }
  return { kind: 'song', i: s, n: '', a: '' };
}

// ---------- 简易缓存 ----------
const CACHE_TTL = 30 * 60 * 1000;
const cache = new Map();

function cacheGet(key) {
  const hit = cache.get(key);
  if (hit && Date.now() < hit.expire) return hit.value;
  if (hit) cache.delete(key);
  return undefined;
}

function cacheSet(key, value, ttl = CACHE_TTL) {
  if (cache.size > 400) cache.clear();
  cache.set(key, { expire: Date.now() + ttl, value });
  return value;
}

// ---------- 请求层 ----------
const httpAgent = new http.Agent({ keepAlive: true, maxSockets: 16 });
const httpsAgent = new https.Agent({ keepAlive: true, maxSockets: 16, rejectUnauthorized: false });

function rawRequest(u, method, headers, body, timeout) {
  return new Promise((resolve, reject) => {
    const isHttps = u.protocol === 'https:';
    const mod = isHttps ? https : http;
    const options = {
      host: u.hostname,
      port: u.port ? Number(u.port) : (isHttps ? 443 : 80),
      method,
      path: u.pathname + (u.search || ''),
      headers,
      timeout: timeout || REQ_TIMEOUT,
      agent: isHttps ? httpsAgent : httpAgent,
    };
    if (isHttps) options.rejectUnauthorized = false;
    let settled = false;
    const fail = (e) => {
      if (settled) return;
      settled = true;
      reject(e);
    };
    try {
      const req = mod.request(options, (res) => {
        const chunks = [];
        res.on('data', (d) => chunks.push(d));
        res.on('error', fail);
        res.on('end', () => {
          if (settled) return;
          settled = true;
          let buf = Buffer.concat(chunks);
          const enc = String(res.headers['content-encoding'] || '').toLowerCase();
          try {
            if (enc === 'gzip' || enc === 'x-gzip') buf = zlib.gunzipSync(buf);
            else if (enc === 'deflate') buf = zlib.inflateSync(buf);
            else if (enc === 'br' && zlib.brotliDecompressSync) buf = zlib.brotliDecompressSync(buf);
          } catch (e) {
            // 解压失败保留原始字节，交给上层判断
          }
          resolve({ status: res.statusCode, headers: res.headers, data: buf });
        });
      });
      req.on('error', fail);
      req.on('timeout', () => {
        const e = new Error('timeout');
        e.code = 'ETIMEDOUT';
        req.destroy(e);
        fail(e);
      });
      if (body) req.end(body);
      else req.end();
    } catch (e) {
      fail(e);
    }
  });
}

async function request(url, opt = {}, depth = 0) {
  const u = new URL(url);
  const method = String(opt.method || 'GET').toUpperCase();
  const headers = Object.assign(
    {
      'User-Agent': UA,
      Accept: '*/*',
      'Accept-Language': 'zh-CN,zh;q=0.9',
      'Accept-Encoding': 'gzip, deflate',
    },
    opt.headers || {},
  );
  if (opt.body) headers['Content-Length'] = Buffer.byteLength(opt.body);
  const res = await rawRequest(u, method, headers, opt.body, opt.timeout);
  const loc = res.headers && res.headers.location;
  if (loc && res.status >= 300 && res.status < 400 && opt.follow !== false && depth < 4) {
    const keep = res.status === 307 || res.status === 308;
    return await request(new URL(loc, u).toString(), Object.assign({}, opt, {
      method: keep ? method : 'GET',
      body: keep ? opt.body : undefined,
    }), depth + 1);
  }
  return res;
}

// ---------- 会员登录态 ----------
// VIP 曲的完整地址是服务端按账号权益下发的：没有权益时 data.path 直接缺失，本地无从生成。
// 想听全曲只有一条路——把你自己（有会员的）账号登录态带上，让服务端自己把 path 发出来。
// 配置文件（任一存在即生效，改完 10 秒内自动热更新，删掉等于登出）：
//   <vod-routes>/qianqian.auth.json   或   <vod-routes>/routes/qianqian.auth.json
// {
//   "cookie":  "浏览器登录 music.91q.com 后整条 Cookie 原样粘进来",
//   "headers": { "Authorization": "..." },   // 可选：额外请求头，原样发送
//   "params":  { "userid": "12345678" }      // 可选：额外查询参数，会一起参与 sign 计算
// }
// 也支持偷懒写法：{"userid":"...","token":"..."} → 自动拼成 params.userid + Cookie
const AUTH_FILES = [
  nodePath.join(__dirname, '..', 'qianqian.auth.json'),
  nodePath.join(__dirname, 'qianqian.auth.json'),
];
let AUTH = { cookie: '', headers: {}, params: {}, src: '', stamp: '', checkedAt: 0, fromExt: false };

function authEmpty(a) {
  return !a.cookie && !Object.keys(a.headers).length && !Object.keys(a.params).length;
}

function hasAuth() {
  return !authEmpty(AUTH);
}

function normalizeAuth(cfg, src) {
  const a = { cookie: '', headers: {}, params: {}, src: src || '', stamp: '', checkedAt: Date.now(), fromExt: src === 'ext' };
  if (!cfg || typeof cfg !== 'object') return a;
  a.cookie = String(cfg.cookie || cfg.Cookie || '').trim();
  const copy = (from, to) => {
    if (!from || typeof from !== 'object') return;
    Object.keys(from).forEach((k) => {
      const v = from[k];
      if (v !== undefined && v !== null && v !== '') to[k] = String(v);
    });
  };
  copy(cfg.headers, a.headers);
  copy(cfg.params, a.params);
  const uid = cfg.userid || cfg.userId || cfg.uid;
  if (uid && !a.params.userid) a.params.userid = String(uid);
  const tk = cfg.token || cfg.access_token;
  if (tk && !a.params.token && !a.headers.token) a.params.token = String(tk);
  if (!a.cookie && a.params.userid && tk) a.cookie = `userid=${a.params.userid}; token=${tk}`;
  return a;
}

// 每 10 秒最多探一次文件，mtime+size 没变就不重读
function loadAuth() {
  if (AUTH.fromExt) return; // ext 显式给了凭据，文件不再覆盖
  const now = Date.now();
  if (now - AUTH.checkedAt < 10000) return;
  AUTH.checkedAt = now;
  for (let i = 0; i < AUTH_FILES.length; i += 1) {
    const f = AUTH_FILES[i];
    try {
      const st = fs.statSync(f);
      if (!st.isFile()) continue;
      const stamp = `${st.mtimeMs}:${st.size}`;
      if (AUTH.src === f && AUTH.stamp === stamp) return; // 没改动
      const a = normalizeAuth(JSON.parse(fs.readFileSync(f, 'utf8')), f);
      a.stamp = stamp;
      AUTH = a;
      cache.clear(); // 授权变了，旧的取链结果全部作废
      return;
    } catch (e) {
      if (!e || e.code !== 'ENOENT') noteErr('auth', e);
    }
  }
  if (AUTH.src) { // 配置文件被删掉 → 退回未登录
    AUTH = { cookie: '', headers: {}, params: {}, src: '', stamp: '', checkedAt: now, fromExt: false };
    cache.clear();
  }
}

// ---------- 签名 & 接口 ----------
function signParams(params) {
  const p = {};
  Object.keys(params || {}).forEach((k) => {
    const v = params[k];
    if (v !== undefined && v !== null && v !== '') p[k] = String(v);
  });
  p.appid = APPID;
  p.timestamp = String(Math.floor(Date.now() / 1000));
  const raw = Object.keys(p).sort().map((k) => `${k}=${p[k]}`).join('&');
  p.sign = crypto.createHash('md5').update(raw + SECRET, 'utf8').digest('hex');
  return p;
}

function apiUrl(host, path, signed) {
  const qs = Object.keys(signed).map((k) => `${encodeURIComponent(k)}=${encodeURIComponent(signed[k])}`).join('&');
  return host.replace(/\/+$/, '') + path + '?' + qs;
}

// 成功返回 data，业务错误或网络全挂返回 null（上层用 failCard 兜底）
async function api(path, params) {
  loadAuth();
  const hosts = [HOST].concat(ALT_HOSTS.filter((h) => h !== HOST));
  for (let hi = 0; hi < hosts.length; hi += 1) {
    for (let attempt = 0; attempt < 2; attempt += 1) {
      try {
        // 登录态参数必须一起进签名，否则服务端算出来的 sign 对不上
        const url = apiUrl(hosts[hi], path, signParams(Object.assign({}, AUTH.params, params)));
        const res = await request(url, {
          headers: Object.assign({
            Accept: 'application/json, text/plain, */*',
            Referer: REFERER,
            Origin: REFERER.replace(/\/$/, ''),
            from: 'web',
          }, AUTH.cookie ? { Cookie: AUTH.cookie } : {}, AUTH.headers),
          timeout: REQ_TIMEOUT,
        });
        const text = res.data.toString('utf8');
        let json = null;
        try {
          json = JSON.parse(text);
        } catch (e) {
          throw new Error(`bad json ${res.status} len=${text.length}`);
        }
        const errno = intOf(json.errno, -1);
        if (errno !== OK_ERRNO) {
          noteErr(path, new Error(`errno ${errno} ${String(json.errmsg || '').slice(0, 40)}`));
          return null; // 业务错误换域名/重试没意义
        }
        return json.data === undefined ? null : json.data;
      } catch (e) {
        noteErr(path, e);
      }
    }
  }
  return null;
}

async function apiCached(path, params, ttl = CACHE_TTL) {
  const key = path + '|' + JSON.stringify(params || {});
  const hit = cacheGet(key);
  if (hit !== undefined) return hit;
  const data = await api(path, params);
  if (data === null || data === undefined) return null; // 失败不写缓存
  return cacheSet(key, data, ttl);
}

async function fetchLyric(url) {
  const u = String(url || '').trim();
  if (!/^https?:\/\//i.test(u)) return '';
  const key = 'lrc|' + u;
  const hit = cacheGet(key);
  if (hit !== undefined) return hit;
  try {
    const res = await request(u, { headers: { Accept: '*/*', Referer: REFERER }, timeout: REQ_TIMEOUT });
    if (!res || res.status !== 200) return cacheSet(key, '', 5 * 60 * 1000);
    const text = res.data
      .toString('utf8')
      .replace(/\r/g, '')
      .split('\n')
      .map((l) => l.replace(/^(?:\[\d{1,3}:\d{1,2}(?:[.:]\d{1,3})?\])+/, '').trim())
      .filter((l) => l && !/^\[[a-z]+:.*\]$/i.test(l))
      .join('\n');
    return cacheSet(key, text.slice(0, 3000), CACHE_TTL);
  } catch (e) {
    noteErr('lyric', e);
    return '';
  }
}

// ---------- 曲目/卡片 ----------
function artistsOf(item) {
  const arr = item && Array.isArray(item.artist) ? item.artist : [];
  return arr.map((a) => (a && a.name ? String(a.name) : '')).filter(Boolean).join(' / ');
}

function isVipTrack(t) {
  return intOf(t && t.isVip, 0) === 1;
}

function availableRates(track) {
  const all = track && Array.isArray(track.allRate) ? track.allRate.map((r) => String(r)) : [];
  const hit = RATES.filter((r) => all.includes(r.k));
  return hit.length ? hit : RATES;
}

function unionRates(tracks) {
  const set = new Set();
  tracks.forEach((t) => {
    if (t && Array.isArray(t.allRate)) t.allRate.forEach((r) => set.add(String(r)));
  });
  const hit = RATES.filter((r) => set.has(r.k));
  return hit.length ? hit : RATES;
}

function songCard(track, prefix) {
  if (!track || !track.TSID) return null;
  const tsid = String(track.TSID);
  const name = sanitize(track.title || '未知歌曲');
  const who = sanitize(artistsOf(track));
  const album = sanitize(track.albumTitle || '');
  const head = isVipTrack(track) ? '[VIP] ' : '';
  const tail = [sanitize(prefix || ''), who || album].filter(Boolean).join(' · ');
  return {
    vod_id: pack('song', { i: tsid, n: name, a: who }),
    vod_name: name,
    vod_pic: String(track.pic || ''),
    vod_remarks: (head + tail).slice(0, 60),
  };
}

function listCard(item) {
  if (!item || !item.id) return null;
  const name = sanitize(item.title || '歌单');
  const tags = Array.isArray(item.tagList) ? item.tagList.map((x) => sanitize(x)).filter(Boolean) : [];
  const count = intOf(item.trackCount, 0);
  return {
    vod_id: pack('list', { i: String(item.id), n: name }),
    vod_name: name,
    vod_pic: String(item.pic || ''),
    vod_remarks: [count ? `${count}首` : '', tags.slice(0, 2).join(' ')].filter(Boolean).join(' · ').slice(0, 60),
  };
}

function artistCard(item) {
  const code = item && (item.artistCode || item.code || item.id);
  if (!code) return null;
  const name = sanitize(item.name || '歌手');
  const num = intOf(item.trackTotal || item.songNum, 0);
  return {
    vod_id: pack('art', { i: String(code), n: name }),
    vod_name: name,
    vod_pic: String(item.pic || ''),
    vod_remarks: ['歌手', num ? `${num}首` : '', sanitize(item.region || '')].filter(Boolean).join(' · ').slice(0, 60),
  };
}

function albumCard(item) {
  const code = item && (item.albumAssetCode || item.assetCode || item.code || item.id);
  if (!code) return null;
  const name = sanitize(item.title || '专辑');
  return {
    vod_id: pack('alb', { i: String(code), n: name }),
    vod_name: name,
    vod_pic: String(item.pic || ''),
    vod_remarks: ['专辑', sanitize(artistsOf(item)), String(item.releaseDate || '').slice(0, 4)].filter(Boolean).join(' · ').slice(0, 60),
  };
}

// ---------- 分类 & 筛选 ----------
function getClasses() {
  return [
    { type_id: 'tracklist', type_name: '精选歌单' },
    { type_id: 'artist', type_name: '歌手' },
  ].concat(KEYWORD_CLASSES.map(([name, kw]) => ({ type_id: 'kw_' + kw, type_name: name })));
}

async function buildFilters() {
  const key = 'filters';
  const hit = cacheGet(key);
  if (hit) return hit;
  const data = await apiCached('/v1/tracklist/category', {}, CACHE_TTL);
  const groups = Array.isArray(data) ? data : (data && Array.isArray(data.result) ? data.result : []);
  let items = groups
    .map((g) => {
      const gid = String((g && g.id) || '');
      const subs = g && Array.isArray(g.subCate) ? g.subCate : [];
      if (!gid || !subs.length) return null;
      const value = [{ n: '全部', v: '' }].concat(
        subs
          .map((s) => {
            const v = String((s && s.id) || '');
            if (!v) return null;
            const c = intOf(s.count, 0);
            return { n: sanitize(s.categoryName || v) + (c ? `(${c})` : ''), v };
          })
          .filter(Boolean),
      );
      return { key: 'c' + gid, name: sanitize(g.categoryName || '分类'), value };
    })
    .filter(Boolean);
  if (!items.length) {
    items = CATE_FALLBACK.map(([gid, gname, spec]) => ({
      key: 'c' + gid,
      name: gname,
      value: [{ n: '全部', v: '' }].concat(spec.split(',').map((p) => {
        const i = p.indexOf(':');
        return { n: p.slice(i + 1), v: p.slice(0, i) };
      })),
    }));
  }
  return cacheSet(key, { tracklist: items });
}

function extendOf(q) {
  const ext = {};
  if (q.f) {
    try {
      const obj = JSON.parse(q.f);
      if (obj && typeof obj === 'object') Object.assign(ext, obj);
    } catch (e) {
      // 忽略非法筛选串
    }
  }
  Object.keys(q || {}).forEach((k) => {
    if (/^c\d+$/.test(k) && q[k] !== undefined && q[k] !== null && q[k] !== '') ext[k] = q[k];
  });
  return ext;
}

function cateIdsOf(ext) {
  const ids = [];
  Object.keys(ext || {}).forEach((k) => {
    if (!/^c\d+$/.test(k)) return;
    String(ext[k] || '').split(/[,+\s]+/).forEach((x) => {
      const n = intOf(x, 0);
      if (n && !ids.includes(n)) ids.push(n);
    });
  });
  return ids;
}

function matchCate(item, ids) {
  const list = item && Array.isArray(item.cateList) ? item.cateList.map((x) => intOf(x, 0)) : [];
  return ids.every((id) => list.includes(id));
}

async function tracklistPage(pageNo, pageSize) {
  const d = await apiCached(
    '/v1/tracklist/list',
    { pageNo: String(pageNo), pageSize: String(pageSize) },
    CACHE_TTL,
  );
  if (!d) return { items: [], total: 0, more: false };
  return {
    items: Array.isArray(d.result) ? d.result : [],
    total: intOf(d.total, 0),
    more: intOf(d.haveMore, 0) === 1,
  };
}

// 官方筛选参数无效，只能翻页 + 本地过滤（原始页 100 条一缓存，翻页越翻越快）
async function filteredTracklist(page, ids) {
  const need = page * PAGE_SIZE + 1;
  const acc = [];
  let maxPages = TL_MAX_PAGES;
  let next = 1;
  while (next <= maxPages && acc.length < need) {
    const batch = [];
    for (let i = 0; i < TL_PARALLEL && next <= maxPages; i += 1, next += 1) batch.push(tracklistPage(next, TL_PAGE_SIZE));
    const results = await Promise.all(batch);
    let empty = false;
    results.forEach((r) => {
      if (r.total) maxPages = Math.min(TL_MAX_PAGES, Math.max(1, Math.ceil(r.total / TL_PAGE_SIZE)));
      if (!r.items.length) empty = true;
      r.items.forEach((it) => {
        if (matchCate(it, ids)) acc.push(it);
      });
    });
    if (empty) break;
  }
  const slice = acc.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  return { items: slice, more: acc.length > page * PAGE_SIZE };
}

async function getTracklistCategory(page, ext) {
  const ids = cateIdsOf(ext);
  if (!ids.length) {
    const r = await tracklistPage(page, PAGE_SIZE);
    const more = r.more || page * PAGE_SIZE < r.total;
    return pageResult(r.items.map(listCard).filter(Boolean), page, !more);
  }
  const r = await filteredTracklist(page, ids);
  return pageResult(r.items.map(listCard).filter(Boolean), page, !r.more);
}

async function getArtistCategory(page) {
  const d = await apiCached(
    '/v1/artist/list',
    { pageNo: String(page), pageSize: String(PAGE_SIZE) },
    10 * 60 * 1000,
  );
  const items = d && Array.isArray(d.result) ? d.result : [];
  const more = !!d && (intOf(d.haveMore, 0) === 1 || page * PAGE_SIZE < intOf(d.total, 0));
  return pageResult(items.map(artistCard).filter(Boolean), page, !more);
}

async function searchTracks(word, page) {
  const size = SHOW_VIP ? PAGE_SIZE : SEARCH_PAGE_SIZE;
  const d = await api('/v1/search', { word, type: '1', pageNo: String(page), pageSize: String(size) });
  if (!d) return { tracks: [], more: false, total: 0 };
  let tracks = Array.isArray(d.typeTrack) ? d.typeTrack : [];
  if (!SHOW_VIP) tracks = tracks.filter((t) => !isVipTrack(t));
  return {
    tracks: tracks.slice(0, PAGE_SIZE),
    more: intOf(d.haveMore, 0) === 1,
    total: intOf(d.total, 0),
  };
}

// ---------- 主流程 ----------
async function getHome() {
  const classes = getClasses();
  const [filters, hot] = await Promise.all([
    buildFilters().catch(() => ({})),
    searchTracks('新歌', 1).catch(() => ({ tracks: [] })),
  ]);
  let list = (hot.tracks || []).map((t) => songCard(t, '新歌')).filter(Boolean);
  if (!list.length && recentFail()) list = [failCard()];
  return { class: classes, filters, list, parse: 0, jx: 0 };
}

function pageResult(list, page, single = false) {
  let items = list;
  if (!items.length && page === 1 && recentFail()) items = [failCard()];
  const pagecount = single || items.length < PAGE_SIZE ? page : page + 1;
  return {
    list: items,
    page,
    pagecount,
    limit: PAGE_SIZE,
    total: pagecount > page ? 99999 : (page - 1) * PAGE_SIZE + items.length,
    parse: 0,
    jx: 0,
  };
}

async function getCategory(tid, pg = 1, ext = {}) {
  const page = Math.max(intOf(pg, 1), 1);
  const id = String(tid || '').trim();
  if (id === 'tracklist' || id === 'list' || id === 'gd') return await getTracklistCategory(page, ext);
  if (id === 'artist' || id === 'art' || id === 'gs') return await getArtistCategory(page);
  let kw = id;
  if (kw.startsWith('kw_')) kw = kw.slice(3);
  else if (kw.startsWith('search_')) kw = kw.slice(7); // 兼容 python 版分类 id
  const r = await searchTracks(kw, page);
  return pageResult(r.tracks.map((t) => songCard(t, kw)).filter(Boolean), page, !r.more);
}

async function doSearch(wd, pg = 1) {
  const page = Math.max(intOf(pg, 1), 1);
  const word = String(wd || '').trim();
  if (!word) return pageResult([], 1, true);
  const jobs = [searchTracks(word, page)];
  if (page === 1) {
    // 第一页顺带给出歌手 / 专辑入口卡，点进去就是整张歌单
    jobs.push(api('/v1/search', { word, type: '2', pageNo: '1', pageSize: '5' }));
    jobs.push(api('/v1/search', { word, type: '3', pageNo: '1', pageSize: '5' }));
  }
  const [main, ar, al] = await Promise.all(jobs);
  const list = (main.tracks || []).map((t) => songCard(t)).filter(Boolean);
  if (ar && Array.isArray(ar.typeArtist)) list.push(...ar.typeArtist.slice(0, 5).map(artistCard).filter(Boolean));
  if (al && Array.isArray(al.typeAlbum)) list.push(...al.typeAlbum.slice(0, 5).map(albumCard).filter(Boolean));
  return pageResult(list, page, !main.more);
}

// ---------- 详情 ----------
function episodeName(track, idx) {
  const name = sanitize(track.title || `第${idx + 1}首`);
  const who = sanitize(artistsOf(track));
  const tag = isVipTrack(track) ? ' [VIP]' : '';
  return `${String(idx + 1).padStart(2, '0')}.${name}${who ? ' - ' + who : ''}${tag}`.slice(0, 80);
}

function playLines(tracks) {
  const rates = unionRates(tracks);
  const from = [];
  const urls = [];
  rates.forEach((r) => {
    from.push(r.n);
    urls.push(tracks.map((t, i) => `${episodeName(t, i)}$a:${String(t.TSID)}:${r.k}`).join('#'));
  });
  return { from: from.join('$$$'), urls: urls.join('$$$') };
}

async function songDetail(rawId, info) {
  const tsid = info.i;
  const data = await api('/v1/song/tracklink', { TSID: tsid });
  const track = data && data.TSID ? data : { TSID: tsid, title: info.n, allRate: RATES.map((r) => r.k) };
  const title = sanitize(track.title || info.n || '未知歌曲');
  const who = sanitize(artistsOf(track) || info.a);
  const album = sanitize(track.albumTitle || '');
  const dur = intOf(track.duration, 0);
  const vip = isVipTrack(track);
  const rates = availableRates(track);
  const lyric = await fetchLyric(track.lyric);
  const from = rates.map((r) => r.n);
  const urls = rates.map((r) => `${title || '播放'}$a:${tsid}:${r.k}`);
  const content = [
    vip ? '[VIP 歌曲：一般仅 30 秒试听，少数曲目接口不给地址]' : '',
    '专辑：' + (album || '未知专辑'),
    who ? '歌手：' + who : '',
    dur ? '时长：' + fmtDur(dur) : '',
    lyric ? '\n' + lyric : '',
  ].filter(Boolean).join('\n');
  return {
    vod_id: rawId,
    vod_name: title + (vip ? ' [VIP]' : ''),
    vod_pic: String(track.pic || ''),
    type_name: '音乐',
    vod_actor: who,
    vod_director: album,
    vod_area: sanitize(track.lang || ''),
    vod_year: String(track.releaseDate || '').slice(0, 10),
    vod_remarks: [dur ? fmtDur(dur) : '', vip ? 'VIP试听' : ''].filter(Boolean).join(' · '),
    vod_content: content,
    vod_play_from: from.join('$$$') || SITE_NAME,
    vod_play_url: urls.join('$$$') || `${title || '播放'}$a:${tsid}:128`,
  };
}

async function bundleDetail(rawId, info) {
  const kind = info.kind;
  const meta = { name: info.n || KIND_NAME[kind] || SITE_NAME, pic: '', content: '', actor: '', remark: '', year: '', area: '' };
  let tracks = [];

  if (kind === 'list') {
    const d = (await apiCached('/v1/tracklist/info', { id: info.i }, 10 * 60 * 1000)) || {};
    tracks = Array.isArray(d.trackList) ? d.trackList : [];
    const tags = Array.isArray(d.tagList) ? d.tagList.map((x) => sanitize(x)).filter(Boolean) : [];
    meta.name = sanitize(d.title || meta.name);
    meta.pic = String(d.pic || '');
    meta.year = String(d.addDate || '').slice(0, 10);
    meta.area = '歌单';
    meta.remark = [tracks.length ? `${tracks.length}首` : '', tags.slice(0, 3).join(' ')].filter(Boolean).join(' · ');
    meta.content = [stripHtml(d.desc), tags.length ? '标签：' + tags.join(' / ') : ''].filter(Boolean).join('\n');
  } else if (kind === 'art') {
    const [a, songs] = await Promise.all([
      apiCached('/v1/artist/info', { artistCode: info.i }, 10 * 60 * 1000),
      apiCached('/v1/artist/songs', { artistCode: info.i, pageNo: '1', pageSize: '100' }, 10 * 60 * 1000),
    ]);
    const inf = a || {};
    tracks = songs && Array.isArray(songs.result) ? songs.result.slice() : [];
    const total = songs ? intOf(songs.total, 0) : 0;
    if (tracks.length >= 100 && total > tracks.length) {
      const p2 = await apiCached('/v1/artist/songs', { artistCode: info.i, pageNo: '2', pageSize: '100' }, 10 * 60 * 1000);
      if (p2 && Array.isArray(p2.result)) tracks = tracks.concat(p2.result);
    }
    meta.name = sanitize(inf.name || meta.name);
    meta.pic = String(inf.pic || '');
    meta.actor = meta.name;
    meta.area = sanitize(inf.region || '');
    meta.remark = [total || tracks.length ? `${total || tracks.length}首` : '', sanitize(inf.gender || '')].filter(Boolean).join(' · ');
    meta.content = stripHtml(inf.introduce).slice(0, 1500);
  } else {
    const d = (await apiCached('/v1/album/info', { albumAssetCode: info.i }, 10 * 60 * 1000)) || {};
    tracks = Array.isArray(d.trackList) ? d.trackList : [];
    meta.name = sanitize(d.title || meta.name);
    meta.pic = String(d.pic || '');
    meta.actor = sanitize(artistsOf(d));
    meta.year = String(d.releaseDate || '').slice(0, 10);
    meta.area = sanitize(d.lang || '');
    meta.remark = [tracks.length ? `${tracks.length}首` : '', sanitize(d.genre || '')].filter(Boolean).join(' · ');
    meta.content = stripHtml(d.introduce).slice(0, 1500);
  }

  tracks = tracks.filter((t) => t && t.TSID).slice(0, MAX_TRACKS);
  if (!tracks.length) {
    const why = (DIAG.errors[DIAG.errors.length - 1] || {}).msg || '接口没有返回曲目';
    return {
      vod_id: rawId,
      vod_name: meta.name,
      vod_pic: meta.pic,
      type_name: KIND_NAME[kind] || '音乐',
      vod_remarks: '无曲目',
      vod_content: `${KIND_NAME[kind] || ''}取数失败：${String(why).slice(0, 80)}`,
      vod_play_from: SITE_NAME,
      vod_play_url: '暂无曲目$a::128',
    };
  }
  const vipN = tracks.filter(isVipTrack).length;
  const lines = playLines(tracks);
  return {
    vod_id: rawId,
    vod_name: meta.name,
    vod_pic: meta.pic || String(tracks[0].pic || ''),
    type_name: KIND_NAME[kind] || '音乐',
    vod_actor: meta.actor || sanitize(artistsOf(tracks[0])),
    vod_director: '',
    vod_area: meta.area,
    vod_year: meta.year,
    vod_remarks: meta.remark || `${tracks.length}首`,
    vod_content: [vipN ? `[含 ${vipN} 首 VIP 歌曲：一般仅 30 秒试听]` : '', meta.content].filter(Boolean).join('\n'),
    vod_play_from: lines.from,
    vod_play_url: lines.urls,
  };
}

async function getDetail(ids) {
  const rawId = String((Array.isArray(ids) ? ids[0] : ids) || '').trim();

  if (rawId === '__diag__') {
    const d = await diagnose().catch((e) => ({ error: noteErr('diag', e) }));
    return {
      list: [{
        vod_id: '__diag__',
        vod_name: `${SITE_NAME}诊断`,
        vod_pic: '',
        type_name: '诊断',
        vod_remarks: BUILD,
        vod_content: JSON.stringify(d, null, 1).slice(0, 4000),
        vod_play_from: '诊断',
        vod_play_url: '无播放$a::128',
      }],
      parse: 0,
      jx: 0,
    };
  }

  const info = unpack(rawId);
  try {
    if (info.kind === 'list' || info.kind === 'art' || info.kind === 'alb') {
      return { list: [await bundleDetail(rawId, info)], parse: 0, jx: 0 };
    }
    return { list: [await songDetail(rawId, info)], parse: 0, jx: 0 };
  } catch (e) {
    const why = noteErr('detail', e);
    const tsid = info.i || rawId;
    return {
      list: [{
        vod_id: rawId,
        vod_name: sanitize(info.n) || SITE_NAME,
        vod_pic: '',
        type_name: '音乐',
        vod_remarks: '详情异常',
        vod_content: '详情获取失败：' + why,
        vod_play_from: SITE_NAME,
        vod_play_url: `播放$a:${tsid}:128`,
      }],
      parse: 0,
      jx: 0,
    };
  }
}

// ---------- 播放 ----------
// 播放 id 形如 a:{TSID}:{rate}
function splitPlayId(x) {
  const s = String(x || '').trim();
  const m = /^a:([^:]*):?(\d*)$/.exec(s);
  if (m) return { tsid: m[1], rate: m[2] || '' };
  const parts = s.split(':');
  if (parts.length >= 2) return { tsid: parts[parts.length - 2], rate: parts[parts.length - 1] };
  return { tsid: s, rate: '' };
}

async function getPlay(playId) {
  const header = { 'User-Agent': UA, Referer: REFERER };
  const { tsid, rate } = splitPlayId(playId);
  if (!tsid) return { parse: 0, jx: 0, url: '', playUrl: '', header, message: '播放参数为空' };

  const tried = new Set();
  let allRate = null;
  let lastData = null;
  let vipMiss = 0;
  const MAX_TRY = 5;
  const attempt = async (r) => {
    const key = String(r || '');
    if (tried.has(key) || tried.size >= MAX_TRY) return null;
    tried.add(key);
    const params = key ? { TSID: tsid, rate: key } : { TSID: tsid };
    const d = await api('/v1/song/tracklink', params);
    if (!d) return null;
    lastData = d;
    if (Array.isArray(d.allRate) && !allRate) allRate = d.allRate.map((x) => String(x));
    const direct = String(d.path || '');
    if (direct) return { url: direct, trial: null, data: d };
    const trial = d.trail_audio_info || d.trailAudioInfo || {};
    const tp = String(trial.path || '');
    if (tp) return { url: tp, trial, data: d };
    if (intOf(d.isVip, 0) === 1) vipMiss += 1;
    return null;
  };

  let hit = await attempt(rate);
  if (!hit) hit = await attempt('');
  // 试听链是否存在只跟曲目授权有关、跟档位无关，连着两档都没地址就别再换档了
  if (!hit && vipMiss < 2) {
    for (const r of (allRate || RATES.map((x) => x.k))) {
      hit = await attempt(r);
      if (hit || vipMiss >= 2) break;
    }
  }
  if (!hit) {
    if (lastData && intOf(lastData.isVip, 0) === 1) {
      const why = hasAuth()
        ? '当前账号无此曲权益，接口未提供试听地址'
        : '需会员：未配置登录态（qianqian.auth.json），且接口未提供试听地址';
      return { parse: 0, jx: 0, url: '', playUrl: '', header, message: '[VIP] ' + why };
    }
    const why = (DIAG.errors[DIAG.errors.length - 1] || {}).msg || '接口未返回音频地址';
    return { parse: 0, jx: 0, url: '', playUrl: '', header, message: '取链失败：' + String(why).slice(0, 60) };
  }

  const d = hit.data || {};
  const trial = hit.trial;
  const fmt = fmtOfUrl(hit.url) || (trial ? '' : String(d.format || ''));
  const kbps = intOf(trial ? trial.rate : d.rate, 0);
  const secs = trial ? (intOf(trial.duration, 30) || 30) : 0;
  const vip = intOf(d.isVip, 0) === 1;
  let msg;
  if (trial) {
    // 试听链是服务端另存的独立小文件（实测 128K/30 秒 ≈ 470KB），不是完整文件被截断，本地补不出全曲
    msg = `[VIP] 仅 ${secs} 秒试听 · ${kbps || 128}K ${(fmt || 'mp3').toUpperCase()}`;
    if (!hasAuth()) msg += ' · 配置会员登录态可听全曲';
  } else if (vip) {
    msg = `[VIP] 会员完整版 · ${kbps ? kbps + 'K ' : ''}${(fmt || '').toUpperCase()}`.trim();
  }
  return {
    parse: 0,
    jx: 0,
    url: hit.url,
    playUrl: '',
    music_player: 1,
    format: fmt || undefined,
    header,
    message: msg,
  };
}

// ---------- 诊断 ----------
async function diagnose() {
  loadAuth();
  const t0 = Date.now();
  const s = await api('/v1/search', { word: '新歌', type: '1', pageNo: '1', pageSize: '5' });
  const searchMs = Date.now() - t0;
  const tracks = s && Array.isArray(s.typeTrack) ? s.typeTrack : [];

  // 免费曲验证真实取链，VIP 曲单独探一次：有的给 30 秒试听、有的完全不给地址
  const probeLink = async (t) => {
    if (!t || !t.TSID) return null;
    const t1 = Date.now();
    const d = await api('/v1/song/tracklink', { TSID: String(t.TSID), rate: '3000' });
    const ms = Date.now() - t1;
    if (!d) return { ms, ok: false, title: sanitize(t.title || '') };
    const trial = d.trail_audio_info || d.trailAudioInfo || {};
    const url = String(d.path || trial.path || '');
    return {
      ms,
      ok: !!url,
      title: d.title,
      isVip: intOf(d.isVip, 0),
      has_path: !!d.path, // 完整地址是否被服务端下发（VIP 曲没有权益时这里恒为 false）
      full_size: intOf(d.size, 0), // 服务端声明的完整文件大小，可跟实际下载体积对照
      api_format: String(d.format || ''),
      real_format: fmtOfUrl(url),
      real_rate: intOf(trial.rate || d.rate, 0),
      trial: !d.path && !!trial.path,
      trial_secs: intOf(trial.duration, 0),
      url: url.slice(0, 110),
    };
  };
  const freeT = tracks.find((t) => !isVipTrack(t)) || tracks[0];
  const vipT = tracks.find(isVipTrack);
  const link = await probeLink(freeT);
  const vipLink = vipT && (!freeT || String(vipT.TSID) !== String(freeT.TSID)) ? await probeLink(vipT) : null;

  const t2 = Date.now();
  const cate = await api('/v1/tracklist/category', {});
  const cateMs = Date.now() - t2;
  const t3 = Date.now();
  const tl = await api('/v1/tracklist/list', { pageNo: '1', pageSize: '5' });
  const tlMs = Date.now() - t3;

  return {
    site: SITE_NAME,
    build: BUILD,
    node: process.version,
    host: HOST,
    alt: ALT_HOSTS,
    show_vip: SHOW_VIP,
    timeout: REQ_TIMEOUT,
    auth: {
      loaded: hasAuth(),
      src: AUTH.src || (AUTH.fromExt ? 'ext' : ''),
      cookie_bytes: AUTH.cookie ? AUTH.cookie.length : 0,
      sign_params: Object.keys(AUTH.params),
      extra_headers: Object.keys(AUTH.headers),
      files: AUTH_FILES,
      hint: hasAuth()
        ? '已带登录态；看 tracklink_vip.has_path 是否为 true 判断权益是否生效'
        : '未配置登录态，VIP 曲只能拿到 30 秒试听（服务端不下发完整 path）',
    },
    search: { ms: searchMs, n: tracks.length, first: tracks[0] ? tracks[0].title : null, vip: tracks.filter(isVipTrack).length },
    tracklink: link,
    tracklink_vip: vipLink,
    category: { ms: cateMs, groups: Array.isArray(cate) ? cate.length : 0 },
    tracklist: { ms: tlMs, total: tl ? intOf(tl.total, 0) : 0 },
    cache: cache.size,
    errors: DIAG.errors.slice(-8),
  };
}

// ---------- 入口 ----------
// ext 支持 {"site":"https://music.91q.com","vip":0,"timeout":20,"ua":"...","cookie":"...","params":{"userid":"..."}} 或直接一个域名
// 其中 cookie / headers / params / userid / token 为会员登录态，给了就优先于 qianqian.auth.json
function applyExt(ext) {
  if (!ext) return;
  const raw = String(ext).trim();
  let cfg = null;
  if (raw.startsWith('{')) {
    try {
      cfg = JSON.parse(raw);
    } catch (e) {
      return;
    }
  } else if (/^https?:\/\//i.test(raw)) {
    cfg = { site: raw };
  }
  if (!cfg || typeof cfg !== 'object') return;
  const a = normalizeAuth(cfg, 'ext');
  if (!authEmpty(a)) {
    const same = AUTH.fromExt && AUTH.cookie === a.cookie
      && JSON.stringify(AUTH.params) === JSON.stringify(a.params)
      && JSON.stringify(AUTH.headers) === JSON.stringify(a.headers);
    if (!same) {
      AUTH = a;
      cache.clear();
    }
  }
  const site = String(cfg.site || cfg.url || cfg.host || '').trim().replace(/\/+$/, '');
  if (site && /^https?:\/\//i.test(site) && site !== HOST) {
    HOST = site;
    cache.clear();
  }
  if (cfg.vip !== undefined) SHOW_VIP = !(cfg.vip === 0 || cfg.vip === '0' || cfg.vip === false || cfg.vip === 'false');
  if (cfg.timeout !== undefined) REQ_TIMEOUT = Math.max(5000, Math.min(60000, intOf(cfg.timeout, 15) * (intOf(cfg.timeout, 15) < 1000 ? 1000 : 1)));
  if (cfg.ua) UA = String(cfg.ua);
}

async function handle(req) {
  const q = req.query || {};
  applyExt(q.ext);
  if (q.diag) return await diagnose();
  const ac = q.ac;
  const isPlay = !!q.play || ac === 'play' || (!!q.flag && !!q.id);
  const wd = q.wd || q.key || q.keyword;
  const tid = q.t || q.type_id;
  // 分类请求同样带 ac=detail，只有明确 ids / 非分类 id 才当详情
  const ids = q.ids || (q.id && !isPlay && !tid ? q.id : '');
  if (isPlay) return await getPlay(q.play || q.id);
  if (ids) return await getDetail(ids);
  if (wd) return await doSearch(wd, q.pg || 1);
  if (tid && String(tid) !== '0') return await getCategory(tid, q.pg || 1, extendOf(q));
  return await getHome();
}

module.exports = async (app, opt) => {
  const path = '/video/qianqian';
  app.get(path, async (req) => await handle(req));
  app.get('/video/千千音乐', async (req) => await handle(req));
  opt.sites.push({
    key: 'qianqian',
    name: '[听]千千音乐',
    type: 4,
    api: path,
    searchable: 1,
    quickSearch: 1,
    filterable: 1,
    changeable: 0,
    ext: '',
  });
};
