const axios = require("axios");
const CryptoJS = require("crypto-js");
const { create } = require("xmlbuilder2");

// ==========================================
//          配置区 - 请按需填写
// ==========================================
const BILI_COOKIE = "";

const BILI_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Referer": "https://www.bilibili.com",
    "Cookie": BILI_COOKIE
};

const isLoggedIn = () => BILI_COOKIE && BILI_COOKIE.includes("SESSDATA=");

// ==========================================
//      MPD 生成函数（從 bilibili.js 移植）
// ==========================================
const getMpd = (dash, query) => {
    store.log.info(query);

    const root = create({ version: '1.0', encoding: 'UTF-8' })
        .ele('MPD', {
            'xmlns': 'urn:mpeg:dash:schema:mpd:2011',
            'profiles': 'urn:mpeg:dash:profile:isoff-on-demand:2011',
            'type': 'static',
            'minBufferTime': 'PT1.5S',
            'mediaPresentationDuration': `PT${dash.duration}S`
        })
        .ele('Period');

    if (dash.video) {
        // 🟢Start: 过滤逻辑 - 只保留最高画质的 H.264 轨道
        // 1. 筛选 H.264 (codecid 为 7 或 codecs 以 avc 开头)
        let targetVideos = dash.video.filter(v => v.codecid === 7 || (v.codecs && v.codecs.startsWith('avc')));

        // 2. 容错回退：如果视频里完全没有 H.264 (极少数情况)，则使用原始列表，避免黑屏
        if (targetVideos.length === 0) {
            targetVideos = dash.video;
        }

        // 3. 排序：优先级为 画质ID(id) > 码率(bandwidth) > 分辨率宽(width)
        // 降序排列，保证第一个就是最好的
        targetVideos.sort((a, b) => {
            if (b.id !== a.id) return b.id - a.id; // 画质等级 (如 120, 80, 64)
            if (b.bandwidth !== a.bandwidth) return (b.bandwidth || 0) - (a.bandwidth || 0); // 码率
            return (b.width || 0) - (a.width || 0); // 分辨率
        });

        // 4. 截取：只保留列表中的第一条 (即最高画质 H.264)
        if (targetVideos.length > 0) {
            dash.video = [targetVideos[0]];
        }
        // 🟢End: 过滤逻辑结束

        const adaptionSet = root.ele('AdaptationSet', {
            'mimeType': 'video/mp4', 'contentType': 'video',
            'subsegmentAlignment': 'true', 'subsegmentStartsWithSAP': '1'
        });
        dash.video.forEach((video, index) => {
            const representation = adaptionSet.ele('Representation', {
                'id': video.id,
                'codecs': video.codecs || 'avc1.64001E',
                'bandwidth': video.bandwidth,
                'width': video.width,
                'height': video.height,
                'frameRate': video.frame_rate
            });
            if (query.isEscape == "true") {
                video.baseUrl = video.baseUrl.replaceAll('&', '&amp;');
                // 🟢 这里使用了 .dat() 来生成 <![CDATA[ ]]> 包装
                representation.ele('BaseURL').dat(video.baseUrl).up();
            } else {
                representation.ele('BaseURL').txt(video.baseUrl || video.base_url).up();
            }
            if (video.SegmentBase?.Initialization) {
                representation.ele('SegmentBase', { 'indexRange': video.SegmentBase.indexRange })
                    .ele('Initialization', { 'range': video.SegmentBase.Initialization }).up().up();
            }
        });
    }

    if (dash.audio) {
        const adaptionSet = root.ele('AdaptationSet', {
            'mimeType': 'audio/mp4', 'contentType': 'audio',
            'subsegmentAlignment': 'true', 'subsegmentStartsWithSAP': '1'
        });
        dash.audio.forEach((audio, index) => {
            const representation = adaptionSet.ele('Representation', {
                'id': audio.id, 'codecs': audio.codecs || 'mp4a.40.2', 'bandwidth': audio.bandwidth
            });
            if (query.isEscape == "true") {
                audio.baseUrl = audio.baseUrl.replaceAll('&', '&amp;');
                // 🟢 这里使用了 .dat() 来生成 <![CDATA[ ]]> 包装
                representation.ele('BaseURL').dat(audio.baseUrl).up();
            } else {
                representation.ele('BaseURL').txt(audio.baseUrl || audio.base_url).up();
            }
            if (audio.SegmentBase?.Initialization) {
                representation.ele('SegmentBase', { 'indexRange': audio.SegmentBase.indexRange })
                    .ele('Initialization', { 'range': audio.SegmentBase.Initialization }).up().up();
            }
        });
    }
    return root.end({ prettyPrint: true });
};

// ==========================================
//          辅助函数
// ==========================================
const fixCover = (url) => {
    if (!url) return "";
    if (url.startsWith("//")) return "https:" + url;
    return url;
};

const formatDuration = (seconds) => {
    if (seconds <= 0) return '00:00';
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
};

const formatSearchDuration = (duration) => {
    const parts = duration.split(':');
    if (parts.length === 2) return duration;
    return '00:00';
};

function getRequestInfo(request) {
    const rawHeaders = request.raw?.rawHeaders || [];
    store.log.info(rawHeaders);
    
    const getHeader = (key) => {
        const index = rawHeaders.indexOf(key);
        return index !== -1 ? rawHeaders[index + 1] : null;
    };

    const host = getHeader('Host') || getHeader('host');
    const userAgent = getHeader('User-Agent') || getHeader('user-agent');
    const protocol = getHeader('X-Forwarded-Proto') || 'http';

    return {
        fullUrl: `${protocol}://${host}`,
        userAgent: userAgent || ""
    };
}

// ==========================================
//          分類 / 首頁 / 搜尋 等（保持原樣）
// ==========================================
const CLASSES = [
    { type_id: "沙雕仙逆", type_name: "傻屌仙逆" },
    { type_id: "沙雕动画", type_name: "沙雕动画" },
    { type_id: "纪录片超清", type_name: "纪录片" },
    { type_id: "演唱会超清", type_name: "演唱会" },
    { type_id: "音乐超清", type_name: "流行音乐" },
    { type_id: "美食超清", type_name: "美食" },
    { type_id: "食谱", type_name: "食谱" },
    { type_id: "体育超清", type_name: "体育" },
    { type_id: "球星", type_name: "球星" },
    { type_id: "中小学教育", type_name: "教育" },
    { type_id: "幼儿教育", type_name: "幼儿教育" },
    { type_id: "旅游", type_name: "旅游" },
    { type_id: "风景4K", type_name: "风景" },
    { type_id: "说案", type_name: "说案" },
    { type_id: "知名UP主", type_name: "知名UP主" },
    { type_id: "探索发现超清", type_name: "探索发现" },
    { type_id: "鬼畜", type_name: "鬼畜" },
    { type_id: "搞笑超清", type_name: "搞笑" },
    { type_id: "儿童超清", type_name: "儿童" },
    { type_id: "动物世界超清", type_name: "动物世界" },
    { type_id: "相声小品超清", type_name: "相声小品" },
    { type_id: "戏曲", type_name: "戏曲" },
    { type_id: "解说", type_name: "解说" },
    { type_id: "演讲", type_name: "演讲" },
    { type_id: "小姐姐超清", type_name: "小姐姐" },
    { type_id: "荒野求生超清", type_name: "荒野求生" },
    { type_id: "健身", type_name: "健身" },
    { type_id: "帕梅拉", type_name: "帕梅拉" },
    { type_id: "太极拳", type_name: "太极拳" },
    { type_id: "广场舞", type_name: "广场舞" },
    { type_id: "舞蹈", type_name: "舞蹈" },
    { type_id: "音乐", type_name: "音乐" },
    { type_id: "歌曲", type_name: "歌曲" },
    { type_id: "MV4K", type_name: "MV" },
    { type_id: "舞曲超清", type_name: "舞曲" },
    { type_id: "4K", type_name: "4K" },
    { type_id: "电影", type_name: "电影" },
    { type_id: "电视剧", type_name: "电视剧" },
    { type_id: "白噪音超清", type_name: "白噪音" },
    { type_id: "考公考证", type_name: "考公考证" },
    { type_id: "平面设计教学", type_name: "平面设计教学" },
    { type_id: "软件教程", type_name: "软件教程" },
    { type_id: "Windows", type_name: "Windows" }
];

const _home = async ({ filter }) => {
    return {
        class: CLASSES,
        list: [],
        filters: {
            '1001': [
                {
                    'key': 'sort',
                    'name': '排序',
                    'value': [
                        { 'n': '最新', 'v': 'new' },
                        { 'n': '最热', 'v': 'hot' },
                        { 'n': '推荐', 'v': 'recommend' }
                    ]
                }
            ]
        }
    };
};

const _homeVideo = async () => {
    const url = 'https://api.bilibili.com/x/web-interface/popular?ps=20&pn=1';
    try {
        const { data } = await axios.get(url, { headers: BILI_HEADERS });
        let videos = [];
        if (data.data && data.data.list) {
            videos = data.data.list.map(item => ({
                vod_id: item.aid + "",
                vod_name: item.title.replace(/<[^>]*>/g, ""),
                vod_pic: fixCover(item.pic),
                vod_remarks: formatDuration(item.duration)
            }));
        }
        return { list: videos };
    } catch (e) {
        store.log.error(e);
        return { list: [] };
    }
};

const _category = async ({ id, page, filter, filters }) => {
    page = Math.max(1, parseInt(page) || 1);
    const url = 'https://api.bilibili.com/x/web-interface/search/type';
    const params = {
        search_type: 'video',
        keyword: id,
        page: page
    };

    try {
        const { data } = await axios.get(url, { params, headers: BILI_HEADERS });
        let videos = [];
        if (data.data && data.data.result) {
            videos = data.data.result
                .filter(item => item.type === 'video')
                .map(item => ({
                    vod_id: item.aid + "",
                    vod_name: item.title.replace(/<[^>]*>/g, ""),
                    vod_pic: fixCover(item.pic),
                    vod_remarks: formatSearchDuration(item.duration)
                }));
        }
        const pageCount = data.data.numPages || 1;
        const total = data.data.numResults || videos.length;
        return {
            list: videos,
            page: page,
            pagecount: pageCount,
            limit: 20,
            total: total
        };
    } catch (e) {
        store.log.error(e);
        return { list: [] };
    }
};

const _detail = async ({ id }) => {
    const result = { list: [] };
    const ids = Array.isArray(id) ? id : [id];

    for (const vid of ids) {
        const url = 'https://api.bilibili.com/x/web-interface/view?aid=' + vid;
        try {
            const { data } = await axios.get(url, { headers: BILI_HEADERS });
            if (data.data) {
                const video = data.data;
                let playUrl = '';
                video.pages.forEach((page, index) => {
                    const part = page.part || `第${index + 1}集`;
                    playUrl += `${part}$${vid}_${page.cid}#`;
                });
                playUrl = playUrl.replace(/#$/g, '');

                const vod = {
                    vod_id: vid,
                    vod_name: video.title.replace(/<[^>]*>/g, ""),
                    vod_pic: fixCover(video.pic),
                    vod_content: video.desc,
                    vod_play_from: "B站视频",
                    vod_play_url: playUrl
                };
                result.list.push(vod);
            }
        } catch (e) {
            store.log.error(`Error fetching detail for ${vid}`, e);
        }
    }
    return result;
};

// ==========================================
//          播放邏輯（含代理 MPD 優先）
// ==========================================
const _play = async ({ flag, flags, id, req }) => {
    try {
        const parts = id.split('_');
        if (parts.length < 2) throw new Error("Invalid play id format");
        const avid = parts[0];
        const cid = parts[1];

        const loggedIn = isLoggedIn();
        const info = getRequestInfo(req);

        const availableQualities = [];
        const qualitySet = new Set();

        // ───────────── 優先加入 DASH 代理線路（需登入） ─────────────
        if (loggedIn) {
            const fullUrl = info.fullUrl;
            const isEscape = !info.userAgent.toLowerCase().includes("okhttp");
            const proxyUrl = `${fullUrl}${meta.api}/proxy?ac=proxy&ids=${avid}_${cid}&type=mpd&qn=127&fnval=4048&fourk=1&isEscape=${isEscape}`;

            availableQualities.push({
                name: 'DASH(代理)',
                url: proxyUrl,
                qn: info.userAgent && (info.userAgent.toLowerCase().includes("okhttp") || info.userAgent.toLowerCase().includes("dart")) ? 1000 : 10,           // 故意設最高，確保排第一
                priority: 10,
                isProxy: true
            });
        }

        const qualityNameMap = {
            127: '8K 超高清', 126: '杜比視界', 125: 'HDR 真彩色', 120: '4K 超清',
            116: '1080P60 高幀率', 112: '1080P+ 高碼率', 80: '1080P 高清',
            74: '720P60 高幀率', 64: '720P 高清', 32: '480P 清晰', 16: '360P 流暢'
        };

        const qualityList = loggedIn
            ? [127, 126, 125, 120, 116, 112, 80, 74, 64, 32, 16]
            : [80, 64, 32, 16];

        const headers = {
            ...BILI_HEADERS,
            "Referer": `https://www.bilibili.com/video/av${avid}`
        };

        // ───────────── 逐畫質嘗試（兜底直連） ─────────────
        for (const qn of qualityList) {
            const useDash = qn > 116;
            const params = {
                avid,
                cid,
                qn,
                fnval: useDash ? 4048 : 1,
                fourk: qn >= 120 ? 1 : 0,
                ...( !loggedIn ? { try_look: 1 } : {} )
            };

            try {
                const { data } = await axios.get('https://api.bilibili.com/x/player/playurl', {
                    params,
                    headers
                });

                if (data.code !== 0 || !data.data) continue;

                const r = data.data;
                const actualQn = r.quality || qn;

                if (qualitySet.has(actualQn)) continue;
                qualitySet.add(actualQn);

                if (r.dash) {
                    const bestVideo = r.dash.video?.sort((a,b) => (b.bandwidth||0) - (a.bandwidth||0))[0];
                    const bestAudio = r.dash.audio?.sort((a,b) => (b.bandwidth||0) - (a.bandwidth||0))[0];

                    if (bestVideo && bestAudio) {
                        availableQualities.push({
                            name: qualityNameMap[actualQn] || `DASH ${bestVideo.width||'?'}p`,
                            url: bestVideo.base_url || bestVideo.baseUrl,
                            audioUrl: bestAudio.base_url || bestAudio.baseUrl,
                            qn: actualQn,
                            isDash: true
                        });
                    }
                } else if (r.durl?.[0]?.url) {
                    availableQualities.push({
                        name: qualityNameMap[actualQn] || `画质${actualQn}`,
                        url: r.durl[0].url,
                        qn: actualQn,
                        isDash: false
                    });
                }
            } catch {}
        }

        if (availableQualities.length === 0) throw new Error("无法获取任何可用画质");

        // 按 qn 降序（代理最高 → DASH → MP4）
        availableQualities.sort((a, b) => b.qn - a.qn);

        const urlArray = [];
        availableQualities.forEach(q => {
            urlArray.push(q.name);
            urlArray.push(q.url);
        });

        const playResponse = {
            parse: 0,
            url: urlArray,
            header: {
                "User-Agent": headers["User-Agent"],
                "Referer": headers["Referer"],
                "Origin": "https://www.bilibili.com"
            },
            danmaku: `https://api.bilibili.com/x/v1/dm/list.so?oid=${cid}`
        };

        if (availableQualities[0]?.audioUrl) {
            playResponse.extra = { audio: availableQualities[0].audioUrl };
        }

        return playResponse;

    } catch (e) {
        store.log.error("Play error:", e.message);
        return { parse: 0, url: "", header: {}, danmaku: "" };
    }
};

const _proxy = async (req, reply) => {
    const id = req.query.ids;
    store.log.info(`[Proxy請求] IP: ${req.ip || '未知'} ids: ${id}`);

    if (reply.header) {
        reply.header('Access-Control-Allow-Origin', '*');
        reply.header('Access-Control-Allow-Methods', 'GET, OPTIONS');
        reply.header('Access-Control-Allow-Headers', 'Content-Type, Referer, User-Agent');
    }
    if (req.method === 'OPTIONS') {
        if (reply.code) reply.code(204);
        return reply.send ? reply.send('') : '';
    }

    const parts = id.split("_");
    if (parts.length < 2) {
        if (reply.code) reply.code(400);
        return "Invalid id format";
    }

    const avid = parts[0];
    const cid = parts[1];

    const url = `https://api.bilibili.com/x/player/playurl?avid=${avid}&cid=${cid}&qn=127&fnval=4048&fnver=0&fourk=1`;

    try {
        const response = await axios.get(url, { headers: BILI_HEADERS });
        const json = response.data;

        if (json.code === 0 && json.data?.dash) {
            const xml = getMpd(json.data.dash, req.query);
            if (reply.header) reply.header('Content-Type', 'application/dash+xml');
            return reply.send ? reply.send(xml) : xml;
        }
        else if (json.code === 0 && json.data?.durl?.[0]?.url) {
            if (reply.redirect) return reply.redirect(json.data.durl[0].url);
            return reply.send ? reply.send(json.data.durl[0].url) : json.data.durl[0].url;
        }
        else {
            store.log.error("Bilibili API error:", json);
            if (reply.code) reply.code(500);
            return JSON.stringify({ error: "API Error", msg: json.message || "未知錯誤" });
        }
    } catch (e) {
        store.log.error("[Proxy 網絡錯誤]:", e.message);
        if (reply.code) reply.code(500);
        return "Network Error";
    }
};

const _search = async ({ page, quick, wd }) => {
    return await _category({ id: wd, page });
};

const meta = {
    key: "bilibili_all",
    name: "哔哩大全[官]",
    type: 4,
    api: "/video/bilibili_all",
    searchable: 1,
    quickSearch: 1,
    changeable: 0,
};

const store = { init: false };

const init = async (server) => {
    if (store.init) return;
    store.log = server.log;
    store.init = true;
};

module.exports = async (app, opt) => {
    app.get(meta.api, async (req, reply) => {
        if (!store.init) await init(req.server);

        const { ac, pg, ids, flag, play, wd, t, ext, quick } = req.query;

        if (play) {
            return await _play({ flag: flag || "", flags: [], id: play, req });
        }
        if (wd) {
            return await _search({ page: parseInt(pg || "1"), quick: quick || false, wd });
        }
        if (!ac) {
            return await _home({ filter: false });
        }
        if (ac === "detail") {
            if (t) {
                return await _category({
                    id: t,
                    page: parseInt(pg || "1"),
                    filter: false,
                    filters: ext ? JSON.parse(Buffer.from(ext, 'base64').toString()) : {}
                });
            }
            if (ids) {
                return await _detail({ id: ids.split(",").map(v => v.trim()).filter(Boolean) });
            }
            return await _homeVideo();
        }
        return req.query;
    });

    app.get(`${meta.api}/proxy`, { attachValidation: true }, _proxy);

    opt.sites.push(meta);
};