"use strict"; module.exports = require("./appv7-client").createRoute({ key: "appv7fenzhu", name: "[影]粉猪秒播", configKey: "AppV7Fz" });
