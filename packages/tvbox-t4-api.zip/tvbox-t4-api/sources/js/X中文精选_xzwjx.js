// @name X中文精选
// @author 网络管家
// @version 1.1.3
// @description X中文精选不夜 T4 源：热播排行榜/热门关键词一级分类+二级筛选（全部关键词）、14站内分类、搜索、m3u8 直链播放；域名失效自动从发布页切换
// @domains www.xzwjx8.hair,xzwjx8.hair

const axios = require('axios');
const cheerio = require('cheerio');
const CryptoJS = require('crypto-js');
const http = require('http');
const https = require('https');

// ===== 域名防失效（2026-09-05 主人指令）=====
// 当前域名失效时自动从发布页拉取最新域名；发布页需非浏览器 UA（浏览器 UA 会命中广告跳转壳）
const BUILTIN_BASE = 'https://www.xzwjx8.hair';
const SITE_HOME_PATH = '/xzwjx/';
const PUBLISH_PAGES = [
  'http://ysl.3abu.com/2202/app/hot/332.php?key=***',
  'https://uce.avdby1.com/u/',
  'https://zid.avdby1.com/w/',
];
const PUB_UA = 'okhttp/4.9.0';
const BASE_TTL = 5 * 60 * 1000;
const BASE_REFRESH_COOLDOWN = 15 * 1000;

const API_PATH = '/video/xzwjx';
const UA = PUB_UA;

const meta = {
  key: 'xzwjx',
  name: '🔞┆X中文精选┆成人',
  type: 4,
  api: API_PATH,
  searchable: 1,
  quickSearch: 1,
  filterable: 1,
  changeable: 0,
};

// 14 个站内分类（/vodtype/20~33）+ 热播排行榜（总/月/周/日）+ 热门关键词（首页动态注入）
// 分类结构（2026-09-05 16:13 主人指令）：热播排行榜、热门关键词为一级分类排最前，二级选项走 filters/ext
const CLASSES = [
  { type_id: 'label:rank', type_name: '🔥热播排行榜' },
  { type_id: 'kw:all', type_name: '🔍热门关键词' },
  { type_id: '20', type_name: '国产精品' },
  { type_id: '21', type_name: '主播大秀' },
  { type_id: '22', type_name: '抖阴视频' },
  { type_id: '23', type_name: '女神学生' },
  { type_id: '24', type_name: '美熟少妇' },
  { type_id: '25', type_name: '娇妻素人' },
  { type_id: '26', type_name: '空姐模特' },
  { type_id: '27', type_name: '国产乱伦' },
  { type_id: '28', type_name: '自慰群交' },
  { type_id: '29', type_name: '野合车震' },
  { type_id: '30', type_name: '职场同事' },
  { type_id: '31', type_name: '国产名人' },
  { type_id: '32', type_name: '日本无码' },
  { type_id: '33', type_name: '精品三级' },
];

// 排行榜二级筛选：总/月/周/日 + 最新上传（/label/{v}.html）
const RANK_TABS = [
  { n: '总排行榜', v: 'hot' },
  { n: '月排行榜', v: 'hot_month' },
  { n: '周排行榜', v: 'hot_week' },
  { n: '日排行榜', v: 'hot_day' },
  { n: '最新上传', v: 'new' },
];

const client = axios.create({
  timeout: 18000,
  httpAgent: new http.Agent({ keepAlive: true, maxSockets: 16, maxFreeSockets: 8 }),
  httpsAgent: new https.Agent({ keepAlive: true, maxSockets: 16, maxFreeSockets: 8 }),
  headers: {
    'User-Agent': UA,
    Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'zh-CN,zh;q=0.9',
  },
  proxy: false,
  validateStatus: (s) => s >= 200 && s < 400,
  maxRedirects: 5,
});

// ===== 域名状态与切换 =====
let baseState = { base: BUILTIN_BASE, resolvedAt: 0 };
let lastRefreshAt = 0;

const nowMs = () => Date.now();
const isDomainHost = (host) => /^www\.xzwjx/i.test(host) || /xzwjx[0-9a-z]*\./i.test(host);

function extractDomainFromPublish(html) {
  const text = String(html || '');
  // ① dns-prefetch 内嵌域名
  let m = text.match(/dns-prefetch"\s+href="(https?:\/\/[^"'/\s]+)/i);
  if (m && isDomainHost(safeHost(m[1]))) return m[1];
  // ② input value="最新域名https://.../xzwjx/"
  m = text.match(/value="[^"]*?(https?:\/\/[^"'/\s]+)\/xzwjx\//i);
  if (m && isDomainHost(safeHost(m[1]))) return m[1];
  // ③ 混淆 JS："www.xzwjx8a@bhair"（a@b → .）
  m = text.match(/"(www\.xzwjx[0-9a-zA-Z@b.]+)"/);
  if (m) {
    const host = m[1].replace(/a@b/g, '.');
    if (isDomainHost(host)) return `https://${host}`;
  }
  return '';
}

function safeHost(url) {
  try { return new URL(url).hostname; } catch { return ''; }
}

async function fetchPublishDomain() {
  for (const pub of PUBLISH_PAGES) {
    try {
      const res = await client.get(pub, { responseType: 'text', timeout: 10000 });
      const domain = extractDomainFromPublish(res.data);
      if (domain) return domain;
    } catch { /* 尝试下一个发布页 */ }
  }
  return '';
}

function isValidSiteHtml(html) {
  const text = String(html || '');
  return text.length > 5000 && (text.includes('X中文精选') || text.includes('post-box'));
}

async function probeBase(base) {
  try {
    const res = await client.get(base + SITE_HOME_PATH, { responseType: 'text', timeout: 10000 });
    return res.status === 200 && isValidSiteHtml(res.data);
  } catch { return false; }
}

// 确保可用 base：缓存未过期直接用；过期/无效时依次 内置域名→发布页提取
async function ensureBase(force = false) {
  const fresh = !force && baseState.base && nowMs() - baseState.resolvedAt < BASE_TTL;
  if (fresh) return baseState.base;
  if (await probeBase(baseState.base)) {
    baseState = { base: baseState.base, resolvedAt: nowMs() };
    return baseState.base;
  }
  if (nowMs() - lastRefreshAt < BASE_REFRESH_COOLDOWN) return baseState.base;
  lastRefreshAt = nowMs();
  const domain = await fetchPublishDomain();
  if (domain && (await probeBase(domain))) {
    baseState = { base: domain, resolvedAt: nowMs() };
    return baseState.base;
  }
  baseState = { base: baseState.base, resolvedAt: nowMs() };
  return baseState.base;
}

// ===== HTML 缓存 =====
const HTML_CACHE_MAX = 80;
const htmlCache = new Map();
const htmlInflight = new Map();

function htmlCacheTtl() {
  return 5 * 60 * 1000;
}

function getCachedHtml(url) {
  const cached = htmlCache.get(url);
  if (!cached) return '';
  if (Date.now() >= cached.expiresAt) {
    htmlCache.delete(url);
    return '';
  }
  htmlCache.delete(url);
  htmlCache.set(url, cached);
  return cached.html;
}

function setCachedHtml(url, html) {
  htmlCache.delete(url);
  htmlCache.set(url, { html, expiresAt: Date.now() + htmlCacheTtl() });
  while (htmlCache.size > HTML_CACHE_MAX) htmlCache.delete(htmlCache.keys().next().value);
}

const cleanText = (value = '') => String(value).replace(/&nbsp;/gi, ' ').replace(/\s+/g, ' ').trim();
const safePage = (value) => Math.max(1, parseInt(value || '1', 10) || 1);

// 带域名切换的抓取：当前 base 失败/返回异常 → 切换域名重试一次
async function fetchHtml(path) {
  const urlOf = (base) => `${base}${path}`;
  const cached = getCachedHtml(urlOf(baseState.base));
  if (cached) return cached;

  const load = async (base) => {
    const res = await client.get(urlOf(base), { responseType: 'text' });
    if (res.status !== 200 || !res.data) throw new Error(`HTTP ${res.status}`);
    const html = String(res.data);
    if (!isValidSiteHtml(html)) throw new Error('site html invalid (ad shell/domain dead)');
    return html;
  };

  const pending = (async () => {
    let lastError;
    for (let attempt = 0; attempt < 2; attempt += 1) {
      const base = await ensureBase(attempt > 0);
      try {
        const html = await load(base);
        setCachedHtml(urlOf(base), html);
        return html;
      } catch (error) {
        lastError = error;
        if (attempt === 0) await new Promise((r) => setTimeout(r, 300));
      }
    }
    throw lastError;
  })();
  htmlInflight.set(path, pending);
  try {
    return await pending;
  } finally {
    htmlInflight.delete(path);
  }
}

// ===== 解析 =====
// 列表条目：<article class="post-box ..."><a href="/113xxxx.html"><div class="post-box-image" style="background-image: url(...);"></div>...<h2 class="post-box-title"><a>标题</a></h2><p>已有N人观看</p>
function parsePostList($) {
  const list = [];
  $('article.post-box').each((_, el) => {
    const node = $(el);
    const link = node.find('.post-box-title a[href], .post-box-container > a[href]').first().attr('href') || '';
    const match = String(link).match(/^\/(\d+)\.html$/);
    if (!match) return;
    const title = cleanText(node.find('.post-box-title a').first().text());
    if (!title) return;
    const style = node.find('.post-box-image').first().attr('style') || '';
    const picMatch = style.match(/url\((https?:\/\/[^)]+)\)/);
    const remarks = cleanText(node.find('p').first().text());
    list.push({
      vod_id: match[1],
      vod_name: title,
      vod_pic: picMatch ? picMatch[1] : '',
      vod_remarks: remarks,
    });
  });
  const seen = new Set();
  return list.filter((item) => {
    if (seen.has(item.vod_id)) return false;
    seen.add(item.vod_id);
    return true;
  });
}

// 分页：找「尾页」链接尾数字（/vodtype/20-552.html、/label/hot/page/4033.html、/s/xx/page/47.html）
function pageInfo($, fallbackPage, listLength) {
  let pagecount = 0;
  $('a').each((_, a) => {
    const text = cleanText($(a).text());
    if (text !== '尾页') return;
    const href = $(a).attr('href') || '';
    const m = href.match(/(\d+)\.html$/);
    if (m) pagecount = Math.max(pagecount, parseInt(m[1], 10) || 0);
  });
  if (!pagecount) pagecount = listLength > 0 ? fallbackPage : 1;
  return Math.max(1, pagecount);
}

// 全量关键词缓存（/label/more_keywords.html 全站搜索词，30min TTL）
let kwCache = { words: [], ts: 0 };
const KW_TTL = 30 * 60 * 1000;

async function loadAllKeywords(force = false) {
  if (!force && kwCache.words.length && Date.now() - kwCache.ts < KW_TTL) return kwCache.words;
  try {
    const html = await fetchHtml('/label/more_keywords.html');
    const $ = cheerio.load(html);
    const words = [];
    $('a[href^="/s/"]').each((_, a) => {
      const href = $(a).attr('href') || '';
      if (/\/s\/index\.html$/.test(href) || /\/page\//.test(href)) return;
      const word = cleanText($(a).text());
      if (word && !words.includes(word)) words.push(word);
    });
    if (words.length) kwCache = { words, ts: Date.now() };
  } catch { /* 拉取失败沿用旧缓存 */ }
  return kwCache.words;
}

// ext 解码（v1.1.2，2026-09-05 17:02 抓包定案）：客户端传 Base64(JSON)，如 {"rank":"hot"}/{"kw":"百合"}/{}
// 三级解析：Base64→JSON→取已知键；兼容明文直传；解码含控制字符回退明文
function decodeExt(raw) {
  const value = String(raw || '').trim();
  if (!value) return '';
  let decoded = value;
  if (/^[A-Za-z0-9+/=_-]+$/.test(value)) {
    try {
      const out = CryptoJS.enc.Base64.parse(value.replace(/-/g, '+').replace(/_/g, '/')).toString(CryptoJS.enc.Utf8);
      if (out && !/[\u0000-\u0008\u000e-\u001f]/.test(out)) decoded = out;
    } catch { /* 保持明文 */ }
  }
  const trimmed = decoded.trim();
  if (trimmed.startsWith('{') && trimmed.endsWith('}')) {
    try {
      const obj = JSON.parse(trimmed);
      if (obj && typeof obj === 'object') {
        for (const key of ['rank', 'kw', 'sub', 'v', 'value']) {
          if (obj[key] !== undefined && obj[key] !== null) return String(obj[key]);
        }
        return '';
      }
    } catch { /* 保持明文 */ }
  }
  return trimmed;
}

// ===== 业务接口 =====
async function home() {
  const html = await fetchHtml(SITE_HOME_PATH);
  const $ = cheerio.load(html);
  const list = parsePostList($);
  const keywords = await loadAllKeywords();
  const filters = {
    'label:rank': [{ key: 'rank', name: '', init: 'hot', value: RANK_TABS.map((t) => ({ n: t.n, v: t.v })) }],
    'kw:all': [{ key: 'kw', name: '', init: '', value: [{ n: '全部', v: '' }, ...keywords.map((w) => ({ n: w, v: w }))] }],
  };
  return {
    class: CLASSES,
    filters,
    list,
    page: 1,
    pagecount: 1,
    limit: list.length,
    total: list.length,
  };
}

// 类型路由：label:rank + ext(总/月/周/日/最新上传) → /label/{v}.html；kw:all + ext(关键词) → /s/{词}.html；20~33 → /vodtype/{id}(-pg).html
async function category(typeId, page, ext) {
  const tid = String(typeId || '20').trim();
  const pg = safePage(page);

  if (tid === 'label:rank') {
    const extValue = decodeExt(ext);
    const tab = RANK_TABS.find((t) => t.v === extValue) || RANK_TABS[0];
    const url = pg > 1 ? `/label/${tab.v}/page/${pg}.html` : `/label/${tab.v}.html`;
    const html = await fetchHtml(url);
    const $ = cheerio.load(html);
    const list = parsePostList($);
    const pagecount = pageInfo($, pg, list.length);
    return { list, page: pg, pagecount, limit: list.length, total: pagecount * list.length };
  }

  if (tid === 'kw:all') {
    const word = decodeExt(ext).trim();
    // 客户端「全部」选项传 {} → 回退站点首页最新列表（空列表体验差）
    if (!word) {
      const html = await fetchHtml(SITE_HOME_PATH);
      const $ = cheerio.load(html);
      const list = parsePostList($);
      return { list, page: pg, pagecount: pg > 1 ? 1 : 1, limit: list.length, total: list.length };
    }
    return search(word, pg);
  }

  if (tid.startsWith('label:')) {
    const label = tid.slice(6).replace(/[^a-z_]/g, '') || 'hot';
    const url = pg > 1 ? `/label/${label}/page/${pg}.html` : `/label/${label}.html`;
    const html = await fetchHtml(url);
    const $ = cheerio.load(html);
    const list = parsePostList($);
    const pagecount = pageInfo($, pg, list.length);
    return { list, page: pg, pagecount, limit: list.length, total: pagecount * list.length };
  }

  if (tid.startsWith('kw:')) {
    return search(tid.slice(3).trim(), pg);
  }

  const numeric = tid.replace(/\D/g, '') || '20';
  const url = pg > 1 ? `/vodtype/${numeric}-${pg}.html` : `/vodtype/${numeric}.html`;
  const html = await fetchHtml(url);
  const $ = cheerio.load(html);
  const list = parsePostList($);
  const pagecount = pageInfo($, pg, list.length);
  return { list, page: pg, pagecount, limit: list.length, total: pagecount * list.length };
}

function extractRawUrl(html) {
  const match = String(html).match(/const\s+rawUrl\s*=\s*'([^']+)'/);
  if (match) return match[1];
  const fallback = String(html).match(/(https?:\/\/[^\s'"$#]+\.m3u8(?:\?[^\s'"#]*)?)/i);
  return fallback ? fallback[1] : '';
}

async function detail(id) {
  const vid = String(id || '').trim();
  const html = await fetchHtml(`/${vid}.html`);
  const $ = cheerio.load(html);
  const title = cleanText($('h1.post-title').first().text())
    || cleanText($('title').first().text()).replace(/ - X中文精选\s*$/, '');
  const playUrl = extractRawUrl(html);
  if (!playUrl) return { list: [] };
  const typeName = cleanText($('.metadata a[rel="tag"]').first().text());
  const dateText = cleanText($('.metadata time.entry-date').first().text()).replace(/^更新时间：?/, '');
  const views = (String(html).match(/播放量：\s*(\d+)/) || [])[1] || '';
  const vod = {
    vod_id: vid,
    vod_name: title,
    type_name: typeName,
    vod_pic: '',
    vod_year: (dateText.match(/^\d{4}/) || [''])[0],
    vod_area: '',
    vod_actor: '',
    vod_director: '',
    vod_remarks: views ? `${views}次播放` : '',
    vod_content: '',
    vod_play_from: 'X中文精选',
    vod_play_url: `第1集$${playUrl}`,
  };
  return { list: [vod] };
}

async function play(url) {
  const input = String(url || '').trim();
  if (/^https?:\/\//i.test(input) && /\.m3u8(?:\?|$)/i.test(input)) {
    return { parse: 0, jx: 0, url: input, header: { 'User-Agent': UA, Referer: `${baseState.base}/` } };
  }
  const html = await fetchHtml(`/${input}.html`);
  const playUrl = extractRawUrl(html);
  if (playUrl) return { parse: 0, jx: 0, url: playUrl, header: { 'User-Agent': UA, Referer: `${baseState.base}/` } };
  return { parse: 1, jx: 1, url: `${baseState.base}/${input}.html` };
}

async function search(keyword, page) {
  const pg = safePage(page);
  const wd = encodeURIComponent(String(keyword || '').trim());
  const url = pg > 1 ? `/s/${wd}/page/${pg}.html` : `/s/${wd}.html`;
  const html = await fetchHtml(url);
  const $ = cheerio.load(html);
  const list = parsePostList($);
  const pagecount = pageInfo($, pg, list.length);
  return { list, page: pg, pagecount, limit: list.length, total: pagecount * list.length };
}

// fire-and-forget 预热（SOP 第5步：提供 init 语义的统一后台预热，不阻塞）
function startWarmup() {
  void (async () => {
    await ensureBase(true);
    const html = await fetchHtml(SITE_HOME_PATH);
    const $ = cheerio.load(html);
    const first = parsePostList($)[0];
    if (first) await fetchHtml(`/${first.vod_id}.html`);
    await loadAllKeywords(true);
  })().catch(() => {});
}

async function handle(req) {
  const query = req.query || {};
  const page = safePage(query.pg || query.page);
  const detailId = String(query.ids || query.id || query.vod_id || '').trim();
  if (query.play) return play(query.play);
  if (detailId) return detail(detailId);
  if (query.wd) return search(query.wd, page);
  if (query.t || query.ac === 'detail') return category(String(query.t || '20'), page, query.ext);
  return home();
}

module.exports = async (app, opt = {}) => {
  app.get(meta.api, async (req) => {
    try { return await handle(req); }
    catch (error) {
      req?.log?.warn?.({ msg: '[xzwjx] request failed', error: error?.message || String(error) });
      return { class: CLASSES, filters: {}, list: [], page: 1, pagecount: 1, limit: 0, total: 0, error: error?.message || String(error) };
    }
  });
  if (Array.isArray(opt.sites)) opt.sites.push(meta);
  startWarmup();
};
