// 【功能说明】觅盘（www.mipan.so）全网网盘资源聚合搜索，纯搜型不夜源；自建 token 鉴权 + PanSou 聚合接口。
// 【主要特征】搜索后按网盘类型分组（夸克/UC/百度/天翼/123/115/移动/迅雷/阿里/光鸭/PikPak），点分组进入该盘结果列表；详情走不夜统一驱动，播放交统一驱动；失效链接运行时盘检过滤。
// 【JSON 使用语法】{ "key": "mipan", "name": "🔍┆觅盘┆搜盘", "type": 4, "api": "/video/mipan", "searchable": 1, "quickSearch": 1, "filterable": 0, "changeable": 0 }
// 【分享说明】脱敏分享版：无账号、无 Cookie、无 Token 硬编码（token 运行时获取）；可直接分享。
const axios = require("axios");
const CryptoJS = require("crypto-js");
const dayjs = require("dayjs");
const { resolveCloudDriveVod, resolveCloudDrivePlay } = require("../../../../plugins/cloud-drive-client");
const { filterValidPanLinks, isPanUrl } = require("../../../../plugins/pan-link-validator");
const { searchPansoResources } = require("../../../../plugins/panso");

const HOST = "https://www.mipan.so";
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36";

const SITE = {
  key: "mipan",
  name: "🔍┆觅盘┆搜盘",
  api: "/video/mipan",
  driveKeys: ["quark", "uc", "baidu", "a189", "a123", "a115", "a139", "xunlei", "ali", "guangya", "pikpak"],
};

// 网盘图标（与生产源 蜗牛4K/盘搜分组 同源；store.drives 不带 pic，必须硬编码）
const PAN_PIC_BASE = "https://xget.xi-xu.me/gh/power721/alist-tvbox/raw/refs/heads/master/web-ui/public";
const PAN_PICS = {
  quark: `${PAN_PIC_BASE}/quark.png`,
  uc: `${PAN_PIC_BASE}/uc.png`,
  baidu: `${PAN_PIC_BASE}/baidu.jpg`,
  a189: `${PAN_PIC_BASE}/189.png`,
  a123: `${PAN_PIC_BASE}/123.png`,
  a115: `${PAN_PIC_BASE}/115.jpg`,
  a139: `${PAN_PIC_BASE}/139.jpg`,
  xunlei: `${PAN_PIC_BASE}/thunder.png`,
  ali: `${PAN_PIC_BASE}/ali.jpg`,
  guangya: `${PAN_PIC_BASE}/guangya.webp`,
  pikpak: `${PAN_PIC_BASE}/pikpak.jpg`,
};

const DRIVE_LABELS = {
  quark: "夸克网盘",
  uc: "UC网盘",
  baidu: "百度网盘",
  a189: "天翼云盘",
  a123: "123网盘",
  a115: "115网盘",
  a139: "移动云盘",
  xunlei: "迅雷网盘",
  ali: "阿里云盘",
  guangya: "光鸭网盘",
  pikpak: "PikPak",
};

const DRIVE_FLAG_ALIASES = {
  quark: ["quark", "夸克", "夸克网盘"],
  uc: ["uc", "uc网盘"],
  baidu: ["baidu", "百度", "百度网盘"],
  a189: ["a189", "189", "天翼", "天翼云盘", "tianyi"],
  a123: ["a123", "123", "123pan", "123网盘", "pan123"],
  a115: ["a115", "115", "115网盘", "pan115"],
  a139: ["a139", "139", "移动", "移动云盘", "cmcc", "mobile"],
  xunlei: ["xunlei", "迅雷", "迅雷网盘"],
  ali: ["ali", "阿里", "阿里云盘", "aliyun", "aliyundrive"],
  guangya: ["guangya", "guangyapan", "gy", "光鸭", "光鸭网盘"],
  pikpak: ["pikpak"],
};

const QUALITY_KEYWORDS = [
  "HDR", "杜比视界", "DV", "REMUX", "HQ", "臻彩", "高码", "高画质",
  "60FPS", "60帧", "高帧率", "60HZ", "4K", "2160P", "SDR", "1080P", "HD", "高清", "720P", "标清",
];
const COMPLETED_KEYWORDS = ["完结", "全集", "已完成", "全"];

const http = axios.create({
  baseURL: HOST,
  timeout: 20000,
  proxy: false,
  headers: {
    "User-Agent": UA,
    "Referer": HOST + "/",
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "zh-CN,zh;q=0.9",
  },
  validateStatus: () => true,
});

const init = async (server) => {
  if (store.init) return;
  store.redis = server.redis;
  store.log = server.log;
  store.drives = Array.isArray(server.drives) ? server.drives : [];
  store.init = true;
};

const clean = (value = "", max = 120) => String(value || "")
  .replace(/[#$]/g, " ")
  .replace(/\s+/g, " ")
  .trim()
  .slice(0, max);
const b64e = (v) => Buffer.from(typeof v === "string" ? v : JSON.stringify(v)).toString("base64url");
const b64d = (s) => { try { const t = Buffer.from(String(s || ""), "base64url").toString(); try { return JSON.parse(t); } catch { return t; } } catch { return s; } };

// mipan 返回的类型键（merged_by_type） → 不夜统一驱动 key
function mapDriveType(value = "", url = "") {
  const raw = String(value || "").trim().toLowerCase();
  if (raw === "quark") return "quark";
  if (raw === "uc") return "uc";
  if (raw === "baidu") return "baidu";
  if (raw === "tianyi" || raw === "189" || raw === "a189") return "a189";
  if (raw === "pan123" || raw === "123" || raw === "a123") return "a123";
  if (raw === "pan115" || raw === "115" || raw === "a115") return "a115";
  if (raw === "cmcc" || raw === "139" || raw === "mobile" || raw === "a139") return "a139";
  if (raw === "xunlei") return "xunlei";
  if (raw === "aliyun" || raw === "ali" || raw === "aliyundrive") return "ali";
  if (raw === "guangya" || raw === "guangyapan" || raw === "gy" || raw === "光鸭" || raw === "光鸭网盘") return "guangya";
  if (raw === "pikpak") return "pikpak";

  const low = String(url || "").toLowerCase();
  if (low.includes("pan.quark.cn") || low.includes("drive.quark.cn")) return "quark";
  if (low.includes("drive.uc.cn") || low.includes("fast.uc.cn")) return "uc";
  if (low.includes("pan.baidu.com")) return "baidu";
  if (low.includes("cloud.189.cn")) return "a189";
  if (["123pan.com", "123pan.cn", "123684.com", "123865.com", "123912.com", "123592.com"].some((host) => low.includes(host))) return "a123";
  if (low.includes("115.com") || low.includes("115cdn.com")) return "a115";
  if (low.includes("yun.139.com") || low.includes("caiyun.139.com")) return "a139";
  if (low.includes("pan.xunlei.com") || low.includes("xunlei.com")) return "xunlei";
  if (low.includes("aliyundrive.com") || low.includes("alipan.com")) return "ali";
  if (low.includes("guangyapan.com")) return "guangya";
  if (low.includes("pikpak.com")) return "pikpak";
  return "";
}

function driveKeyFromFlag(flag = "") {
  const raw = String(flag || "").trim().toLowerCase();
  for (const [key, aliases] of Object.entries(DRIVE_FLAG_ALIASES)) {
    if (aliases.some((alias) => raw === String(alias).toLowerCase())) return key;
  }
  return "";
}

function drivePic(key = "") {
  return PAN_PICS[key] || store.drives.find((drive) => drive?.key === key)?.pic || "";
}

// ==================== 影片海报补全（本地 PanSou images 优先，豆瓣兜底） ====================
// 觅盘 API 只回 url/password/note/datetime/source，不含图片；
// 这里复用 百度盘搜 同源的本地 PanSou（images[0]）按 url / 清洗片名匹配补图，缺失再走豆瓣。
const TITLE_PREFIX_RE = /^(国漫|动漫|动画|电视剧|电影|综艺|纪录片|更新|推荐|全网|资源|热播|高分|最新|顶配|收藏|分享|漫剧|短剧|美剧|韩剧|日剧|港剧|泰剧|剧集|合集|自制|首发|独家)/;
const TITLE_NOISE_RE = /(4k|2160p|1080p|720p|\bhd\b|hdr|杜比视界|杜比|remux|臻彩|高码|高画质|60fps|60帧|更新至?.{0,4}[集话期]|完结|全集|全\d+[集话期]|第[一二三四五六七八九十\d]+[季部]|年番\d?|s\d+e\d+|web|sdr|国语|中字|简体|繁体|字幕|剧场版|max|双语|超清|原画|无删减|标题|名称|资源)/i;

const normUrl = (u = "") => String(u || "").split("?")[0].split("#")[0].replace(/\/+$/, "").trim();

function coreTitle(s = "") {
  let t = String(s || "");
  t = t.replace(/[\[\(（【].*?[\]\)）】]/g, " ");
  t = t.replace(/[\u2600-\u27bf\u{1F300}-\u{1FAFF}#＃]/gu, " ");
  t = t.replace(TITLE_PREFIX_RE, " ").replace(TITLE_NOISE_RE, " ");
  const m = t.match(/[\u4e00-\u9fff]{2,}/);
  return m ? m[0].slice(0, 8) : "";
}

async function buildPansouPosterMap(req, keyword) {
  const out = { url: {}, title: {} };
  const resp = await searchPansoResources(keyword, {
    request: req,
    fastify: req?.server || { log: store.log || {} },
    titleMode: "clean",
  }).catch(() => null);
  for (const r of (resp?.resources || [])) {
    const img = (Array.isArray(r.images) ? r.images[0] : "") || r.poster || r.image || "";
    if (!img) continue;
    if (r.url) out.url[normUrl(r.url)] = img;
    const ct = coreTitle(r.note || r.title || "");
    if (ct) out.title[ct] = out.title[ct] || img;
  }
  return out;
}

async function doubanLookup(title, req) {
  const key = `mipan:poster:${CryptoJS.MD5(title)}`;
  const redis = store.redis;
  try {
    if (redis?.get) {
      const cached = await redis.get(key);
      if (cached) { const p = JSON.parse(cached); return p.img || ""; }
    }
  } catch (_) { /* ignore */ }
  let img = "";
  try {
    const res = await http.get("https://movie.douban.com/j/subject_suggest", {
      params: { q: title },
      headers: {
        "User-Agent": UA,
        "Referer": "https://movie.douban.com/",
        "Accept": "application/json, text/javascript, */*; q=0.01",
      },
      timeout: 6000,
      validateStatus: () => true,
    });
    if (res?.status === 200 && Array.isArray(res.data) && res.data[0]?.img) {
      img = String(res.data[0].img).replace(/\\\//g, "/");
      if (img.startsWith("http://")) img = "https://" + img.slice(7);
    }
  } catch (_) { /* ignore */ }
  try {
    if (redis?.set) {
      await redis.set(key, JSON.stringify({ img }));
      if (redis?.expire) await redis.expire(key, img ? 2592000 : 86400);
    }
  } catch (_) { /* ignore */ }
  return img;
}

async function mapLimit(items, limit, fn) {
  const out = new Array(items.length);
  let i = 0;
  const workers = Array.from({ length: Math.max(1, Math.min(limit, items.length)) }, async () => {
    while (i < items.length) { const idx = i++; out[idx] = await fn(items[idx]); }
  });
  await Promise.all(workers);
  return out;
}

async function attachPosters(rows, req, keyword) {
  if (!rows.length) return;
  const map = await buildPansouPosterMap(req, keyword);
  for (const row of rows) {
    row.poster = map.url[normUrl(row.url)] || map.title[coreTitle(row.title)] || "";
  }
  const seen = new Set();
  const missing = [];
  for (const row of rows) {
    if (row.poster) continue;
    const ct = coreTitle(row.title);
    if (ct && !seen.has(ct)) { seen.add(ct); missing.push(ct); }
  }
  if (!missing.length) return;
  const picks = missing.slice(0, 16);
  const imgs = await mapLimit(picks, 4, (t) => doubanLookup(t, req));
  const dic = {};
  picks.forEach((t, idx) => { if (imgs[idx]) dic[t] = imgs[idx]; });
  for (const row of rows) {
    if (!row.poster) row.poster = dic[coreTitle(row.title)] || "";
  }
}

function qualityScore(name = "") {
  const text = String(name || "").toUpperCase();
  return QUALITY_KEYWORDS.reduce((score, keyword, index) => (
    text.includes(keyword.toUpperCase()) ? score + QUALITY_KEYWORDS.length - index + 1 : score
  ), 0);
}

function countKeywords(name = "", keywords = []) {
  const text = String(name || "").toUpperCase();
  return keywords.reduce((count, kw) => count + (text.includes(kw.toUpperCase()) ? 1 : 0), 0);
}

// ==================== mipan token（运行时获取，带缓存与 403 刷新） ====================
const TOKEN = { value: "", expireAt: 0, inflight: null };

async function fetchToken() {
  if (TOKEN.value && Date.now() < TOKEN.expireAt) return TOKEN.value;
  if (TOKEN.inflight) return TOKEN.inflight;
  TOKEN.inflight = (async () => {
    try {
      const res = await http.get("/api/token");
      const token = res?.data?.token;
      const ttl = Number(res?.data?.ttl || 7200);
      if (token) {
        TOKEN.value = String(token);
        TOKEN.expireAt = Date.now() + Math.max(60, ttl - 300) * 1000;
        return TOKEN.value;
      }
    } catch (_) { /* ignore */ }
    return "";
  })();
  const token = await TOKEN.inflight;
  TOKEN.inflight = null;
  return token;
}

async function searchMipan(keyword) {
  const kw = String(keyword || "").trim();
  if (!kw) return null;
  const doSearch = async () => {
    const token = await fetchToken();
    const headers = token ? { "X-Mipan-Token": token } : {};
    return http.post("/api/search", { kw }, { headers });
  };
  let res = await doSearch();
  if (res?.status === 403) {
    TOKEN.value = "";
    TOKEN.expireAt = 0;
    res = await doSearch();
  }
  if (res?.status !== 200 || !res?.data || res.data.code !== 0) return null;
  return res.data.data || null;
}

function flattenMerged(data) {
  const rows = [];
  const merged = data?.merged_by_type;
  if (merged && typeof merged === "object") {
    for (const [type, arr] of Object.entries(merged)) {
      if (!Array.isArray(arr)) continue;
      for (const item of arr) {
        if (!item || typeof item !== "object") continue;
        rows.push({
          url: String(item.url || item.link || "").trim(),
          title: clean(item.note || item.title || "", 120),
          password: clean(item.password || item.pwd || "", 16),
          datetime: item.datetime || item.date || "",
          source: clean(item.source || item.channel || "", 50),
          type,
        });
      }
    }
  }
  return rows;
}

const emptyResult = (page = 1) => ({ list: [], page, pagecount: 1, total: 0 });

// 单条资源 → 不夜列表项（详情 id 用 share 结构：分享链接 + 标题 + 盘别）
function buildShareItem(row) {
  const now = dayjs();
  const rowTime = dayjs(row.datetime || row.date);
  const timeDiff = now.diff(rowTime, "minute");
  const dt = dayjs(timeDiff <= 70 && timeDiff >= 0 ? "0001-01-01T00:00:00Z" : (row.datetime || row.date));
  return {
    vod_id: b64e({ kind: "share", url: row.url, title: row.title, pan: row.pan, pic: row.poster || "" }),
    vod_name: row.title || DRIVE_LABELS[row.pan] || "网盘资源",
    vod_pic: row.poster || drivePic(row.pan),
    vod_remarks: [row.source, dt.isValid() ? dt.format("MMDDYY") : ""].filter(Boolean).join(" | "),
    vod_tag: "video",
    type_id: row.pan,
    type_name: DRIVE_LABELS[row.pan] || row.pan,
    time: dt.isValid() ? dt.unix() : 0,
    pan: row.pan,
  };
}

// ==================== 三态实现 ====================
const detail = async ({ id }, req) => {
  const ids = Array.isArray(id) ? id : [id];
  const rawId = String(ids[0] || "").trim();
  if (!rawId) return { list: [] };
  const decoded = b64d(rawId);
  // 分组项（folder）不是资源，不提供详情
  if (decoded && typeof decoded === "object" && decoded.kind === "folder") return { list: [] };
  const url = (decoded && typeof decoded === "object" && decoded.url) ? decoded.url : rawId;
  const realTitle = (decoded && typeof decoded === "object" && decoded.title) ? decoded.title : "";
  const decodedPan = (decoded && typeof decoded === "object" && decoded.pan) ? decoded.pan : "";
  const decodedPic = (decoded && typeof decoded === "object" && decoded.pic) ? decoded.pic : "";

  const driveKey = mapDriveType("", url) || decodedPan;
  const resolved = await resolveCloudDriveVod(req, {
    url,
    input: url,
    driveKey,
    title: SITE.name,
    rawText: url,
    allowFallbackMatch: true,
    extra: { flag: driveKey },
    playFrom: DRIVE_LABELS[driveKey] || SITE.name,
    vodName: SITE.name,
    vodPic: decodedPic || drivePic(driveKey),
  }).catch(() => null);

  const vod = resolved?.data;
  if (vod?.vod_play_url) {
    if (realTitle) vod.vod_name = realTitle;
    if (!vod.vod_content) vod.vod_content = url;
    if (!vod.vod_pic) vod.vod_pic = decodedPic || drivePic(driveKey);
    return { list: [{ ...vod, vod_id: rawId }] };
  }

  // fallback：统一驱动失败时用搜索标题 + 原始链接构建基础 vod
  return {
    list: [{
      vod_id: rawId,
      vod_name: realTitle || SITE.name,
      vod_pic: decodedPic || drivePic(driveKey),
      vod_content: url,
      vod_remarks: DRIVE_LABELS[driveKey] || driveKey || "网盘",
      vod_play_from: DRIVE_LABELS[driveKey] || SITE.name,
      vod_play_url: `${realTitle || SITE.name}$${url}`,
    }],
  };
};

const search = async ({ page, wd, pan }, req) => {
  const keyword = String(wd || "").trim();
  const pg = Math.max(1, parseInt(page || "1", 10) || 1);
  if (!keyword) return emptyResult(pg);
  if (pg > 1) return emptyResult(pg); // PanSou 单次返回即全量，无分页

  const data = await searchMipan(keyword).catch(() => null);
  if (!data) return emptyResult(pg);

  const rows = flattenMerged(data)
    .map((row) => ({ ...row, pan: mapDriveType(row.type, row.url) }))
    .filter((row) => row.url && isPanUrl(row.url) && SITE.driveKeys.includes(row.pan));

  // 补影片海报（本地 PanSou images 优先，豆瓣兜底；失败不影响搜索）
  try { await attachPosters(rows, req, keyword); } catch (_) { /* ignore */ }

  const panKey = driveKeyFromFlag(pan) || "";

  // ---------- 视图2：某网盘分组内的资源列表（fs 视图） ----------
  if (panKey) {
    const subRows = rows.filter((row) => row.pan === panKey);
    if (!subRows.length) return emptyResult(1);

    const checked = await filterValidPanLinks(subRows, {
      req,
      strict: true,
      getUrl: (item) => item?.url,
      getTitle: (item) => item?.title,
      getPassword: (item) => item?.password,
    }).catch(() => ({ rows: [] }));
    const validRows = Array.isArray(checked?.rows) ? checked.rows : [];
    if (!validRows.length) return emptyResult(1);

    const list = validRows.map(buildShareItem);
    list.sort((a, b) => {
      const qa = qualityScore(a.vod_name);
      const qb = qualityScore(b.vod_name);
      if (qa !== qb) return qb - qa;
      const ca = countKeywords(a.vod_name, COMPLETED_KEYWORDS);
      const cb = countKeywords(b.vod_name, COMPLETED_KEYWORDS);
      if (ca !== cb) return cb - ca;
      return b.time - a.time;
    });

    return { list, page: 1, pagecount: 1, total: list.length };
  }

  // ---------- 视图1：搜索结果按网盘类型分组（folder 视图） ----------
  const counts = {};
  for (const row of rows) counts[row.pan] = (counts[row.pan] || 0) + 1;

  // 分组封面：取该盘组内「画质最高且有海报」的条目图，缺失回退网盘图标
  const groupPoster = {};
  for (const row of rows) {
    if (!row.poster) continue;
    const cur = groupPoster[row.pan];
    if (!cur || qualityScore(row.title) > cur.score) groupPoster[row.pan] = { img: row.poster, score: qualityScore(row.title) };
  }

  const list = [];
  for (const key of SITE.driveKeys) {
    const count = counts[key] || 0;
    if (count <= 0) continue;
    list.push({
      vod_id: b64e({ kind: "folder", pan: key, title: keyword }),
      vod_name: DRIVE_LABELS[key] || key,
      vod_pic: groupPoster[key]?.img || drivePic(key),
      vod_remarks: `${count}条`,
      vod_tag: "folder",
      type_id: key,
      type_name: DRIVE_LABELS[key] || key,
      pan: key,
    });
  }
  return { list, page: 1, pagecount: 1, total: list.length };
};

const play = async ({ flag, id }, req) => {
  const raw = String(id || "").trim();
  const driveKey = driveKeyFromFlag(flag) || mapDriveType("", raw);
  const played = await resolveCloudDrivePlay(req, {
    url: raw,
    input: raw,
    driveKey,
    flag: driveKey || flag || "",
    allowFallbackMatch: true,
  }).catch(() => null);
  if (played?.success && played?.data?.url) return played.data;
  return { parse: 1, jx: 0, url: raw };
};

const cachedFunction = (fn, timeout = 1) => async (params, req) => {
  const redis = store.redis;
  if (
    !redis ||
    typeof redis.get !== "function" ||
    typeof redis.set !== "function" ||
    typeof redis.expire !== "function"
  ) return fn(params, req);
  const name = fn.name.replace("_", "").trim();
  const cacheKey = `${store.meta.key}${name}:${CryptoJS.MD5(JSON.stringify(params))}`;
  const cached = await redis.get(cacheKey);
  if (cached) return JSON.parse(cached);
  const result = await fn(params, req);
  await redis.set(cacheKey, JSON.stringify(result));
  if ((timeout ?? 0) > 0) await redis.expire(cacheKey, timeout);
  return result;
};

const store = {
  init: false,
  meta: {
    key: SITE.key,
    name: SITE.name,
    type: 4,
    api: SITE.api,
    searchable: 1,
    quickSearch: 1,
    changeable: 0,
  },
  home: async () => ({ class: [{ type_id: 1, type_name: "纯搜|无资源" }], list: [] }),
  category: async ({ id, page }, req) => {
    const raw = String(id || "").trim();
    if (!raw) return emptyResult(page || 1);
    const decoded = b64d(raw);
    // 点击分组项：进入该网盘的资源列表
    if (decoded && typeof decoded === "object" && decoded.kind === "folder") {
      return search({ page: page || 1, wd: decoded.title, pan: decoded.pan }, req);
    }
    // 兜底：支持 "pan|关键词" 明文形式
    if (raw.includes("|")) {
      const idx = raw.indexOf("|");
      return search({ page: page || 1, wd: raw.slice(idx + 1), pan: raw.slice(0, idx) }, req);
    }
    return emptyResult(page || 1);
  },
  detail: cachedFunction(detail),
  search: cachedFunction(search),
  play: cachedFunction(play),
};

module.exports = async (app, opt) => {
  app.get(store.meta.api, async (req) => {
    if (!store.init) await init(req.server);
    const { filter, t, ac, pg, ext, ids, flag, play: playId, wd, quick, fs: fsParam, pan } = req.query;
    if (playId) return store.play({ flag: flag || "", id: playId }, req);
    if (wd) return store.search({ page: parseInt(pg || "1"), wd, fs: fsParam, pan }, req);
    if (!ac) return store.home({ filter: filter ?? false });
    if (ac === "detail") {
      if (t) {
        const body = { id: t, page: parseInt(pg || "1"), filter: filter || false, filters: {}, fs: fsParam, pan };
        if (ext) {
          try {
            body.filters = JSON.parse(CryptoJS.enc.Base64.parse(ext).toString(CryptoJS.enc.Utf8));
          } catch {}
        }
        return store.category(body, req);
      }
      if (ids) {
        return store.detail({ id: ids.split(",").map((value) => value.trim()).filter(Boolean) }, req);
      }
    }
    return req.query;
  });
  if (Array.isArray(opt?.sites)) opt.sites.push(store.meta);
};