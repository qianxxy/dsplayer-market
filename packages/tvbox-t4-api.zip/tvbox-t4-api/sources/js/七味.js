const axios = require("axios");
const cheerio = require("cheerio");
const CryptoJS = require("crypto-js");

const HOSTS = [
  "https://www.pcmp4.com",
  "https://www.qwnull.com",
  "https://www.qwmkv.com",
  "https://www.qwfilm.com",
  "https://www.qnmp4.com",
  "https://www.qnnull.com",
  "https://www.qnhot.com"
];

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
const PAGE_LIMIT = 20;
const LIST_CACHE_TTL_SECONDS = 300;
const DETAIL_CACHE_TTL_SECONDS = 1800;
const PLAY_CACHE_TTL_SECONDS = 600;
const GROUP_CACHE_TTL_SECONDS = 43200;
const SCRIPT_VERSION = "2026-05-08-qiwei-group-night-v3-search-api";

const PANCHECK_API = text(process.env.PANCHECK_API || "");
const PANCHECK_ENABLED = text(process.env.PANCHECK_ENABLED || (PANCHECK_API ? "1" : "0")) === "1";
const PANCHECK_PLATFORMS = text(process.env.PANCHECK_PLATFORMS || "quark,baidu,uc,pan123,tianyi,cmcc,aliyun,xunlei,115");
const SOURCE_NAMES_CONFIG = splitConfigList(process.env.SOURCE_NAMES_CONFIG || "本地代理;服务端代理;直连");
const MAGNET_LOCAL_SCHEME = text(process.env.MAGNET_LOCAL_SCHEME || "");
const MAGNET_PROXY_API = text(process.env.MAGNET_PROXY_API || "");
const QIWEI_115_COOKIE = text(process.env.QIWEI_115_COOKIE || process.env.WOOG_115_COOKIE || process.env.PAN_115_COOKIE || "");
const QIWEI_115_MAGNET_CACHE_TTL_SECONDS = Number(process.env.QIWEI_115_MAGNET_CACHE_EX_SECONDS || 2592000);
const QIWEI_SEARCH_API_TEMPLATE = text(process.env.QIWEI_SEARCH_API || "/index.php/ajax/suggest?mid=1&limit={limit}&wd={keyword}&page={page}");

const FULL_TYPE_OPTIONS = [
  "剧情", "科幻", "动作", "喜剧", "爱情", "冒险", "儿童", "歌舞", "音乐", "奇幻", "动画", "恐怖", "惊悚", "丧尸", "战争", "传记", "纪录", "犯罪", "悬疑", "西部", "灾难", "古装", "武侠", "家庭", "短片", "校园", "文艺", "运动", "青春", "同性", "励志", "人性", "美食", "女性", "治愈", "历史"
];
const FULL_YEAR_OPTIONS = ["2026", "2025", "2024", "2023", "2022", "2021", "2020", "2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010"];
const FULL_AREA_OPTIONS = ["大陆", "香港", "台湾", "日本", "韩国", "泰国", "美国", "英国", "法国", "德国", "印度", "丹麦", "瑞典", "荷兰", "加拿大", "俄罗斯", "意大利", "比利时", "西班牙", "澳大利亚", "其他"];
const FULL_LANG_OPTIONS = ["国语", "粤语", "英语", "法语", "日语", "韩语", "泰语", "德语", "俄语", "闽南语", "丹麦语", "波兰语", "瑞典语", "印地语", "挪威语", "意大利语", "西班牙语", "无对白", "其他"];
const FULL_SORT_OPTIONS = [
  { n: "按时间", v: "time" },
  { n: "按人气", v: "hits" },
  { n: "按评分", v: "score" }
];

function buildFilterOptionList(list = []) {
  return [{ n: "全部", v: "" }, ...list.map((item) => ({ n: item, v: item }))];
}

function buildCategoryFilters({ includeType = true, includeYear = true, includeArea = true, includeLang = true } = {}) {
  const filters = [{ key: "sort", name: "排序", init: "time", value: FULL_SORT_OPTIONS }];
  if (includeType) filters.push({ key: "type", name: "类型", init: "", value: buildFilterOptionList(FULL_TYPE_OPTIONS) });
  if (includeYear) filters.push({ key: "year", name: "年代", init: "", value: buildFilterOptionList(FULL_YEAR_OPTIONS) });
  if (includeArea) filters.push({ key: "area", name: "地区", init: "", value: buildFilterOptionList(FULL_AREA_OPTIONS) });
  if (includeLang) filters.push({ key: "lang", name: "语言", init: "", value: buildFilterOptionList(FULL_LANG_OPTIONS) });
  return filters;
}

const SITE_CONFIG = {
  key: "qiwei_group_night",
  name: "[纯]七味分组",
  type: 4,
  api: "/video/qiwei_group_night",
  searchable: 1,
  quickSearch: 1,
  filterable: 1,
  changeable: 0,
  class: [
    { type_id: "1", type_name: "电影" },
    { type_id: "2", type_name: "剧集" },
    { type_id: "3", type_name: "综艺" },
    { type_id: "4", type_name: "动漫" },
    { type_id: "30", type_name: "短剧" }
  ],
  filter: {
    "1": buildCategoryFilters(),
    "2": buildCategoryFilters(),
    "3": buildCategoryFilters({ includeYear: false, includeArea: false, includeLang: false }),
    "4": buildCategoryFilters({ includeArea: false, includeLang: false }),
    "30": buildCategoryFilters({ includeArea: false, includeLang: false })
  }
};

const DEFAULT_HEADERS = {
  "User-Agent": UA,
  Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
  "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
  Connection: "keep-alive"
};

const MAGNET_PLAY_HEADERS = {
  "User-Agent": UA,
  "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
  Cookie: ""
};

const http = axios.create({
  timeout: 15000,
  validateStatus: () => true,
  responseType: "text",
  maxRedirects: 5
});

let currentHostIndex = 0;

const store = {
  init: false,
  redis: null,
  log: null,
  drives: [],
  meta: {
    key: SITE_CONFIG.key,
    name: SITE_CONFIG.name,
    type: SITE_CONFIG.type,
    api: SITE_CONFIG.api,
    searchable: SITE_CONFIG.searchable,
    quickSearch: SITE_CONFIG.quickSearch,
    filterable: SITE_CONFIG.filterable,
    changeable: SITE_CONFIG.changeable
  }
};

function logInfo(message) {
  store.log?.info?.(`[七味分组] ${message}`);
}

function logWarn(message) {
  store.log?.warn?.(`[七味分组] ${message}`);
}

function logError(message) {
  store.log?.error?.(`[七味分组] ${message}`);
}

async function init(server) {
  if (store.init) return;
  store.redis = server?.redis || null;
  store.log = server?.log || null;
  store.drives = server?.drives || [];
  store.init = true;
  logInfo(`init version=${SCRIPT_VERSION}, marker=115-format-log, drives=${store.drives.map((item) => item.key).join(",")}`);
}

function text(value) {
  return value == null ? "" : String(value).trim();
}

function safeJsonParse(value, fallback = {}) {
  if (value == null) return fallback;
  if (typeof value === "object") return value;
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

function splitConfigList(value) {
  return text(value)
    .split(/[;,]/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, Math.max(0, Number(ms) || 0)));
}

function stringifyForLog(value) {
  try {
    return JSON.stringify(value);
  } catch {
    return text(value);
  }
}

function parsePage(value, defaultValue = 1) {
  const n = parseInt(value, 10);
  return Number.isFinite(n) && n > 0 ? n : defaultValue;
}

function getCurrentHost() {
  return HOSTS[currentHostIndex] || HOSTS[0];
}

function fixUrl(url, host = getCurrentHost()) {
  const value = text(url);
  if (!value) return "";
  if (/^https?:\/\//i.test(value)) return value;
  if (value.startsWith("//")) return `https:${value}`;
  if (value.startsWith("/")) return `${host}${value}`;
  return `${host}/${value.replace(/^\.\//, "")}`;
}

function normalizeImage(url, host = getCurrentHost()) {
  return fixUrl(url, host).replace(/\s+/g, "%20");
}

function normalizeText(value) {
  return text(value)
    .replace(/&nbsp;/gi, " ")
    .replace(/&#160;/gi, " ")
    .replace(/<br\s*\/?>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function encodeMeta(obj) {
  try {
    return Buffer.from(JSON.stringify(obj || {}), "utf8").toString("base64");
  } catch {
    return "";
  }
}

function decodeMeta(value) {
  try {
    return JSON.parse(Buffer.from(String(value || ""), "base64").toString("utf8"));
  } catch {
    return {};
  }
}

function buildCacheKey(name, args) {
  return `${store.meta.key}:${SCRIPT_VERSION}:${name}:${CryptoJS.MD5(JSON.stringify(args || []))}`;
}

async function getCachedJSON(key) {
  try {
    const cached = await store.redis?.get(key);
    return cached ? JSON.parse(cached) : null;
  } catch (e) {
    logWarn(`读取缓存失败 key=${key}: ${e.message}`);
    return null;
  }
}

async function setCachedJSON(key, value, exSeconds = LIST_CACHE_TTL_SECONDS) {
  try {
    await store.redis?.set(key, JSON.stringify(value));
    if ((exSeconds ?? 0) > 0) await store.redis?.expire(key, exSeconds);
  } catch (e) {
    logWarn(`写入缓存失败 key=${key}: ${e.message}`);
  }
}

function shouldCacheResult(data) {
  if (data == null) return false;
  if (Array.isArray(data)) return data.length > 0;
  if (typeof data !== "object") return true;
  if (Array.isArray(data.list)) return data.list.length > 0;
  if (Array.isArray(data.class)) return data.class.length > 0;
  return Object.keys(data).length > 0;
}

async function withCache(name, args, ttlSeconds, loader) {
  const key = buildCacheKey(name, args);
  const cached = await getCachedJSON(key);
  if (cached) {
    logInfo(`cache hit fn=${name}`);
    return cached;
  }
  const data = await loader();
  if (shouldCacheResult(data)) {
    await setCachedJSON(key, data, ttlSeconds);
  }
  return data;
}

async function requestWithHost(host, path, options = {}) {
  const url = /^https?:\/\//i.test(path) ? path : `${host}${path}`;
  const res = await http.get(url, {
    headers: {
      ...DEFAULT_HEADERS,
      Referer: `${host}/`,
      Origin: host,
      ...(options.headers || {})
    }
  });
  if (res.status >= 400) {
    throw new Error(`HTTP ${res.status}`);
  }
  return {
    html: typeof res.data === "string" ? res.data : JSON.stringify(res.data || {}),
    host,
    url
  };
}

async function requestWithFailover(path, options = {}) {
  let lastError = null;
  for (let offset = 0; offset < HOSTS.length; offset += 1) {
    const index = (currentHostIndex + offset) % HOSTS.length;
    const host = HOSTS[index];
    try {
      const result = await requestWithHost(host, path, options);
      currentHostIndex = index;
      return result;
    } catch (e) {
      lastError = e;
      logWarn(`站点请求失败 host=${host}, path=${path}, error=${e.message}`);
    }
  }
  throw lastError || new Error("全部镜像请求失败");
}

async function requestText(url, options = {}) {
  const res = await http.get(url, {
    headers: {
      ...DEFAULT_HEADERS,
      Referer: options.referer || `${getCurrentHost()}/`,
      ...(options.headers || {})
    }
  });
  if (res.status >= 400) {
    throw new Error(`HTTP ${res.status}`);
  }
  return typeof res.data === "string" ? res.data : JSON.stringify(res.data || {});
}

function extractVideoId(urlOrId) {
  const value = text(urlOrId);
  const match = value.match(/\/mv\/(\d+)\.html/);
  return match ? match[1] : value;
}

function parseFilters(params = {}) {
  const merged = {};
  const candidates = [params.filters, params.extend, params.ext];
  for (const item of candidates) {
    if (!item) continue;
    if (typeof item === "object") {
      Object.assign(merged, item);
      continue;
    }
    if (typeof item === "string") {
      try {
        const parsed = JSON.parse(item);
        if (parsed && typeof parsed === "object") Object.assign(merged, parsed);
      } catch {
        continue;
      }
    }
  }
  const out = {};
  for (const [key, value] of Object.entries(merged)) {
    if (["sort", "type", "area", "lang", "year"].includes(key)) out[key] = text(value);
  }
  if (!["time", "hits", "score"].includes(out.sort)) out.sort = "time";
  return out;
}

function buildCategoryPath(categoryId, page, filters = {}) {
  const area = encodeURIComponent(text(filters.area));
  const sort = text(filters.sort || "time") || "time";
  const type = encodeURIComponent(text(filters.type));
  const lang = encodeURIComponent(text(filters.lang));
  const year = encodeURIComponent(text(filters.year));
  return `/ms/${categoryId}-${area}-${sort}-${type}-${lang}-------${year}.html?page=${page}`;
}

function pickFirstText($root, selectors = []) {
  for (const selector of selectors) {
    const value = $root.find(selector).first().text().trim();
    if (value) return value;
  }
  return "";
}

function pickFirstAttr($root, selectors = [], attrName = "href") {
  for (const selector of selectors) {
    const value = $root.find(selector).first().attr(attrName);
    if (value) return text(value);
  }
  return "";
}

function parsePosterItem($, element, host) {
  const $item = $(element);
  const title = pickFirstAttr($item, ["h3 a", ".title a", ".li-img a", "a"], "title") || pickFirstText($item, ["h3 a", ".title a", "a"]);
  if (!title) return null;
  const desc = pickFirstText($item, [".tag", ".label", ".remark"]);
  const img = pickFirstAttr($item, [".li-img img", "img"], "src");
  const href = pickFirstAttr($item, ["h3 a", ".title a", ".li-img a", "a"], "href");
  if (!href) return null;
  return {
    vod_id: fixUrl(href, host),
    vod_name: title,
    vod_pic: normalizeImage(img, host),
    vod_remarks: desc || ""
  };
}

function parseVideoList(html, host) {
  const $ = cheerio.load(html || "");
  const list = [];
  $(".content-list li").each((_, element) => {
    const item = parsePosterItem($, element, host);
    if (item) list.push(item);
  });
  return list;
}

function parseDetailInfo(html, host) {
  const $ = cheerio.load(html || "");
  const title = $(".main-ui-meta h1").first().clone().children("span").remove().end().text().trim() || $(".detail-title").first().text().trim() || "";
  const typeMatch = html.match(/<div><span>类型：<\/span>[\s\S]*?<\/div>/);
  const areaMatch = html.match(/<div><span>地区：<\/span>[\s\S]*?<\/div>/);
  const directorMatch = html.match(/<div>[\s\S]*?导演：[\s\S]*?<\/div>/);
  const typeName = typeMatch ? [...typeMatch[0].matchAll(/<a[^>]*>([^<]+)<\/a>/g)].map((m) => m[1]).filter(Boolean).join("/") : "";
  const area = areaMatch ? [...areaMatch[0].matchAll(/<a[^>]*>([^<]+)<\/a>/g)].map((m) => m[1]).filter(Boolean).join("/") : "";
  const director = directorMatch?.[0]?.match(/<a[^>]*>([^<]+)<\/a>/)?.[1] || "";
  const showContent = $(".movie-introduce .zkjj_a").first().text().replace(/\s*\[展开全部\]/g, "").trim();
  const hideContent = $(".movie-introduce .sqjj_a").first().text().replace(/\s*\[收起部分\]/g, "").trim();
  return {
    vod_name: title,
    type_name: typeName || $(".main-ui-meta div:nth-child(9) a").first().text().trim(),
    vod_pic: normalizeImage($(".img img").first().attr("src"), host),
    vod_content: hideContent || showContent || $(".detail-content").first().text().trim() || "",
    vod_remarks: $(".otherbox").first().text().trim() || "",
    vod_year: ($(".main-ui-meta h1 span.year").first().text() || "").replace(/[()]/g, "").trim(),
    vod_area: area || $(".main-ui-meta div:nth-child(11) a").first().text().trim(),
    vod_actor: ($(".main-ui-meta div.text-overflow").first().text() || "").replace(/^主演：/, "").trim(),
    vod_director: director
  };
}

function buildPanRootFolderVodId(videoId = "") {
  return Buffer.from(JSON.stringify({ kind: "panroot", videoId: text(videoId) }), "utf8").toString("base64");
}

function buildPanGroupFolderVodId(videoId = "", panTypeKey = "") {
  return Buffer.from(JSON.stringify({ kind: "pangroup", videoId: text(videoId), panTypeKey: normalizeDriveType(panTypeKey) }), "utf8").toString("base64");
}

function buildPanShareVodId(videoId = "", panTypeKey = "", shareIndex = 0) {
  return Buffer.from(JSON.stringify({ kind: "panshare", videoId: text(videoId), panTypeKey: normalizeDriveType(panTypeKey), shareIndex: parseInt(shareIndex, 10) || 0 }), "utf8").toString("base64");
}

function buildSourceFolderVodId(videoId = "", sourceType = "") {
  return Buffer.from(JSON.stringify({ kind: "sourcefolder", videoId: text(videoId), sourceType: text(sourceType).toLowerCase() }), "utf8").toString("base64");
}

function buildSourceLineFolderVodId(videoId = "", sourceType = "", lineIndex = 0) {
  return Buffer.from(JSON.stringify({ kind: "sourceline", videoId: text(videoId), sourceType: text(sourceType).toLowerCase(), lineIndex: parseInt(lineIndex, 10) || 0 }), "utf8").toString("base64");
}

function buildMagnetPlayId(videoId = "", lineIndex = 0, episodeIndex = 0, magnetUrl = "") {
  return Buffer.from(JSON.stringify({
    kind: "magnetplay",
    videoId: text(videoId),
    lineIndex: parseInt(lineIndex, 10) || 0,
    episodeIndex: parseInt(episodeIndex, 10) || 0,
    magnetUrl: normalizeMagnetUrl(magnetUrl)
  }), "utf8").toString("base64");
}

function build115MagnetPlayId(meta = {}) {
  return Buffer.from(JSON.stringify({
    kind: "115magnetplay",
    magnet: text(meta.magnet),
    fileName: text(meta.fileName),
    fileId: text(meta.fileId),
    pickcode: text(meta.pickcode)
  }), "utf8").toString("base64");
}

function parseFolderVodId(vodId = "") {
  const raw = text(vodId);
  if (!raw) return {};
  try {
    const decoded = JSON.parse(Buffer.from(raw, "base64").toString("utf8"));
    return decoded && typeof decoded === "object" ? decoded : {};
  } catch {
    return {};
  }
}

function buildPanSearchEntryVod(video = {}, host = "") {
  const rawVideoId = extractVideoId(video?.vod_id || "");
  const folderVodId = buildPanRootFolderVodId(rawVideoId || video?.vod_id || "");
  return {
    vod_id: folderVodId,
    vod_name: text(video?.vod_name),
    vod_pic: normalizeImage(video?.vod_pic || "", host) || text(video?.vod_pic),
    vod_remarks: text(video?.vod_remarks || "点击查看网盘分组") || "点击查看网盘分组",
    vod_tag: "folder",
    type_id: folderVodId,
    type_name: "剧集网盘分组"
  };
}

function buildSearchApiPath(keyword = "", page = 1, limit = PAGE_LIMIT) {
  const encodedKeyword = encodeURIComponent(text(keyword));
  const replacements = {
    "{keyword}": encodedKeyword,
    "{wd}": encodedKeyword,
    "{page}": encodeURIComponent(String(parsePage(page, 1))),
    "{pg}": encodeURIComponent(String(parsePage(page, 1))),
    "{limit}": encodeURIComponent(String(limit))
  };
  let path = QIWEI_SEARCH_API_TEMPLATE || "/index.php/ajax/suggest?mid=1&limit={limit}&wd={keyword}&page={page}";
  for (const [token, value] of Object.entries(replacements)) {
    path = path.replaceAll(token, value);
  }
  if (!/[?&](?:wd|keyword|q)=/i.test(path)) {
    path += `${path.includes("?") ? "&" : "?"}wd=${encodedKeyword}`;
  }
  if (!/[?&](?:page|pg)=/i.test(path)) {
    path += `${path.includes("?") ? "&" : "?"}page=${parsePage(page, 1)}`;
  }
  return path;
}

function pickFirstArray(...values) {
  for (const value of values) {
    if (Array.isArray(value)) return value;
  }
  return [];
}

function pickFirstValue(obj = {}, keys = []) {
  for (const key of keys) {
    const value = obj?.[key];
    if (value != null && text(value)) return value;
  }
  return "";
}

function normalizeSearchItem(item = {}, host = "") {
  if (!item || typeof item !== "object") return null;
  const rawId = pickFirstValue(item, ["vod_id", "id", "video_id", "vid", "mid", "_id"]);
  const rawUrl = pickFirstValue(item, ["url", "href", "link", "vod_url"]);
  const videoId = extractVideoId(rawId || rawUrl);
  const vodName = text(pickFirstValue(item, ["vod_name", "name", "title", "text", "vod_title"]));
  if (!videoId || !vodName) return null;
  const vodPic = pickFirstValue(item, ["vod_pic", "pic", "img", "image", "cover", "poster", "vod_img"]);
  const vodRemarks = text(pickFirstValue(item, ["vod_remarks", "remarks", "remark", "vod_remark", "type_name"]));
  return buildPanSearchEntryVod({
    vod_id: videoId,
    vod_name: vodName,
    vod_pic: vodPic,
    vod_remarks: vodRemarks || "点击查看网盘分组"
  }, host);
}

function getSearchResponseList(data = {}) {
  const list = pickFirstArray(
    data?.list,
    data?.data?.list,
    data?.data?.rows,
    data?.data?.items,
    data?.data?.records,
    data?.data?.vod_list,
    data?.result?.list,
    data?.result?.data,
    data?.result?.rows,
    data?.result?.records,
    data?.rows,
    data?.items,
    data?.records,
    data?.vod_list,
    data?.data
  );
  if (Array.isArray(list)) return list;
  return [];
}

function pickSearchNumber(data = {}, keys = [], fallback = 0) {
  const containers = [data, data?.data, data?.result, data?.pagination, data?.page_info].filter(Boolean);
  for (const container of containers) {
    for (const key of keys) {
      const n = Number(container?.[key]);
      if (Number.isFinite(n) && n >= 0) return n;
    }
  }
  return fallback;
}

function normalizeSearchResponse(data = {}, host = "", fallbackPage = 1) {
  const rawItems = getSearchResponseList(data);
  const list = rawItems.map((item) => normalizeSearchItem(item, host)).filter((item) => item?.vod_id && item?.vod_name);
  const page = pickSearchNumber(data, ["page", "current_page", "pageIndex", "pg"], parsePage(fallbackPage, 1)) || parsePage(fallbackPage, 1);
  const pagecount = pickSearchNumber(data, ["pagecount", "page_count", "pageCount", "total_page", "totalPage", "pages"], list.length >= PAGE_LIMIT ? page + 1 : page) || (list.length >= PAGE_LIMIT ? page + 1 : page);
  const total = pickSearchNumber(data, ["total", "total_count", "totalCount", "count"], list.length) || list.length;
  return { page, pagecount, total, limit: PAGE_LIMIT, list };
}

function paginateList(list = [], page = 1, pageSize = 20) {
  const limit = Math.max(1, parseInt(pageSize, 10) || 20);
  const pg = Math.max(1, parseInt(page, 10) || 1);
  const total = Array.isArray(list) ? list.length : 0;
  const pagecount = total > 0 ? Math.ceil(total / limit) : 1;
  return {
    page: pg,
    pagecount,
    total,
    list: (list || []).slice((pg - 1) * limit, pg * limit)
  };
}

function buildFolderPageResult(paged) {
  return {
    page: 1,
    pagecount: 1,
    total: Array.isArray(paged?.list) ? paged.list.length : 0,
    limit: PAGE_LIMIT,
    list: paged.list
  };
}

function buildSingleDetailResult(vod) {
  return {
    list: vod ? [vod] : [],
    page: 1,
    pagecount: 1,
    total: vod ? 1 : 0,
    limit: 1
  };
}

function normalizeCollectLineName(name = "") {
  return text(name)
    .replace(/[\u00a0\u2000-\u200f\u2028-\u202f\u205f\u3000]/g, " ")
    .replace(/\s+/g, " ")
    .replace(/^(?:collect|采集)\s*/iu, "")
    .replace(/^(?:线路|route)\s*/iu, "")
    .replace(/[：:\-]+$/u, "")
    .replace(/\s+(\d+)$/u, "")
    .trim();
}

function isBlockedLineName(name = "") {
  return text(name).includes("磁力");
}

function isPanUrl(url = "") {
  return /(pan\.baidu\.com|pan\.quark\.cn|drive\.uc\.cn|cloud\.189\.cn|yun\.139\.com|alipan\.com|aliyundrive\.com|115\.com|115cdn\.com|123pan\.com|123684\.com|123865\.com|123912\.com|pan\.xunlei\.com)/i.test(text(url));
}

function isDirectVideoUrl(url = "") {
  return /\.(m3u8|mp4|flv|avi|mkv|ts|mov|webm)(\?|$)/i.test(text(url));
}

function normalizeShareUrl(url = "") {
  let value = text(url).replace(/[)）】》,，。]+$/g, "").replace(/&amp;/gi, "&");
  if (!value) return "";
  try {
    const parsed = new URL(value);
    parsed.hash = "";
    if (parsed.searchParams.has("dn")) parsed.searchParams.delete("dn");
    if (parsed.searchParams.has("displayName")) parsed.searchParams.delete("displayName");
    if (parsed.searchParams.has("filename")) parsed.searchParams.delete("filename");
    if (parsed.searchParams.has("title")) parsed.searchParams.delete("title");
    if (parsed.hostname.includes("pan.baidu.com")) {
      const pwd = parsed.searchParams.get("pwd") || "";
      return `https://pan.baidu.com${parsed.pathname}${pwd ? `?pwd=${encodeURIComponent(pwd)}` : ""}`;
    }
    return parsed.toString();
  } catch {
    return value.replace(/([?&])dn=[^&#]*/ig, "$1").replace(/[?&]$/g, "");
  }
}

function normalizeMagnetUrl(url = "") {
  const cleaned = text(url)
    .replace(/&amp;/gi, "&")
    .replace(/["'<>\s]+$/g, "")
    .replace(/[)）】》,，。]+$/g, "")
    .replace(/#.*$/g, "")
    .trim();
  const hashMatch = cleaned.match(/btih:([a-fA-F0-9]{32,40})/i);
  if (hashMatch?.[1]) {
    return `magnet:?xt=urn:btih:${hashMatch[1]}`;
  }
  return cleaned;
}

function normalizeSeedType(type = "", link = "") {
  const t = text(type).toLowerCase();
  const u = text(link).toLowerCase();
  if (u.startsWith("magnet:")) return "magnet";
  if (u.startsWith("ed2k://")) return "ed2k";
  if (/\.torrent($|\?)/i.test(u)) return "torrent";
  if (["magnet", "magnet_url", "magnet_link"].includes(t)) return "magnet";
  if (["ed2k", "ed2k_url", "ed2k_link"].includes(t)) return "ed2k";
  if (t === "torrent") return "torrent";
  return t || "other";
}

function extractEpisodeNumber(name = "") {
  const raw = text(name);
  const patterns = [
    /S\d{1,2}E(\d{1,3})/i,
    /第\s*(\d{1,3})\s*[集话]/,
    /\[(\d{1,3})\s*[集话]\]/,
    /(?:^|[^A-Z0-9])E[P]?(\d{1,3})(?:[^A-Z0-9]|$)/i
  ];
  for (const pattern of patterns) {
    const match = raw.match(pattern);
    const episode = Number(match?.[1]);
    if (Number.isFinite(episode) && episode > 0) return episode;
  }
  return null;
}

function extractEpisodeRange(name = "") {
  const raw = text(name);
  const patterns = [
    /\[第\s*(\d{1,3})\s*[-—~～至]\s*(\d{1,3})\s*[集话]\]/,
    /第\s*(\d{1,3})\s*[-—~～至]\s*(\d{1,3})\s*[集话]/,
    /\[(\d{1,3})\s*[-—~～至]\s*(\d{1,3})\s*[集话]\]/
  ];
  for (const pattern of patterns) {
    const match = raw.match(pattern);
    const start = Number(match?.[1]);
    const end = Number(match?.[2]);
    if (Number.isFinite(start) && Number.isFinite(end) && start > 0 && end >= start) return { start, end };
  }
  return null;
}

function formatEpisodeLabel(ep, fallbackTitle = "") {
  return Number.isFinite(ep) && ep > 0 ? `第${String(ep).padStart(2, "0")}集` : (fallbackTitle || "资源");
}

function formatEpisodeRangeLabel(range, fallbackTitle = "") {
  return range && Number.isFinite(range.start) && Number.isFinite(range.end)
    ? `第${String(range.start).padStart(2, "0")}-${String(range.end).padStart(2, "0")}集`
    : (fallbackTitle || "资源");
}

function sortEpisodesByEpisodeNumber(episodes = []) {
  return [...episodes].sort((a, b) => {
    const aStart = Number.isFinite(a?.episodeRangeStart) ? a.episodeRangeStart : null;
    const bStart = Number.isFinite(b?.episodeRangeStart) ? b.episodeRangeStart : null;
    const aEp = Number.isFinite(a?.episodeNumber) ? a.episodeNumber : (aStart ?? Number.MAX_SAFE_INTEGER);
    const bEp = Number.isFinite(b?.episodeNumber) ? b.episodeNumber : (bStart ?? Number.MAX_SAFE_INTEGER);
    if (aEp !== bEp) return aEp - bEp;
    return text(a?.name).localeCompare(text(b?.name), "zh-Hans-CN");
  });
}

function formatFileSize(size) {
  const n = Number(size) || 0;
  if (n <= 0) return "";
  const units = ["B", "K", "M", "G", "T", "P"];
  let value = n;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }
  return `${value === Math.floor(value) ? Math.floor(value) : value.toFixed(2)}${units[unit]}`;
}

function cleanPlayLabel(value = "", fallback = "") {
  const cleaned = text(value)
    .replace(/[$#]+/g, " ")
    .replace(/[\r\n\t]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  return cleaned || fallback;
}

function stripEpisodeSerialSuffix(name = "", index = 0) {
  const value = cleanPlayLabel(name);
  const serial = String((parseInt(index, 10) || 0) + 1);
  if (!value || !serial) return value;
  const escaped = serial.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return value
    .replace(new RegExp(`([\\]】）)])\\s*${escaped}$`, "u"), "$1")
    .replace(new RegExp(`(\\[[^\\]]{1,24}\\])\\s*${escaped}$`, "u"), "$1")
    .trim();
}

function buildEpisodeButtonName(ep = {}, index = 0, defaultPrefix = "资源") {
  const raw = cleanPlayLabel(ep?._displayName || ep?.name || ep?._rawName || "");
  const rangeStart = Number.isFinite(ep?._episodeRangeStart) ? ep._episodeRangeStart : null;
  const rangeEnd = Number.isFinite(ep?._episodeRangeEnd) ? ep._episodeRangeEnd : null;
  if (rangeStart && rangeEnd) return formatEpisodeRangeLabel({ start: rangeStart, end: rangeEnd }, raw);
  const episodeNumber = Number.isFinite(ep?._episodeNumber) ? ep._episodeNumber : extractEpisodeNumber(raw);
  if (episodeNumber) return formatEpisodeLabel(episodeNumber, raw);
  return cleanPlayLabel(raw, `${defaultPrefix}${index + 1}`);
}

function normalizePlayableEpisode(ep = {}, index = 0, defaultPrefix = "资源") {
  const name = buildEpisodeButtonName(ep, index, defaultPrefix);
  const playId = text(ep?.playId);
  return {
    name,
    title: name,
    playId,
    url: playId
  };
}

function buildLegacyPlayFields(playSources = []) {
  const vodPlayFrom = [];
  const vodPlayUrl = [];
  for (const source of Array.isArray(playSources) ? playSources : []) {
    const sourceName = cleanPlayLabel(source?.name, "默认线路");
    const episodeItems = (Array.isArray(source?.episodes) ? source.episodes : [])
      .map((ep, index) => {
        const name = stripEpisodeSerialSuffix(cleanPlayLabel(ep?.name || ep?.title, `第${index + 1}集`), index) || `第${index + 1}集`;
        const playId = text(ep?.playId || ep?.url);
        return playId ? `${name}$${playId}` : "";
      })
      .filter(Boolean);
    if (episodeItems.length > 0) {
      vodPlayFrom.push(sourceName);
      vodPlayUrl.push(episodeItems.join("#"));
    }
  }
  return { vod_play_from: vodPlayFrom.join("$$$"), vod_play_url: vodPlayUrl.join("$$$") };
}

function summarizeLegacyPlayFields(vodPlayFrom = "", vodPlayUrl = "") {
  const sources = text(vodPlayFrom).split("$$$").filter(Boolean);
  const groups = text(vodPlayUrl).split("$$$");
  return sources.map((sourceName, sourceIndex) => {
    const episodeItems = text(groups[sourceIndex] || "").split("#").filter(Boolean);
    return {
      sourceIndex,
      sourceName,
      episodeCount: episodeItems.length,
      episodes: episodeItems.slice(0, 12).map((item, episodeIndex) => {
        const splitIndex = item.indexOf("$");
        const name = splitIndex >= 0 ? item.slice(0, splitIndex) : "";
        const playId = splitIndex >= 0 ? item.slice(splitIndex + 1) : item;
        const parsed = parseFolderVodId(playId);
        return {
          episodeIndex,
          name,
          nameLength: name.length,
          playIdKind: parsed?.kind || (playId.startsWith("magnet:") ? "magnet" : (playId.startsWith("115magnet:") ? "115magnet_legacy" : "raw")),
          playIdPrefix: playId.slice(0, 32),
          playIdLength: playId.length
        };
      })
    };
  });
}

function pickBetterShareDisplayName(...names) {
  return names
    .map((item) => normalizeText(item))
    .filter(Boolean)
    .sort((a, b) => b.length - a.length)[0] || "";
}

function buildMagnetEpisode(item = {}, fallbackTitle = "") {
  const link = text(item?.link || item?.zlink || item?.magnet || item?.magnet_url || item?.ed2k || item?.torrent);
  const seedType = normalizeSeedType(item?.type || "", link);
  const rawTitle = pickBetterShareDisplayName(item?.seed_name, item?.zname, item?.name, fallbackTitle) || fallbackTitle || "资源";
  const size = normalizeText(item?.zsize || item?.size || "");
  const quality = normalizeText(item?.zqxd || item?.definition_group || "");
  const createdAt = normalizeText(item?.ezt || item?.created_at || "");
  const episodeRange = extractEpisodeRange(rawTitle);
  const episodeNumber = episodeRange ? null : extractEpisodeNumber(rawTitle);
  const episodeLabel = episodeRange ? formatEpisodeRangeLabel(episodeRange, rawTitle) : formatEpisodeLabel(episodeNumber, rawTitle);
  const remark = [size, quality, createdAt].filter(Boolean).join(" / ");
  const displayName = remark ? `${episodeLabel} [${remark}]` : episodeLabel;
  return {
    name: episodeLabel,
    playId: link,
    seedType,
    episodeNumber,
    episodeRangeStart: episodeRange?.start ?? null,
    episodeRangeEnd: episodeRange?.end ?? null,
    _displayName: displayName,
    _rawName: rawTitle
  };
}

function normalizeTorrentLikePlayUrl(url = "") {
  const value = text(url);
  if (/^magnet:\/\/\//i.test(value)) {
    return value.replace(/^magnet:\/\/\//i, "file:///");
  }
  return value;
}

function buildMagnetPlayUrls(link = "") {
  const target = text(link);
  const urls = [];
  if (!target) return urls;

  if (MAGNET_LOCAL_SCHEME) {
    const localName = SOURCE_NAMES_CONFIG[0] || "本地代理";
    const localUrl = MAGNET_LOCAL_SCHEME.includes("{")
      ? MAGNET_LOCAL_SCHEME.replaceAll("{url}", encodeURIComponent(target))
      : `${MAGNET_LOCAL_SCHEME}${encodeURIComponent(target)}`;
    urls.push({ name: localName, url: localUrl });
  }

  if (MAGNET_PROXY_API) {
    const proxyName = SOURCE_NAMES_CONFIG[1] || "服务端代理";
    const joiner = MAGNET_PROXY_API.includes("?") ? "&" : "?";
    urls.push({ name: proxyName, url: `${MAGNET_PROXY_API}${joiner}url=${encodeURIComponent(target)}` });
  }

  const directName = SOURCE_NAMES_CONFIG[SOURCE_NAMES_CONFIG.length - 1] || "直连";
  urls.push({ name: directName, url: target });
  return urls;
}

function inferDriveTypeFromShareURL(shareURL = "") {
  const raw = text(shareURL).toLowerCase();
  if (!raw) return "";
  if (raw.includes("pan.quark.cn") || raw.includes("drive.quark.cn")) return "quark";
  if (raw.includes("drive.uc.cn") || raw.includes("fast.uc.cn")) return "uc";
  if (raw.includes("pan.baidu.com")) return "baidu";
  if (raw.includes("cloud.189.cn")) return "tianyi";
  if (raw.includes("yun.139.com")) return "cmcc";
  if (raw.includes("www.aliyundrive.com") || raw.includes("www.alipan.com") || raw.includes("aliyundrive.com") || raw.includes("alipan.com")) return "aliyun";
  if (raw.includes("pan.xunlei.com")) return "xunlei";
  if (raw.includes("115.com")) return "115";
  if (raw.includes("123684.com") || raw.includes("123865.com") || raw.includes("123912.com") || raw.includes("123pan.com")) return "pan123";
  return "";
}

function normalizeDriveType(driveType = "") {
  const raw = text(driveType).toLowerCase();
  if (raw.includes("aliyun") || raw === "ali" || raw.includes("阿里") || raw.includes("alipan")) return "aliyun";
  if (raw.includes("baidu") || raw.includes("百度")) return "baidu";
  if (raw.includes("tianyi") || raw.includes("天翼")) return "tianyi";
  if (raw.includes("quark") || raw.includes("夸克")) return "quark";
  if (raw === "uc" || raw.includes("uc")) return "uc";
  if (raw.includes("115")) return "115";
  if (raw.includes("xunlei") || raw.includes("迅雷")) return "xunlei";
  if (raw.includes("cmcc") || raw.includes("mobile") || raw.includes("139") || raw.includes("移动")) return "cmcc";
  if (raw.includes("pan123") || raw === "123" || raw.includes("123")) return "pan123";
  return raw;
}

function parsePanType(shareURL = "") {
  const key = inferDriveTypeFromShareURL(shareURL);
  const names = {
    baidu: "百度网盘",
    quark: "夸克网盘",
    uc: "UC网盘",
    tianyi: "天翼云盘",
    cmcc: "移动云盘",
    aliyun: "阿里云盘",
    pan123: "123云盘",
    xunlei: "迅雷网盘",
    "115": "115网盘"
  };
  return names[key] || "其他";
}

function getPanCheckSelectedPlatforms() {
  return splitConfigList(PANCHECK_PLATFORMS).map((item) => normalizeDriveType(item)).filter(Boolean);
}

function splitLinksByPanCheckPlatforms(links = []) {
  const selectedPlatforms = getPanCheckSelectedPlatforms();
  if (selectedPlatforms.length === 0) {
    return { selectedPlatforms: [], linksToCheck: links, bypassLinks: [] };
  }
  const selectedSet = new Set(selectedPlatforms);
  const linksToCheck = [];
  const bypassLinks = [];
  for (const link of links) {
    const driveType = inferDriveTypeFromShareURL(link);
    if (selectedSet.has(driveType)) linksToCheck.push(link);
    else bypassLinks.push(link);
  }
  return { selectedPlatforms, linksToCheck, bypassLinks };
}

async function checkLinksWithPanCheck(links = []) {
  if (!PANCHECK_ENABLED || !PANCHECK_API || !Array.isArray(links) || links.length === 0) {
    return { invalidLinksSet: new Set(), stats: null };
  }
  try {
    const normalizedLinks = [...new Set(links.map((item) => normalizeShareUrl(item)).filter(Boolean))];
    const { selectedPlatforms, linksToCheck, bypassLinks } = splitLinksByPanCheckPlatforms(normalizedLinks);
    if (linksToCheck.length === 0) {
      return { invalidLinksSet: new Set(), stats: { totalInput: normalizedLinks.length, totalChecked: 0, totalBypass: bypassLinks.length } };
    }
    const apiUrl = PANCHECK_API.replace(/\/$/, "");
    const checkURL = `${apiUrl}/api/v1/links/check`;
    const res = await axios.post(checkURL, {
      links: linksToCheck,
      selected_platforms: selectedPlatforms
    }, {
      timeout: 30000,
      headers: {
        "Content-Type": "application/json",
        "User-Agent": UA
      },
      validateStatus: () => true
    });
    if (res.status !== 200) {
      logWarn(`PanCheck 响应异常 status=${res.status}`);
      return { invalidLinksSet: new Set(), stats: null };
    }
    const data = safeJsonParse(res.data, {});
    const invalid = Array.isArray(data.invalid_links) ? data.invalid_links.map((item) => normalizeShareUrl(item)).filter(Boolean) : [];
    return {
      invalidLinksSet: new Set(invalid),
      stats: {
        totalInput: normalizedLinks.length,
        totalChecked: linksToCheck.length,
        totalInvalid: invalid.length,
        totalBypass: bypassLinks.length
      }
    };
  } catch (e) {
    logWarn(`PanCheck 失败: ${e.message}`);
    return { invalidLinksSet: new Set(), stats: null };
  }
}

function buildPanGroupEntries(video = {}, grouped = {}) {
  const entries = [];
  const collectGroups = Array.isArray(grouped.collect) ? grouped.collect : [];
  const magnetGroups = Array.isArray(grouped.magnet) ? grouped.magnet : [];

  if (collectGroups.length > 0) {
    entries.push({
      vod_id: buildSourceFolderVodId(video.vod_id, "collect"),
      vod_name: "采集",
      vod_pic: text(video.vod_pic),
      type_id: "source_category",
      type_name: "采集分组",
      vod_remarks: `${collectGroups.length}条线路`,
      vod_tag: "folder",
      sourceType: "collect"
    });
  }

  if (magnetGroups.length > 0) {
    if (magnetGroups.length === 1) {
      const only = magnetGroups[0] || {};
      entries.push({
        vod_id: buildSourceLineFolderVodId(video.vod_id, "magnet", only.lineIndex ?? 0),
        vod_name: text(only.name || "磁力") || "磁力",
        vod_pic: text(video.vod_pic),
        type_id: "source_line",
        type_name: "磁力线路",
        vod_remarks: `${Array.isArray(only.episodes) ? only.episodes.length : 0}条资源`,
        vod_tag: "video",
        sourceType: "magnet"
      });
    } else {
      entries.push({
        vod_id: buildSourceFolderVodId(video.vod_id, "magnet"),
        vod_name: "磁力",
        vod_pic: text(video.vod_pic),
        type_id: "source_category",
        type_name: "磁力分组",
        vod_remarks: `${magnetGroups.length}条线路`,
        vod_tag: "folder",
        sourceType: "magnet"
      });
    }
  }

  for (const [panTypeKey, links] of Object.entries(grouped || {})) {
    if (panTypeKey === "collect" || panTypeKey === "magnet") continue;
    const normalizedLinks = [...new Set((links || []).map((item) => normalizeShareUrl(item)).filter(Boolean))];
    if (normalizedLinks.length === 0) continue;
    entries.push({
      vod_id: buildPanGroupFolderVodId(video.vod_id, panTypeKey),
      vod_name: parsePanType(normalizedLinks[0]),
      vod_pic: text(video.vod_pic),
      type_id: "pan_category",
      type_name: "网盘分类",
      vod_remarks: `${normalizedLinks.length}条结果`,
      vod_tag: "folder",
      panType: panTypeKey,
      shareCount: normalizedLinks.length
    });
  }
  return entries;
}

function buildSourceLineEntries(video = {}, sourceType = "", groups = []) {
  const normalizedSourceType = text(sourceType).toLowerCase();
  return (groups || []).map((group, index) => ({
    vod_id: buildSourceLineFolderVodId(video.vod_id, normalizedSourceType, group?.lineIndex ?? index),
    vod_name: text(group?.name || `${normalizedSourceType}线路${index + 1}`),
    vod_pic: text(video.vod_pic),
    vod_remarks: normalizedSourceType === "magnet" ? `${Array.isArray(group?.episodes) ? group.episodes.length : 0}条资源` : `${Array.isArray(group?.episodes) ? group.episodes.length : 0}集`,
    vod_tag: normalizedSourceType === "magnet" ? "video" : "folder",
    type_id: "source_line",
    type_name: normalizedSourceType === "magnet" ? "磁力线路" : "采集线路",
    sourceType: normalizedSourceType
  }));
}

function buildPanShareEntries(video = {}, detailInfo = {}, panTypeKey = "", links = []) {
  return [...new Set((links || []).map((item) => normalizeShareUrl(item)).filter(Boolean))].map((shareURL, index) => ({
    vod_id: buildPanShareVodId(video.vod_id, panTypeKey, index),
    vod_name: `分享 ${index + 1}`,
    vod_pic: text(detailInfo?.vod_pic || video?.vod_pic),
    vod_remarks: text(parsePanType(shareURL) || panTypeKey || "网盘分享"),
    vod_tag: "video",
    panType: panTypeKey,
    shareIndex: index,
    shareURL
  }));
}

async function extractPanLinksFromDetail(videoId) {
  const normalizedVideoId = extractVideoId(videoId);
  if (!normalizedVideoId) return { detailInfo: {}, grouped: {} };
  const path = `/mv/${normalizedVideoId}.html`;
  const { html, host } = await requestWithFailover(path);
  const detailInfo = parseDetailInfo(html, host);
  const $ = cheerio.load(html || "");

  const collectGroups = [];
  const tabItems = $(".py-tabs li").toArray();
  const episodeContainers = $(".bd ul.player").toArray();
  const normalizedLineNames = tabItems.map((tab, index) => {
    const rawName = $(tab).text().trim();
    return normalizeCollectLineName(rawName) || `线路${index + 1}`;
  });
  const lineNameCounter = normalizedLineNames.reduce((acc, item) => {
    acc.set(item, (acc.get(item) || 0) + 1);
    return acc;
  }, new Map());
  const lineNameSeen = new Map();

  for (let i = 0; i < Math.min(tabItems.length, episodeContainers.length); i += 1) {
    const baseLineName = normalizedLineNames[i] || `线路${i + 1}`;
    const currentIndex = (lineNameSeen.get(baseLineName) || 0) + 1;
    lineNameSeen.set(baseLineName, currentIndex);
    const duplicatedCount = lineNameCounter.get(baseLineName) || 0;
    const lineName = duplicatedCount > 1 ? `${baseLineName} ${currentIndex}` : baseLineName;
    if (isBlockedLineName(lineName)) continue;

    const episodes = [];
    $(episodeContainers[i]).find("a").each((idx, node) => {
      const name = $(node).text().trim() || `第${idx + 1}集`;
      const fid = `${normalizedVideoId}#${i}#${idx}`;
      episodes.push({
        name,
        playId: `${normalizedVideoId}|${i}|${idx}|||${encodeMeta({ sid: normalizedVideoId, fid, e: name })}`
      });
    });
    if (episodes.length === 0) {
      const fid = `${normalizedVideoId}#${i}#0`;
      episodes.push({ name: "正片", playId: `${normalizedVideoId}|${i}|0|||${encodeMeta({ sid: normalizedVideoId, fid, e: "正片" })}` });
    }
    collectGroups.push({ lineIndex: i, name: lineName, episodes });
  }

  const magnetGroups = [];
  const magnetMetaMap = new Map();
  const upsertMagnetMeta = (rawLink = "", meta = {}) => {
    const link = text(rawLink);
    if (!/^(magnet:\?xt=urn:btih:|ed2k:\/\/|https?:\/\/[^\s]+\.torrent(?:$|\?))/i.test(link)) return;
    const normalized = link.startsWith("magnet:") ? normalizeMagnetUrl(link) : link;
    if (!normalized) return;
    const previous = magnetMetaMap.get(normalized) || {};
    magnetMetaMap.set(normalized, {
      ...previous,
      ...meta,
      link: normalized,
      zname: pickBetterShareDisplayName(meta?.zname || meta?.name || "", previous?.zname || previous?.name || ""),
      zsize: text(meta?.zsize || previous?.zsize || ""),
      zqxd: text(meta?.zqxd || previous?.zqxd || ""),
      ezt: text(meta?.ezt || previous?.ezt || ""),
      type: normalizeSeedType(meta?.type || previous?.type || "", normalized)
    });
  };
  html.replace(/magnet:\?xt=urn:btih:[A-Za-z0-9]+[^"'\s<]*/gi, (match) => {
    upsertMagnetMeta(match);
    return match;
  });
  html.replace(/ed2k:\/\/[^"'\s<]+/gi, (match) => {
    upsertMagnetMeta(match);
    return match;
  });
  html.replace(/https?:\/\/[^"'\s<]+\.torrent(?:\?[^"'\s<]*)?/gi, (match) => {
    upsertMagnetMeta(match);
    return match;
  });
  $("a").each((_, node) => {
    const anchor = $(node);
    const href = text(anchor.attr("href"));
    const clipboard = text(anchor.attr("data-clipboard-text"));
    const title = pickBetterShareDisplayName(anchor.attr("title"), anchor.text());
    upsertMagnetMeta(href, { zname: title });
    upsertMagnetMeta(clipboard, { zname: title });
  });
  Array.from(magnetMetaMap.values()).forEach((item, index) => {
    const episode = buildMagnetEpisode(item, item?.zname || `磁力资源${index + 1}`);
    magnetGroups.push({
      lineIndex: index,
      name: `磁力线路${index + 1}`,
      episodes: [{
        name: episode.name,
        playId: episode.playId,
        _displayName: episode._displayName || episode.name,
        _rawName: episode._rawName || episode.name,
        _seedType: episode.seedType,
        _episodeNumber: episode.episodeNumber,
        _episodeRangeStart: episode.episodeRangeStart,
        _episodeRangeEnd: episode.episodeRangeEnd
      }]
    });
  });

  const shareMetaMap = new Map();
  const panRegex = /https?:\/\/(pan\.baidu\.com|pan\.quark\.cn|drive\.uc\.cn|cloud\.189\.cn|yun\.139\.com|alipan\.com|aliyundrive\.com|115\.com|115cdn\.com|123pan\.com|123684\.com|123865\.com|123912\.com|pan\.xunlei\.com)\/[^"'\s>]+/g;
  const htmlPanLinks = html.match(panRegex) || [];
  for (const rawLink of htmlPanLinks) {
    const shareURL = normalizeShareUrl(rawLink);
    if (shareURL) shareMetaMap.set(shareURL, shareURL);
  }
  $("a").each((_, node) => {
    const href = text($(node).attr("href"));
    const clipboard = text($(node).attr("data-clipboard-text"));
    if (isPanUrl(href)) shareMetaMap.set(normalizeShareUrl(href), normalizeShareUrl(href));
    if (isPanUrl(clipboard)) shareMetaMap.set(normalizeShareUrl(clipboard), normalizeShareUrl(clipboard));
  });

  const grouped = {};
  for (const shareURL of shareMetaMap.keys()) {
    const panTypeKey = inferDriveTypeFromShareURL(shareURL);
    if (!panTypeKey) continue;
    if (!grouped[panTypeKey]) grouped[panTypeKey] = [];
    grouped[panTypeKey].push(shareURL);
  }
  if (collectGroups.length > 0) grouped.collect = collectGroups;
  if (magnetGroups.length > 0) grouped.magnet = magnetGroups;

  return { detailInfo, grouped };
}

function buildGroupCacheKey(videoId = "") {
  return `${store.meta.key}:group:${SCRIPT_VERSION}:${text(videoId)}`;
}

async function buildAndCacheVideoPanDetail(video = {}) {
  const videoId = text(video?.vod_id);
  if (!videoId) return null;
  const panData = await extractPanLinksFromDetail(videoId);
  const detailInfo = panData?.detailInfo || {};
  const groupedRaw = panData?.grouped || {};
  const allLinks = [];
  for (const [groupKey, links] of Object.entries(groupedRaw)) {
    if (groupKey === "collect" || groupKey === "magnet") continue;
    allLinks.push(...(Array.isArray(links) ? links : []));
  }
  let invalidLinksSet = new Set();
  if (allLinks.length > 0) {
    const checked = await checkLinksWithPanCheck(allLinks);
    invalidLinksSet = checked.invalidLinksSet || new Set();
  }

  const grouped = {};
  for (const [groupKey, links] of Object.entries(groupedRaw)) {
    if (groupKey === "collect" || groupKey === "magnet") {
      if (Array.isArray(links) && links.length > 0) grouped[groupKey] = links;
      continue;
    }
    const filtered = [...new Set((links || []).map((item) => normalizeShareUrl(item)).filter((item) => item && !invalidLinksSet.has(item)))];
    if (filtered.length > 0) grouped[groupKey] = filtered;
  }

  const payload = {
    video: {
      vod_id: videoId,
      vod_name: text(video?.vod_name || detailInfo?.vod_name),
      vod_pic: text(video?.vod_pic || detailInfo?.vod_pic),
      vod_remarks: text(video?.vod_remarks || detailInfo?.vod_remarks)
    },
    detailInfo,
    grouped
  };
  await setCachedJSON(buildGroupCacheKey(videoId), payload, GROUP_CACHE_TTL_SECONDS);
  return payload;
}

async function ensureDetailCache(videoId, video = {}) {
  const normalizedVideoId = text(videoId || video?.vod_id);
  if (!normalizedVideoId) return null;
  const cacheKey = buildGroupCacheKey(normalizedVideoId);
  const cached = await getCachedJSON(cacheKey);
  if (cached?.grouped) return cached;
  return buildAndCacheVideoPanDetail({
    vod_id: normalizedVideoId,
    vod_name: text(video?.vod_name),
    vod_pic: text(video?.vod_pic),
    vod_remarks: text(video?.vod_remarks)
  });
}

function build115MagnetCacheKey(magnet = "") {
  return buildCacheKey("115_magnet", [text(magnet).toLowerCase()]);
}

function normalize115OfflineFiles(files = []) {
  return (Array.isArray(files) ? files : [])
    .map((file, index) => ({
      id: text(file?.id || file?.fid || file?.file_id || file?.pickcode || file?.pick_code || index),
      name: text(file?.name || file?.file_name || file?.server_filename || `115文件${index + 1}`),
      size: Number(file?.size || file?.file_size || 0) || 0,
      pickcode: text(file?.pickcode || file?.pick_code || "")
    }))
    .filter((file) => file.id && file.name);
}

async function cache115MagnetResult(magnet, result) {
  if (!magnet || !Array.isArray(result?.files) || result.files.length === 0) return;
  await setCachedJSON(build115MagnetCacheKey(magnet), result, QIWEI_115_MAGNET_CACHE_TTL_SECONDS);
}

function build115Headers(referer = "https://115.com/") {
  return {
    "User-Agent": UA,
    Cookie: QIWEI_115_COOKIE,
    Origin: "https://115.com",
    Referer: referer,
    Accept: "application/json, text/javascript, */*; q=0.01",
    "X-Requested-With": "XMLHttpRequest"
  };
}

async function pushMagnetTo115(magnet, options = {}) {
  const normalizedMagnet = text(magnet);
  if (!QIWEI_115_COOKIE) return { ok: false, state: "no_cookie", files: [], magnet: normalizedMagnet };
  if (!normalizedMagnet.startsWith("magnet:")) return { ok: false, state: "invalid_magnet", files: [], magnet: normalizedMagnet };

  const cacheKey = build115MagnetCacheKey(normalizedMagnet);
  if (options.useCache !== false) {
    const cached = await getCachedJSON(cacheKey);
    if (Array.isArray(cached?.files) && cached.files.length > 0) {
      logInfo(`115秒传缓存命中 fileCount=${cached.files.length}`);
      return { ...cached, ok: true, state: cached.state || "cached", magnet: normalizedMagnet, cached: true };
    }
  }

  try {
    const uid = QIWEI_115_COOKIE.match(/UID=(\d+)/)?.[1] || "";
    if (!uid) return { ok: false, state: "missing_uid", files: [], magnet: normalizedMagnet };
    const httpsAgent = new (require("https").Agent)({ rejectUnauthorized: false });
    const headers = build115Headers("https://115.com/web/lixian/");
    const spaceRes = await axios.get("https://115.com/?ct=offline&ac=space", { headers, timeout: 10000, httpsAgent });
    const spaceJson = spaceRes.data || {};
    if (!spaceJson.state || !spaceJson.sign || !spaceJson.time) {
      logWarn(`115秒传签名失败 state=${stringifyForLog(spaceJson)}`);
      return { ok: false, state: "space_failed", files: [], magnet: normalizedMagnet, raw: spaceJson };
    }

    const addTask = async () => {
      const res = await axios.post(
        "https://115.com/web/lixian/?ct=lixian&ac=add_task_url",
        `url=${encodeURIComponent(normalizedMagnet)}&uid=${uid}&sign=${spaceJson.sign}&time=${spaceJson.time}`,
        { headers: { ...headers, "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" }, timeout: 15000, httpsAgent }
      );
      return res.data || {};
    };

    let finalJson = await addTask();
    let files = normalize115OfflineFiles(finalJson?.files || []);
    const pollMaxAttempts = Number(options.pollMaxAttempts || 4);
    const pollIntervalMs = Number(options.pollIntervalMs || 1500);
    for (let attempt = 0; files.length === 0 && attempt < pollMaxAttempts && (finalJson.state || finalJson.errcode === 0 || finalJson.errcode === 10008); attempt += 1) {
      await sleep(pollIntervalMs);
      finalJson = await addTask();
      files = normalize115OfflineFiles(finalJson?.files || []);
      if (finalJson?.errcode === 10008 && files.length === 0) break;
    }

    if (finalJson.state || finalJson.errcode === 0 || finalJson.errcode === 10008) {
      const result = {
        ok: true,
        state: finalJson.errcode === 10008 ? "exists" : (files.length > 0 ? "submitted" : "submitted_waiting"),
        magnet: normalizedMagnet,
        infoHash: text(finalJson.info_hash),
        files,
        raw: finalJson
      };
      if (files.length > 0) await cache115MagnetResult(normalizedMagnet, result);
      logInfo(`115秒传提交完成 state=${result.state}, fileCount=${files.length}`);
      return result;
    }
    return { ok: false, state: "add_failed", files, magnet: normalizedMagnet, raw: finalJson };
  } catch (e) {
    logWarn(`115秒传异常: ${e.message}`);
    return { ok: false, state: "exception", files: [], magnet: normalizedMagnet, error: e.message };
  }
}

async function build115EpisodesFromMagnet(magnet, baseName = "115资源") {
  const result = await pushMagnetTo115(magnet);
  if (!result?.ok || !Array.isArray(result.files) || result.files.length === 0) {
    return { episodes: [], reason: result?.state || "push_failed", state: result?.state || "" };
  }
  const hash = result.infoHash || CryptoJS.SHA1(text(magnet)).toString();
  return {
    name: "115网盘",
    result,
    episodes: result.files.map((file, index) => {
      const rawName = cleanPlayLabel(file.name, `${baseName}${index + 1}`);
      const displayName = file.size > 0 ? `[${formatFileSize(file.size)}] ${rawName}` : rawName;
      const episodeRange = extractEpisodeRange(rawName);
      const episodeNumber = episodeRange ? null : extractEpisodeNumber(rawName);
      const name = episodeRange
        ? formatEpisodeRangeLabel(episodeRange, `${baseName}${index + 1}`)
        : (episodeNumber ? formatEpisodeLabel(episodeNumber, `${baseName}${index + 1}`) : `${baseName}${index + 1}`);
      const meta = { type: "115_magnet", magnet, fileName: rawName, fileId: file.id, pickcode: file.pickcode };
      return {
        name,
        playId: build115MagnetPlayId(meta),
        _displayName: displayName,
        _rawName: rawName,
        _seedType: "115",
        _episodeNumber: episodeNumber,
        _episodeRangeStart: episodeRange?.start ?? null,
        _episodeRangeEnd: episodeRange?.end ?? null,
        _fid: `115magnet:${hash}:${file.id}`
      };
    })
  };
}

function same115FileName(a = "", b = "") {
  const basename = (value) => text(value).split(/[\\/]/).pop();
  return Boolean(basename(a) && basename(a) === basename(b));
}

async function find115FileByName(fileName = "") {
  const targetName = text(fileName);
  if (!targetName || !QIWEI_115_COOKIE) return null;
  const key = buildCacheKey("115_file", [targetName]);
  const cached = await getCachedJSON(key);
  if (cached?.fid || cached?.pickcode) return cached;
  const keyword = targetName.split(/[\\/]/).pop().replace(/\.[a-z0-9]{2,5}$/i, "").slice(0, 80);
  const res = await axios.get(`https://webapi.115.com/files/search?search_value=${encodeURIComponent(keyword)}&format=json&type=4&limit=50`, {
    headers: build115Headers(),
    timeout: 10000,
    httpsAgent: new (require("https").Agent)({ rejectUnauthorized: false })
  });
  const json = res.data || {};
  const list = Array.isArray(json?.data) ? json.data : (Array.isArray(json?.data?.list) ? json.data.list : (Array.isArray(json?.files) ? json.files : []));
  const normalized = list.map((item) => ({
    fid: text(item.fid || item.file_id || item.id || item.cid || ""),
    name: text(item.n || item.name || item.file_name || item.server_filename || ""),
    pickcode: text(item.pc || item.pickcode || item.pick_code || ""),
    size: Number(item.s || item.size || item.file_size || 0) || 0
  })).filter((item) => item.name && (item.fid || item.pickcode));
  const matched = normalized.find((item) => same115FileName(item.name, targetName)) || normalized[0] || null;
  if (matched) await setCachedJSON(key, matched, QIWEI_115_MAGNET_CACHE_TTL_SECONDS);
  return matched;
}

async function get115VideoPlayUrl(file) {
  const pickcode = text(file?.pickcode || file?.pc || "");
  if (!pickcode) throw new Error("115真实文件缺少 pickcode，无法解析播放地址");
  const urls = [
    `https://115.com/api/video/m3u8/${encodeURIComponent(pickcode)}.m3u8`,
    `https://webapi.115.com/files/video?pickcode=${encodeURIComponent(pickcode)}`
  ];
  let lastError = null;
  for (const url of urls) {
    try {
      const res = await axios.get(url, {
        headers: build115Headers(),
        timeout: 10000,
        maxRedirects: 0,
        validateStatus: (status) => status >= 200 && status < 400,
        httpsAgent: new (require("https").Agent)({ rejectUnauthorized: false })
      });
      if (res.headers?.location) return res.headers.location;
      if (typeof res.data === "string" && res.data.includes("#EXTM3U")) return url;
      const data = res.data || {};
      const candidate = data?.data?.video_url || data?.data?.url || data?.video_url || data?.url || data?.data?.m3u8 || data?.m3u8 || "";
      if (candidate) return candidate;
    } catch (e) {
      lastError = e;
      logWarn(`115视频地址解析失败 url=${url}, error=${e.message}`);
    }
  }
  throw lastError || new Error("115未返回可播放地址");
}

async function resolve115MagnetPlay(playIdOrData) {
  const data = typeof playIdOrData === "object" && playIdOrData
    ? playIdOrData
    : safeJsonParse(Buffer.from(text(playIdOrData).replace(/^115magnet:/, ""), "base64").toString("utf8"), {});
  const magnet = text(data.magnet);
  const result = await pushMagnetTo115(magnet);
  const targetFile = (result.files || []).find((file) => text(file.id) === text(data.fileId)) || (result.files || [])[0];
  if (!targetFile?.name) throw new Error("115秒传缓存未找到目标文件名");
  const realFile = await find115FileByName(targetFile.name);
  if (!realFile) throw new Error("115网盘内未搜索到真实文件");
  const playUrl = await get115VideoPlayUrl(realFile);
  return {
    parse: 0,
    url: playUrl,
    urls: [{ name: "115播放", url: playUrl }],
    flag: "115网盘",
    header: { "User-Agent": UA, Referer: "https://115.com/", Cookie: QIWEI_115_COOKIE },
    headers: { "User-Agent": UA, Referer: "https://115.com/", Cookie: QIWEI_115_COOKIE }
  };
}

function buildDirectPlayResult(url) {
  return { parse: isDirectVideoUrl(url) ? 0 : 1, url };
}

function resolveCallerSource(params = {}, context = {}) {
  return text(context?.from || params?.source).toLowerCase();
}

function resolveRouteType(flag = "", callerSource = "") {
  let routeType = callerSource === "web" ? "服务端代理" : "直连";
  if (flag) {
    if (flag.includes("-")) {
      const parts = flag.split("-");
      routeType = parts[parts.length - 1];
    } else {
      routeType = flag;
    }
  }
  return routeType;
}

function parsePlayerData(html = "") {
  const match = html.match(/r player_.*?=(.*?)<\/script>/);
  if (!match?.[1]) return {};
  return safeJsonParse(match[1], {});
}

function stripPanTypeSuffix(name = "") {
  const raw = text(name);
  if (!raw) return "";
  return raw.replace(/\s*\[[^\]]*(?:网盘|夸克|百度|阿里|UC|115|天翼|迅雷|移动|123)[^\]]*\]\s*$/u, "").trim() || raw;
}

function summarizePlayResult(result) {
  const urls = Array.isArray(result?.urls) ? result.urls : [];
  return {
    parse: Number(result?.parse ?? -1),
    url: text(result?.url || urls[0]?.url).slice(0, 240),
    urlCount: urls.length,
    headerKeys: Object.keys(result?.header || {})
  };
}

async function resolveDriveVod(shareURL) {
  for (const drive of store.drives || []) {
    try {
      if (!drive.matchShare?.(shareURL)) continue;
      const vod = await drive.getVod?.(shareURL);
      if (vod) return { vod, drive };
    } catch (e) {
      logWarn(`驱动详情解析失败 drive=${drive?.key || "unknown"}, error=${e.message}`);
    }
  }
  return { vod: null, drive: null };
}

async function home() {
  return withCache("home", [], LIST_CACHE_TTL_SECONDS, async () => {
    const { html, host } = await requestWithFailover("/");
    const list = parseVideoList(html, host).map((item) => buildPanSearchEntryVod(item, host)).filter((item) => item.vod_id && item.vod_name);
    return { class: SITE_CONFIG.class, filters: SITE_CONFIG.filter, list };
  });
}

async function category(params, context = {}) {
  const categoryId = text(params.id || params.type_id || "1");
  const page = parsePage(params.page, 1);
  const filters = parseFilters(params);
  const parsed = parseFolderVodId(categoryId);
  const parsedVideoId = extractVideoId(parsed.videoId);
  const targetPanType = normalizeDriveType(parsed.panTypeKey || "");
  const sourceType = text(parsed.sourceType).toLowerCase();

  if (parsed.kind === "panroot" && parsedVideoId) {
    const payload = await ensureDetailCache(parsedVideoId, { vod_id: parsedVideoId });
    const grouped = payload?.grouped || {};
    const video = payload?.video || { vod_id: parsedVideoId };
    const list = buildPanGroupEntries(video, grouped);
    return { page, pagecount: 1, total: list.length, limit: PAGE_LIMIT, list };
  }

  if (parsed.kind === "sourcefolder" && parsedVideoId && sourceType) {
    const payload = await ensureDetailCache(parsedVideoId, { vod_id: parsedVideoId });
    const groups = Array.isArray(payload?.grouped?.[sourceType]) ? payload.grouped[sourceType] : [];
    const list = buildSourceLineEntries(payload?.video || { vod_id: parsedVideoId }, sourceType, groups);
    const paged = paginateList(list, 1, 20);
    return buildFolderPageResult(paged);
  }

  if (parsed.kind === "sourceline" && parsedVideoId && sourceType) {
    return detail({ id: categoryId }, context);
  }

  if (parsed.kind === "pangroup" && parsedVideoId && targetPanType) {
    const payload = await ensureDetailCache(parsedVideoId, { vod_id: parsedVideoId });
    const detailInfo = payload?.detailInfo || {};
    const video = payload?.video || { vod_id: parsedVideoId };
    const links = Array.isArray(payload?.grouped?.[targetPanType]) ? payload.grouped[targetPanType] : [];
    const list = buildPanShareEntries(video, detailInfo, targetPanType, links);
    const paged = paginateList(list, 1, 20);
    return buildFolderPageResult(paged);
  }

  return withCache("category", [categoryId, page, filters], LIST_CACHE_TTL_SECONDS, async () => {
    const path = buildCategoryPath(categoryId, page, filters);
    const { html, host } = await requestWithFailover(path);
    const list = parseVideoList(html, host).map((item) => buildPanSearchEntryVod(item, host)).filter((item) => item.vod_id && item.vod_name);
    return {
      page,
      pagecount: list.length >= PAGE_LIMIT ? page + 1 : page,
      total: list.length,
      limit: PAGE_LIMIT,
      list
    };
  });
}

async function search(params) {
  const keyword = text(params.wd || params.keyword);
  const page = parsePage(params.page, 1);
  if (!keyword) return { page, pagecount: 1, total: 0, list: [] };
  return withCache("search", [QIWEI_SEARCH_API_TEMPLATE, keyword, page], LIST_CACHE_TTL_SECONDS, async () => {
    const path = buildSearchApiPath(keyword, page, PAGE_LIMIT);
    const { html, host } = await requestWithFailover(path, {
      headers: {
        Accept: "application/json, text/plain, */*",
        "X-Requested-With": "XMLHttpRequest",
        Referer: `${getCurrentHost()}/`
      }
    });
    const data = safeJsonParse(html, {});
    const normalized = normalizeSearchResponse(data, host, page);
    if (normalized.list.length > 0 || !/^</.test(text(html))) {
      logInfo(`搜索接口完成 path=${path}, host=${host}, count=${normalized.list.length}, total=${normalized.total}, pagecount=${normalized.pagecount}`);
      return normalized;
    }

    const list = parseVideoList(html, host).map((item) => buildPanSearchEntryVod(item, host)).filter((item) => item.vod_id && item.vod_name);
    logInfo(`搜索接口返回HTML，已按列表页兜底解析 path=${path}, host=${host}, count=${list.length}`);
    return {
      page,
      pagecount: list.length >= PAGE_LIMIT ? page + 1 : page,
      total: list.length,
      limit: PAGE_LIMIT,
      list
    };
  });
}

async function detail(params, context = {}) {
  const rawId = Array.isArray(params.id) ? text(params.id[0]) : text(params.id || params.videoId);
  const parsed = parseFolderVodId(rawId);
  const videoId = extractVideoId(parsed.videoId || rawId);
  const targetPanType = normalizeDriveType(parsed.panTypeKey || "");
  const sourceType = text(parsed.sourceType).toLowerCase();

  if (!videoId) return { list: [] };

  if (parsed.kind === "sourceline" && sourceType) {
    const payload = await ensureDetailCache(videoId, { vod_id: videoId });
    const detailInfo = payload?.detailInfo || {};
    const video = payload?.video || { vod_id: videoId };
    const groups = Array.isArray(payload?.grouped?.[sourceType]) ? payload.grouped[sourceType] : [];
    const targetGroup = groups.find((group, index) => (group?.lineIndex ?? index) === (parseInt(parsed.lineIndex, 10) || 0));
    if (!targetGroup) return { list: [] };
    const lineName = text(targetGroup.name || (sourceType === "magnet" ? "磁力线路" : "采集线路"));
    const normalizeSourceEpisodes = (episodes, defaultPrefix) => {
      let list = (Array.isArray(episodes) ? episodes : []).map((ep, index) => ({
        name: text(ep?.name || `${defaultPrefix}${index + 1}`),
        playId: text(ep?.playId),
        _displayName: text(ep?._displayName || ep?.name || ""),
        _rawName: text(ep?._rawName || ep?.name || ""),
        _seedType: text(ep?._seedType || ""),
        _episodeNumber: Number.isFinite(ep?._episodeNumber) ? ep._episodeNumber : null,
        _episodeRangeStart: Number.isFinite(ep?._episodeRangeStart) ? ep._episodeRangeStart : null,
        _episodeRangeEnd: Number.isFinite(ep?._episodeRangeEnd) ? ep._episodeRangeEnd : null
      })).filter((ep) => ep.playId);
      if (sourceType === "magnet") {
        list = sortEpisodesByEpisodeNumber(list.map((ep) => ({
          ...ep,
          name: ep._displayName || ep.name,
          episodeNumber: ep._episodeNumber,
          episodeRangeStart: ep._episodeRangeStart,
          episodeRangeEnd: ep._episodeRangeEnd
        })));
      }
      return list;
    };

    const rawEpisodes = Array.isArray(targetGroup.episodes) ? targetGroup.episodes : [];
    const playSources = [];
    if (sourceType === "magnet") {
      const convertedEpisodes = [];
      const failures = [];
      for (const ep of rawEpisodes) {
        const magnetPlayId = text(ep?.playId);
        if (!magnetPlayId.startsWith("magnet:")) {
          failures.push(text(ep?.name || "非磁力资源"));
          continue;
        }
        const converted = await build115EpisodesFromMagnet(magnetPlayId, ep?.name || "115资源");
        if (converted?.episodes?.length) convertedEpisodes.push(...converted.episodes);
        else failures.push(`${text(ep?.name || "磁力资源")}:${converted?.reason || "empty"}`);
      }
      const episodes115 = convertedEpisodes
        .map((ep, index) => ({
          name: stripEpisodeSerialSuffix(cleanPlayLabel(ep?._rawName || ep?._displayName || ep?.name, `115资源${index + 1}`), index),
          playId: text(ep?.playId)
        }))
        .filter((ep) => ep.playId);
      if (episodes115.length > 0) {
        playSources.push({ name: "115秒传", episodes: episodes115 });
      } else if (rawEpisodes.length > 0) {
        logWarn(`磁力线路秒传115未生成资源 line=${parsed.lineIndex}, failures=${failures.slice(0, 3).join(";")}`);
      }
    }

    const normalizedEpisodes = normalizeSourceEpisodes(rawEpisodes, sourceType === "magnet" ? "磁力资源" : "第")
      .map((ep, index) => normalizePlayableEpisode({
        ...ep,
        playId: sourceType === "magnet"
          ? buildMagnetPlayId(videoId, targetGroup?.lineIndex ?? 0, index, ep.playId)
          : ep.playId
      }, index, sourceType === "magnet" ? "磁力资源" : "第"))
      .filter((item) => item.playId);
    if (normalizedEpisodes.length > 0) {
      playSources.push({ name: lineName || (sourceType === "magnet" ? "磁力" : "采集线路"), episodes: normalizedEpisodes });
    }

    const legacyPlay = buildLegacyPlayFields(playSources);
    const vod = {
      vod_id: rawId,
      vod_name: stripPanTypeSuffix(detailInfo.vod_name || video.vod_name || "七味资源"),
      vod_pic: detailInfo.vod_pic || video.vod_pic || "",
      vod_content: detailInfo.vod_content || "",
      vod_remarks: detailInfo.vod_remarks || text(targetGroup.name),
      type_name: detailInfo.type_name || text(targetGroup.name),
      vod_year: detailInfo.vod_year || "",
      vod_area: detailInfo.vod_area || "",
      vod_actor: detailInfo.vod_actor || "",
      vod_director: detailInfo.vod_director || "",
      vod_play_from: legacyPlay.vod_play_from,
      vod_play_url: legacyPlay.vod_play_url
    };
    logInfo(`详情最终接口输出格式 ${stringifyForLog({
      videoId,
      sourceType,
      lineIndex: parseInt(parsed.lineIndex, 10) || 0,
      vodPlayFrom: vod.vod_play_from,
      vodPlayUrlLength: vod.vod_play_url.length,
      vodPlayUrlPreview: vod.vod_play_url.slice(0, 500),
      playSourcesPreview: playSources.map((source, sourceIndex) => ({
        sourceIndex,
        name: source.name,
        episodeCount: Array.isArray(source.episodes) ? source.episodes.length : 0,
        episodes: (source.episodes || []).slice(0, 12).map((ep, episodeIndex) => {
          const parsedPlayId = parseFolderVodId(ep?.playId || "");
          return {
            episodeIndex,
            name: ep?.name || "",
            nameLength: text(ep?.name).length,
            playIdKind: parsedPlayId?.kind || (text(ep?.playId).startsWith("magnet:") ? "magnet" : (text(ep?.playId).startsWith("115magnet:") ? "115magnet_legacy" : "raw")),
            playIdPrefix: text(ep?.playId).slice(0, 32),
            playIdLength: text(ep?.playId).length
          };
        })
      })),
      legacyParsed: summarizeLegacyPlayFields(vod.vod_play_from, vod.vod_play_url),
      responseShape: { list: 1, fields: Object.keys(vod) }
    })}`);
    return buildSingleDetailResult(vod);
  }

  if (parsed.kind === "panshare" && targetPanType) {
    const payload = await ensureDetailCache(videoId, { vod_id: videoId });
    const detailInfo = payload?.detailInfo || {};
    const video = payload?.video || { vod_id: videoId };
    const links = Array.isArray(payload?.grouped?.[targetPanType]) ? payload.grouped[targetPanType] : [];
    const shareURL = normalizeShareUrl(links[parseInt(parsed.shareIndex, 10) || 0] || "");
    if (!shareURL) return { list: [] };
    const { vod } = await resolveDriveVod(shareURL);
    if (!vod) {
      logWarn(`网盘详情解析失败 share=${shareURL}`);
      return { list: [] };
    }
    return buildSingleDetailResult({
      vod_id: rawId,
      vod_name: stripPanTypeSuffix(detailInfo.vod_name || video.vod_name || vod.vod_name || "七味资源"),
      vod_pic: detailInfo.vod_pic || video.vod_pic || vod.vod_pic || "",
      vod_content: detailInfo.vod_content || vod.vod_content || "",
      vod_remarks: detailInfo.vod_remarks || parsePanType(shareURL),
      type_name: detailInfo.type_name || parsePanType(shareURL),
      vod_year: detailInfo.vod_year || vod.vod_year || "",
      vod_area: detailInfo.vod_area || vod.vod_area || "",
      vod_actor: detailInfo.vod_actor || vod.vod_actor || "",
      vod_director: detailInfo.vod_director || vod.vod_director || "",
      vod_play_from: vod.vod_play_from,
      vod_play_url: vod.vod_play_url
    });
  }

  return withCache("detail_warm", [videoId], DETAIL_CACHE_TTL_SECONDS, async () => {
    const { html, host } = await requestWithFailover(`/mv/${videoId}.html`);
    const detailInfo = parseDetailInfo(html, host);
    await ensureDetailCache(videoId, {
      vod_id: videoId,
      vod_name: detailInfo.vod_name || "",
      vod_pic: detailInfo.vod_pic || "",
      vod_remarks: detailInfo.vod_remarks || ""
    });
    return { list: [] };
  });
}

async function play(params, context = {}) {
  let playId = text(params.id || params.playId);
  const flag = text(params.flag);
  const callerSource = resolveCallerSource(params, context);
  let playMeta = {};

  if (!playId) return { parse: 1, url: "" };
  if (playId.includes("|||")) {
    const [mainPlayId, metaB64] = playId.split("|||");
    playId = mainPlayId;
    playMeta = decodeMeta(metaB64 || "");
  }

  const wrapped = async () => {
    if (playId.startsWith("115magnet:")) {
      try {
        return await resolve115MagnetPlay(playId);
      } catch (e) {
        logWarn(`115磁力播放失败，回退磁力: ${e.message}`);
        if (playMeta.magnet) playId = playMeta.magnet;
        else throw e;
      }
    }

    const parsedPlay = parseFolderVodId(playId);
    if (parsedPlay?.kind === "115magnetplay") {
      return await resolve115MagnetPlay(parsedPlay);
    }

    if (parsedPlay?.kind === "magnetplay") {
      const magnetUrl = normalizeMagnetUrl(parsedPlay.magnetUrl || "");
      await pushMagnetTo115(magnetUrl);
      const urls = buildMagnetPlayUrls(magnetUrl);
      return {
        url: urls[0]?.url || magnetUrl,
        urls,
        parse: 0,
        flag: "magnet",
        header: MAGNET_PLAY_HEADERS,
        headers: MAGNET_PLAY_HEADERS
      };
    }

    if (/^magnet:/i.test(playId)) {
      const magnetUrl = normalizeMagnetUrl(playId);
      await pushMagnetTo115(magnetUrl);
      const torrentLikeUrl = normalizeTorrentLikePlayUrl(magnetUrl);
      if (/^file:\/\//i.test(torrentLikeUrl)) {
        const urls = buildMagnetPlayUrls(torrentLikeUrl);
        return {
          url: urls[0]?.url || torrentLikeUrl,
          urls,
          parse: 0,
          flag: "torrent",
          header: MAGNET_PLAY_HEADERS,
          headers: MAGNET_PLAY_HEADERS
        };
      }
      const urls = buildMagnetPlayUrls(magnetUrl);
      return {
        url: urls[0]?.url || magnetUrl,
        urls,
        parse: 0,
        flag: "magnet",
        header: MAGNET_PLAY_HEADERS,
        headers: MAGNET_PLAY_HEADERS
      };
    }

    const drive = (store.drives || []).find((item) => new RegExp(`^${item.key}`, "i").test(flag));
    if (drive?.play && !playId.startsWith("http")) {
      return await drive.play(playId, flag || resolveRouteType(flag, callerSource));
    }

    if (isPanUrl(playId)) {
      const matchedDrive = (store.drives || []).find((item) => item.matchShare?.(playId));
      if (matchedDrive?.getVod) {
        const vod = await matchedDrive.getVod(playId);
        if (vod?.vod_play_from && vod?.vod_play_url) {
          const firstFlag = text(vod.vod_play_from.split("$$$")[0]);
          const firstGroup = text(vod.vod_play_url.split("$$$")[0]);
          const firstPlayId = text(firstGroup.split("#")[0]).split("$").pop();
          if (firstFlag && firstPlayId && matchedDrive.play) {
            return await matchedDrive.play(firstPlayId, firstFlag);
          }
        }
      }
      return { parse: 0, url: `push://${normalizeShareUrl(playId)}`, urls: [{ name: "网盘资源", url: `push://${normalizeShareUrl(playId)}` }], header: {} };
    }

    const parts = playId.split("|");
    if (parts.length === 3 && parts.every(Boolean)) {
      return withCache("play_collect", [flag, playId], PLAY_CACHE_TTL_SECONDS, async () => {
        const videoId = parts[0];
        const lineIndex = parseInt(parts[1], 10);
        const episodeIndex = parseInt(parts[2], 10);
        const pageUrl = `${getCurrentHost()}/py/${videoId}-${lineIndex + 1}-${episodeIndex + 1}.html`;
        try {
          const html = await requestText(pageUrl, { referer: `${getCurrentHost()}/` });
          const player = parsePlayerData(html);
          const rawUrl = text(player?.url);
          const encrypt = Number(player?.encrypt || 0);
          let decodedUrl = rawUrl;
          if (encrypt === 1) decodedUrl = unescape(rawUrl);
          if (encrypt === 2) decodedUrl = unescape(Buffer.from(rawUrl, "base64").toString("utf8"));
          decodedUrl = text(decodedUrl).replace(/\\\//g, "/");
          if (decodedUrl) {
            const abs = fixUrl(decodedUrl);
            if (isDirectVideoUrl(abs)) {
              return {
                parse: 0,
                url: abs,
                urls: [{ name: "默认线路", url: abs }],
                header: {
                  "User-Agent": UA,
                  Referer: pageUrl,
                  Origin: getCurrentHost()
                }
              };
            }
            return {
              parse: 1,
              jx: 1,
              url: abs,
              header: {
                "User-Agent": UA,
                Referer: pageUrl,
                Origin: getCurrentHost()
              }
            };
          }
        } catch (e) {
          logWarn(`采集播放页解析失败 url=${pageUrl}, error=${e.message}, meta=${stringifyForLog(playMeta)}`);
        }
        return {
          parse: 1,
          jx: 1,
          url: pageUrl,
          header: {
            "User-Agent": UA,
            Referer: `${getCurrentHost()}/`,
            Origin: getCurrentHost()
          }
        };
      });
    }

    const resolvedPlayUrl = fixUrl(playId);
    if (isDirectVideoUrl(resolvedPlayUrl)) {
      return {
        parse: 0,
        url: resolvedPlayUrl,
        urls: [{ name: "默认线路", url: resolvedPlayUrl }],
        header: {
          "User-Agent": UA,
          Referer: `${getCurrentHost()}/`,
          Origin: getCurrentHost()
        }
      };
    }
    return buildDirectPlayResult(resolvedPlayUrl);
  };

  const result = await wrapped();
  logInfo(`play flag=${flag}, id=${playId.slice(0, 160)}, result=${stringifyForLog(summarizePlayResult(result))}`);
  return result;
}

module.exports = async (app, opt) => {
  app.get(store.meta.api, async (req, reply) => {
    if (!store.init) await init(req.server);
    reply.header("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
    reply.header("Pragma", "no-cache");
    reply.header("Expires", "0");

    const { ac, t, pg, ids, wd, play: playParam, flag, filter, ext, quick } = req.query;
    try {
      if (playParam) {
        return await play({ flag: flag || "", id: playParam, source: req.query.source || req.query.from }, { from: req.query.from || "" });
      }
      if (wd) {
        return await search({ page: parseInt(String(pg || "1"), 10) || 1, quick: quick || false, wd });
      }
      if (!ac) {
        return await home({ filter: filter ?? false, ext: ext || "" });
      }
      if (ac === "detail") {
        if (t) {
          return await category({
            id: t,
            page: parseInt(String(pg || "1"), 10) || 1,
            filter: filter || false,
            filters: {}
          }, { from: req.query.from || "" });
        }
        if (ids) {
          return await detail({
            id: String(ids).split(",").map((item) => item.trim()).filter(Boolean)
          }, { from: req.query.from || "" });
        }
      }
      if (ac === "class") {
        return { class: SITE_CONFIG.class, filters: SITE_CONFIG.filter };
      }
      return req.query;
    } catch (e) {
      logError(`请求失败: ${e.stack || e.message}`);
      return { list: [], page: 1, pagecount: 1, total: 0, error: e.message };
    }
  });

  opt.sites.push(store.meta);
  logInfo("七味分组不夜版插件已加载");
};
