/**
 * 咪视界直播 - T4 插件
 * 基于本地 127.0.0.1:3330 咪视界直播源聚合后台
 * 线路 = 分类名(分组)，选集 = 频道名，同频道多线路合并为多线路播放
 */
"use strict";
const axios = require("axios");
const http = require("http");
const https = require("https");

const API_HOST = "http://127.0.0.1:3330";

const axiosInstance = axios.create({
    timeout: 10000,
    httpAgent: new http.Agent({ keepAlive: true }),
    headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'application/json, text/plain, */*'
    }
});

const cache = {
    data: new Map(),
    ttl: { home: 60000, category: 30000, detail: 30000 },
    get: (key) => {
        const item = cache.data.get(key);
        if (!item) return null;
        if (Date.now() > item.expire) { cache.data.delete(key); return null; }
        return item.data;
    },
    set: (key, data, type = 'category') => {
        cache.data.set(key, { data, expire: Date.now() + (cache.ttl[type] || 60000) });
        if (cache.data.size > 500) cache.data.clear();
    }
};

/** 分组存储：group_分组名 -> 聚合项 */
const groupStore = new Map();
/** 频道存储：ch_频道名 -> 频道条目（分类页用，不聚合分组） */
const channelStore = new Map();

async function apiGet(params) {
    const url = API_HOST + '/?' + new URLSearchParams(params).toString();
    const res = await axiosInstance.get(url);
    return res.data;
}

/**
 * 频道级构建（分类页用，不聚合分组）：
 *   每条频道一个 vod，同频道多线路合并为多线路切换
 *   vod_play_from = 分类名(每条线路一份)
 *   vod_play_url  = 频道名$url $$$ 频道名$url ... (每条线路一个选集)
 */
function buildByChannel(rawList) {
    const chans = new Map(); // 频道名 -> {urls, pic, group}
    for (const it of rawList || []) {
        const name = (it.vod_name || '').trim();
        if (!name) continue;
        const u = it.vod_play_url || '';
        const url = u.includes('$') ? u.split('$').pop() : u;
        if (!url) continue;
        if (!chans.has(name)) chans.set(name, { urls: [], pic: it.vod_pic || '', group: (it.vod_remarks || '直播').trim() });
        const ch = chans.get(name);
        if (!ch.urls.includes(url)) ch.urls.push(url);
        if (!ch.pic && it.vod_pic) ch.pic = it.vod_pic;
    }
    const list = [];
    for (const [name, ch] of chans) {
        const urls = ch.urls.slice(0, 5); // 线路上限 5
        const lineName = ch.group || '直播';
        const agg = {
            vod_id: 'ch_' + name,
            vod_name: name,
            vod_pic: ch.pic,
            vod_remarks: urls.length + '源',
            vod_play_from: new Array(urls.length).fill(lineName).join('$$$'),
            vod_play_url: urls.map(u => name + '$' + u).join('$$$'),
            vod_content: '频道:' + name + '，共 ' + urls.length + ' 个源'
        };
        channelStore.set('ch_' + name, agg);
        list.push(agg);
    }
    return list;
}

/**
 * 按分组(分类)聚合（首页/全部直播用）：
 *   vod_name        = 分组名(分类名)
 *   vod_play_from   = 分类名$$$分类名...   (线路 = 分类名, 每个线路一份)
 *   vod_play_url    = 频道名$url#频道名$url...  $$$ 频道名$url#频道名$url...
 *                     (每条线路下 选集 = 频道名；同频道多线路 = 多线路播放)
 */
function buildByGroup(rawList) {
    const groups = new Map(); // 分组名 -> Map(频道名 -> Set(url))
    for (const it of rawList || []) {
        const g = (it.vod_remarks || '默认频道').trim();
        const name = (it.vod_name || '').trim();
        if (!name) continue;
        const u = it.vod_play_url || '';
        const url = u.includes('$') ? u.split('$').pop() : u;
        if (!url) continue;
        if (!groups.has(g)) groups.set(g, new Map());
        const chMap = groups.get(g);
        if (!chMap.has(name)) chMap.set(name, new Set());
        chMap.get(name).add(url);
    }
    const list = [];
    for (const [g, chMap] of groups) {
        const names = [...chMap.keys()];
        // 封面: 取该分组第一个频道的 logo
        let firstLogo = '';
        for (const [name, urls] of chMap) {
            const src = rawList.find(it => (it.vod_remarks || '默认频道').trim() === g && (it.vod_name || '').trim() === name);
            if (src && src.vod_pic) { firstLogo = src.vod_pic; break; }
        }
        // 线路数 = 频道中最多线路数, 上限 5
        let maxLines = 1;
        for (const urls of chMap.values()) maxLines = Math.max(maxLines, urls.size);
        maxLines = Math.min(maxLines, 5);
        // 每条线路: 所有频道各取一条 url(不足则用最后一条兜底)
        const urlsPerLine = [];
        for (let i = 0; i < maxLines; i++) {
            const line = [];
            for (const [name, urls] of chMap) {
                const arr = [...urls];
                line.push(name + '$' + (arr[i] || arr[arr.length - 1]));
            }
            urlsPerLine.push(line.join('#'));
        }
        const agg = {
            vod_id: 'group_' + g,
            vod_name: g,
            vod_pic: '',
            vod_remarks: names.length + '个频道',
            vod_play_from: g,
            vod_play_url: urlsPerLine.join('$$$'),
            vod_content: '分类:' + g + '，共 ' + names.length + ' 个频道'
        };
        groupStore.set('group_' + g, agg);
        list.push(agg);
    }
    return list;
}

async function home() {
    const ck = 'home';
    let data = cache.get(ck);
    if (data) return data;
    const raw = await apiGet({});
    const classes = [{ type_id: 'all', type_name: '全部直播' }];
    for (const c of raw.class || []) {
        if (c.type_id && c.type_id.startsWith('group_') && c.type_name) classes.push(c);
    }
    const list = buildByGroup(raw.list);
    data = { class: classes, list };
    cache.set(ck, data, 'home');
    return data;
}

async function category(t, pg) {
    if (t === 'all') return home();
    const ck = 'cat_' + t;
    let data = cache.get(ck);
    if (data) return data;
    const raw = await apiGet({ t });
    const list = buildByGroup(raw.list).filter(x => x.vod_id === t);
    data = { page: 1, pagecount: 1, limit: 999, total: list.length, list };
    cache.set(ck, data, 'category');
    return data;
}

async function detail(idList) {
    const list = [];
    for (const rawId of idList) {
        const key = String(rawId || '');
        let agg = groupStore.get(key);
        if (!agg) {
            const g = key.startsWith('group_') ? key.slice(6) : key;
            const raw = await apiGet({ t: g });
            const built = buildByGroup(raw.list);
            agg = groupStore.get(key) || built.find(x => x.vod_id === key);
        }
        if (agg) list.push(agg);
    }
    return { list };
}

async function play(flag, id) {
    // id = 频道名$URL, 取第一个 $ 之后的 URL
    let url = String(id || '');
    if (url.includes('$')) url = url.split('$').slice(1).join('$');
    if (!url) return { parse: 0, url: '' };
    return { parse: 0, url };
}

async function search(wd, pg) {
    if (!wd) return { list: [] };
    const raw = await apiGet({ wd });
    const list = buildByChannel(raw.list);
    return { page: 1, pagecount: 1, limit: 999, total: list.length, list, parse: 0, jx: 0 };
}

const meta = {
    key: "mishijie_zhibo",
    name: "咪视界直播[+]",
    type: 4,
    api: "/video/mishijie",
    searchable: 1,
    quickSearch: 1,
    filterable: 0,
    changeable: 0,
};

module.exports = async (app, opt) => {
    app.get(meta.api, async (req) => {
        const q = req.query || {};
        const { ac, t, pg, wd, play: playId, ids } = q;
        try {
            if (playId) return await play(q.flag, playId);
            if (wd) return await search(wd, pg);
            if (ids) return await detail([String(ids)]);
            if (t) return await category(t, pg || "1");
            if (ac === "list") return await category("all", pg || "1");
            return await home();
        } catch (e) {
            app.log && app.log.error && app.log.error(`[咪视界] ${e && e.message || e}`);
            return { list: [] };
        }
    });

    opt.sites.push(meta);
};
