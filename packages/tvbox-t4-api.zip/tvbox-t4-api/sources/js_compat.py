# -*- coding: utf-8 -*-
"""JS 源接入引导（框架文件，升级时强制覆盖）

这个文件本身不是源，只负责在框架扫描 sources/ 时被导入一次，
从而把 ``js_bridge``（宿主侧 node 里的 ``sources/js/**/*.js``）接进 T4 服务。

注意：真正的包装类定义在 ``js_bridge``（模块名不是本模块），
所以 sources 扫描器不会把本文件里的东西当成源重复加载。
"""

from __future__ import annotations

import logging
import threading

_log = logging.getLogger("js_compat")


def _boot() -> None:
    try:
        import js_bridge

        js_bridge.boot()
    except Exception as exc:  # 绝不因 JS 侧问题影响 py 源
        _log.warning("[js] 引导失败: %s", exc)


threading.Timer(0.3, _boot).start()
