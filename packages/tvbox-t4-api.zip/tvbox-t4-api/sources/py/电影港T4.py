# -*- coding: utf-8 -*-
"""电影港 dyg7.com —— TVBox T4 源。

站点: https://www.dyg7.com/  (电影港-新版-高清电影下载, UTF-8)
类型: 高清电影下载站 —— 详情提供 磁力(magnet) + 迅雷/夸克/百度网盘 下载链接。
      短剧分类无下载链接(纯展示页), 电影/电视剧有磁力+网盘。
结构:
  分类   /dy/(子类)/ 电影: bangumi动作 tvplay喜剧 aqp爱情 khp科幻 jqp剧情 kbp恐怖
         zzp战争 jlp纪录片 donghuapian动画; /dsj/(dlj国产|rhj日韩|omj欧美)/ 电视剧;
         /duanju/ 短剧; /dongman/ 动漫; /zyjm/ 综艺
  列表   /dy/khp/ 第一页; /dy/khp/index_2.html 第N页(共约29页)
         卡片: <li class="p1 m1"><a class="link-hover" href="/dy/khp/25165.html"
               title="罪火焦点"><img class="lazy" data-original="图" alt="标题">
               <p class="name">标题</p><p class="other"><i>正片</i>
  详情   /dy/khp/25165.html  ◎年 代:2026 ◎产 地 ◎类 别 ◎导 演 ◎主 演 ◎简 介
         【下载地址】磁力: magnet + 迅雷云盘/夸克云盘/百度云盘链接
  搜索   POST /e/search/index.php  keyboard={wd}&submit=搜 索&show=title,zhuyan&tempid=1
⚠️ 分页页强制返回 gzip(无视 Accept-Encoding identity) → 识别 gzip 魔数 \x1f\x8b 解压。
"""
from __future__ import annotations

import gzip
import json
import re
import threading
import time
import urllib.parse
import urllib.request

from core.base import (
    VodDetailItem, VodHandler, VodItem, VodListResult, PlayerResult, HomeResult,
)
from core.cache import TTLCache

_HOST = "https://www.dyg7.com"
_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")

# (type_id, 名称, 子分类映射)
_SUB = {
    "dy": [("bangumi", "动作片"), ("tvplay", "喜剧片"), ("aqp", "爱情片"), ("khp", "科幻片"),
           ("jqp", "剧情片"), ("kbp", "恐怖片"), ("zzp", "战争片"), ("jlp", "纪录片"),
           ("donghuapian", "动画片")],
    "dsj": [("dlj", "国产剧"), ("rhj", "日韩剧"), ("omj", "欧美剧")],
}
_TOPS = [("dy", "电影"), ("dsj", "电视剧"), ("duanju", "短剧"),
         ("dongman", "动漫"), ("zyjm", "综艺")]


def _fetch(url: str, post: dict | None = None, timeout: int = 20) -> str:
    try:
        data = urllib.parse.urlencode(post).encode() if post else None
        req = urllib.request.Request(url, data=data, headers={
            "User-Agent": _UA, "Referer": _HOST + "/", "Accept-Encoding": "identity",
            "Content-Type": "application/x-www-form-urlencoded" if post else ""})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
        if raw[:2] == b"\x1f\x8b":          # 分页页强制 gzip
            try:
                raw = gzip.decompress(raw)
            except Exception:
                pass
        try:
            return raw.decode("utf-8")
        except Exception:
            return raw.decode("gbk", "ignore")
    except Exception:
        return ""


def _cards(html: str) -> list[dict]:
    out, seen = [], set()
    pat = (r'<a[^>]*href="(/[^"]+\.html)"[^>]*title="([^"]+)"[^>]*>'
           r'[\s\S]{0,400}?data-original="([^"]+)"[\s\S]{0,600}?'
           r'<p class="other"><i>([^<]*)</i>')
    for m in re.finditer(pat, html or ""):
        try:
            href, title, pic, rm = m.group(1), m.group(2), m.group(3), m.group(4)
            if not href or not title or href in seen:
                continue
            seen.add(href)
            out.append(VodItem(vod_id=href, vod_name=title.strip(),
                               vod_pic=pic, vod_remarks=rm.strip()).to_dict())
        except Exception:
            continue
    return out


class Dyg7(VodHandler):
    source_name = "dyg7"
    display_name = "电影港"
    HOST = "https://www.dyg7.com"

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._cache = TTLCache(1800)

    # ── home ─────────────────────────────────────────────────────────

    def home(self) -> dict:
        classes = [{"type_id": t, "type_name": n} for t, n in _TOPS]
        filters = {}
        for top, name in _TOPS:
            if top in _SUB:
                filters[top] = [{"key": "class", "name": "分类", "value":
                                 [{"n": "全部", "v": ""}] +
                                 [{"n": n, "v": "/%s/%s" % (top, s)} for s, n in _SUB[top]]}]
        lst = _cards(_fetch(_HOST + "/dy/"))[:24]
        return HomeResult(classes=classes, filters=filters, list=lst).to_dict()

    # ── category ─────────────────────────────────────────────────────

    def category(self, type_id: str, page: str, ext: str = "") -> dict:
        pg = self.safe_int(page)
        tid = str(type_id)
        if "/" in tid:
            path = "/" + tid.rstrip("/") + "/"
        else:
            path = "/" + tid + "/"
        url = path if pg == 1 else "%sindex_%d.html" % (path, pg)
        cards = _cards(_fetch(_HOST + url))
        return VodListResult(list=cards, page=pg,
                             pagecount=9999 if cards else pg,
                             limit=30, total=99999).to_dict()

    # ── detail ───────────────────────────────────────────────────────

    def detail(self, ids: str) -> dict:
        href = str(ids).split(",")[0].strip()
        if not href.startswith("/"):
            href = "/" + href
        html = _fetch(_HOST + href)
        if not html:
            return {"list": []}
        vod = {"vod_id": href, "vod_name": "", "vod_pic": "", "vod_year": "",
               "vod_actor": "", "vod_director": "",
               "vod_content": "", "vod_remarks": ""}
        t = re.search(r"<title>([^<]*)", html)
        if t:
            vod["vod_name"] = t.group(1).split("_")[0].strip()
        p = re.search(r'<img[^>]*data-original="([^"]+)"', html) or \
            re.search(r'<img[^>]*src="([^"]+)"', html)
        if p:
            vod["vod_pic"] = p.group(1)

        def _field(lb):
            pat = r"◎\s*" + r"\s*".join(re.escape(c) for c in lb) + r"[：:]\s*([^\n<◎]{1,80})"
            m = re.search(pat, html)
            return m.group(1).strip().replace("&middot;", "·") if m else ""
        vod["vod_year"] = _field("年代")
        area = _field("产地")
        vod["vod_director"] = _field("导演")
        vod["vod_actor"] = _field("主演")
        if area:
            vod["vod_remarks"] = area
        dm = re.search(r"◎\s*简\s*介[\s\S]{0,40}?([\s\S]{0,1200}?)<", html)
        if dm:
            vod["vod_content"] = re.sub(r"<[^>]+>", "", dm.group(1)).strip()
        # 下载链接(线路): 磁力 + 网盘
        lines = {}
        for m in re.finditer(r'(magnet:[^"\']+)|https?://(pan\.\w+\.[^"\']+)', html):
            if m.group(1):
                lines.setdefault("磁力", []).append(m.group(1))
            elif m.group(2):
                u = m.group(2)
                if "xunlei" in u:
                    lines.setdefault("迅雷云盘", []).append(u)
                elif "quark" in u:
                    lines.setdefault("夸克云盘", []).append(u)
                elif "baidu" in u:
                    lines.setdefault("百度云盘", []).append(u)
        froms, urls = [], []
        for name, eps in lines.items():
            froms.append(name)
            urls.append("#".join("%s$%s" % (name, u.replace("&amp;", "&")) for u in eps))
        if froms:
            vod["vod_play_from"] = "$$$".join(froms)
            vod["vod_play_url"] = "$$$".join(urls)
        return {"list": [VodDetailItem(**vod).to_dict()]}

    # ── search ───────────────────────────────────────────────────────

    def search(self, keyword: str, page: str, ext: str = "") -> dict:
        pg = self.safe_int(page)
        kw = (keyword or "").strip()
        if pg > 1 or not kw:
            return VodListResult().to_dict()
        html = _fetch(_HOST + "/e/search/index.php",
                      {"keyboard": kw, "submit": "搜 索",
                       "show": "title,zhuyan", "tempid": "1"})
        cards = _cards(html)
        if not cards:
            # 搜索页卡片可能缺 data-original, 兜底提取 title+href
            seen = set()
            for m in re.finditer(r'href="(/[^"]+\.html)"[^>]*>\s*([^<]{2,60})', html):
                href, title = m.group(1), m.group(2).strip()
                if href and title and title not in ("返回顶部",) and href not in seen:
                    seen.add(href)
                    cards.append(VodItem(vod_id=href, vod_name=title,
                                         vod_pic="", vod_remarks="").to_dict())
        return VodListResult(list=cards, page=pg,
                             pagecount=pg if len(cards) < 20 else pg + 1,
                             limit=20, total=len(cards)).to_dict()

    # ── player ───────────────────────────────────────────────────────

    def player(self, flag: str, play_url: str) -> dict:
        u = str(play_url or "").replace("&amp;", "&")
        hdr = {"User-Agent": _UA, "Referer": _HOST + "/"}
        return PlayerResult(url=u, header=hdr).to_dict()

    # ── 诊断 ─────────────────────────────────────────────────────────

    def diag_urls(self) -> list[tuple[str, str]]:
        return [
            ("首页", _HOST + "/"),
            ("分类", _HOST + "/dy/khp/"),
            ("分页", _HOST + "/dy/khp/index_2.html"),
            ("详情", _HOST + "/dy/khp/25165.html"),
            ("搜索", _HOST + "/e/search/index.php"),
        ]