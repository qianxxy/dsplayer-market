# -*- coding: utf-8 -*-
"""荐片磁力 —— TVBox T4 源（jien原版协议,逆向自 TVBox csp_JianPian 类）。

接口全貌（2026-09 实测）:
  · API 域名动态下发: DNS TXT https://dns.alidns.com/resolve?name=swrdsfeiujo25sw.cc&type=TXT
      -> Answer[0].data = "hzhnl.com,hzkfr.com,hzlfm.com,whfft.com,zxfmj.com"
      每个候选域名拼 https://{6位随机}.{domain} 做真实探测(HTTP 200)选可用;
      aaaa()=不以http开头则拼 https://{rand6}.{domain}
  · 图片域名: GET {api}/api/v2/settings/resourceDomainConfig -> data.imgDomain
      = "img.cdgbq.com,img.cqkgy.com,..." ; 图片url = https://{imgDomain}{path}
  · 列表: /api/crumb/list?fcate_pid={c}&category_id=&area=&year=&type=&sort=&page={p}
      data[]{id,title,tvimg,path,mask}
      短剧(分类67): /api/crumb/shortList?fcate_pid={c}&category_id=&sort=update&page={p}
  · 搜索: /api/v2/search/videoV2?key={kw}&category_id=88&page=1&pageSize=20
      data[]{id,title,thumbnail,mask,top_category.id}
  · 详情: /api/video/detailv2?id={id}（普通）| /api/detail?vid={id}（短剧67）
      data{title,description,year,area,actors[{name}],source_list_source[{name,source_list[{source_name,url}]}]}
  · vod_id 约定: "{id}$$${title}$$${pic}$$${top_cat_id}"（detail从ids里split取段）
  · 播放: 直链 m3u8(url 字段已含),无需再解析

请求头: UA = Mozilla/5.0 (Linux; Android 7.1.2; V2049A Build/UP1A.231005.007; wv) ...
"""
from __future__ import annotations

import json
import random
import re
import string
import threading
import time
import urllib.parse

from core import settings
from core.base import (
    VodDetailItem, VodHandler, VodItem, VodListResult,
    PlayerResult, HomeResult,
)
from core.cache import TTLCache
from core.http_client import HttpClient

# ── 分类: type_id 用站方顶层分类 id ────────────────────────────────
CATS = [
    (1, "电影"), (2, "电视剧"), (3, "动漫"), (4, "综艺"), (67, "短剧"),
]

# 搜索 category_id 固定 88;短剧走另一详情接口
SHORT_CAT = "67"

DNS_URL = "https://dns.alidns.com/resolve?name=swrdsfeiujo25sw.cc&type=TXT"
SETTINGS_PATH = "/api/v2/settings/resourceDomainConfig"
LIST_PATH = "/api/crumb/list"
SHORT_LIST_PATH = "/api/crumb/shortList"
SEARCH_PATH = "/api/v2/search/videoV2"
DETAIL_PATH = "/api/video/detailv2"
SHORT_DETAIL_PATH = "/api/detail"
UA = ("Mozilla/5.0 (Linux; Android 7.1.2; V2049A Build/UP1A.231005.007; wv) "
      "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36")


class Jianpian(VodHandler):
    source_name = "jianpian"
    display_name = "荐片磁力"
    HOST = "https://hzhnl.com"   # 动态域名锚点;实际 API 域名经 DNS 下发后探测

    MIN_INTERVAL = 0.3

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._last_hit = 0.0
        self._http = self._new_http()
        self._cache = TTLCache(1800)      # 域名/图片/列表缓存
        self._api = ""                     # 选定的可用 API 域名(带随机子域)
        self._img = ""                     # 图片域名

    # ── HttpClient ───────────────────────────────────────────────────

    def _new_http(self) -> HttpClient:
        return HttpClient(
            headers={"User-Agent": UA, "Accept": "application/json,*/*",
                     "Referer": "https://jianpian.online/"},
            timeout=settings.HTTP_TIMEOUT,
            doh_url=settings.DOH_URL if settings.USE_DOH else None,
            proxy=self._proxy(),
        )

    def _proxy(self) -> str | None:
        import os
        up = self.source_name.upper()
        return (os.getenv(f"SOURCE_PROXY_{up}", "") or os.getenv(f"{up}_PROXY", "")
                or settings.HTTP_PROXY or "") or None

    def _throttle(self) -> None:
        if self.MIN_INTERVAL <= 0:
            return
        with self._lock:
            wait = self.MIN_INTERVAL - (time.monotonic() - self._last_hit)
            if wait > 0:
                time.sleep(wait)
            self._last_hit = time.monotonic()

    def _get(self, url: str) -> str:
        """GET 文本;JSON 失败/风控重建会话重试。"""
        self._throttle()
        for _ in range(2):
            html = self._http.get(url)
            if html.startswith("{"):
                return html
            try:
                self._http.close()
            except Exception:                       # noqa: BLE001
                pass
            self._http = self._new_http()
            self._throttle()
        return html

    def _api_json(self, path_params: str) -> dict:
        """请求 API(带 ? 后的参数串)并解析 JSON。"""
        api = self._ensure_api()
        if not api:
            return {}
        url = api + path_params
        txt = self._get(url)
        if not txt.startswith("{"):
            return {}
        try:
            return json.loads(txt)
        except Exception:                           # noqa: BLE001
            return {}

    # ── 域名 / 图片域名 (缓存) ─────────────────────────────────────

    def _ensure_api(self) -> str:
        if self._api:
            return self._api
        cached = self._cache.get("api_domain")
        if cached:
            self._api = cached
            return cached
        domains = self._dns_domains()
        for d in domains:
            base = self._rand_domain(d)
            if self._probe(base):
                self._api = base
                self._cache.set("api_domain", base)
                self._img = self._load_img(base)
                return base
        # 全挂取第一个
        base = self._rand_domain(domains[0] if domains else "hzhnl.com")
        self._api = base
        return base

    def _dns_domains(self) -> list[str]:
        """DNS TXT → 候选域名列表。

        ⚠️ 必须 urllib 直连: DNS 响应 ~240B 会被框架 HttpClient 的
        HTTP_MIN_LEN=512 当风控页吞掉(与 yunduo 的 decode 同款坑)。
        """
        txt = self._dns_raw()
        try:
            j = json.loads(txt)
            data = j["Answer"][0]["data"]
        except Exception:                           # noqa: BLE001
            return ["hzhnl.com", "hzkfr.com"]
        data = data.replace('"', "").replace("'", "")
        return [x.strip() for x in data.split(",") if x.strip()] or ["hzhnl.com"]

    def _dns_raw(self) -> str:
        try:
            import urllib.request
            import ssl
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            req = urllib.request.Request(DNS_URL, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=15, context=ctx) as r:
                return r.read().decode("utf-8", "ignore")
        except Exception:                           # noqa: BLE001
            return ""

    @staticmethod
    def _rand(n: int) -> str:
        return "".join(random.choices(string.ascii_lowercase + string.digits, k=n))

    def _rand_domain(self, domain: str) -> str:
        """aaaa(): 不以 http 开头则拼 https://{6位随机}.{domain}。"""
        if domain.startswith("http://") or domain.startswith("https://"):
            return domain
        return f"https://{self._rand(6)}.{domain}"

    def _probe(self, base: str) -> bool:
        """真实探测 base 是否可用(HTTP 200)。"""
        try:
            txt = self._http.get(base + LIST_PATH +
                                 "?fcate_pid=1&category_id=&area=&year=&type=&sort=&page=1")
            return bool(txt and txt.startswith("{"))
        except Exception:                           # noqa: BLE001
            return False

    def _load_img(self, api: str) -> str:
        try:
            txt = self._get(api + SETTINGS_PATH)
            j = json.loads(txt)
            imgs = [x.strip() for x in str(j["data"]["imgDomain"]).split(",") if x.strip()]
            if imgs:
                self._cache.set("img_domain", imgs)
                return imgs[0]
        except Exception:                           # noqa: BLE001
            pass
        cached = self._cache.get("img_domain")
        return cached[0] if cached else "img.cdgbq.com"

    def _pic(self, path: str) -> str:
        """c(): 相对路径图片 → https://{imgDomain}{path}。"""
        if not path:
            return ""
        if path.startswith("http"):
            return path
        if not self._img:
            self._img = self._cache.get("img_domain")[0] if self._cache.get("img_domain") else "img.cdgbq.com"
        p = path if path.startswith("/") else "/" + path
        if not self._img.startswith("http"):
            return "https://" + self._img + p
        return self._img + p

    # ── 五个契约方法 ────────────────────────────────────────────────

    def home(self) -> dict:
        if cached := self._cache.get("home"):
            return cached
        classes = [{"type_id": str(t), "type_name": n} for t, n in CATS]
        result = HomeResult(classes=classes, filters={}, list=self._home_recommend()).to_dict()
        self._cache.set("home", result)
        return result

    def _home_recommend(self) -> list[dict]:
        """首页推荐: /api/dyTag/list?category_id=88 → 各标签组 dataList 合并。"""
        api = self._ensure_api()
        if not api:
            return []
        j = self._api_json("/api/dyTag/list?category_id=88")
        data = j.get("data") or []
        items: list[dict] = []
        seen: set[str] = set()
        for grp in data:
            dl = grp.get("dataList") or []
            for it in dl:
                vid = str(it.get("id") or "")
                if not vid or vid in seen:
                    continue
                seen.add(vid)
                c = self._card(it, "1")   # 推荐都是电影类,top=1
                if c:
                    items.append(c)
        return items

    def _card(self, it: dict, force_top: str = "") -> dict:
        pic_path = (it.get("tvimg") or it.get("thumbnail")
                    or it.get("cover_image") or "")
        top = force_top or self._top_cat(it)
        return VodItem(
            vod_id=f"{it.get('id')}$$${it.get('title','')}$$${pic_path}$$${top}",
            vod_name=it.get("title", "").strip(),
            vod_pic=self._pic(pic_path),
            vod_remarks=str(it.get("mask") or "") or str(it.get("score") or ""),
        ).to_dict()

    @staticmethod
    def _top_cat(it: dict) -> str:
        try:
            return str(it["top_category"]["id"])
        except Exception:                           # noqa: BLE001
            return ""

    def _cat_list(self, tid: str, pg: int) -> list[dict]:
        if tid == SHORT_CAT:
            path = (SHORT_LIST_PATH + f"?fcate_pid={tid}&category_id=&sort=update&page={pg}")
        else:
            path = (f"{LIST_PATH}?fcate_pid={tid}&category_id=&area=&year=&type=&sort=&page={pg}")
        j = self._api_json(path)
        raw = j.get("data") or []
        force = SHORT_CAT if tid == SHORT_CAT else ""
        return [c for c in (self._card(i, force) for i in raw) if c]

    def category(self, type_id: str, page: str, ext: str = "") -> dict:
        pg = self.safe_int(page)
        tid = str(type_id or "1")
        lst = self._cat_list(tid, pg)
        return VodListResult(list=lst, page=pg, pagecount=pg + 1 if lst else pg,
                             limit=len(lst) or 20).to_dict()

    def search(self, keyword: str, page: str, ext: str = "") -> dict:
        pg = self.safe_int(page)
        kw = (keyword or "").strip()
        if not kw:
            return VodListResult(list=[], page=1, pagecount=1).to_dict()
        api = self._ensure_api()
        if not api:
            return VodListResult(list=[], page=1, pagecount=1).to_dict()
        q = urllib.parse.quote(kw)
        j = self._api_json(f"{SEARCH_PATH}?key={q}&category_id=88&page={pg}&pageSize=20")
        raw = j.get("data") or []
        lst = [c for c in (self._card(i) for i in raw) if c]
        return VodListResult(list=lst, page=pg, pagecount=pg + 1 if lst else pg,
                             limit=len(lst) or 20).to_dict()

    def detail(self, ids: str) -> dict:
        vid = (ids or "").strip()
        if not vid:
            return {"list": []}
        parts = vid.split("$$$")
        vid_id = parts[0]
        vname = parts[1] if len(parts) > 1 else vid
        top = parts[3] if len(parts) > 3 else ""
        # 短剧 vs 普通
        path = (f"{SHORT_DETAIL_PATH}?vid={vid_id}" if top == SHORT_CAT
                else f"{DETAIL_PATH}?id={vid_id}")
        j = self._api_json(path)
        data = j.get("data")
        if not isinstance(data, dict):
            return {"list": []}
        out = {
            "vod_id": vid,
            "vod_name": data.get("title") or vname,
            "vod_pic": self._pic(data.get("thumbnail") or data.get("tvimg")
                                 or data.get("cover_image") or ""),
            "vod_year": str(data.get("year") or ""),
            "vod_area": str(data.get("area") or ""),
            "vod_director": self._names(data.get("directors")),
            "vod_actor": self._names(data.get("actors")),
            "vod_content": str(data.get("description") or ""),
            "vod_remarks": str(data.get("mask") or ""),
        }
        # ── 线路 ──
        # 短剧(/api/detail): data.playlist = 平铺 [{title,url}, ...],一条"常规线路"
        # 普通(/api/video/detailv2): data.source_list_source = [{name, source_list[{source_name,url}]}]
        froms, urls = [], []
        if top == SHORT_CAT:
            eps = []
            for s in (data.get("playlist") or []):
                url = str(s.get("url") or "").strip()
                if not url:
                    continue
                ename = str(s.get("title") or s.get("source_name") or "正片").strip() or "正片"
                eps.append(f"{ename}${url}")
            if eps:
                froms.append("荐片")
                urls.append("#".join(eps))
        else:
            for src in (data.get("source_list_source") or []):
                name = str(src.get("name") or "线路")
                eps = []
                for s in (src.get("source_list") or []):
                    url = str(s.get("url") or "").strip()
                    if not url:
                        continue
                    ename = str(s.get("source_name") or "正片").strip() or "正片"
                    eps.append(f"{ename}${url}")
                if eps:
                    froms.append(name)
                    urls.append("#".join(eps))
        if froms:
            out["vod_play_from"] = "$$$".join(froms)
            out["vod_play_url"] = "$$$".join(urls)
        return {"list": [out]}

    @staticmethod
    def _names(items) -> str:
        if not items:
            return ""
        try:
            return "/".join(str(x.get("name") or "") for x in items if x.get("name"))
        except Exception:                           # noqa: BLE001
            return ""

    def player(self, flag: str, play_url: str) -> dict:
        url = str(play_url or "").strip()
        if not url:
            return PlayerResult(parse=0, url="", header={}).to_dict()
        ref = urllib.parse.urlsplit(url)
        referer = f"{ref.scheme}://{ref.netloc}/"
        return PlayerResult(url=url,
                            header={"User-Agent": UA, "Referer": referer}).to_dict()

    # ── 诊断 ───────────────────────────────────────────────────────────

    def diag_urls(self) -> list[tuple[str, str]]:
        return [
            ("DNS域名", DNS_URL),
            ("首页列表", LIST_PATH + "?fcate_pid=1&category_id=&area=&year=&type=&sort=&page=1"),
            ("搜索", SEARCH_PATH + "?key=test&category_id=88&page=1&pageSize=20"),
            ("详情", DETAIL_PATH + "?id=575252"),
        ]