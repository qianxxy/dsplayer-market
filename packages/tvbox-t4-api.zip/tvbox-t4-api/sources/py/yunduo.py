# -*- coding: utf-8 -*-
"""云朵影视 —— TVBox T4 源。

RN/Hermes 签名协议（每次请求现算，非重放）。后端 http://154.21.198.181:8002
（2026-09-17 由 8081 迁到 8002，同 IP 新端口）。

接口（全部 GET，需签名头 + x-user-token）：
    /api.php/app/index/home                  分类 + 推荐
    /api.php/app/ranking/list                榜单（补首页推荐量）
    /api.php/app/filter/vod?type_name=..    点分类页（电影/剧集/动漫/综艺）
    /api.php/app/search/index?wd=..&page=..  搜索
    /api.php/app/vod/playback_v2?vod_id=..    线路表（from + display_name）
    /api.php/app/vod/get_detail?vod_id=..     详情（vod_play_from/url，集 ID 内嵌来源前缀）
    /api.php/app/decode/url/?url=..&vodFrom=.. 解出真实播放地址（m3u8/mp4 直链）

关键坑（勿删）：
  · decode 响应只有几十字节（<512B），会被框架 HttpClient 的 HTTP_MIN_LEN=512
    当风控页吞掉 → decode 必须用标准库 urllib 直连（返回真 JSON，无 CF，安全）。
  · get_detail 的 vod_play_from 顺序 = decode 的线路顺序，vod_play_url 每集 ID
    已带来源前缀（vwnet-xxx / IMDB-xx / BBA-xx），decode 的 url 参数取 $ 后段、
    vodFrom 取 from 原值，二者来源前缀须一致（乱配返回 code=0/401）。
  · 线路失效分两类：①间歇（重试可救）——交锋 IMDB 实测 code 序列 [0,0,0]→[1,1,1]
    ②持久（真无源）——八仙/蜘蛛侠/龙餐馆 IMDB 恒 0。故 player 重试要够（5次递增），
    仍败则跨线路自动回落到同片首条可播线路（detail 时缓存 集ID→影片 映射供回落）。
  · 集 ID（如 IMDB-xxx）不携带影片 id，回落须靠 detail 缓存的反查表才找得到同片。
  · 首页推荐量少（源站 recommend 仅 6 条）→ 用 ranking 榜单(4榜×20)合并去重补到 ~80 条。
"""
from __future__ import annotations

import hashlib
import json
import random
import threading
import time
import urllib.parse
import urllib.request
from urllib.parse import quote as _quote

from core import settings
from core.base import VodDetailItem, VodHandler, VodItem, VodListResult
from core.cache import TTLCache
from core.http_client import HttpClient

_UA = "okhttp/4.12.0"
_FINGER = "SF-F5F11CB15897115AE6BCFE063C288F730CA865588F572C780A3E8477D0DD3776"
_SK = "SK-sk_13oXDZ7u9j2Tk1c0cawWVFfO"
_DEVICE_UUID = "uuid-a43a3421-2704-4deb-afe4-136aed229307"
_USER_TOKEN = "ZThkNjRlYzhlNmZmNzZkMDI1ZDhhMTVhNzA2YjFlN2YxYjQwMTA5NzBkZThiN2NlZTk0ZGYzOWU2MmQ5NzQ3Y3wxMzI5NnxmemNyeW18MTc4ODM1ODE1Ng=="

# 分类：type_id(1/2/3/4) -> filter/vod 的 type_name
_CATS = [("1", "电影"), ("2", "剧集"), ("3", "动漫"), ("4", "综艺")]

# 首集探测失败次数阈值：连续 N 次 code=0 视为持久失效（跨线回落已在 player 兜底）
_FALLBACK_MAX = 8


def _sign_headers() -> dict:
    import hashlib as _h
    t = str(int(time.time() * 1000))
    nonce = (_h.sha256(_DEVICE_UUID.encode()).hexdigest().upper()[:8]
             + "".join(str(random.randint(0, 9)) for _ in range(8)))
    sign = _h.sha256((
        "finger=" + _FINGER + "&id=com.tvcloud.io&nonce=" + nonce
        + "&sk=" + _SK + "&time=" + t + "&v=4").encode()).hexdigest().upper()
    return {
        "User-Agent": _UA, "accept": "application/json",
        "x-aid": "com.tvcloud.io", "x-ave": "4",
        "x-time": t, "x-nonc": nonce, "x-sign": sign,
        "x-device-id": _DEVICE_UUID, "x-device-brand": "realtek",
        "x-device-model": "ZIDOO_X9S", "x-client-type": "tv",
        "x-update-id": "embedded", "x-user-token": _USER_TOKEN,
    }


class Yunduo(VodHandler):
    source_name = "yunduo"
    display_name = "云朵影视"

    HOST = "http://154.21.198.181:8002"
    UA = _UA
    MIN_INTERVAL = 0.3

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._last_hit = 0.0
        self._http = HttpClient(
            headers={"User-Agent": _UA, "accept": "application/json"},
            timeout=settings.HTTP_TIMEOUT,
            proxy=settings.HTTP_PROXY or None,
        )
        self._cache = TTLCache(600)
        # 集ID -> 影片id，player 回落用（集 ID 不携带影片 id）
        self._ep2vid: dict[str, str] = {}
        # 影片id -> [(flag, 首集ID)] 供跨线路回落
        self._lines: dict[str, list[tuple[str, str]]] = {}

    # ── HTTP ──────────────────────────────────────────────────────────

    def _throttle(self) -> None:
        if self.MIN_INTERVAL <= 0:
            return
        with self._lock:
            wait = self.MIN_INTERVAL - (time.monotonic() - self._last_hit)
            if wait > 0:
                time.sleep(wait)
            self._last_hit = time.monotonic()

    def _api(self, path: str) -> dict:
        """取 API JSON。走自框架 HttpClient；失败回退重建实例。"""
        url = self.HOST + path
        self._throttle()
        try:
            d = self._http.get_json(url, extra_headers=_sign_headers())
            if isinstance(d, dict):
                return d
        except Exception:
            pass
        try:
            self._http.close()
        except Exception:
            pass
        self._http = HttpClient(
            headers={"User-Agent": _UA, "accept": "application/json"},
            timeout=settings.HTTP_TIMEOUT,
            proxy=settings.HTTP_PROXY or None,
        )
        try:
            d = self._http.get_json(url, extra_headers=_sign_headers())
            if isinstance(d, dict):
                return d
        except Exception:
            pass
        return {}

    def _api_raw(self, path: str) -> str:
        """decode 等小响应(<512B)专用：标准库 urllib 直连。

        框架 HttpClient 会因 HTTP_MIN_LEN=512 把几十字节的合法 decode 响应
        当风控页丢弃，所以这条不走 self._http。host 是 http 明文 IP、无
        Cloudflare，urllib 足够。
        """
        url = self.HOST + path
        self._throttle()
        req = urllib.request.Request(url, headers=_sign_headers())
        try:
            return urllib.request.urlopen(req, timeout=20).read().decode("utf-8", "ignore")
        except Exception:
            return ""

    def _decode(self, ep: str, flag: str):
        """单次 decode，返回 (is_ok, url_or_reason)。"""
        path = "/api.php/app/decode/url/?url={}&vodFrom={}&_t={}".format(
            _quote(ep), _quote(flag), int(time.time() * 1000))
        raw = self._api_raw(path)
        try:
            d = json.loads(raw)
            u = (d.get("data") or "").strip()
            if d.get("code") == 1 and u.startswith("http"):
                return True, u
            return False, u or raw[:80]
        except Exception:
            return False, raw[:80]

    # ── 通用 ─────────────────────────────────────────────────────────

    @staticmethod
    def _clean(s: str) -> str:
        return (s or "").replace("$", "＄").replace("#", "＃").strip()

    def _card(self, v: dict) -> dict:
        return VodItem(
            vod_id=str(v.get("vod_id") or ""),
            vod_name=str(v.get("vod_name") or ""),
            vod_pic=v.get("vod_pic") or "",
            vod_remarks=str(v.get("vod_remarks") or ""),
        ).to_dict()

    def _dedup(self, items: list) -> list:
        seen, out = set(), []
        for it in items:
            vid = str(it.get("vod_id") or "")
            if not vid or vid in seen:
                continue
            seen.add(vid)
            out.append(self._card(it))
        return out

    # ── T4 契约 ──────────────────────────────────────────────────────

    def home(self) -> dict:
        classes = [{"type_id": tid, "type_name": name} for tid, name in _CATS]
        # 源站 recommend 只有 6 条 → 用 ranking 榜单补量（4 榜 × 20 去重 ≈ 80 条）
        cards = []
        j = self._api("/api.php/app/index/home")
        d = j.get("data") or {}
        for v in (d.get("recommend") or []):
            if v.get("vod_id"):
                cards.append(v)
        try:
            jr = self._api("/api.php/app/ranking/list")
            for rk in (jr.get("data") or {}).get("rankings") or []:
                for v in (rk.get("videos") or []):
                    if v.get("vod_id"):
                        cards.append(v)
        except Exception:
            pass
        # 若排行榜也没给够，补一张分类热门保证首页不空
        if len(cards) < 20:
            tf = self._api("/api.php/app/filter/vod?type_name=%E7%94%B5%E5%BD%B1&page=1&limit=24&sort=hits")
            for v in (tf.get("data") or []):
                if v.get("vod_id"):
                    cards.append(v)
        return {"class": classes, "filters": {}, "list": self._dedup(cards)}

    def category(self, type_id: str, page: str, ext: str = "") -> dict:
        pg = self.safe_int(page)
        name = dict(_CATS).get(str(type_id), "")
        if not name:
            for tid, nm in _CATS:
                if nm == str(type_id):
                    name = nm
                    break
        if not name:
            name = "电影"
        path = "/api.php/app/filter/vod?type_name={}&page={}&limit=24&sort=hits".format(
            _quote(name), pg)
        j = self._api(path)
        lst = j.get("data")
        if not isinstance(lst, list):
            lst = []
        out = [self._card(v) for v in lst if v.get("vod_id")]
        total = int(j.get("total") or len(out) or 0)
        pagecount = int(j.get("pageCount") or 0) or max(1, -(-total // 24))
        return VodListResult(list=out, page=pg, pagecount=pagecount,
                             limit=24, total=total).to_dict()

    def detail(self, ids: str) -> dict:
        vid = str(ids).split(",")[0].split("?")[0].strip()
        j = self._api("/api.php/app/vod/get_detail?vod_id=" + _quote(vid))
        v = (j.get("data") or [{}])[0]
        pf = (v.get("vod_play_from") or "").split("$$$")
        pu = (v.get("vod_play_url") or "").split("$$$")
        epmap = {f: pu[i] for i, f in enumerate(pf) if f and i < len(pu)}

        flags = [f for f in pf if f and epmap.get(f)]
        if not flags and v.get("vod_play_url"):
            flags = ["线路1"]
            epmap = {"线路1": v["vod_play_url"]}

        # 线路重排：IMDB/quark 网盘线的 m3u8 分片被 OSS 防盗链拦（400
        # InvalidConditionExpression，实测 87381；mp4 直链的能播如 54725）。
        # 把这类线路排到末尾，让 TVBox 默认走稳定线路（vwnet/NBY/BBA），
        # 用户手切 IMDB 仍保留（decode+回落已兜底）。
        _st = ("IMDB", "CO4K", "qsvip")
        flags = [f for f in flags if f not in _st] + [f for f in flags if f in _st]
        urls = [epmap[f] for f in flags]

        # 缓存 集ID→影片 与 影片→(线路,首集ID) 回落表
        lines = []
        for f, uu in zip(flags, urls):
            eps = [x.split("$")[-1] for x in (uu.split("#") if uu else []) if x]
            first = eps[0] if eps else ""
            for e in eps:
                self._ep2vid[e] = vid
            if first:
                lines.append((f, first))
        self._lines[vid] = lines
        if len(self._ep2vid) > 30000:
            self._ep2vid.clear()
        if len(self._lines) > 4000:
            self._lines = {}

        import re as _re
        _ct = _re.sub(r"<[^>]+>", "", v.get("vod_content") or "").strip()
        vod = VodDetailItem(
            vod_id=vid,
            vod_name=str(v.get("vod_name") or vid),
            vod_pic=v.get("vod_pic") or "",
            vod_year=str(v.get("vod_year") or ""),
            vod_content=_ct,
            vod_actor=str(v.get("vod_actor") or ""),
            vod_director=str(v.get("vod_director") or ""),
            vod_remarks=str(v.get("vod_remarks") or ""),
            # 只有线路名全角转义；vod_play_url 的 '#'(集分隔)/'$'(集名与播放ID) 原样保留
            vod_play_from="$$$".join(self._clean(x) for x in flags),
            vod_play_url="$$$".join(str(x) for x in urls),
        )
        return {"list": [vod.to_dict()]}

    def player(self, flag: str, play_url: str) -> dict:
        ep = (play_url or "").strip()
        flag = (flag or "").strip()
        header = {"Referer": self.HOST + "/", "User-Agent": _UA}
        if not ep or not flag:
            return {"parse": 0, "url": "", "header": header}

        # ① 原线路递增重试，救间歇性失效
        for i in range(5):
            ok, u = self._decode(ep, flag)
            if ok:
                return {"parse": 0, "url": u, "header": header}
            time.sleep(0.5 + 0.6 * i)

        # ② 持久失效 → 跨线路自动回落：同片其它线路的首集
        vid = self._ep2vid.get(ep, "")
        if vid:
            for o_flag, o_first in self._lines.get(vid, []):
                if o_flag == flag:
                    continue
                ok, u = self._decode(o_first, o_flag)
                if ok:
                    return {"parse": 0, "url": u, "header": header}
                time.sleep(0.3)
        return {"parse": 0, "url": "", "header": header}

    def search(self, keyword: str, page: str, ext: str = "") -> dict:
        kw = (keyword or "").strip()
        if not kw:
            return VodListResult().to_dict()
        pg = self.safe_int(page)
        j = self._api("/api.php/app/search/index?wd={}&page={}".format(_quote(kw), pg))
        d = j.get("data")
        lst = d if isinstance(d, list) else (d.get("videos", []) if isinstance(d, dict) else [])
        out = [self._card(v) for v in lst if v.get("vod_id")]
        return VodListResult(list=out, page=pg,
                             pagecount=pg if len(out) >= 10 else pg,
                             limit=10, total=pg * 10).to_dict()

    # ── 诊断 ─────────────────────────────────────────────────────────

    def diag_urls(self) -> list[str]:
        return [
            self.HOST + "/api.php/app/index/home",
            self.HOST + "/api.php/app/ranking/list",
            self.HOST + "/api.php/app/vod/get_detail?vod_id=88972",
            self.HOST + "/api.php/app/search/index?wd=%E7%88%B1%E4%B8%8A&page=1",
        ]