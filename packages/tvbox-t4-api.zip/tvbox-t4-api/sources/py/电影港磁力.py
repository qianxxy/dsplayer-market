#!/usr/bin/python
# coding=utf-8
"""电影港(dyg7.com 新版) —— TVBox Python 爬虫(type 3, 纯 stdlib)。

站点: https://www.dyg7.com/  (电影港-新版-高清电影下载, UTF-8)
类型: 高清电影下载站 —— 详情提供 磁力(magnet) + 迅雷/夸克/百度网盘 下载链接,无在线播放流。
      TVBox 中 magnet 由播放器磁力内核处理(部分版本支持),网盘链接返回直链(外部/浏览器)。

结构:
  分类:  /dy/(子类)/  电影: bangumi动作 tvplay喜剧 aqp爱情 khp科幻 jqp剧情 kbp恐怖
         zzp战争 jlp纪录片 donghuapian动画;  /dsj/(dlj国产|rhj日韩|omj欧美)/ 电视剧;
         /duanju/ 短剧; /dongman/ 动漫; /zyjm/ 综艺
  列表:  /dy/khp/           第一页;  /dy/khp/index_2.html  第N页
         卡片: <li class="p1 m1"><a class="link-hover" href="/dy/khp/25165.html"
               title="罪火焦点"><img class="lazy" data-original="图" alt="标题">
               <span class="lzbz"><p class="name">标题</p>...</span><p class="other"><i>正片</i>
  详情:  /dy/khp/25165.html   ◎年　　代:2026 / ◎产　　地 / ◎类　　别 / ◎导　　演 / ◎主　　演
         ◎简　　介 / 【下载地址】磁力+迅雷/夸克/百度网盘
  搜索:  POST /e/search/index.php  keyboard={wd}&submit=搜 索&show=title,zhuyan&tempid=1
"""
import json
import re
import urllib.parse
import urllib.request

try:
    from base.spider import Spider as BaseSpider
except Exception:
    class BaseSpider(object):
        pass

HOST = "https://www.dyg7.com"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")

# (type_id, 名称, 子路径)
CATS = [
    ("1", "电影", ""),
    ("2", "电视剧", ""),
    ("3", "短剧", "duanju"),
    ("4", "动漫", "dongman"),
    ("5", "综艺", "zyjm"),
]
# 电影/电视剧 子分类 -> 名称
SUB = {
    "dy": [("bangumi", "动作片"), ("tvplay", "喜剧片"), ("aqp", "爱情片"), ("khp", "科幻片"),
           ("jqp", "剧情片"), ("kbp", "恐怖片"), ("zzp", "战争片"), ("jlp", "纪录片"),
           ("donghuapian", "动画片")],
    "dsj": [("dlj", "国产剧"), ("rhj", "日韩剧"), ("omj", "欧美剧")],
}


def _fetch(url, post=None, timeout=20):
    import gzip
    try:
        data = urllib.parse.urlencode(post).encode() if post else None
        req = urllib.request.Request(url, data=data, headers={
            "User-Agent": UA, "Referer": HOST + "/",
            "Accept-Encoding": "identity",   # 请求明文,避免 gzip(分页页返回 gzip 会乱)
            "Content-Type": "application/x-www-form-urlencoded" if post else ""})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
        # 站点分页页强制返回 gzip(无视 Accept-Encoding identity) → 识别魔数并解压
        if raw[:2] == b"\x1f\x8b":
            try:
                raw = gzip.decompress(raw)
            except Exception:
                pass
        try:
            return raw.decode("utf-8")
        except Exception:
            return raw.decode("gbk", "ignore")
    except Exception:
        return ""


class Spider(BaseSpider):
    def init(self, extend=""):
        self.host = HOST
        return self

    def getName(self):
        return "电影港"

    def isVideoFormat(self, url):
        u = str(url or "").lower()
        return u.startswith("magnet:") or any(x in u for x in
            (".m3u8", ".mp4", ".flv", ".mkv", ".ts", ".avi"))

    def manualVideoCheck(self):
        return False

    def destroy(self):
        return

    # ── 卡片 ─────────────────────────────────────────────────────────

    def _cards(self, html):
        out, seen = [], set()
        for m in re.finditer(
                r'<a[^>]*href="(/[^"]+\.html)"[^>]*title="([^"]+)"[^>]*>'
                r'[\s\S]{0,400}?data-original="([^"]+)"[\s\S]{0,600}?'
                r'<p class="other"><i>([^<]*)</i>', html):
            try:
                href, title, pic, rm = m.group(1), m.group(2), m.group(3), m.group(4)
                if not href or not title or href in seen:
                    continue
                seen.add(href)
                out.append({"vod_id": href, "vod_name": title.strip(),
                            "vod_pic": pic, "vod_remarks": rm.strip()})
            except Exception:
                continue
        # 兜底: 标题在 alt
        if not out:
            for m in re.finditer(
                    r'<a[^>]*href="(/[^"]+\.html)"[^>]*>[\s\S]{0,400}?'
                    r'data-original="([^"]+)"[^>]*alt="([^"]+)"', html):
                href, pic, title = m.group(1), m.group(2), m.group(3)
                if href and title and href not in seen:
                    seen.add(href)
                    out.append({"vod_id": href, "vod_name": title.strip(),
                                "vod_pic": pic, "vod_remarks": ""})
        return out

    # ── 首页 ─────────────────────────────────────────────────────────

    def homeContent(self, filter):
        classes = [{"type_id": "dy", "type_name": "电影"},
                   {"type_id": "dsj", "type_name": "电视剧"},
                   {"type_id": "duanju", "type_name": "短剧"},
                   {"type_id": "dongman", "type_name": "动漫"},
                   {"type_id": "zyjm", "type_name": "综艺"}]
        # 首页推荐: 电影页
        lst = self._cards(_fetch(self.host + "/dy/"))[:24]
        return {"class": classes, "filters": {}, "list": lst}

    def homeVideoContent(self):
        return {"list": self._cards(_fetch(self.host + "/dy/"))[:12]}

    # ── 分类 ─────────────────────────────────────────────────────────

    def categoryContent(self, tid, pg, filter, extend):
        pg = int(pg) if str(pg).isdigit() else 1
        tid = str(tid)
        # 确定路径: tid 可能是 "dy" / "dsj" / "duanju" / "dy/khp" / 子分类值
        if "/" in tid:
            path = "/" + tid.rstrip("/") + "/"   # 例如 "dy/khp" → /dy/khp/
        elif tid in ("dy", "dsj"):
            # 电影/电视剧: 展子分类为"全部", 列表用该分类顶层
            path = "/" + tid + "/"
        else:
            path = "/" + tid + "/"    # duanju/dongman/zyjm
        url = path if pg == 1 else "%sindex_%d.html" % (path, pg)
        cards = self._cards(_fetch(self.host + url))
        pagecount = pg + 1 if len(cards) >= 24 else pg
        return {"list": cards, "page": pg, "pagecount": 9999 if cards else pg,
                "limit": 30, "total": 99999}

    # ── 详情 ─────────────────────────────────────────────────────────

    def detailContent(self, ids):
        href = str(ids[0]).strip()
        if not href.startswith("/"):
            href = "/" + href
        html = _fetch(self.host + href)
        vod = {"vod_id": href, "vod_name": "", "vod_pic": "",
               "vod_year": "", "vod_area": "", "vod_actor": "",
               "vod_director": "", "vod_content": ""}
        # 标题
        t = re.search(r"<title>([^<]*)", html)
        if t:
            vod["vod_name"] = t.group(1).split("_")[0].strip()
        # 图片
        p = re.search(r'<img[^>]*data-original="([^"]+)"', html) or \
            re.search(r'<img[^>]*src="([^"]+)"', html)
        if p:
            vod["vod_pic"] = p.group(1)
        # 信息字段: ◎年\u3000\u3000代:\u30002026(字间全角空格\u3000)
        def _field(lb):
            pat = r"◎\s*" + r"\s*".join(re.escape(ch) for ch in lb) + r"[：:]\s*([^\n<◎]{1,80})"
            m = re.search(pat, html)
            if m:
                return m.group(1).strip().replace("&middot;", "·")
            return ""
        vod["vod_year"] = _field("年代")
        vod["vod_area"] = _field("产地")
        vod["vod_director"] = _field("导演")
        vod["vod_actor"] = _field("主演")
        # 简介
        dm = re.search(r"◎\s*简\s*介[\s\S]{0,40}?([\s\S]{0,1200}?)<", html)
        if dm:
            vod["vod_content"] = re.sub(r"<[^>]+>", "", dm.group(1)).strip()
        # 下载链接(线路): 磁力 + 网盘
        froms, urls = [], []
        lines = {}
        for m in re.finditer(r'(magnet:[^"\']+)|https?://(pan\.\w+\.[^"\']+)', html):
            if m.group(1):
                lines.setdefault("磁力", []).append(("磁力", m.group(1)))
            elif m.group(2):
                u = m.group(2)
                if "xunlei" in u:
                    lines.setdefault("迅雷云盘", []).append(("迅雷云盘", u))
                elif "quark" in u:
                    lines.setdefault("夸克云盘", []).append(("夸克云盘", u))
                elif "baidu" in u:
                    lines.setdefault("百度云盘", []).append(("百度云盘", u))
        for name, eps in lines.items():
            froms.append(name)
            urls.append("#".join("%s$%s" % (en, u.replace("&amp;", "&"))
                                 for en, u in eps))
        if froms:
            vod["vod_play_from"] = "$$$".join(froms)
            vod["vod_play_url"] = "$$$".join(urls)
        return {"list": [vod]}

    # ── 搜索 ─────────────────────────────────────────────────────────

    def searchContent(self, key, quick, pg="1"):
        pg = int(pg) if str(pg).isdigit() else 1
        if pg > 1 or not str(key or "").strip():
            return {"list": [], "page": pg, "pagecount": 1, "limit": 0, "total": 0}
        html = _fetch(self.host + "/e/search/index.php",
                      {"keyboard": str(key), "submit": "搜 索",
                       "show": "title,zhuyan", "tempid": "1"})
        cards = self._cards(html)
        # 搜索卡片可能不含 data-original, 兜底提取 alt+href
        if not cards:
            for m in re.finditer(r'<a[^>]*href="(/[^"]+\.html)"[^>]*>[\s\S]{0,300}?'
                                 r'(?:data-original="([^"]+)"|[\s\S]{0,50})'
                                 r'[^>]*title="([^"]+)"|title="([^"]+)"[^>]*>', html):
                pass
            # 简化: 提取所有含标题的详情链接
            for m in re.finditer(
                    r'href="(/[^"]+\.html)"[^>]*>\s*([^<]{2,60})', html):
                href, title = m.group(1), m.group(2).strip()
                if href and title and title not in ("返回顶部",) and href not in {c["vod_id"] for c in cards}:
                    cards.append({"vod_id": href, "vod_name": title,
                                  "vod_pic": "", "vod_remarks": ""})
        return {"list": cards, "page": pg,
                "pagecount": pg if len(cards) < 20 else pg + 1,
                "limit": 20, "total": len(cards)}

    # ── 播放 ─────────────────────────────────────────────────────────

    def playerContent(self, flag, id, vipFlags):
        u = str(id or "").replace("&amp;", "&")
        hdr = {"User-Agent": UA, "Referer": self.host + "/"}
        if u.startswith("magnet:"):
            return {"parse": 0, "playUrl": "", "url": u, "header": json.dumps(hdr)}
        if u.startswith("http"):
            return {"parse": 0, "playUrl": "", "url": u, "header": json.dumps(hdr)}
        return {"parse": 0, "playUrl": "", "url": u, "header": json.dumps(hdr)}