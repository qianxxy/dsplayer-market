# -*- coding: utf-8 -*-
# 黄果短剧 融合版（优化：预取不阻塞、host 切换更稳、线程不外泄）
# 依赖：requests, beautifulsoup4, pycryptodome (或 Crypto)
# 适配 TVBox / 类 TVBox 壳

import sys
import re
import json
import time
import base64
import random
import string
import threading
import html as htmllib
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed

sys.path.append('..')
try:
    from base.spider import Spider
except ImportError:
    class Spider:
        pass

try:
    import requests as rq
    rq.packages.urllib3.disable_warnings()
except Exception:
    rq = None

try:
    from bs4 import BeautifulSoup
except ImportError:
    BeautifulSoup = None

try:
    from Crypto.Cipher import AES
except ImportError:
    try:
        from Cryptodome.Cipher import AES
    except ImportError:
        AES = None

# ---------- 常量 ----------


def _gen_random_subdomain():
    length = random.randint(3, 6)
    chars = string.ascii_lowercase + string.digits
    return ''.join(random.choice(chars) for _ in range(length))


def _gen_backup_hosts(n=8):
    return [f"https://{_gen_random_subdomain()}.ediayikma.cc" for _ in range(n)]


HOSTS = ["https://huangguoai.com"] + _gen_backup_hosts(8)
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
TIMEOUT = 12
PAGE_SIZE = 24
_AES_KEY = b'f5d965df75336270'
_AES_IV = b'97b60394abc2fbe1'
_PLACEHOLDER_GIF = base64.b64decode(
    'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7')
_PROXY_PORT = [0]
_TAG_RE = re.compile(r'<[^>]+>')
_LABEL_RE = re.compile(r'<[^>]+>')

_BS4_PARSER = None
if BeautifulSoup is not None:
    try:
        BeautifulSoup("<a/>", "lxml")
        _BS4_PARSER = "lxml"
    except Exception:
        _BS4_PARSER = "html.parser"


def _clean(s):
    if not s:
        return ""
    s = htmllib.unescape(str(s))
    s = _TAG_RE.sub(' ', s)
    return re.sub(r'\s+', ' ', s).strip()


def _log(msg):
    try:
        print("[黄果短剧] %s" % msg)
    except Exception:
        pass


# ---------- 本地图片代理 ----------
try:
    from http.server import BaseHTTPRequestHandler, HTTPServer

    def _fetch_img_raw(u, referer):
        headers = {"User-Agent": UA, "Referer": referer, "Accept": "image/*"}
        try:
            rr = rq.get(u, headers=headers, timeout=(4, 8), verify=False,
                        allow_redirects=True)
            if rr.status_code == 200 and rr.content and len(rr.content) > 50:
                return rr.content
        except Exception:
            pass
        return b''

    def _decrypt_img(data):
        if not data or AES is None:
            return data
        if data[:3] == b'\xff\xd8\xff' or data[:8] == b'\x89PNG\r\n\x1a\n' \
                or data[:6] in (b'GIF87a', b'GIF89a') \
                or (data[:4] == b'RIFF' and data[8:12] == b'WEBP'):
            return data
        try:
            dec = AES.new(_AES_KEY, AES.MODE_CBC, _AES_IV).decrypt(data)
            pad = dec[-1]
            if 1 <= pad <= 16 and all(b == pad for b in dec[-pad:]):
                dec = dec[:-pad]
            else:
                dec = dec.rstrip(b'\x00')
            return dec
        except Exception:
            return data

    def _detect_mime(data):
        if data[:3] == b'\xff\xd8\xff':
            return 'image/jpeg'
        if data[:8] == b'\x89PNG\r\n\x1a\n':
            return 'image/png'
        if data[:6] in (b'GIF87a', b'GIF89a'):
            return 'image/gif'
        if data[:4] == b'RIFF' and data[8:12] == b'WEBP':
            return 'image/webp'
        return 'image/jpeg'

    class _ImgHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            try:
                pr = urllib.parse.urlparse(self.path)
                if pr.path not in ('/img', '/proxy'):
                    self.send_response(404)
                    self.end_headers()
                    return
                q = urllib.parse.parse_qs(pr.query)
                u = q.get('u', q.get('url', ['']))[0]
                u = urllib.parse.unquote(u)
                if not u.startswith('http'):
                    self.send_response(400)
                    self.end_headers()
                    return
                raw = _fetch_img_raw(u, HOSTS[0] + "/")
                data = _decrypt_img(raw) if raw else b''
                if not data or len(data) < 50:
                    data, ctype = _PLACEHOLDER_GIF, 'image/gif'
                else:
                    ctype = _detect_mime(data)
                self.send_response(200)
                self.send_header('Content-Type', ctype)
                self.send_header('Content-Length', str(len(data)))
                self.send_header('Cache-Control', 'max-age=86400')
                self.end_headers()
                self.wfile.write(data)
            except Exception:
                pass

        def log_message(self, *args):
            pass

    def _start_proxy_server():
        if _PROXY_PORT[0]:
            return _PROXY_PORT[0]
        for port in [9978] + list(range(9979, 10020)) + list(range(30261, 30281)):
            try:
                srv = HTTPServer(('127.0.0.1', port), _ImgHandler)
                _PROXY_PORT[0] = port
                threading.Thread(target=srv.serve_forever, daemon=True).start()
                return port
            except Exception:
                continue
        return 0
except Exception:
    def _start_proxy_server():
        return 0

    def _decrypt_img(data):
        return data

    def _detect_mime(data):
        return 'image/jpeg'


class Spider(Spider):

    _PRIMARY_FAIL_THRESHOLD = 3

    def getName(self):
        return "黄果短剧"

    def init(self, extend=""):
        primary = HOSTS[0].rstrip('/')
        self.host = primary
        self._working_backups = []
        self._primary_fails = [0]
        self._list_cache = {}
        self._cache_lock = threading.Lock()
        self._switch_lock = threading.Lock()

        try:
            self.s = rq.Session()
            self.s.verify = False
            self.s.headers.update({
                "User-Agent": UA,
                "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
                "Accept-Language": "zh-CN,zh;q=0.9",
                "Referer": self.host + "/",
            })
            try:
                from requests.adapters import HTTPAdapter
                _adapter = HTTPAdapter(
                    pool_connections=16, pool_maxsize=32, max_retries=0)
                self.s.mount('http://', _adapter)
                self.s.mount('https://', _adapter)
            except Exception:
                pass
        except Exception:
            self.s = None

        try:
            _start_proxy_server()
        except Exception:
            pass

        try:
            t = threading.Thread(target=self._prefetch_backups,
                                 name="hg-prefetch", daemon=True)
            t.start()
        except Exception as e:
            _log("启动预取线程失败: %s" % e)

    # ---------- 备用域名探测 ----------

    @staticmethod
    def _probe_host(h):
        """单机探测：返回可用 host，否则 None"""
        try:
            r = rq.get(h.rstrip('/'),
                       headers={"User-Agent": UA},
                       timeout=(3, 4),      # (连接, 读取)
                       verify=False)
            if r.status_code == 200 and (
                    '黄果' in r.text
                    or 'huangguo' in r.text.lower()
                    or len(r.text) > 2000):
                return h.rstrip('/')
        except Exception:
            pass
        return None

    def _prefetch_backups(self):
        """后台预热：并行探测备用域名。任何异常都不往外抛，绝不阻塞主线程。"""
        try:
            primary = HOSTS[0].rstrip('/')
            backups = [h.rstrip('/') for h in HOSTS[1:]
                       if h.rstrip('/') != primary]
            if not backups:
                return

            results = []
            lock = threading.Lock()

            def _do_probe(h):
                try:
                    r = self._probe_host(h)
                    if r:
                        with lock:
                            results.append(r)
                except Exception:
                    pass

            ex = ThreadPoolExecutor(max_workers=min(6, len(backups)),
                                    thread_name_prefix="hg-probe")
            try:
                futs = [ex.submit(_do_probe, h) for h in backups]
                try:
                    # 全部完成或超时都行，结果已在 _do_probe 里收集
                    for _ in as_completed(futs, timeout=12):
                        pass
                except TimeoutError:
                    _log("备用域名探测超时，使用已收集 %d 个" % len(results))
                except Exception as e:
                    _log("备用域名探测异常: %s" % e)
            finally:
                # 关键：不等待未完成任务，避免像原来那样把请求拖到 28s
                try:
                    ex.shutdown(wait=False, cancel_futures=True)
                except TypeError:
                    ex.shutdown(wait=False)

            if results:
                self._working_backups = results
                _log("备用域名就绪 %d 个: %s"
                     % (len(results), ",".join(results[:3])))
        except Exception as e:
            _log("_prefetch_backups 异常: %s" % e)

    def _switch_host(self, new_host):
        new_host = (new_host or "").rstrip('/')
        if not new_host:
            return
        with self._switch_lock:
            self.host = new_host
            try:
                if self.s is not None:
                    self.s.headers["Referer"] = new_host + "/"
            except Exception:
                pass

    # ---------- HTTP 请求 ----------

    def _fetch_one(self, host, path, ref, timeout):
        """单 host 请求（线程安全：不依赖 self.s）。path 为完整 URL 时直接请求。"""
        try:
            if path.startswith("http"):
                url = path
                base = host or getattr(self, 'host', '') or ''
                ref_url = base + (ref or "/")
            else:
                url = (host or "") + path
                ref_url = (host or "") + (ref or "/")

            headers = {
                "User-Agent": UA,
                "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
                "Accept-Language": "zh-CN,zh;q=0.9",
                "Referer": ref_url,
            }
            r = rq.get(url, timeout=timeout, verify=False,
                       allow_redirects=True, headers=headers)
            if r.status_code == 200 and r.text:
                r.encoding = 'utf-8'
                return r.text
        except Exception:
            pass
        return ""

    def _wrap_pic(self, url):
        if not url or not str(url).startswith('http'):
            return url or ""
        if not _PROXY_PORT[0]:
            _start_proxy_server()
        if _PROXY_PORT[0]:
            return ("http://127.0.0.1:%d/proxy?url=%s"
                    % (_PROXY_PORT[0], urllib.parse.quote(url, safe='')))
        try:
            b = base64.b64encode(url.encode('utf-8')).decode('ascii')
            return f"proxy://type=pic&url={b}"
        except Exception:
            return url

    def _get_candidates(self, current):
        """返回除当前 host 外的候选 host 列表（最多 4 个）。"""
        try:
            known_good = list(getattr(self, '_working_backups', None) or [])
        except Exception:
            known_good = []
        candidates = [h for h in known_good if h != current][:4]
        if not candidates:
            candidates = [h.rstrip('/') for h in HOSTS
                          if h.rstrip('/') != current][:4]
        return candidates

    def _try_parallel(self, path, ref, candidates):
        """并行尝试多个候选 host；找到第一个可用即返回，不等待剩余的。"""
        if not candidates:
            return ""
        if len(candidates) == 1:
            text = self._fetch_one(candidates[0], path, ref, 6)
            if text:
                self._switch_host(candidates[0])
            return text

        ex = ThreadPoolExecutor(max_workers=len(candidates),
                                thread_name_prefix="hg-get")
        try:
            futs = {ex.submit(self._fetch_one, h, path, ref, 6): h
                    for h in candidates}
            try:
                for fut in as_completed(futs, timeout=8):
                    try:
                        text = fut.result()
                    except Exception:
                        continue
                    if text:
                        won = futs[fut]
                        # 取消尚未开始的任务（不等它们跑完）
                        for f in futs:
                            if not f.done():
                                f.cancel()
                        self._switch_host(won)
                        return text
            except TimeoutError:
                pass
            except Exception:
                pass
        finally:
            try:
                ex.shutdown(wait=False, cancel_futures=True)
            except TypeError:
                ex.shutdown(wait=False)
        return ""

    def _get(self, path, ref="/"):
        # 完整 URL 直接请求
        if path.startswith("http"):
            headers = {"Referer": self.host.rstrip('/') + (ref or "/")}
            try:
                if self.s is not None:
                    r = self.s.get(path, timeout=TIMEOUT,
                                   allow_redirects=True, headers=headers)
                else:
                    r = rq.get(path, timeout=TIMEOUT, verify=False,
                               headers={"User-Agent": UA, **headers})
                if r.status_code == 200 and r.text:
                    r.encoding = 'utf-8'
                    return r.text
            except Exception:
                pass
            return ""

        primary = HOSTS[0].rstrip('/')
        current = (getattr(self, 'host', primary) or primary).rstrip('/')

        # 1) 当前 host 优先（较短超时，失败要快速回退）
        text = self._fetch_one(current, path, ref, 6)
        if text:
            try:
                self._primary_fails[0] = 0
            except (AttributeError, IndexError):
                pass
            return text

        # 2) 失败累计 & 阈值后自动切主 host
        try:
            if current == primary:
                self._primary_fails[0] += 1
                if (self._primary_fails[0] >= self._PRIMARY_FAIL_THRESHOLD
                        and getattr(self, '_working_backups', None)):
                    self._switch_host(self._working_backups[0])
        except (AttributeError, IndexError):
            pass

        # 3) 并行尝试候选备用
        candidates = self._get_candidates(current)
        if not candidates:
            return ""
        return self._try_parallel(path, ref, candidates)

    def _get_cached(self, path, ref="/", ttl=60):
        now = time.time()
        try:
            with self._cache_lock:
                cached = self._list_cache.get(path)
        except Exception:
            cached = None
        if cached and now - cached[1] < ttl:
            return cached[0]

        text = self._get(path, ref)
        if text:
            try:
                with self._cache_lock:
                    self._list_cache[path] = (text, now)
                    if len(self._list_cache) > 80:
                        for k in list(self._list_cache.keys()):
                            if now - self._list_cache[k][1] > ttl:
                                self._list_cache.pop(k, None)
            except Exception:
                pass
        return text

    def isVideoFormat(self, url):
        return any(x in (url or '')
                   for x in ['.m3u8', '.mp4', '.flv', '.mkv', '.avi'])

    def manualVideoCheck(self):
        return False

    # ---------- 首页 ----------
    def homeContent(self, filter=False):
        result = {
            "class": [
                {"type_id": "recommend", "type_name": "精选推荐"},
                {"type_id": "newest", "type_name": "最近上新"},
                {"type_id": "ai-duanju", "type_name": "AI成人短剧"},
                {"type_id": "ai-manju", "type_name": "AI成人漫剧"},
                {"type_id": "ai-huanlian", "type_name": "AI换脸"},
                {"type_id": "ai-mogai", "type_name": "AI魔改"},
                {"type_id": "topic", "type_name": "📌专题"},
                {"type_id": "ranks", "type_name": "排行榜"},
                {"type_id": "chigua", "type_name": "黄果吃瓜"},
                {"type_id": "author", "type_name": "黄果官方"},
            ],
            "list": [],
            "filters": {
                "ranks": [{"key": "类型", "name": "类型", "value": [
                    {"n": "热播榜", "v": "hot"},
                    {"n": "推荐榜", "v": "recommend"},
                    {"n": "潜力榜", "v": "potential"},
                ]}],
                "chigua": [{"key": "类型", "name": "类型", "value": [
                    {"n": "全部", "v": "page"},
                    {"n": "热门吃瓜", "v": "remen"},
                    {"n": "AI原创", "v": "yuanchuang"},
                ]}],
                "author": [{"key": "类型", "name": "类型", "value": [
                    {"n": "黄果官方", "v": "156291"},
                    {"n": "黄果ai大师", "v": "156305"},
                ]}],
            }
        }
        try:
            html = self._get_cached("/")
            if html:
                result["list"] = self._parse_list(html)
        except Exception:
            pass
        return result

    def homeVideoContent(self):
        try:
            html = self._get_cached("/recommend/1/")
            if not html:
                html = self._get_cached("/")
            return {"list": self._parse_list(html)}
        except Exception:
            return {"list": []}

    # ---------- 分类 ----------
    def categoryContent(self, tid, pg=1, filter=False, extend=""):
        try:
            pg = int(str(pg or 1))
        except Exception:
            pg = 1
        if pg < 1:
            pg = 1
        cid = str(tid or "").strip().strip("/")
        ext = extend if isinstance(extend, dict) else {}
        rc = ext.get("类型", cid)

        videos, pages, total = [], 9999, 0

        try:
            if cid.startswith("dir_topic_"):
                slug = cid.replace("dir_topic_", "")
                html = self._get_cached(f"/topics/{slug}/?page={pg}")
                videos = self._parse_list(html, mode="drama")
                return self._result(videos, pg, 9999)

            if cid in ("ai-duanju", "ai-manju", "ai-huanlian", "ai-mogai"):
                videos, pages, total = self._category_api(cid, pg)
                if not videos:
                    path = f"/{cid}/" if pg <= 1 else f"/{cid}/{pg}/"
                    html = self._get_cached(path)
                    videos = self._parse_list(html)
                    ps = [int(x) for x in re.findall(
                        r'/' + re.escape(cid) + r'/(\d+)/', html or "")]
                    if ps:
                        pages = max(ps)
                if len(videos) > PAGE_SIZE:
                    videos = videos[:PAGE_SIZE]
                return self._result(videos, pg, pages or 9999, total)

            if cid == "recommend":
                html = self._get_cached(f"/recommend/{pg}/")
                videos = self._parse_list(html)
            elif cid == "newest":
                html = self._get_cached(f"/newest/{pg}/")
                videos = self._parse_list(html)
            elif cid == "topic":
                html = self._get_cached("/topics/")
                videos = self._parse_list(html, mode="topic")
                pages = 1
            elif cid == "ranks":
                rtype = rc if rc in ("hot", "recommend", "potential") else "hot"
                html = self._get_cached(f"/ranks/{rtype}/")
                videos = self._parse_list(html, mode="rank")
                pages = 1
            elif cid == "chigua":
                ctype = rc if rc in ("page", "remen", "yuanchuang") else "page"
                html = self._get_cached(f"/chigua/{ctype}/{pg}/")
                videos = self._parse_list(html, mode="post")
            elif cid == "author":
                aid = rc if str(rc).isdigit() else "156291"
                html = self._get(f"/author/{aid}/video/{pg}/")
                videos = self._parse_list(html)
            else:
                path = f"/{cid}/" if pg <= 1 else f"/{cid}/{pg}/"
                html = self._get(path)
                videos = self._parse_list(html)

        except Exception:
            videos = []

        return self._result(videos, pg, pages, total)

    def _category_api(self, slug, pg):
        url = (f"/api/videos/category/{urllib.parse.quote(slug)}"
               f"?sort=hot&page={pg}&size={PAGE_SIZE}")
        text = self._get_cached(url, ref="/" + slug + "/")
        if not text:
            return [], 0, 0
        try:
            data = json.loads(text)
        except Exception:
            return [], 0, 0
        d = data.get("data") or {}
        items = d.get("items") or []
        pag = d.get("pagination") or {}
        videos = []
        for it in items:
            v = self._api_item(it)
            if v:
                videos.append(v)
        pages = total = 0
        try:
            pages = int(pag.get("pages") or 0)
        except Exception:
            pass
        try:
            total = int(pag.get("total") or 0)
        except Exception:
            pass
        return videos, pages, total

    def _api_item(self, it):
        vid = it.get("id")
        if vid is None:
            return None
        title = _clean(it.get("title"))
        if not title:
            return None
        pic = (it.get("cover") or "").strip()
        epc = it.get("episode_count")
        finished = it.get("is_finished")
        if finished:
            remark = "全%d集" % epc if epc else "全剧"
        else:
            remark = "更新至%d集" % epc if epc else "连载中"
        score = it.get("score")
        if score:
            remark = f"{score}分 " + remark
        return {
            "vod_id": str(vid),
            "vod_name": title,
            "vod_pic": self._wrap_pic(pic),
            "vod_remarks": remark or "在线观看",
        }

    def _result(self, videos, pg, pagecount=9999, total=0):
        n = len(videos)
        if total < 1:
            total = pagecount * max(n, 1) if pagecount > 1 else n
        return {
            "list": videos,
            "page": pg,
            "pagecount": pagecount,
            "limit": PAGE_SIZE,
            "total": total,
        }

    # ---------- 搜索 ----------
    def searchContent(self, key, quick=False, pg="1"):
        return self.searchContentPage(key, quick, pg)

    def searchContentPage(self, key, quick, page):
        kw = urllib.parse.quote(str(key or "").strip())
        if not kw:
            return {"list": [], "page": 1, "pagecount": 1,
                    "limit": 20, "total": 0}
        try:
            pg = int(page) if page else 1
        except Exception:
            pg = 1
        html = self._get(f"/search/video/{kw}/{pg}/")
        videos = self._parse_list(html, mode="search")
        has_more = len(videos) >= 18
        return {
            "page": pg,
            "pagecount": pg + 1 if has_more else pg,
            "limit": 20,
            "total": 0,
            "list": videos,
        }

    # ---------- 详情 ----------
    def detailContent(self, ids):
        try:
            raw = ids[0] if isinstance(ids, (list, tuple)) else ids
            did = str(raw).strip()
        except Exception:
            return {"list": []}
        if not did:
            return {"list": []}

        if "/archives/" in did or (did.startswith("http") and "archives" in did):
            return self._detail_chigua(did)

        m = re.search(r'(?:detail/|/)?(\d+)/?$', did)
        vid = m.group(1) if m else (did if did.isdigit() else None)

        vhtml = ""
        if vid:
            # 并行预取 /video/ 页，与 detail 页同时发起；不阻塞退出
            primary = (self.host or HOSTS[0]).rstrip('/')
            ex = ThreadPoolExecutor(max_workers=1, thread_name_prefix="hg-detail")
            try:
                fut_video = ex.submit(self._fetch_one, primary,
                                      f"/video/{vid}/", "/", 8)
                html = self._get(f"/detail/{vid}/")
                try:
                    vhtml = fut_video.result(timeout=10)
                except Exception:
                    vhtml = ""
            finally:
                try:
                    ex.shutdown(wait=False, cancel_futures=True)
                except TypeError:
                    ex.shutdown(wait=False)
        else:
            html = self._get(did if did.startswith("/") else "/" + did)

        if not html:
            return {"list": []}

        title = ""
        m = re.search(r'<h1[^>]*>([^<]+)</h1>', html)
        if m:
            title = _clean(m.group(1))
        if not title:
            m = re.search(r'<meta property="og:title" content="([^"]+)"', html)
            if m:
                title = _clean(m.group(1))
        if not title:
            m = re.search(r'<title>(.*?)</title>', html)
            if m:
                title = _clean(m.group(1).split('|')[0])
        if not title:
            return {"list": []}

        pic = ""
        m = re.search(r'<img[^>]*data-src="([^"]+)"[^>]*>', html)
        if m:
            pic = htmllib.unescape(m.group(1)).strip()
        if not pic:
            m = re.search(r'<meta property="og:image" content="([^"]+)"', html)
            if m:
                pic = htmllib.unescape(m.group(1)).strip()

        desc = ""
        m = re.search(r'<p class="[^"]*hg-web-detail__desc[^"]*"[^>]*>(.*?)</p>',
                      html, re.S)
        if m:
            desc = _clean(m.group(1))
        if not desc:
            m = re.search(r'<meta name="description" content="([^"]+)"', html)
            if m:
                desc = _clean(m.group(1))

        meta = ""
        m = re.search(r'class="[^"]*hg-web-detail__meta[^"]*"[^>]*>(.*?)</div>',
                      html, re.S)
        if m:
            meta = _clean(m.group(1))
        tags = []
        for m in re.finditer(
                r'class="hg-tag"[^>]*href="(/tag/[^"]+)"[^>]*>([^<]+)<', html):
            tags.append(_clean(m.group(2)))
        remark = meta or "在线观看"

        eps = []
        seen = set()
        ep_re = (r'href="(/video/' + re.escape(vid or '')
                 + r'/[^"]*?)"[^>]*>(.*?)</a>') if vid else None
        _ep_num_re = re.compile(r'/(?:ep-?|episode-?|p|play-?)(\d+)/?', re.I)
        _fallback_seq = [0]

        def _label_from_path(path):
            m2 = _ep_num_re.search(path or "")
            if m2:
                return "%02d" % int(m2.group(1))
            _fallback_seq[0] += 1
            return "%02d" % _fallback_seq[0]

        if vid and ep_re:
            for m in re.finditer(ep_re, html, re.S):
                path = m.group(1)
                if not path.startswith("/video/") or path in seen:
                    continue
                label = _label_from_path(path)
                seen.add(path)
                eps.append((label, path))

            if not eps and vhtml:
                for m in re.finditer(ep_re, vhtml, re.S):
                    path = m.group(1)
                    if not path.startswith("/video/") or path in seen:
                        continue
                    label = _label_from_path(path)
                    seen.add(path)
                    eps.append((label, path))

                if not eps:
                    for m in re.finditer(
                            r'<a[^>]*class="hg-play__ep-item[^"]*"[^>]*href="([^"]*)"[^>]*data-ep-id="([^"]*)"[^>]*>(.*?)</a>',
                            vhtml, re.S):
                        path = m.group(1)
                        ep_id = m.group(2)
                        label = _label_from_path(path)
                        if (ep_id and ep_id.isdigit()
                                and label.startswith("0")
                                and not _ep_num_re.search(path or "")):
                            label = "%02d" % int(ep_id)
                        if not path.startswith('/'):
                            path = '/' + path
                        if path not in seen:
                            seen.add(path)
                            eps.append((label, path))

        eps = sorted(eps, key=lambda x: self._ep_sort(x[1]))
        if not eps and vid:
            eps = [("01", f"/video/{vid}/")]

        play_from = ["正片"]
        play_url = ["#".join(f"{l}${p}" for l, p in eps)]

        vod = {
            "vod_id": vid or did,
            "vod_name": title,
            "vod_pic": self._wrap_pic(pic),
            "type_name": ",".join(tags) or "黄果短剧",
            "vod_remarks": remark,
            "vod_content": desc,
            "vod_play_from": "$$$".join(play_from),
            "vod_play_url": "$$$".join(play_url),
            "vod_year": "",
            "vod_area": "",
            "vod_actor": "",
            "vod_director": "",
        }
        return {"list": [vod]}

    def _detail_chigua(self, url):
        if not url.startswith("http"):
            url = self.host.rstrip('/') + (url if url.startswith('/') else '/' + url)
        try:
            if url.startswith(self.host):
                html = self._get(url.replace(self.host, ""))
            else:
                html = ""
            if not html:
                r = rq.get(url, headers={"User-Agent": UA,
                                         "Referer": self.host + "/"},
                           timeout=TIMEOUT, verify=False)
                html = r.text if r.status_code == 200 else ""
        except Exception:
            return {"list": []}
        if not html:
            return {"list": []}

        title = ""
        m = re.search(r'<title>(.*?)</title>', html)
        if m:
            title = _clean(m.group(1).split('|')[0])

        players = re.findall(
            r'<div class="post-video-player"[^>]*data-player-key="([^"]*)"[^>]*data-src="([^"]*)"',
            html)
        if not players:
            players = re.findall(r'data-src="(https?://[^"]+\.m3u8[^"]*)"', html)
            players = [(f"线路{i+1}", u) for i, u in enumerate(players)]

        play = "#".join([f"{k}${v.replace('&amp;', '&')}"
                         for k, v in players]) if players else ""

        video = {
            "vod_id": url,
            "vod_name": title or "吃瓜",
            "vod_pic": "",
            "vod_remarks": "",
            "vod_content": title,
            "type_name": "黄果吃瓜",
            "vod_play_from": "黄果吃瓜",
            "vod_play_url": play or f"正片${url}",
            "vod_year": "", "vod_area": "", "vod_actor": "", "vod_director": "",
        }
        return {"list": [video]}

    @staticmethod
    def _ep_sort(path):
        m = re.search(r'/(?:ep-?|episode-?|p|play-?)(\d+)/?', path or "", re.I)
        return int(m.group(1)) if m else 0

    # ---------- 播放 ----------
    def playerContent(self, flag, id, vipFlags=None, vipIds=None):
        key = str(id or "").strip()
        if not key:
            return {"parse": 0, "url": "", "header": {"User-Agent": UA}}

        def _norm(u):
            if not u:
                return ""
            u = str(u).replace("\\u0026", "&").replace("&amp;", "&").strip()
            if u.startswith("//"):
                u = "https:" + u
            return u

        def _direct(url):
            url = _norm(url)
            if not url:
                return ""
            if url.startswith("http") and self.isVideoFormat(url):
                return url
            if url.startswith("http") and any(
                    x in url for x in ['auth_key', 'playlist.m3u8',
                                       '/m3u8/', '.m3u8']):
                return url
            return ""

        if key.startswith("http"):
            u = _direct(key)
            if u:
                return {
                    "parse": 0,
                    "url": u,
                    "header": {"User-Agent": UA, "Referer": self.host + "/"},
                }

        if flag == "黄果吃瓜" and key.startswith("http"):
            return {
                "parse": 0,
                "url": _norm(key),
                "header": {"User-Agent": UA, "Referer": self.host + "/"},
            }

        if key.isdigit():
            key = f"/video/{key}/"
        elif not key.startswith("/") and not key.startswith("http"):
            key = "/" + key

        html = self._get(key, ref="/")
        if not html:
            return {
                "parse": 1,
                "url": self.host.rstrip('/') + key,
                "header": {"User-Agent": UA, "Referer": self.host + "/"},
            }

        m = re.search(
            r'<script id="videoInitialData" type="application/json">(.*?)</script>',
            html, re.S)
        if m:
            try:
                raw = m.group(1)
                data = None
                try:
                    data = json.loads(raw)
                except Exception:
                    for end in range(len(raw), max(0, len(raw) - 2000), -1):
                        try:
                            data = json.loads(raw[:end])
                            break
                        except Exception:
                            continue
                if data:
                    url = ""
                    for k in ("videoSrc", "videoUrl", "playUrl", "src",
                              "url", "video_src", "play_url"):
                        v = data.get(k)
                        if v and isinstance(v, str):
                            url = v
                            break
                    if not url:
                        eps = None
                        for k in ("epPlaySrcs", "episodes", "playSrcs",
                                  "ep_play_srcs", "playSources"):
                            v = data.get(k)
                            if isinstance(v, dict):
                                eps = v
                                break
                        if eps:
                            ep = (data.get("ep") or data.get("episode")
                                  or data.get("currentEp"))
                            if ep is not None and str(ep) in eps:
                                url = eps[str(ep)]
                            else:
                                for ek, ev in eps.items():
                                    if str(ep) in str(ek):
                                        url = ev
                                        break
                                if not url:
                                    for ev in eps.values():
                                        if ev:
                                            url = ev
                                            break
                    url = _norm(url)
                    if url.startswith("http"):
                        return {
                            "parse": 0,
                            "url": url,
                            "header": {"User-Agent": UA,
                                       "Referer": self.host + "/"},
                        }
            except Exception:
                pass

        m = re.search(
            r'<article[^>]*class="[^"]*hg-play__slide[^"]*is-active[^"]*"[^>]*data-play-src="([^"]*)"',
            html)
        if not m:
            m = re.search(r'data-play-src="(https?://[^"]+)"', html)
        if m:
            url = _norm(m.group(1))
            if url.startswith("http"):
                return {
                    "parse": 0,
                    "url": url,
                    "header": {"User-Agent": UA, "Referer": self.host + "/"},
                }

        return {
            "parse": 1,
            "url": self.host.rstrip('/') + key,
            "header": {"User-Agent": UA, "Referer": self.host + "/"},
        }

    # ---------- 本地代理 ----------
    def localProxy(self, param):
        try:
            if isinstance(param, dict):
                if param.get("type") == "pic":
                    return self._proxy_pic(param)
                url = param.get("url") or param.get("u") or ""
            else:
                url = self._resolve_img_param(param)
            if not url:
                return None
            headers = {"User-Agent": UA, "Referer": self.host + "/",
                       "Accept": "image/*"}
            rr = rq.get(url, headers=headers, timeout=(4, 10),
                        verify=False, allow_redirects=True)
            if rr.status_code == 200 and rr.content and len(rr.content) > 50:
                data = _decrypt_img(rr.content)
                ctype = _detect_mime(data)
                return [200, ctype, data]
        except Exception:
            pass
        return None

    def _proxy_pic(self, params):
        try:
            raw = params.get("url") or ""
            if not raw.startswith("http"):
                try:
                    raw = base64.b64decode(raw + "==").decode("utf-8", "ignore")
                except Exception:
                    pass
            if not raw.startswith("http"):
                return None
            headers = {"User-Agent": UA, "Referer": self.host + "/"}
            data = rq.get(raw, headers=headers, timeout=(4, 10),
                          verify=False).content
            data = _decrypt_img(data)
            mime = _detect_mime(data)
            return [200, mime, data]
        except Exception:
            return None

    @staticmethod
    def _resolve_img_param(param):
        if not param:
            return ""
        p = str(param).strip()
        p = re.sub(r'^https?://127\.0\.0\.1:\d+/proxy\?', '', p)
        p = re.sub(r'^proxy\?', '', p)
        if "url=" in p:
            q = urllib.parse.parse_qs(p)
            cand = q.get("url", [""])[0]
            if cand:
                p = cand
        try:
            p = urllib.parse.unquote(p)
        except Exception:
            pass
        if not p.startswith("http"):
            try:
                dec = base64.b64decode(p + "==").decode("utf-8", "ignore")
                if dec.startswith("http"):
                    p = dec
            except Exception:
                pass
        return p if p.startswith("http") else ""

    # ---------- 列表解析 ----------
    def _parse_list(self, html, mode="drama"):
        if not html or len(html) < 150:
            return []
        if BeautifulSoup is not None:
            try:
                return self._parse_bs4(html, mode)
            except Exception:
                pass
        return self._parse_regex(html)

    def _parse_bs4(self, html, mode):
        videos, seen = [], set()
        doc = BeautifulSoup(html, _BS4_PARSER or "html.parser")

        if mode in ("drama", "search"):
            for card in doc.select("div.hg-drama-card"):
                a = card.find("a", href=True)
                if not a:
                    continue
                href = a.get("href", "")
                m = re.search(r"/detail/(\d+)", href)
                if not m:
                    continue
                vid = m.group(1)
                if vid in seen:
                    continue
                seen.add(vid)
                img = card.find("img")
                pic = ""
                if img:
                    pic = img.get("data-src") or img.get("src") or ""
                title = ""
                if img:
                    title = img.get("alt") or ""
                if not title:
                    t = card.select_one(
                        ".hg-drama-card__title a, .hg-drama-card__title, h2, h3")
                    title = t.get_text(strip=True) if t else ""
                if not title:
                    title = card.get("data-track-title") or ""
                parts = []
                for sel in [".hg-drama-card__score", ".hg-drama-card__episode",
                            ".hg-drama-card__badge"]:
                    el = card.select_one(sel)
                    if el:
                        parts.append(el.get_text(strip=True))
                remark = " ".join(parts).strip() or "在线观看"
                if title:
                    videos.append({
                        "vod_id": vid,
                        "vod_name": _clean(title),
                        "vod_pic": self._wrap_pic(pic),
                        "vod_remarks": remark,
                    })

            if mode == "search" and not videos:
                for a in doc.find_all("a", href=re.compile(r"/detail/\d+")):
                    m = re.search(r"/detail/(\d+)", a.get("href", ""))
                    if not m or m.group(1) in seen:
                        continue
                    seen.add(m.group(1))
                    img = a.find("img")
                    if not img:
                        continue
                    pic = img.get("data-src") or img.get("src") or ""
                    title = (img.get("alt") or img.get("title")
                             or a.get("title") or "")
                    if not title:
                        t = a.find(class_=re.compile("title"))
                        title = t.get_text(strip=True) if t else ""
                    remark = ""
                    for cls in ["episode", "score"]:
                        s = a.find(class_=re.compile(cls))
                        if s:
                            remark = s.get_text(strip=True)
                            break
                    if title:
                        videos.append({
                            "vod_id": m.group(1),
                            "vod_name": _clean(title),
                            "vod_pic": self._wrap_pic(pic),
                            "vod_remarks": remark or "在线观看",
                        })

        elif mode == "rank":
            for item in doc.select("div.hg-rank-item"):
                a = (item.find("a", href=True, class_=re.compile("cover"))
                     or item.find("a", href=True))
                if not a:
                    continue
                href = a.get("href", "")
                m = re.search(r"/detail/(\d+)", href)
                vid = m.group(1) if m else href
                if vid in seen:
                    continue
                seen.add(vid)
                img = item.find("img")
                pic = (img.get("data-src") or img.get("src") or "") if img else ""
                title = (item.get("data-track-title")
                         or (img.get("alt") if img else "") or "")
                if not title:
                    t = item.select_one(".hg-rank-item__title, h2")
                    title = t.get_text(strip=True) if t else ""
                heat = item.select_one(".hg-rank-item__heat-value")
                remark = ("🔥" + heat.get_text(strip=True)) if heat else ""
                if title:
                    videos.append({
                        "vod_id": vid,
                        "vod_name": _clean(title),
                        "vod_pic": self._wrap_pic(pic),
                        "vod_remarks": remark,
                    })

        elif mode == "topic":
            for card in doc.select("a.hg-topic-card"):
                href = card.get("href", "")
                slug = href.strip("/").split("/")[-1]
                img = card.find("img")
                pic = (img.get("data-src") or img.get("src") or "") if img else ""
                t = card.select_one(".hg-topic-card__title, h2")
                title = (t.get_text(strip=True) if t
                         else (img.get("alt") if img else ""))
                meta = card.select_one(".hg-topic-card__meta")
                remark = meta.get_text(strip=True) if meta else ""
                if title:
                    videos.append({
                        "vod_id": "dir_topic_" + slug,
                        "vod_name": _clean(title),
                        "vod_pic": self._wrap_pic(pic),
                        "vod_remarks": remark,
                        "vod_tag": "folder",
                    })

        elif mode == "post":
            for card in doc.select("a.hg-post-card"):
                href = card.get("href", "")
                if not href:
                    continue
                img = card.find("img")
                pic = (img.get("data-src") or img.get("src") or "") if img else ""
                h3 = card.find("h3")
                title = h3.get_text(strip=True) if h3 else ""
                date = card.select_one(".hg-post-card__date")
                cat = card.select_one(".hg-post-card__cat")
                parts = [s.get_text(strip=True) for s in (date, cat) if s]
                videos.append({
                    "vod_id": href if href.startswith("http") else self.host + href,
                    "vod_name": _clean(title),
                    "vod_pic": self._wrap_pic(pic),
                    "vod_remarks": " | ".join(parts),
                })

        return videos

    def _parse_regex(self, html):
        result, seen = [], set()
        for block in re.split(r'<div class="hg-drama-card"', html)[1:]:
            m = re.search(r'href="(/detail/(\d+)/)"', block)
            if not m:
                continue
            vid = m.group(2)
            if vid in seen:
                continue
            pic = ""
            pm = re.search(r'data-src="([^"]+)"', block)
            if pm:
                pic = htmllib.unescape(pm.group(1)).strip()
            if not pic:
                pm = re.search(r'<img[^>]*src="([^"]+)"', block)
                if pm:
                    pic = htmllib.unescape(pm.group(1)).strip()
            title = ""
            tm = re.search(
                r'class="[^"]*hg-drama-card__title[^"]*"[^>]*>\s*<a[^>]*>(.*?)</a>',
                block, re.S)
            if tm:
                title = _clean(tm.group(1))
            if not title:
                tm = re.search(r'<img[^>]*alt="([^"]+)"', block)
                if tm:
                    title = _clean(tm.group(1))
            parts = []
            sm = re.search(r'class="hg-drama-card__score">([^<]+)<', block)
            if sm:
                parts.append(_clean(sm.group(1)))
            em = re.search(r'class="hg-drama-card__episode">([^<]+)<', block)
            if em:
                parts.append(_clean(em.group(1)))
            remark = " ".join(parts).strip() or "在线观看"
            if not title:
                continue
            seen.add(vid)
            result.append({
                "vod_id": vid,
                "vod_name": title,
                "vod_pic": self._wrap_pic(pic),
                "vod_remarks": remark,
            })
        return result