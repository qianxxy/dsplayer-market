# coding=utf-8
"""
目标站: yxxq32  首页: https://www.yxxq32.cc
"""
import re
import sys
import json
import urllib.parse
from bs4 import BeautifulSoup

sys.path.append('..')
from base.spider import Spider

class Spider(Spider):

    def init(self, extend=""):
        self.site_url = "https://www.yxxq32.cc"
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Referer': self.site_url,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8'
        }

        self.categories = [
            {"type_id": "1", "type_name": "电影"},
            {"type_id": "2", "type_name": "电视剧"},
            {"type_id": "3", "type_name": "综艺"},
            {"type_id": "4", "type_name": "动漫"},
            {"type_id": "5", "type_name": "纪录片"},
            {"type_id": "6", "type_name": "短剧"}
        ]
        self.filters = {}

    def _get_pic(self, soup, parent):
        """统一提取图片：优先从 .module-item-pic img 获取，其次 img.lazy，最后 img"""
        img = parent.select_one('div.module-item-pic img') or parent.select_one('img.lazy') or parent.select_one('img')
        if img:
            src = img.get('data-src') or img.get('data-original') or img.get('src') or ''
            if src:
                if src.startswith('//'):
                    return 'https:' + src
                elif src.startswith('/'):
                    return self.site_url + src
                elif not src.startswith('http'):
                    return 'https:' + src
                else:
                    return src
        return ''

    def _get_name(self, a):
        """从 a 标签提取标题"""
        name = a.get('title') or ''
        if not name:
            title_tag = a.select_one('.module-item-title')
            if title_tag:
                name = title_tag.get_text(strip=True)
        return name

    def _get_remarks(self, a):
        """提取备注（通常为模块封面文字）"""
        remark_tag = a.select_one('.module-item-cover')
        return remark_tag.get_text(strip=True) if remark_tag else ''

    def homeContent(self, filter):
        url = self.site_url + "/"
        resp = self.fetch(url, headers=self.headers)
        video_list = []
        if resp:
            soup = BeautifulSoup(resp.text, 'html.parser')
            items = soup.select('a.module-poster-item')
            for a in items[:20]:
                href = a.get('href', '')
                if not href:
                    continue
                vod_name = self._get_name(a)
                if not vod_name:
                    continue
                video_list.append({
                    "vod_id": href,
                    "vod_name": vod_name,
                    "vod_pic": self._get_pic(soup, a),
                    "vod_remarks": self._get_remarks(a)
                })
        return {"class": self.categories, "list": video_list}

    def homeVideoContent(self):
        return self.homeContent(False)

    def categoryContent(self, tid, pg, filter, extend):
        page = int(pg) if pg else 1
        if page == 1:
            url = f"{self.site_url}/top/{tid}-----------.html"
        else:
            url = f"{self.site_url}/top/{tid}--------{page}---.html"

        resp = self.fetch(url, headers=self.headers)
        if not resp:
            return {"list": [], "page": page, "pagecount": 1, "limit": 24, "total": 0}

        soup = BeautifulSoup(resp.text, 'html.parser')
        video_list = []
        items = soup.select('a.module-poster-item')
        for a in items:
            href = a.get('href', '')
            if not href:
                continue
            vod_name = self._get_name(a)
            if not vod_name:
                continue
            video_list.append({
                "vod_id": href,
                "vod_name": vod_name,
                "vod_pic": self._get_pic(soup, a),
                "vod_remarks": self._get_remarks(a)
            })

        pagecount = 1
        page_block = soup.select_one('div#page')
        if page_block:
            page_links = page_block.select('a.page-link')
            nums = []
            for a_tag in page_links:
                text = a_tag.get_text(strip=True)
                if text.isdigit():
                    nums.append(int(text))
                elif '下页' in text or '下一页' in text:
                    nums.append(page + 1)
            if nums:
                pagecount = max(nums)

        return {
            "list": video_list,
            "page": page,
            "pagecount": pagecount,
            "limit": len(video_list),
            "total": pagecount * len(video_list) if video_list else 0
        }

    def detailContent(self, ids):
        if not ids:
            return {"list": []}
        vod_id = ids[0]
        url = vod_id if vod_id.startswith('http') else self.site_url + vod_id
        resp = self.fetch(url, headers=self.headers)
        if not resp or resp.status_code != 200:
            return {"list": []}

        soup = BeautifulSoup(resp.text, 'html.parser')

        # --- 基础信息 ---
        vod_name = ''
        title_elem = soup.select_one('.module-info-heading h1') or soup.select_one('h1') or soup.select_one('h2')
        if title_elem:
            vod_name = title_elem.get_text(strip=True)
        if not vod_name:
            vod_name = vod_id

        vod_pic = ''
        img_elem = soup.select_one('.module-info-poster img') or soup.select_one('img.lazy')
        if img_elem:
            src = img_elem.get('data-src') or img_elem.get('data-original') or img_elem.get('src') or ''
            if src:
                if src.startswith('//'):
                    vod_pic = 'https:' + src
                elif src.startswith('/'):
                    vod_pic = self.site_url + src
                elif not src.startswith('http'):
                    vod_pic = 'https:' + src
                else:
                    vod_pic = src

        vod_director = ''
        vod_actor = ''
        vod_remarks = ''
        info_items = soup.select('.module-info-item')
        for item in info_items:
            text = item.get_text(strip=True)
            if '导演' in text:
                vod_director = text.split('：')[-1].strip()
            elif '主演' in text:
                vod_actor = text.split('：')[-1].strip()
            elif '连载' in text or '状态' in text or '更新' in text:
                vod_remarks = text.split('：')[-1].strip()

        vod_content = ''
        desc_elem = soup.select_one('.module-info-introduction') or soup.select_one('.detail-desc')
        if desc_elem:
            vod_content = desc_elem.get_text(strip=True)
        if not vod_content:
            meta_desc = soup.select_one('meta[name="description"]')
            if meta_desc:
                vod_content = meta_desc.get('content', '')

        vod_year = ''
        year_match = re.search(r'(\d{4})', vod_name + vod_content)
        if year_match:
            vod_year = year_match.group(1)

        # --- 播放列表解析 ---
        play_from_list = []
        play_url_list = []

        # 1. 尝试 JS 变量
        match = re.search(r'var\s+player_\w+\s*=\s*({[\s\S]*?});', resp.text, re.DOTALL)
        if not match:
            match = re.search(r'player_data\s*=\s*({[\s\S]*?});', resp.text, re.DOTALL)
        if match:
            try:
                data = json.loads(match.group(1))
                flags = data.get('flag', [])
                urls = data.get('url', [])
                if flags and urls:
                    for f, u in zip(flags, urls):
                        play_from_list.append(str(f))
                        play_url_list.append(str(u))
            except Exception:
                pass

        # 2. 页面模块 div.module-play-list（给无名线路自动编号）
        if not play_url_list:
            play_blocks = soup.select('div.module-play-list')
            unnamed_counter = 0
            for block in play_blocks:
                title_div = block.select_one('.module-play-list-title')
                source_name = title_div.get_text(strip=True) if title_div else ''
                if not source_name:
                    unnamed_counter += 1
                    source_name = f'线路{unnamed_counter}'
                episodes = []
                links = block.select('a[href*="/play/"]')
                for a in links:
                    ep_name = a.get_text(strip=True)
                    ep_href = a.get('href', '')
                    if ep_name and ep_href:
                        episodes.append(f"{ep_name}${ep_href}")
                if episodes:
                    play_from_list.append(source_name)
                    play_url_list.append('#'.join(episodes))

        # 3. 终极兜底：没有任何线路时，收集所有 /play/ 链接组成唯一“默认线路”
        if not play_url_list:
            all_play_links = soup.select('a[href*="/play/"]')
            if all_play_links:
                episodes = []
                for a in all_play_links:
                    name = a.get_text(strip=True)
                    href = a.get('href', '')
                    if name and href:
                        episodes.append(f"{name}${href}")
                if episodes:
                    play_from_list.append('默认线路')
                    play_url_list.append('#'.join(episodes))

        vod_play_from = '$$$'.join(play_from_list) if play_from_list else ''
        vod_play_url = '$$$'.join(play_url_list) if play_url_list else ''

        result = [{
            "vod_id": vod_id,
            "vod_name": vod_name,
            "vod_pic": vod_pic,
            "vod_content": vod_content,
            "vod_actor": vod_actor,
            "vod_director": vod_director,
            "vod_area": '',
            "vod_year": vod_year,
            "vod_remarks": vod_remarks,
            "vod_play_from": vod_play_from,
            "vod_play_url": vod_play_url
        }]
        return {"list": result}

    def searchContent(self, key, quick, pg="1"):
        page = int(pg) if pg else 1
        url = f"{self.site_url}/search/?wd={urllib.parse.quote(key)}"
        if page > 1:
            url += f"&page={page}"
        resp = self.fetch(url, headers=self.headers)
        if not resp:
            return {"list": [], "page": page, "pagecount": 1}
        soup = BeautifulSoup(resp.text, 'html.parser')
        video_list = []
        items = soup.select('a.module-poster-item')
        for a in items[:20]:
            href = a.get('href', '')
            if not href:
                continue
            vod_name = self._get_name(a)
            if not vod_name:
                continue
            video_list.append({
                "vod_id": href,
                "vod_name": vod_name,
                "vod_pic": self._get_pic(soup, a),
                "vod_remarks": self._get_remarks(a)
            })
        pagecount = 1
        page_block = soup.select_one('div#page')
        if page_block:
            page_links = page_block.select('a.page-link')
            nums = []
            for a_tag in page_links:
                text = a_tag.get_text(strip=True)
                if text.isdigit():
                    nums.append(int(text))
                elif '下页' in text or '下一页' in text:
                    nums.append(page + 1)
            if nums:
                pagecount = max(nums)
        return {"list": video_list, "page": page, "pagecount": pagecount}

    def playerContent(self, flag, id, vipFlags):
        url = id if id.startswith('http') else self.site_url + id
        return {"parse": 1, "url": url, "header": self.headers}