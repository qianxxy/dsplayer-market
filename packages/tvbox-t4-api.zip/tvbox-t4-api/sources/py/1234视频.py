import re
import time
import base64
import http.cookiejar
import urllib.parse
import urllib.request
import requests
from bs4 import BeautifulSoup
try:
    from base.spider import Spider as _BaseSpider
except ImportError:
    class _BaseSpider(object):
        pass

SUBCAT = {
    "A2xeflx0UY1tu": [
        ("国产剧", "A1zZRjN083yIX"), ("港台剧", "A1vocTi262A4n"),
        ("欧美剧", "A1d2UDP06Kv5I"), ("韩国剧", "A1ZHexk0TsGRb"),
        ("日本剧", "A1kY8ij34a2CF"), ("泰国剧", "A1gnJT41Wl9SP"),
        ("其他剧", "A1O1BCl3sXwad"),
    ],
    "A2mOC0y4HbZ3l": [
        ("喜剧", "A2idMlJ49C2tX"), ("动作", "A2esXVe1UdisF"),
        ("爱情", "A2M6PFL1tYL3U"), ("恐怖", "A2Tc3kf1UUB3F"),
        ("犯罪", "A2PrEV01jrfYy"), ("剧情", "A2756Eh1WkGKD"),
        ("奇幻", "A23KGz24Mz907"), ("战争", "A2Eakk12GoKEK"),
        ("悬疑", "A2ApvUM3iOu01"), ("动画", "A1s3nE31yzGaQ"),
        ("科幻", "A2ILZzg2dr1WD"), ("其他片", "A1oIxyO4EmwKm"),
    ],
    "A2ttqWI1YGgTu": [
        ("国漫", "A1KGLx64BWy5k"), ("日漫", "A1VWpi53ICCKJ"),
        ("其他动漫", "A1Rm0SQ3lvlSz"),
    ],
    "A2b7iFz0ozYru": [
        ("国产综艺", "A0xjOR80zha71"), ("港澳综艺", "A15F2wS3VQMBM"),
        ("日韩综艺", "A18zsC70g5g96"), ("其他综艺", "A1GVWhR1ONhYa"),
    ],
}

# 豆瓣图床防盗链：把请求头内联进封面 URL，交给图片代理带 Referer/UA 拉取。
PIC_REFERER = "https://api.douban.com/"
PIC_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
          "(KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36")
PIC_TAIL = "@Referer=" + PIC_REFERER + "@User-Agent=" + PIC_UA


class Spider(_BaseSpider):
    name = "1234视频"
    base_url = "https://www.1234sp.cc"
    timeout = 18
    UA_MOBILE = (
        "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) "
        "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 "
        "Mobile/15E148 Safari/604.1"
    )
    class_name = ["连续剧", "电影", "动漫", "综艺"]
    class_url = ["A2xeflx0UY1tu", "A2mOC0y4HbZ3l", "A2ttqWI1YGgTu", "A2b7iFz0ozYru"]
    page_size = 36
    PERMIT_COOKIE = "maccms_human_permit"
    _HEADERS = {
        "User-Agent": UA_MOBILE,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Accept-Encoding": "identity",
    }
    CLASSES = [{"type_id": u, "type_name": n} for n, u in zip(class_name, class_url)]
    FILTERS = {
        tid: [{"key": "子分类", "name": "分类",
               "value": [{"n": "全部", "v": tid}] + [{"n": n, "v": v} for n, v in SUBCAT.get(tid, [])]}]
        for tid in class_url
    }
    META_MAP = {"主演": "vod_actor", "导演": "vod_director", "类型": "vod_class", "状态": "vod_remarks"}
    _session = None
    _cookie_domain = ""

    def getName(self):
        return self.name

    def init(self, extend=""):
        host = urllib.parse.urlparse(self.base_url).netloc.split(":")[0].split(".")
        self._cookie_domain = "." + ".".join(host[-2:]) if len(host) >= 2 else host[0]
        if self._session is None:
            self._session = requests.Session()
            self._session.headers.update(self._HEADERS)

    def destroy(self):
        if self._session is not None:
            try:
                self._session.close()
            except Exception:
                pass

    def _get(self, url, referer=None):
        try:
            return self._session.get(url, headers={"Referer": referer or (self.base_url + "/")},
                                     timeout=self.timeout)
        except Exception:
            return None

    def _get_text(self, url):
        r = self._get(url)
        return r.text if r and r.status_code == 200 else None

    # ---------- 封面：绕过豆瓣防盗链 ----------
    @staticmethod
    def _fix_pic(url):
        if url and "doubanio.com" in url and "@Referer=" not in url:
            return url + PIC_TAIL
        return url

    # ---------- 人形验证（搜索会触发） ----------
    # 必须用独立 urllib opener + 独立 CookieJar 完成握手：站点校验 challenge 与本次
    # 请求上下文（连接/会话）绑定，复用主 session 直连会被 WAF 以 400 拒绝。
    def _solve_human_check(self, return_path):
        cj = http.cookiejar.CookieJar()
        opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
        opener.addheaders = [("User-Agent", self.UA_MOBILE),
                             ("Accept-Language", "zh-CN,zh;q=0.9")]
        ch_url = self.base_url + "/human-check?" + urllib.parse.urlencode({"return": return_path})
        try:
            ch_html = opener.open(urllib.request.Request(
                ch_url, headers={"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                                 "Referer": self.base_url + return_path}),
                timeout=self.timeout).read().decode("utf-8", "ignore")
        except Exception:
            return False
        m1 = re.search(r'name="challenge" value="([^"]+)"', ch_html)
        m2 = re.search(r'name="return" value="([^"]+)"', ch_html)
        if not m1 or not m2:
            return False
        try:
            opener.open(urllib.request.Request(
                self.base_url + "/human-check/verify",
                data=urllib.parse.urlencode({
                    "challenge": m1.group(1), "return": m2.group(1),
                    "duration_ms": "850", "move_points": "47", "final_percent": "100",
                    "pressed": "true", "released": "true",
                }).encode("utf-8"),
                method="POST",
                headers={**self._HEADERS,
                         "Content-Type": "application/x-www-form-urlencoded",
                         "Origin": self.base_url, "Referer": ch_url,
                         "Sec-Fetch-Site": "same-origin", "Sec-Fetch-Mode": "navigate",
                         "Sec-Fetch-Dest": "document", "Sec-Fetch-User": "?1",
                         "Upgrade-Insecure-Requests": "1"}),
                timeout=self.timeout).read()
        except Exception:
            return False
        permit = next((c for c in cj if c.name == self.PERMIT_COOKIE), None)
        if not permit:
            return False
        exp = permit.expires or (int(time.time()) + 7200)
        self._session.cookies.set(self.PERMIT_COOKIE, permit.value,
                                  domain=self._cookie_domain, path="/", expires=exp)
        return True

    # ---------- 列表解析 ----------
    CARD_RE = re.compile(
        r'<article class="pixel-card">\s*'
        r'<a class="pixel-card__link" href="/v/(?P<vid>[A-Za-z0-9]+)\.html"[^>]*?title="(?P<title>[^"]+)"'
        r'.*?<img src="(?P<pic>[^"]+)"[^>]*?>'
        r'.*?<span class="pixel-card__remark">(?P<remark>[^<]*)</span>',
        re.S,
    )

    def _parse_card_grid(self, html):
        return [{
            "vod_id": m.group("vid"),
            "vod_name": m.group("title"),
            "vod_pic": self._fix_pic(m.group("pic")),
            "vod_remarks": (m.group("remark") or "").strip(),
        } for m in self.CARD_RE.finditer(html or "")]

    def _parse_page_count(self, html):
        if not html:
            return 1
        nav = re.search(r'<nav class="pixel-pagination"[^>]*>(?P<body>.*?)</nav>', html, re.S)
        if not nav:
            return 1
        nums = [int(x) for x in re.findall(r'aria-label="第\s*(\d+)\s*页"', nav.group("body"))]
        return max(nums) if nums else 1

    def homeContent(self, filter=True):
        result = {"list": [], "class": [], "filters": {}}
        try:
            html = self._get_text(self.base_url + "/")
            if not html:
                return result
            hero = re.search(r'<div class="pixel-home__lead">(.*?)</div>\s*</section>', html, re.S)
            result["list"] = self._parse_card_grid(hero.group(1) if hero else html)[:30]
            result["class"] = self.CLASSES
            result["filters"] = self.FILTERS
        except Exception:
            pass
        return result

    def homeVideoContent(self):
        return self.homeContent()

    def categoryContent(self, tid, pg, filter=True, extend=None):
        page = int(pg) if str(pg).isdigit() else 1
        real_tid = (extend or {}).get("子分类") or tid   # 选了子分类则跳对应列表页，否则用主分类
        result = {"list": [], "page": page, "pagecount": 1, "limit": self.page_size, "total": 0}
        try:
            html = self._get_text(f"{self.base_url}/list/{real_tid}/{page}.html")
            if not html:
                return result
            result["list"] = self._parse_card_grid(html)
            total_pages = self._parse_page_count(html)
            result["pagecount"] = total_pages
            result["total"] = total_pages * self.page_size
        except Exception:
            pass
        return result

    def detailContent(self, ids):
        vid = ids[0] if isinstance(ids, (list, tuple)) and ids else ids
        html = self._get_text(f"{self.base_url}/v/{vid}.html")
        if not html:
            return {"list": []}
        soup = BeautifulSoup(html, "html.parser")

        vod = dict.fromkeys(("vod_id", "vod_name", "vod_pic", "vod_year", "vod_area",
                             "vod_class", "vod_remarks", "vod_director", "vod_actor",
                             "vod_content", "vod_play_from", "vod_play_url"), "")
        vod["vod_id"] = vid

        h1 = soup.find("h1")
        if h1:
            vod["vod_name"] = h1.get_text(strip=True)
        poster = soup.select_one(".pixel-detail__poster img")
        if poster:
            vod["vod_pic"] = self._fix_pic(poster.get("src", ""))

        # 主演/导演/类型/状态 直接映射；地区/年份 拆成两项
        for row in soup.select(".pixel-meta div"):
            dt, dd = row.find("dt"), row.find("dd")
            if not dt or not dd:
                continue
            k, v = dt.get_text(strip=True), dd.get_text(strip=True)
            if k in self.META_MAP:
                vod[self.META_MAP[k]] = v
            elif k in ("地区 / 年份", "地区/年份"):
                parts = [p.strip() for p in v.split("/") if p.strip()]
                if parts:
                    vod["vod_area"] = parts[0]
                if len(parts) > 1:
                    vod["vod_year"] = parts[-1]

        intro = soup.select_one("[data-vod-intro]")
        if intro:
            vod["vod_content"] = intro.get_text(strip=True)

        # 播放列表：每条线路 = (线路名, 集数拼接)
        lines = []
        playlist = soup.select_one("[data-playlist]")
        if playlist:
            panels = {p.get("data-playlist-panel"): p
                      for p in playlist.select("[data-playlist-panel]")}
            for tab in playlist.select("[data-playlist-tab]"):
                line_no = tab.get("data-playlist-tab")
                panel = panels.get(line_no)
                if not panel:
                    continue
                eps = [f"{a.get_text(strip=True)}${m.group(1)}|{m.group(2)}|{m.group(3)}"
                       for a in panel.select(".pixel-playlist__episodes a")
                       if (m := re.search(r"/p/([A-Za-z0-9]+)/(\d+)/(\d+)\.html", a.get("href", "")))]
                if eps:
                    lines.append((tab.get_text(strip=True) or f"线路{line_no}", "#".join(eps)))
        vod["vod_play_from"] = "$$$".join(n for n, _ in lines)
        vod["vod_play_url"] = "$$$".join(u for _, u in lines)
        return {"list": [vod]}

    def searchContent(self, key, quick=None, pg="1"):
        page = int(pg) if str(pg).isdigit() else 1
        bkey = base64.urlsafe_b64encode(str(key or "").encode("utf-8")).decode("ascii").rstrip("=")
        ret_path = f"/search/{bkey}/{page}.html"
        search_url = self.base_url + ret_path
        r = self._get(search_url)
        if r is None:
            return {"list": []}
        if r.status_code in (301, 302, 303, 307) or "/human-check" in r.url or "<title>访问验证" in r.text:
            if self._solve_human_check(ret_path):
                r = self._get(search_url)
                if r is None:
                    return {"list": []}
        return {"list": self._parse_card_grid(r.text)}

    def _fetch_play_iframe(self, vid, line, nid):
        r = self._get(f"{self.base_url}/p/{vid}/{line}/{nid}.html",
                      referer=f"{self.base_url}/v/{vid}.html")
        if r is None:
            return None
        m = re.search(r'<iframe[^>]+src="([^"]+)"', r.text)
        return m.group(1) if m else None

    @staticmethod
    def _extract_query_url(iframe_src):
        params = urllib.parse.parse_qs(urllib.parse.urlparse(iframe_src).query)
        return next((params[k][0] for k in ("url", "URL", "src") if params.get(k)), None)

    def playerContent(self, flag, id, vipFlags=None):
        parts = str(id).split("|")
        if len(parts) != 3:
            return {"parse": 0, "url": str(id), "header": {}}
        vid, line, nid = parts
        iframe = self._fetch_play_iframe(vid, line, nid)
        if not iframe:
            return {"parse": 0, "url": "", "header": {}}

        header = {"User-Agent": self.UA_MOBILE}
        play_url = None
        # Pattern A：player.html 走 /proxy 解出真实地址
        m_a = re.search(r"(https?://[^/\"']+)/(?:[a-z0-9]+/)?player\.html\?v=([a-f0-9]{16,64})", iframe)
        if m_a:
            try:
                data = requests.get(m_a.group(1) + "/proxy/" + m_a.group(2),
                                    headers={"User-Agent": self.UA_MOBILE,
                                             "Accept": "application/json", "Referer": iframe},
                                    timeout=self.timeout).json()
                if data.get("code") == 200 and data.get("url"):
                    play_url = data["url"].strip()
            except Exception:
                pass
        # Pattern B：iframe 内联 m3u8 直链
        if not play_url:
            play_url = self._extract_query_url(iframe)
        if play_url:
            return {"parse": 0, "url": play_url, "header": header}
        return {"parse": 1, "url": iframe, "header": header}
