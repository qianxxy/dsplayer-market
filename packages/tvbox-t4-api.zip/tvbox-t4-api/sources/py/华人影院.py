# -*- coding: utf-8 -*-
"""华人影院 huarw.com —— TVBox T4 源。

MacCMS 二改自定义路由站（配方见 tvbox-spider-dev 技能 references/maccms-custom-routes-huarw.md）：
  频道   /type/{dianying|dianshiju|zongyi|dongman|duanju}/page/N   （page/N 假分页）
  筛选   /search/{class|year|area|lang}/{值}/by/{time|hits|score}/page/N   （SSR 真翻页）
  详情   /movie/{id}
  播放   旧 /play/{vid}-{sid}-{nid}；新 /play/{vid}-{nid} + data-play-sid（Cookie 选线）
  搜索   /search/wd/{key}/page/N

解析要点（改版踩过的坑，勿删）：
  · 列表卡片三套 DOM（标准卡 / 搜索卡 / 置顶轮播 background-image），漏一套=「没有影片信息」
  · 新版集 href 两段且同集各线路 href 相同，线路号在 data-play-sid，须按 sid 归组，不可按 href 全局去重
  · player 需按单次请求带 Cookie mac_play_sid_{vid}={sid}，勿污染共享 headers
  · a 属性顺序/引号/换行会变：全属性解析，勿锚定固定排列
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
from html import unescape
from urllib.parse import parse_qs, quote, urlsplit

from core import settings
from core.base import VodDetailItem, VodHandler, VodItem, VodListResult
from core.cache import TTLCache
from core.http_client import HttpClient

# ── 本地搜索索引（/search/ 被 Cloudflare challenge 锁死, 用 /show/ 热度列表兜底）──
#  /show/ 是 CF 放行路径。定期抓取各分类热度+最新列表构建"标题→影片"索引,
#  search() 本地子串匹配, 规避 CF 对真实搜索端的强制 JS challenge。
_INDEX_FILE = "/tmp/huarw_index.json"
_INDEX_TTL = 21600          # 索引新鲜期 6h
_index_store = {"lock": threading.Lock(), "built": 0.0}


def _index_clean(s):
    return _HTML_TAG.sub("", re.sub(r"\s*封面图$", "", re.sub(r"\s+", " ", s or ""))).strip()


def _index_cards(html):
    out = []
    for attrs, body in re.findall(r"<a\b([^>]*)>(.*?)</a>", html, re.S | re.I):
        m = re.search(r'href="/movie/(\d+)"', attrs)
        if not m:
            continue
        nm = (re.search(r"<h3>\s*<a[^>]*>([^<]+)</a>", body)
              or re.search(r'title="([^"]+)"', attrs)
              or re.search(r'alt="([^"]+?)封面图"', body))
        t = _index_clean(nm.group(1)) if nm else ""
        if not t:
            continue
        pic = re.search(r'data-src="(//[^"]+|https?://[^"]+)"', body)
        p = pic.group(1) if pic else ""
        if p.startswith("//"):
            p = "https:" + p
        rm = re.search(r"public-list-prb[^>]*>\s*([^<]+?)\s*<", body)
        out.append({"id": m.group(1), "n": t, "p": p,
                    "r": _index_clean(rm.group(1)) if rm else ""})
    return out


def _build_index():
    """后台并发抓 /show/{顶层分类}/by/{hits|time} 前若干页 → 标题索引。"""
    import hashlib
    key = "huarw:" + hashlib.md5(_HOST.encode()).hexdigest()[:10]
    now = time.time()
    store = _index_store
    # 内存命中且未过期
    if store["built"] and now - store["built"] < _INDEX_TTL:
        return
    # 磁盘命中且未过期
    if os.path.exists(_INDEX_FILE) and now - os.path.getmtime(_INDEX_FILE) < _INDEX_TTL:
        try:
            with open(_INDEX_FILE, "r", encoding="utf-8") as f:
                j = json.load(f)
            if isinstance(j, dict) and j.get("list"):
                store["built"] = now
                return
        except Exception:
            pass
    # 并发抓取
    from concurrent.futures import ThreadPoolExecutor
    idx = {}
    UAST = {
        "User-Agent": _UA, "Accept-Language": "zh-CN,zh;q=0.9",
        "Referer": _HOST + "/"}
    urls = [_HOST + "/show/{c}/by/{by}/page/{pg}".format(c=c, by=by, pg=pg)
            for c in ("dianying", "dianshiju", "zongyi", "dongman", "duanju")
            for by in ("hits", "time")
            for pg in range(1, 11)]

    def _fetch(u):
        try:
            import urllib.request as _u
            import ssl as _ssl
            ctx = _ssl._create_unverified_context()
            req = _u.Request(u, headers=UAST)
            return _u.urlopen(req, timeout=15, context=ctx).read().decode("utf-8", "ignore")
        except Exception:
            return ""

    with ThreadPoolExecutor(max_workers=6) as ex:
        for html in ex.map(_fetch, urls):
            for it in _index_cards(html):
                if it["id"] not in idx:
                    idx[it["id"]] = it
    # 持久化
    try:
        with open(_INDEX_FILE, "w", encoding="utf-8") as f:
            json.dump({"t": time.time(), "list": list(idx.values())}, f, ensure_ascii=False)
    except Exception:
        pass
    store["built"] = now


def _load_index():
    """返回 标题→卡片 列表(可能为空)。"""
    if os.path.exists(_INDEX_FILE) and time.time() - os.path.getmtime(_INDEX_FILE) < _INDEX_TTL:
        try:
            with open(_INDEX_FILE, "r", encoding="utf-8") as f:
                return (json.load(f) or {}).get("list", []) or []
        except Exception:
            return []
    return []

_HOST = "https://huarw.com"
_UA = (
    "Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 "
    "Chrome/150.0.0.0 Mobile Safari/537.36"
)
_HTML_TAG = re.compile(r"<[^>]+>")

_UNITS = {"dianying": "电影", "dianshiju": "电视剧", "zongyi": "综艺", "dongman": "动漫", "duanju": "短剧"}
_CLASS_MAP = {
    "dianying": ["喜剧片", "动作片", "剧情片", "爱情片", "科幻片", "恐怖片", "动画片", "战争片"],
    "dianshiju": ["国产剧", "欧美剧", "日本剧", "韩国剧", "海外剧"],
}
# /show/{拼音子分类} 走 CF 放行路径(避开被 CF JS challenge 拦截的 /search/)
_CLASS_PY = {
    "dianying": {"喜剧片": "xijupian", "动作片": "dongzuopian", "剧情片": "juqingpian",
                 "爱情片": "aiqingpian", "科幻片": "kehuanpian", "恐怖片": "kongbupian",
                 "动画片": "donghuapian", "战争片": "zhanzhengpian"},
    "dianshiju": {"国产剧": "guochangju", "欧美剧": "oumeiju", "日本剧": "ribenju",
                  "韩国剧": "hanguoju", "海外剧": "haiwaiju"},
}
_YEARS = ["2026", "2025", "2024", "2023", "2022", "2021", "2020", "2019", "2018"]
_AREAS = ["大陆", "香港", "台湾", "美国", "法国", "英国", "日本", "韩国", "泰国", "印度", "其他"]
_AREAS_TV = ["大陆", "香港", "台湾", "美国", "日本", "韩国", "泰国", "其他"]
_ARTS = ["大陆", "日本", "欧美"]
_LANGS = ["国语", "英语", "粤语", "韩语", "日语"]


def _strip_tags(s: str) -> str:
    return _HTML_TAG.sub("", s or "").strip()


class Huarw(VodHandler):
    source_name = "huarw"
    display_name = "华人影院"

    HOST = "https://huarw.com"
    UA = _UA
    MIN_INTERVAL = 0.3  # 站点无 CF 重挑战，但翻页快了偶尔空响应

    _RE_PLAY_HREF = re.compile(r"/play/(\d+)-(\d+)(?:-(\d+))?/?")

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._last_hit = 0.0
        self._http = self._new_http()
        self._cache = TTLCache(1800)

    # ── HTTP（框架公开接口 only：get/close；换会话=重建实例）────────────

    def _new_http(self, extra_headers: dict | None = None) -> object:
        headers = {
            "User-Agent": self.UA,
            "Accept": "text/html,application/xhtml+xml,*/*;q=0.9",
            "Accept-Language": "zh-CN,zh;q=0.9",
            "Referer": self.HOST + "/",
        }
        headers.update(extra_headers or {})
        return HttpClient(
            headers=headers,
            timeout=settings.HTTP_TIMEOUT,
            doh_url=settings.DOH_URL if settings.USE_DOH else None,
            proxy=settings.HTTP_PROXY or None,
        )

    def _throttle(self) -> None:
        if self.MIN_INTERVAL <= 0:
            return
        with self._lock:
            wait = self.MIN_INTERVAL - (time.monotonic() - self._last_hit)
            if wait > 0:
                time.sleep(wait)
            self._last_hit = time.monotonic()

    def _get(self, url: str, extra_headers: dict | None = None, fresh: bool = False) -> str:
        """取页面。fresh=True 用一次性会话（Cookie 选线场景，避免串线路）。"""
        self._throttle()
        http = self._new_http(extra_headers) if fresh else self._http
        try:
            html = http.get(url, extra_headers=extra_headers if not fresh else None)
        except Exception:
            html = ""
        if not fresh and not html:
            # 失败恢复：close 旧实例再重建（框架无 reset_session）
            try:
                self._http.close()
            except Exception:
                pass
            self._http = self._new_http()
            self._throttle()
            try:
                html = self._http.get(url)
            except Exception:
                html = ""
        elif fresh:
            try:
                http.close()
            except Exception:
                pass
        return html or ""

    # ── 通用解析 ────────────────────────────────────────────────────────

    @staticmethod
    def _absolute(url: str) -> str:
        url = (url or "").strip().strip("'\"")
        if url.startswith("//"):
            return "https:" + url
        if url.startswith("/"):
            return _HOST + url
        return url

    def _attrs(self, tag_attrs: str) -> dict:
        return {
            k.lower(): v.replace("&nbsp;", " ")
            for k, _, v in re.findall(r'([\w-]+)\s*=\s*(["\'])(.*?)\2', tag_attrs, re.S)
        }

    def _cards(self, html: str) -> list[dict]:
        if not html:
            return []
        items, seen = [], set()
        for attrs, body in re.findall(r"<a\b([^>]*)>(.*?)</a>", html, re.S | re.I):
            a = self._attrs(attrs)
            m = re.match(r"/movie/(\d+)/?$", a.get("href", "").strip())
            if not m:
                continue
            mid = m.group(1)
            if mid in seen:
                continue
            # 标题：h3>a / title / alt 封面图 / 轮播 slide-info-title
            nm = (re.search(r"<h3>\s*<a[^>]*>([^<]+)</a>", body)
                  or re.search(r'title="([^"]+)"', attrs)
                  or re.search(r'alt="([^"]+?)封面图"', body)
                  or re.search(r'class="slide-info-title[^"]*">([^<]+)<', body))
            title = _strip_tags(nm.group(1)) if nm else ""
            if not title or title == mid:
                continue
            pc = (re.search(r'data-src="(//[^"]+|https?://[^"]+)"', body)
                  or re.search(r'cdn-data-src="(//[^"]+|https?://[^"]+)"', body)
                  or re.search(r"""background-image:\s*url\(['"]([^'"]+)['"]\)""", body))
            rm = re.search(r"public-list-prb[^>]*>\s*([^<]+?)\s*<", body)
            seen.add(mid)
            items.append(VodItem(
                vod_id=mid,
                vod_name=title,
                vod_pic=self._absolute(pc.group(1)) if pc else "",
                vod_remarks=_strip_tags(rm.group(1)) if rm else "",
            ).to_dict())
        return items

    # ── T4 契约 ─────────────────────────────────────────────────────────

    def home(self) -> dict:
        classes = [{"type_id": k, "type_name": v} for k, v in _UNITS.items()]
        cards = self._cards(self._get(_HOST + "/type/dianying"))[:24]
        filters = {}
        for tid in _UNITS:
            flt = [{"key": "class", "name": "分类", "value":
                    [{"n": "全部", "v": ""}] + [{"n": c, "v": c} for c in _CLASS_MAP.get(tid, [])]}]
            flt.append({"key": "year", "name": "年份",
                        "value": [{"n": "全部", "v": ""}] + [{"n": y, "v": y} for y in _YEARS]})
            ar = _ARTS if tid == "dongman" else (_AREAS_TV if tid != "dianying" else _AREAS)
            flt.append({"key": "area", "name": "地区",
                        "value": [{"n": "全部", "v": ""}] + [{"n": a, "v": a} for a in ar]})
            flt.append({"key": "lang", "name": "语言",
                        "value": [{"n": "全部", "v": ""}] + [{"n": l, "v": l} for l in _LANGS]})
            flt.append({"key": "by", "name": "排序", "value": [
                {"n": "最新", "v": "time"}, {"n": "最热", "v": "hits"}, {"n": "评分", "v": "score"}]})
            filters[tid] = flt
        return {"class": classes, "filters": filters, "list": cards[:24]}

    def category(self, type_id: str, page: str, ext: str = "") -> dict:
        pg = self.safe_int(page)
        ext = self._decode_ext(ext)
        # 有 class 筛选 -> /show/{拼音子分类};否则 /show/{顶层分类}
        cls_name = ext.get("class")
        py = _CLASS_PY.get(str(type_id), {}).get(cls_name, "") if cls_name else ""
        path = ("/show/%s" % py) if py else ("/show/%s" % str(type_id))
        # 追加筛选段 year/area/lang + by 排序 + page(/show/ 是真分页,避 CF)
        for k in ("year", "area", "lang"):
            if ext.get(k):
                path += "/%s/%s" % (k, _quote(str(ext[k])))
        if ext.get("by"):
            path += "/by/%s" % ext["by"]
        path += "/page/%d" % pg
        cards = self._cards(self._get(_HOST + path))
        pagecount = pg if len(cards) < 20 else pg + 1
        total = pg * 20
        return VodListResult(list=cards, page=pg, pagecount=pagecount,
                             limit=20, total=total).to_dict()

    def detail(self, ids: str) -> dict:
        mid = str(ids).split(",")[0].split("?")[0].strip()
        html = self._get("%s/movie/%s" % (_HOST, mid))
        vod = {
            "vod_id": mid, "vod_name": mid, "vod_pic": "", "vod_year": "",
            "vod_content": "", "vod_actor": "", "vod_director": "",
            "vod_remarks": "",
        }
        try:
            nm = re.search(r'<h1 class="seo-h1">([^<]+)</h1>', html)
            if nm:
                vod["vod_name"] = nm.group(1).strip()
            pc = re.search(r'(?:data-src|src)="(//[^"]+|https?://[^"]+/upload/vod/[^"]+)"', html)
            if pc:
                vod["vod_pic"] = self._absolute(pc.group(1))
            yr = re.search(r'href="/show/[^"]*?year/(\d{4})"', html)
            if yr:
                vod["vod_year"] = yr.group(1)
            ar = re.search(r'href="/show/[^"]*?area/([^"]+)"', html)
            if ar:
                vod["vod_remarks"] = (vod.get("vod_remarks", "") + " " + _unquote(ar.group(1))).strip()
            cl = re.search(r'href="/show/\d+/class/([^"]+)"', html)
            if cl:
                vod["vod_remarks"] = (vod.get("vod_remarks", "") + " " + _unquote(cl.group(1))).strip()
            rm = re.search(r"备注\s*:\s*([^<]{1,24})", html)
            if rm:
                vod["vod_remarks"] = rm.group(1).strip()
            dr = re.search(r"导演\s*:\s*([^/]{1,60})/", html)
            if dr:
                vod["vod_director"] = dr.group(1).strip()
            ac = re.search(r"演员\s*:\s*([^<]{1,200})", html)
            if ac:
                vod["vod_actor"] = ac.group(1).strip()
            de = re.search(r'id="height_limit"[^>]*>([^<]{10,2000})<', html)
            if de:
                vod["vod_content"] = de.group(1).strip()
            else:
                ld = re.search(r'"description"\s*:\s*"([^"]{10,2000})"', html)
                if ld:
                    vod["vod_content"] = ld.group(1)
        except Exception:
            pass

        # 线路 tab 名（锚定 badge，勿抓裸 swiper-slide——首页轮播同名类会混入）
        tabs = []
        for attrs, body in re.findall(r"<a\b([^>]*)>(.*?)</a>", html, re.S | re.I):
            if "swiper-slide" not in attrs or not re.search(r'class="[^"]*\bbadge\b', body):
                continue
            body = re.sub(r"<span\b[^>]*>.*?</span>", "", body, flags=re.S | re.I)
            label = _strip_tags(body.replace("&nbsp;", " "))
            if label:
                tabs.append(label)

        # 集数：按 data-play-sid（新）或 href 第三段（旧）归组；同一集各线路 href 相同
        lines: dict[str, list[tuple[str, str]]] = {}
        order: list[str] = []
        for attrs, body in re.findall(r"<a\b([^>]*)>(.*?)</a>", html, re.S | re.I):
            a = self._attrs(attrs)
            m = self._RE_PLAY_HREF.fullmatch(a.get("href", "").strip().split("?")[0])
            if not m:
                continue
            vid, second, third = m.groups()
            if third:
                sid, nid, pid = second, third, "%s-%s-%s" % (vid, second, third)
            else:
                sid = a.get("data-play-sid", "")
                if not sid.isdigit():
                    continue
                nid, pid = second, "%s-%s?sid=%s" % (vid, second, sid)
            name = a.get("data-play-name") or _strip_tags(body) or ("第%s集" % (third or nid))
            name = name.replace("$", "＄").replace("#", "＃")
            if sid not in lines:
                lines[sid] = []
                order.append(sid)
            lines[sid].append((name, pid))   # (集名, 播放ID)：player 收 $ 后段

        play_from, play_url = self._build_play({
            (tabs[i] if i < len(tabs) else ("线路%s" % (i + 1))): lines[sid]
            for i, sid in enumerate(order)
        })
        vod.update({
            "vod_play_from": play_from,
            "vod_play_url": play_url,
        })
        return {"list": [VodDetailItem(**vod).to_dict()]}

    def search(self, keyword: str, page: str, ext: str = "") -> dict:
        keyword = (keyword or "").strip()
        if not keyword:
            return VodListResult().to_dict()
        pg = self.safe_int(page)
        # /search/wd/ 被 Cloudflare challenge 强保护(数据中心 IP 无法绕过)。
        # 改用本地索引: 从 /show/ 热度/最新列表构建"标题→影片",本地子串匹配。
        # 首次搜索触发后台构建(磁盘持久化 /tmp/huarw_index.json, 6h 刷新)。
        try:
            threading.Thread(target=_build_index, daemon=True).start()
        except Exception:
            pass
        idx = _load_index()
        if not idx:
            # 索引未就绪 → 返回空(不冒充首页;构建约12s,随后磁盘命中秒回)
            return VodListResult(list=[], page=pg, pagecount=1,
                                 limit=20, total=0).to_dict()
        kw = keyword.lower()
        mat = [c for c in idx if kw in c["n"].lower() or kw in c["n"]]
        # 按标题契合度排序: 前缀>包含
        def _rank(c):
            n = c["n"]
            return (0 if n.lower().startswith(kw) else 1)
        mat.sort(key=_rank)
        cards = []
        for c in mat[:40]:
            cards.append(VodItem(
                vod_id=c["id"], vod_name=c["n"], vod_pic=c.get("p", ""),
                vod_remarks=c.get("r", ""),
            ).to_dict())
        return VodListResult(list=cards, page=pg,
                             pagecount=1 if len(cards) < 40 else pg + 1,
                             limit=20, total=len(cards)).to_dict()

    def player(self, flag: str, play_url: str) -> dict:
        play_url = (play_url or "").strip()
        if not play_url:
            return {"parse": 0, "url": "", "header": {}}
        parts = _urlsplit(play_url)
        pid = parts.path
        headers = {"Referer": _HOST + "/"}
        sid = parse_qs(parts.query).get("sid", [""])[0]
        fresh = False
        if re.fullmatch(r"\d+-\d+", pid) and sid.isdigit():
            # 新路由：线路由 Cookie 选择，须一次性会话防止串线
            headers["Cookie"] = "mac_play_sid_%s=%s" % (pid.split("-")[0], sid)
            fresh = True
        html = self._get(_HOST + "/play/" + pid, extra_headers=headers, fresh=fresh)
        url = ""
        try:
            m = re.search(r"var\s+player_aaaa\s*=\s*(\{.*?\})\s*;?\s*</script>", html, re.S)
            if m:
                d = _json_loads(re.sub(r",(\s*[}\]])", r"\1", m.group(1)))
                url = str(d.get("url") or "")
                want = d.get("sid")
                if fresh and str(want) != sid:      # Cookie 未生效，返回的是别的线路
                    url = ""
        except Exception:
            pass
        if not url:
            fm = re.search(r"""(https?://[^\s"'<>\\]+\.m3u8[^\s"'<>\\]*)""", html)
            url = fm.group(1) if fm else ""
        if not url:
            return {"parse": 1, "url": _HOST + "/play/" + pid, "header": {"Referer": _HOST + "/"}}
        return {"parse": 0, "url": url, "header": {"Referer": _HOST + "/", "User-Agent": self.UA}}

    # ── 诊断 ────────────────────────────────────────────────────────────

    def diag_urls(self) -> list[str]:
        return [
            _HOST + "/",
            _HOST + "/type/dianshiju",
            _HOST + "/movie/242463",
            _HOST + "/search/wd/" + _quote("仙台有树"),
        ]

    # ── 内部小工具 ──────────────────────────────────────────────────────

    @staticmethod
    def _decode_ext(ext: str) -> dict:
        import base64
        import json as _json
        if not ext or ext in ("{}", "null"):
            return {}
        try:
            raw = _json.loads(ext)
            return {str(k): str(v) for k, v in raw.items()}
        except Exception:
            pass
        s = ext.replace("-", "+").replace("_", "/")
        while len(s) % 4:
            s += "="
        try:
            return _json.loads(base64.b64decode(s))
        except Exception:
            return {}

    @staticmethod
    def _build_play(episodes: dict) -> tuple[str, str]:
        """{线路名: [(集名, 地址), ...]} → (vod_play_from, vod_play_url)。段数恒一致。"""
        froms, urls = [], []
        for name, eps in episodes.items():
            eps = [(e.strip(), u.split("#")[0].strip()) for e, u in eps if e and u]
            if not eps:
                continue
            froms.append(name.replace("$", "＄").replace("#", "＃"))
            urls.append("#".join("%s$%s" % (e, u) for e, u in eps))
        return "$$$".join(froms), "$$$".join(urls)


# 模块级小工具（类里引用，便于静态检查）
from json import loads as _json_loads  # noqa: E402
from urllib.parse import parse_qs, quote as _quote, unquote as _unquote, urlsplit as _urlsplit  # noqa: E402
