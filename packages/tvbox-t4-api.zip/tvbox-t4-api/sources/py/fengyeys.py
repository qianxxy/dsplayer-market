# -*- coding: utf-8 -*-
"""枫叶影院公开网页源的 TVBox T4 适配。"""
from __future__ import annotations
import json, re, urllib.parse
from datetime import datetime
from bs4 import BeautifulSoup
from curl_cffi import requests
from core.base import VodHandler

class FengYe(VodHandler):
    source_name = "fengyeys"
    display_name = "枫叶影院"
    HOSTS = ["https://www.cd-zj.com", "https://maihaolian.com", "https://zzztool.com"]
    HOST = "https://www.cd-zj.com"
    UA = "Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 Chrome/150.0.0.0 Mobile Safari/537.36"
    PARSERS = {"YYNB":"https://zzrs.mfdyvip.com", "JD4K":"https://fgsrg.hzqingshan.com", "JD":"https://fgsrg.hzqingshan.com", "co":"https://zzrs.mfdyvip.com", "knmb":"https://zzrs.mfdyvip.com"}
    def __init__(self):
        self.host = self.HOSTS[0]
        self.session = requests.Session(impersonate="chrome", timeout=20)
        self.session.headers.update({"User-Agent":self.UA,"Accept-Language":"zh-CN,zh;q=0.9"})
    def init(self, extend=""):
        try:
            e=json.loads(extend) if isinstance(extend,str) and extend else (extend or {})
            if isinstance(e,dict) and e.get("host"): self.host=str(e["host"]).rstrip("/")
        except Exception: pass
    def _get(self, path, referer=None):
        url=path if str(path).startswith("http") else self.host+path
        try:
            r=self.session.get(url,headers={"Referer":referer or self.host+"/"},timeout=20,verify=False)
            if "系统安全验证" in r.text or "captcha.php?type=code" in r.text:
                self._auto_verify()
                r=self.session.get(url,headers={"Referer":referer or self.host+"/"},timeout=20,verify=False)
            return r.text
        except Exception: return ""
    OCR_HOSTS=["https://py.fzcrym.link:1314","http://192.168.0.158:7800","http://127.0.0.1:7800"]
    def _auto_verify(self):
        mapping={'0':'oO','1':'lLiI','2':'zZ','5':'sS','8':'bB','6':'gG','3':'eE','9':'gGqQ','4':'aA','7':'tT'}
        try:
            for attempt in range(6):
                r=self.session.get(self.host+f"/captcha.php?type=code&r=0.{attempt}",timeout=15,verify=False)
                if r.status_code!=200:continue
                codes=[]
                for ocr in self.OCR_HOSTS:
                    try:
                        j=requests.post(ocr+"/fyocr",data=r.content,timeout=12,verify=False).json()
                        if j.get("code")==1 and j.get("codes"): codes=j["codes"]; break
                    except Exception:continue
                if not codes:continue
                for code in codes:
                    if not (4<=len(code)<=6):continue
                    variants={code,code.lower(),code.upper()}
                    for ch,reps in mapping.items():
                        if ch in code:
                            for rp in reps: variants.add(code.replace(ch,rp))
                    for v in variants:
                        if len(v)!=len(code):continue
                        try:
                            r2=self.session.post(self.host+"/captcha.php?type=verify",data={"check":v},headers={"X-Requested-With":"XMLHttpRequest"},timeout=15,verify=False)
                            if '"code":1' in r2.text or "验证成功" in r2.text: return True
                        except Exception:continue
                import time; time.sleep(1)
        except Exception:pass
        return False
    def _post(self,url,data,referer=None):
        try:
            r=self.session.post(url,data=data,headers={"Referer":referer or self.host+"/","X-Requested-With":"XMLHttpRequest"},timeout=20,verify=False)
            return r
        except Exception: return None
    @staticmethod
    def _pic(u):
        if not u:return ""
        if u.startswith("//"):return "https:"+u
        return u.replace("&amp;","&")
    @staticmethod
    def _text(x): return re.sub(r"<[^>]+>"," ",x or "").replace("\xa0"," ").strip()
    def _cards(self,html,search=False):
        if not html:return []
        s=BeautifulSoup(html,"html.parser"); out=[]; seen=set(); z="zzztool" in self.host
        cards=s.select(".module-item") if z else (s.select(".public-list-box") if search else s.select("a.public-list-exp"))
        for el in cards:
            try:
                a=el.select_one("a") if z else (el if el.name=="a" else el.select_one("a.public-list-exp"))
                if not a:continue
                href=a.get("href",""); m=re.search(r"/detail/(\d+)\.html",href)
                if not m:continue
                vid=m.group(1)
                if vid in seen:continue
                title=(el.select_one(".thumb-txt a") or el.select_one(".module-card-item-title strong") or el.select_one("h3") or a).get_text(" ",strip=True)
                if not title:title=a.get("title","").strip()
                img=el.select_one("img"); pic=self._pic((img.get("data-src") or img.get("src") or "") if img else "")
                rm=el.select_one(".public-list-prb,.ft2,.module-item-note")
                seen.add(vid); out.append({"vod_id":vid,"vod_name":title,"vod_pic":pic,"vod_remarks":rm.get_text(" ",strip=True) if rm else ""})
            except Exception:continue
        return out
    def _filters(self):
        years=[{"n":"全部","v":""}]+[{"n":str(y),"v":str(y)} for y in range(datetime.now().year,datetime.now().year-23,-1)]
        area=[{"n":x,"v":x} for x in ["全部","大陆","香港","台湾","美国","韩国","日本","泰国","英国","法国","其它"]]
        return {k:[{"key":"area","name":"地区","value":area},{"key":"year","name":"年份","value":years},{"key":"sort","name":"排序","value":[{"n":"时间","v":"time"},{"n":"人气","v":"hits"},{"n":"评分","v":"score"}]}] for k in ["1","2","3","4","5"]}
    def home(self):
        cats=[{"type_id":"/label/qq","type_name":"腾讯VIP精选"},{"type_id":"/label/bli","type_name":"B站VIP精选"},{"type_id":"/label/youku","type_name":"优酷VIP精选"},{"type_id":"2","type_name":"电视剧"},{"type_id":"1","type_name":"电影"},{"type_id":"4","type_name":"动漫"},{"type_id":"3","type_name":"综艺"},{"type_id":"5","type_name":"热门短剧"}]
        return {"class":cats,"filters":self._filters(),"list":self._cards(self._get("/"),True)[:24]}
    def category(self,type_id,page,ext=""):
        try: pg=max(1,int(page)); e=json.loads(ext) if isinstance(ext,str) and ext.startswith("{") else (ext or {})
        except Exception: pg=1;e={}
        if not isinstance(e,dict):e={}
        tid=str(type_id); pre="list" if "zzztool" in self.host else "cupfox-list"
        if tid.startswith("/label"): path=f"{tid}/page/{pg}.html"
        else:
            area=e.get("area",""); year=e.get("year",""); sort=e.get("sort","")
            path=f"/{pre}/{e.get('class',tid)}-{area}-{sort}---{pg}---{year}.html" if any((area,year,sort)) else f"/{pre}/{tid}--------{pg}---.html"
        lst=self._cards(self._get(path)); return {"list":lst,"page":pg,"pagecount":pg+1 if len(lst)>=20 else pg,"limit":len(lst) or 36,"total":9999 if lst else 0}
    def detail(self,ids):
        vid=str(ids).split(",")[0]; h=self._get(f"/detail/{vid}.html"); s=BeautifulSoup(h,"html.parser")
        name=(s.select_one("h3.slide-info-title") or s.select_one(".module-info-heading h1")); img=s.select_one("img.lazy,.module-item-pic img")
        lines=[]; urls=[]
        # 提取线路名: .swiper-slide 文本, 如 "至臻4k (169)" -> "至臻4k"
        tab_names=[re.sub(r"\s*\(\s*\d+\s*\)\s*$","",a.get_text(' ',strip=True)).strip()
                   for a in s.select(".swiper-slide")]
        panels=s.select(".anthology-list-box,.mx-anthology-panel")
        groups=[]
        for block in panels:
            eps=[]
            for a in block.select("a"):
                href=a.get("href",""); m=re.search(r"/play/(.*?)\.html",href)
                if m:eps.append(f"{a.get_text(' ',strip=True)}${vid}-{m.group(1)}")
            if eps: groups.append(eps)
        # 若线路名与选集容器一一对应, 用名称; 否则退化为 线路N
        if len(tab_names)==len(groups):
            named=[(n,e) for n,e in zip(tab_names,groups)]
            # 至臻4K/4K 线路排第一
            named.sort(key=lambda x: 0 if ("至臻" in x[0] or "4k" in x[0].lower() or "4K" in x[0]) else 1)
        else:
            named=[(f"线路{i+1}",e) for i,e in enumerate(groups)]
        for n,eps in named:
            lines.append(n); urls.append("#".join(reversed(eps)))
        return {"list":[{"vod_id":vid,"vod_name":name.get_text(' ',strip=True) if name else vid,"vod_pic":self._pic(img.get('data-src') or img.get('src','')) if img else "","vod_content":(s.select_one('#height_limit') or s.select_one('.module-info-introduction-content')).get_text(' ',strip=True) if (s.select_one('#height_limit') or s.select_one('.module-info-introduction-content')) else "","vod_play_from":"$$$".join(lines),"vod_play_url":"$$$".join(urls)}]}
    def search(self,keyword,page,ext=""):
        pg=max(1,int(page or 1)); q=urllib.parse.quote(str(keyword)); h=self._get(f"/cupfox-search/{q}----------{pg}---.html"); lst=self._cards(h,True)
        return {"list":lst,"page":pg,"pagecount":pg+1 if len(lst)>=20 else pg,"limit":20,"total":len(lst)}
    def _resolve(self, token, line):
        base=self.PARSERS.get(line) or self.PARSERS.get("JD4K")
        try:
            q=urllib.parse.quote(str(token),safe="")
            r=self.session.get(base+"/player/?url="+q,headers={"Referer":self.host+"/"},timeout=20,verify=False)
            mt=re.search(r'data-te="([^"]+)"',r.text)
            if not mt:
                mt=re.search(r'data-te=\'([^\']+)\'',r.text)
            if not mt:return ""
            r2=self.session.post(base+"/player/mplayer.php",data={"url":token,"token":mt.group(1)},headers={"Referer":self.host+"/","Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"},timeout=20,verify=False)
            j=r2.json(); u=str(j.get("url") or "")
            return base+u if u.startswith("/") else u
        except Exception:return ""
    def player(self,flag,play_url):
        p=str(play_url or ""); path=p.split("$",1)[-1] if "$" in p else p
        if path.startswith("http") and re.search(r"\.(m3u8|mp4)(\?|$)",path):return {"parse":0,"url":path,"header":{"User-Agent":self.UA,"Referer":self.host+"/"}}
        page=path if path.startswith("http") else self.host+"/play/"+path+".html"
        h=self._get(page); m=re.search(r"player_aaaa\s*=\s*(\{.*?\})\s*</script>",h,re.S)
        video=""; line=flag or ""
        if m:
            try:
                d=json.loads(m.group(1)); video=str(d.get("url") or ""); line=str(d.get("from") or line)
            except Exception:pass
        if video and not video.startswith("http"):
            u=self._resolve(video,line)
            if u:return {"parse":0,"url":u,"header":{"User-Agent":self.UA,"Referer":self.host+"/"}}
        if video and re.search(r"\.(m3u8|mp4)(\?|$)",video):return {"parse":0,"url":video,"header":{"User-Agent":self.UA,"Referer":self.host+"/"}}
        mm=re.search(r"https?://[^\s\"']+\.m3u8[^\s\"']*",h); video=mm.group(0) if mm else ""
        if video:return {"parse":0,"url":video,"header":{"User-Agent":self.UA,"Referer":self.host+"/"}}
        return {"parse":1,"url":page,"header":{"User-Agent":self.UA,"Referer":self.host+"/"}}
    def diag_urls(self): return [self.host+"/",self.host+"/cupfox-list/1--------1---.html",self.host+"/detail/20067.html",self.host+"/cupfox-search/流浪地球----------1---.html"]
