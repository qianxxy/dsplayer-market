# -*- coding: utf-8 -*-
"""短剧库（juku）聚合源 —— 红果 / 黄果 / 黄豆

数据全部来自手机上的「短剧库」服务（juku，默认 http://127.0.0.1:8998）的 HTTP API。
本脚本**不做任何站点解析**：剧库、榜单、搜索、分集、播放直链都由服务端给出。

分类结构：
    红果 / 黄果 / 黄豆   每个分类带「榜单」「题材」两个筛选器（榜单走 rankings，题材按剧库字段过滤）
    剧库工具            4 张「动作卡片」：点一下直接执行、弹结果，不跳详情页
                        （剧库统计 / 更新剧库 / 追剧清单 / 下载任务）

账号：内置在下方 JUKU_USER / JUKU_PASS，脚本启动即自动登录（JUKU_AUTO_LOGIN），掉登录自动重登，
      全程不需要人工参与，界面上没有登录入口（纯后台保活；服务端哪天重新要求登录它能自愈）。
      播放直链走 /api/emby/ 的 token 地址（免 cookie 可播），登录只影响导出/追剧/任务这类接口。

实测契约（2026-09-20 对手机 192.168.0.5:8998 验证通过）：
    GET  /api/ui/viewer                 第 1 次只下发 Cookie（{ready:false}），再调一次才给 id
    GET  /api/ui/dramas[?revision=0]    剧库快照 {data,total,hasMore,loading,loadingSource,revision}
    GET  /api/ui/rankings?board=&page=  榜单 {items:[{rank,drama}]}
    GET  /api/ui/search?q=              联网搜索红果 {data,total,limited,saved,warning}
    POST /api/ui/account/login          {username,password}，必须带 X-Juku-Viewer 头
    POST /api/emby/export               {dramaId,baseUrl} → zip，内含 Season 01/S01E0NN.strm
                                        每个 .strm 就是一条带 token 的 m3u8 直链（免 cookie 播放）
    请求头：X-Juku-Viewer / X-Juku-Sources / X-Juku-Online-Only
"""
import base64
import io
import json
import re
import sys
import threading
import time
import traceback
import zipfile
from collections import Counter
from urllib.parse import quote

import requests

sys.path.append("..")
try:
    from base.spider import Spider
except ImportError:
    class Spider:
        pass


# ── 可调配置 ────────────────────────────────────────────────────────────
JUKU_HOSTS = ("http://127.0.0.1:8998", "http://192.168.0.5:8998")   # 按顺序探测可用地址
JUKU_USER = "admin"                    # ← 默认登录账号
JUKU_PASS = "1234567890"               # ← 默认登录密码
JUKU_AUTO_LOGIN = True                 # ★ 内置账号自动登录：启动即登录 + 掉登录自动重登，无需人工参与
T4_BASE = "http://127.0.0.1:12333"     # ★ 本 T4API 服务地址（壳子跑在别的设备就改成 http://192.168.0.5:12333）
PAGE_SIZE = 24                         # 剧库每页条数
LIB_TTL = 180                          # 剧库快照缓存（秒）
LOGIN_TTL = 1800                       # 登录态多久后自动重新登录（秒）
WARM_PLAY = True                       # 详情页预热第 1 集，点播放时更快出画面
WARM_MAX_CONCURRENT = 1                # 同时最多几个预热在跑。预热会占用短剧库的播放会话名额
                                       # （默认上限 4），连点几部剧就可能占满 → 播放 429，别调大
WARM_GATE = threading.Semaphore(WARM_MAX_CONCURRENT)   # 预热闸门：满了直接跳过，不排队
# 播放/封面地址里给客户端用的服务地址；留空 = 用实际探测到的地址（同一个手机就是 127.0.0.1）
# 如果壳子跑在另一台设备（电视盒子）上，把这里改成 http://192.168.0.5:8998
JUKU_PUBLIC = ""

SRC_LABEL = {"hongguo": "红果", "huangguo": "黄果", "huangdou": "黄豆"}
SRC_ORDER = ("hongguo", "huangguo", "huangdou")
# 服务端 source 字段 → 三个分类（与剧库网页 sourceKey 口径一致）
SRC_KEYS = {
    "hongguo": ("hongguo", "hongguoduanju.com"),
    "huangguo": ("huangguo", "huangguoai", "cloudfront", "huangguo-video", "huangguo.video", "api"),
    "huangdou": ("huangdou", "tideember.cc", "xqjurgek.top"),
}
BOARDS = {
    "hongguo": [("总热播榜", "hongguo-hot"), ("真人剧榜", "hongguo-real"),
                ("漫剧榜", "hongguo-comic"), ("AI剧榜", "hongguo-ai")],
    "huangguo": [("热播榜", "huangguo-hot"), ("推荐榜", "huangguo-recommend"),
                 ("潜力榜", "huangguo-potential")],
    "huangdou": [("总榜", "huangdou-all"), ("魔改榜", "huangdou-mogai"), ("搜索榜", "huangdou-search"),
                 ("收藏榜", "huangdou-favorite"), ("完结榜", "huangdou-finish")],
}
REAUTH_CODES = ("viewer_required", "viewer_changed", "login_required", "password_change_required",
                "sources_changed", "permissions_changed")


class Spider(Spider):
    headers = {
        "User-Agent": "Mozilla/5.0 (Linux; Android 12; TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36",
        "Accept": "application/json",
        "Accept-Language": "zh-CN,zh;q=0.9",
    }

    def __init__(self):
        self._hosts = list(JUKU_HOSTS)
        self._host = ""
        self._s = None
        self._viewer = {}
        self._viewer_at = 0.0
        self._account = {}
        self._login_at = 0.0
        self._last_error = ""
        self._lib_ts = 0.0
        self._lib = []
        self._lock = threading.Lock()
        self._login_lock = threading.RLock()   # 自动登录/重登串行化，避免并发登录风暴
        self._auto_done = False

    def init(self, extend=""):
        override = ""
        if isinstance(extend, dict):
            override = str(extend.get("host") or extend.get("url") or "")
        elif extend:
            text = str(extend).strip()
            try:
                data = json.loads(text)
                if isinstance(data, dict):
                    override = str(data.get("host") or data.get("url") or "")
            except Exception:
                override = text if text.startswith("http") else ""
        override = override.rstrip("/")
        if override:
            self._hosts = [override] + [h for h in JUKU_HOSTS if h != override]
            self._host = ""
        # ★ 内置账号自动登录：后台线程跑，不阻塞启动；失败静默（下次请求掉登录时还会自愈）
        if JUKU_AUTO_LOGIN:
            threading.Thread(target=self._auto_login, daemon=True).start()

    def _auto_login(self):
        """启动即用内置账号登录（无需人工参与），失败静默不打扰用户。"""
        try:
            self._handshake()
            if not self._account_info().get("logged"):
                res = self._login(force=True)
                self._auto_done = bool(res.get("ok"))
            else:
                self._auto_done = True
        except Exception:
            pass

    # ── 基础通信 ────────────────────────────────────────────────────────

    def _sess(self):
        if self._s is None:
            self._s = requests.Session()
        return self._s

    def _hdrs(self, extra=None):
        head = dict(self.headers)
        vid = self._viewer.get("id") or ""
        if vid:
            head["X-Juku-Viewer"] = vid
            head["X-Juku-Sources"] = ",".join(self._viewer.get("sources") or [])
            head["X-Juku-Online-Only"] = "true" if self._viewer.get("onlineOnly") else "false"
        if extra:
            head.update(extra)
        return head

    def _base(self):
        """探测并记住可用的服务地址（同时完成第一次 Cookie 下发）。"""
        if self._host:
            return self._host
        with self._lock:
            if self._host:
                return self._host
            for host in self._hosts:
                try:
                    r = self._sess().get(host + "/api/ui/viewer", headers=dict(self.headers), timeout=8)
                    if r.status_code < 500:
                        self._host = host
                        return host
                except Exception as exc:
                    self._last_error = "%s 不通（%s）" % (host, type(exc).__name__)
            self._host = self._hosts[0]
            return self._host

    def _public_base(self):
        return (JUKU_PUBLIC or self._base()).rstrip("/")

    def _raw(self, method, path, params=None, body=None, timeout=60):
        host = self._base()
        extra = {"Content-Type": "application/json"} if body is not None else None
        payload = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
        return self._sess().request(method, host + path, params=params, headers=self._hdrs(extra),
                                    data=payload, timeout=timeout)

    def _json(self, method, path, params=None, body=None, timeout=60, retry=True):
        """请求 + 解析 JSON；掉登录/换 host 自动重试一次。"""
        try:
            resp = self._raw(method, path, params, body, timeout)
        except Exception as exc:
            self._last_error = "%s: %s" % (type(exc).__name__, exc)
            if retry:
                nxt = self._next_host()
                if nxt:
                    return self._json(method, path, params, body, timeout, retry=False)
            return None
        data = None
        try:
            data = resp.json()
        except Exception:
            data = None
        if retry and (resp.status_code in (401, 403)
                      or (isinstance(data, dict) and data.get("code") in REAUTH_CODES)):
            # ★ 掉登录自愈：无条件用内置账号重登（不再要求「之前登录过」），保证全自动
            with self._login_lock:
                self._handshake(force=True)
                self._login(force=True)
            return self._json(method, path, params, body, timeout, retry=False)
        return data

    def _next_host(self):
        try:
            idx = self._hosts.index(self._host)
        except ValueError:
            idx = -1
        if 0 <= idx < len(self._hosts) - 1:
            self._host = self._hosts[idx + 1]
            self._viewer = {}
            return self._host
        return ""

    # ── 观看身份 / 账号 ────────────────────────────────────────────────

    def _handshake(self, force=False):
        """取 viewer id（服务端第一次只下发 Cookie，要连调两次）。"""
        if self._viewer.get("id") and not force and time.time() - self._viewer_at < 1500:
            return self._viewer
        data = {}
        for _ in range(3):
            data = self._json("GET", "/api/ui/viewer", timeout=20, retry=False) or {}
            if data.get("ready"):
                break
            time.sleep(0.4)
        if not data.get("ready"):
            self._json("GET", "/api/ui/viewer", params={"confirm": 1}, timeout=20, retry=False)
            time.sleep(0.4)
            data = self._json("GET", "/api/ui/viewer", timeout=20, retry=False) or data
        if isinstance(data, dict) and data.get("ready"):
            self._viewer = data
            self._viewer_at = time.time()
            if data.get("account"):
                self._account = data["account"]
        return self._viewer

    def _login(self, user=None, pwd=None, force=False):
        """登录串行化入口：并发请求同时掉登录时只登一次。"""
        with self._login_lock:
            return self._do_login(user, pwd, force)

    def _do_login(self, user=None, pwd=None, force=False):
        if self._account and not force and time.time() - self._login_at < LOGIN_TTL:
            return {"ok": True, "account": self._account, "cached": True}
        self._handshake(force=True)
        if not self._viewer.get("id"):
            return {"ok": False, "error": self._last_error or "服务未就绪，拿不到观看身份"}
        body = {"username": str(user or JUKU_USER), "password": str(pwd or JUKU_PASS)}
        data = self._json("POST", "/api/ui/account/login", body=body, timeout=30, retry=False) or {}
        if not data.get("ok"):
            self._account = {}
            return {"ok": False, "error": data.get("error") or "登录失败"}
        self._viewer = {}          # 登录后 viewer id / 权限会变，重新握手
        self._account = data.get("account") or {}
        self._login_at = time.time()
        self._handshake(force=True)
        return {"ok": True, "account": self._viewer.get("account") or self._account}

    def _logout(self):
        data = self._json("POST", "/api/ui/account/logout", body={}, timeout=20, retry=False) or {}
        self._account = {}
        self._login_at = 0.0
        self._viewer = {}
        self._handshake(force=True)
        return data

    def _account_info(self):
        self._handshake()
        acct = self._viewer.get("account") or self._account or {}
        return {
            "logged": bool(acct),
            "username": acct.get("username") or "",
            "admin": bool(acct.get("admin")),
            "sources": self._viewer.get("sources") or acct.get("sources") or [],
            "onlineOnly": bool(self._viewer.get("onlineOnly")),
            "ready": bool(self._viewer.get("ready")),
            "host": self._base(),
        }

    # ── 剧库 / 榜单 / 搜索 ─────────────────────────────────────────────

    def _library(self, refresh=False, timeout=120):
        now = time.time()
        if not refresh and self._lib and now - self._lib_ts < LIB_TTL:
            return self._lib
        data = self._json("GET", "/api/ui/dramas", params={"revision": 0}, timeout=timeout) or {}
        items = data.get("data") or []
        if items:
            self._lib = items
            self._lib_ts = now
        return self._lib

    def _stats(self, lib=None):
        lib = lib if lib is not None else self._library(timeout=60)
        cnt = Counter(self._group(d) for d in lib)
        return {"total": len(lib), "hongguo": cnt.get("hongguo", 0),
                "huangguo": cnt.get("huangguo", 0), "huangdou": cnt.get("huangdou", 0),
                "other": cnt.get("other", 0)}

    def _group(self, drama):
        raw = str(drama.get("source") or "").strip().lower()
        for group in SRC_ORDER:
            if raw in SRC_KEYS[group]:
                return group
        hint = "%s %s %s" % (drama.get("channelName") or "", drama.get("id") or "", drama.get("sourceId") or "")
        low = hint.lower()
        for group in SRC_ORDER:
            if low.startswith(group) or (" " + group) in low:
                return group
        return "other"

    def _cats(self, group, lib, top=30):
        cnt = Counter(str(d.get("categoryName") or "").strip() for d in lib
                      if self._group(d) == group and str(d.get("categoryName") or "").strip())
        return [name for name, _ in cnt.most_common(top)]

    def _vod(self, drama, remark=""):
        cover = str(drama.get("cover") or drama.get("coverUrl") or "")
        if cover.startswith("/"):
            cover = self._public_base() + cover
        title = str(drama.get("title") or drama.get("name") or "").strip() or "未命名"
        if not remark:
            bits = [SRC_LABEL.get(self._group(drama), "其他")]
            cat = str(drama.get("categoryName") or "").strip()
            if cat:
                bits.append(cat)
            total = str(drama.get("totalEpisode") or drama.get("chapterCount") or "").strip()
            if total and total not in ("0", "1"):
                bits.append("全%s集" % total)
            remark = " · ".join(bits)
        return {"vod_id": str(drama.get("id") or ""), "vod_name": title,
                "vod_pic": cover, "vod_remarks": remark}

    def _board(self, board, page=1):
        data = self._json("GET", "/api/ui/rankings", params={"board": board, "page": page}, timeout=60) or {}
        items = data.get("items") or []
        out = []
        for it in items:
            drama = it.get("drama") or {}
            if not drama:
                continue
            rank = it.get("rank") or (len(out) + 1)
            heat = str(drama.get("heat") or "").strip()
            out.append(self._vod(drama, "第%s名%s" % (rank, (" · " + heat) if heat else "")))
        return out

    # ── 播放地址（Emby 导出）────────────────────────────────────────────

    def _episode_urls(self, drama_id, timeout=240):
        """POST /api/emby/export → 解 zip → 每集一条 token 直链。"""
        try:
            resp = self._raw("POST", "/api/emby/export",
                             body={"dramaId": str(drama_id), "baseUrl": self._public_base()},
                             timeout=timeout)
        except Exception as exc:
            return [], "%s: %s" % (type(exc).__name__, exc)
        if resp.status_code != 200 or resp.content[:2] != b"PK":
            try:
                msg = (resp.json() or {}).get("error") or ""
            except Exception:
                msg = resp.text[:120]
            return [], msg or ("HTTP %s" % resp.status_code)
        try:
            zf = zipfile.ZipFile(io.BytesIO(resp.content))
        except Exception as exc:
            return [], "导出包解析失败：%s" % exc
        rows = []
        for name in zf.namelist():
            if not name.endswith(".strm"):
                continue
            match = re.search(r"S(\d+)E(\d+)\.strm$", name)
            url = zf.read(name).decode("utf-8", "ignore").strip()
            if not url:
                continue
            rows.append((int(match.group(1)) if match else 0,
                         int(match.group(2)) if match else len(rows) + 1, url))
        rows.sort()
        return [u for _, _, u in rows], ""

    def _open_episodes(self, drama_id, timeout=120):
        """POST /api/ui/playback/open → 分集标题（第N集/字段更全）。

        ⚠️ 本方法默认**不再被调用**（见 _detail）：该接口会在服务端创建一个常驻播放会话，
        占「同时播放数量」名额（默认上限 4，空闲 10 分钟才释放），会挤掉正常的播放请求。
        如确需使用，拿到 session 后必须立刻归还：
            POST /api/ui/playback/control  {"session": <sid>, "action": "close"}
        """
        data = self._json("POST", "/api/ui/playback/open",
                          body={"dramaId": str(drama_id), "resume": False}, timeout=timeout) or {}
        return data.get("episodes") or [], data.get("session") or ""

    def _warm(self, url):
        if not WARM_PLAY or not url:
            return
        if not WARM_GATE.acquire(blocking=False):
            return                      # 已有预热在跑，这次跳过（防止连点详情页占满服务端会话名额）
        def run():
            try:
                r = requests.get(url, timeout=240, stream=True)
                next(r.iter_content(256), b"")
                r.close()
            except Exception:
                pass
            finally:
                WARM_GATE.release()
        threading.Thread(target=run, daemon=True).start()

    # ── 首页 ───────────────────────────────────────────────────────────

    def homeContent(self, filter_=False):
        classes = [{"type_id": "src:" + g, "type_name": SRC_LABEL[g]} for g in SRC_ORDER]
        classes.append({"type_id": "account", "type_name": "剧库工具"})
        filters = {}
        try:
            lib = self._library(timeout=60)
            for group in SRC_ORDER:
                views = [{"n": "剧库全部", "v": "lib"}] + [{"n": n, "v": b} for n, b in BOARDS[group]]
                cats = [{"n": "全部", "v": ""}] + [{"n": c, "v": "cat:" + c} for c in self._cats(group, lib)]
                filters["src:" + group] = [
                    {"key": "view", "name": "榜单", "value": views},
                    {"key": "cat", "name": "题材", "value": cats},
                ]
        except Exception:
            traceback.print_exc()
        return {"class": classes, "filters": filters, "list": self.homeVideoContent().get("list", [])}

    def homeVideoContent(self):
        try:
            items = self._board("hongguo-hot", 1)
            if not items:
                items = [self._vod(d) for d in self._library(timeout=60) if self._group(d) == "hongguo"][:30]
            return {"list": items[:30]}
        except Exception:
            traceback.print_exc()
            return {"list": []}

    # ── 一级（分类列表）──────────────────────────────────────────────

    def categoryContent(self, tid, pg, *a):
        page = max(1, int(pg or 1))
        ext = {}
        for arg in a:
            if isinstance(arg, dict):
                ext = arg
        tid = str(tid or "")
        try:
            if tid == "account":
                return self._account_page(page)
            group = tid.split(":", 1)[1] if ":" in tid else tid
            if group not in SRC_LABEL:
                return self._empty(page)
            view = str(ext.get("view") or "lib")
            cat = str(ext.get("cat") or "")
            if cat.startswith("cat:"):
                cat = cat[4:]
            boards = dict((b, n) for n, b in BOARDS[group])
            if view in boards:
                items = self._board(view, page)
                return {"list": items, "page": page, "pagecount": page + 1 if len(items) >= 20 else page,
                        "limit": len(items) or 20, "total": (page * 20 if len(items) >= 20 else (page - 1) * 20 + len(items))}
            lib = self._library()
            items = [d for d in lib if self._group(d) == group]
            if cat:
                items = [d for d in items if str(d.get("categoryName") or "").strip() == cat]
            total = len(items)
            chunk = items[(page - 1) * PAGE_SIZE: page * PAGE_SIZE]
            return {"list": [self._vod(d) for d in chunk], "page": page,
                    "pagecount": max(1, (total + PAGE_SIZE - 1) // PAGE_SIZE),
                    "limit": PAGE_SIZE, "total": total}
        except Exception:
            traceback.print_exc()
            return self._empty(page)

    @staticmethod
    def _empty(page):
        return {"list": [], "page": page, "pagecount": 1, "limit": PAGE_SIZE, "total": 0}

    # ── 二级（详情 / 账号操作）─────────────────────────────────────────

    def detailContent(self, ids):
        try:
            vid = str((ids or [""])[0] if isinstance(ids, (list, tuple)) else ids or "")
        except Exception:
            vid = ""
        if vid.startswith("acct:"):
            # 剧库工具动作卡：壳子直接 GET 本源的 detail 通道拿结果（list → 弹「执行结果」窗口）
            items = self._acct_items(vid)
            for it in items:
                it["vod_id"] = vid
            return {"list": items}
        try:
            return {"list": [self._detail(vid)]}
        except Exception:
            traceback.print_exc()
            return {"list": []}

    def _find_drama(self, drama_id):
        for d in self._library(timeout=90):
            if str(d.get("id")) == str(drama_id):
                return d
        return {}

    def _detail(self, drama_id):
        drama = self._find_drama(drama_id)
        urls, err = self._episode_urls(drama_id)
        # 注意：这里不要调 /api/ui/playback/open 取分集标题 —— 它会在服务端创建一个常驻播放会话
        #（占「同时播放数量」名额，默认上限 4，空闲 10 分钟才释放）。点几部剧就会把名额占满，
        # 之后连播/换集全部返回 429「同时播放数量已达上限，请稍后再试」→ 壳子表现为"不能连续播下集"。
        # 分集标题统一用「第N集」即可，不需要那个接口。
        titles = []
        if not urls:
            play_from, play_url = "", ""
            extra = "\n⚠️ 取播放地址失败：%s" % (err or "未知原因")
        else:
            pairs = []
            for idx, url in enumerate(urls):
                name = titles[idx] if idx < len(titles) and titles[idx] else "第%d集" % (idx + 1)
                pairs.append("%s$%s" % (name, url))
            play_from, play_url = "短剧库·%s" % SRC_LABEL.get(self._group(drama), "短剧"), "#".join(pairs)
            extra = ""
            self._warm(urls[0])
        group = SRC_LABEL.get(self._group(drama), "其他")
        total = str(drama.get("totalEpisode") or len(urls) or "").strip()
        cat = str(drama.get("categoryName") or "").strip()
        content = "【%s%s】%s\n分集：%s 集\n服务：%s%s" % (
            group, ("·" + cat) if cat else "", str(drama.get("title") or drama_id),
            total or "未知", self._public_base(), extra)
        intro = str(drama.get("desc") or drama.get("intro") or "").strip()
        if intro:
            content += "\n\n简介：%s" % intro
        return {"vod_id": str(drama_id), "vod_name": str(drama.get("title") or drama_id),
                "vod_pic": self._vod(drama).get("vod_pic", "") if drama else "",
                "type_name": cat or group,
                "vod_remarks": ("全集 %s 集" % total) if (total and urls) else (err or "共 %d 集" % len(urls)),
                "vod_content": content,
                "vod_play_from": play_from, "vod_play_url": play_url}

    # ── 剧库工具（动作卡）────────────────────────────────────────────

    def _account_page(self, page):
        """剧库工具：4 张动作卡 —— 点了直接弹「执行结果」，不跳详情页。"""
        cards = [
            ("acct:libstat", "📊 剧库统计", "红果/黄果/黄豆 各多少条"),
            ("acct:libupdate", "🔄 更新剧库", "三个源增量刷新（1～3 分钟）"),
            ("acct:following", "⭐ 追剧清单", "服务端追剧记录"),
            ("acct:tasks", "⬇️ 下载任务", "服务端下载队列"),
        ]
        items = [{"vod_id": vid, "vod_name": name, "vod_remarks": rem, "action": self._act_url(vid)}
                 for vid, name, rem in cards]
        return {"list": items, "page": 1, "pagecount": 1, "limit": len(items), "total": len(items)}

    # ── 动作卡片：壳子点到就 GET 本服务，服务端执行后弹「执行结果」─────────
    # 壳子（ActionCardHelper）对 action 字段非空的卡片：点击 → GET 该地址 →
    # 响应里 list 非空 → 弹窗逐条显示 vod_name + vod_remarks（msg → Toast）。
    # 这里把 action 指到本源的 detail 通道：它原样返回源自己的 dict，不被框架包装。

    def _act_url(self, vid):
        """动作卡地址（detail 通道；源 key 由框架注入在 source_name 上）。"""
        key = str(getattr(self, "source_name", "") or self.getName())
        return "%s/vod/%s?ids=%s" % (T4_BASE.rstrip("/"), quote(key, safe=""), quote(vid, safe=""))

    @staticmethod
    def _unb64(text):
        pad = "=" * (-len(text) % 4)
        return base64.urlsafe_b64decode(text + pad).decode("utf-8", "ignore")

    def _acct_items(self, vid):
        """执行「剧库工具」动作，返回结果卡片列表（壳子弹窗逐条显示 vod_name + vod_remarks）。"""
        try:
            if vid == "acct:libstat":
                stat = self._stats()
                info = self._account_info()
                return [self._ok("📊 剧库统计",
                                 "剧库共 %d 条\n  红果 %d\n  黄果 %d\n  黄豆 %d\n  其他 %d\n\n服务：%s\n在线模式：%s"
                                 % (stat["total"], stat["hongguo"], stat["huangguo"], stat["huangdou"], stat["other"],
                                    info["host"], "是" if info["onlineOnly"] else "否"))]
            if vid == "acct:libupdate":
                self._lib = []
                self._lib_ts = 0.0
                # 同步通知要 8～11 秒/源（壳子请求会等超时）→ 丢后台线程，卡片立刻出结果。
                threading.Thread(target=self._kick_update, name="juku-update", daemon=True).start()
                return [self._ok("🔄 更新剧库",
                                 "已通知服务端增量更新（红果 / 黄果 / 黄豆，后台跑 1～3 分钟）：\n  三个源：已提交\n\n过一会儿回列表刷新，或点「📊 剧库统计」看新条数。")]
            if vid == "acct:following":
                rows = (self._json("GET", "/api/ui/following", timeout=60) or {}).get("data") or []
                if not rows:
                    return [self._ok("⭐ 追剧清单", "追剧清单为空（可在剧库详情页追剧，或等壳子同步）")]
                return [self._ok("%d. %s" % (i + 1, r.get("title") or r.get("dramaId")),
                                 "来源：%s" % SRC_LABEL.get(str(r.get("source") or "").lower(), r.get("source") or "-"))
                        for i, r in enumerate(rows[:60])]
            if vid == "acct:tasks":
                d = self._json("GET", "/api/ui/tasks", timeout=60) or {}
                rows = d.get("data") or []
                ff = d.get("ffmpeg") or {}
                if not rows:
                    return [self._ok("⬇️ 下载任务", "没有下载任务。\nFFmpeg：%s（%s）"
                                     % (ff.get("status"), ff.get("detail") or ff.get("path") or ""))]
                return [self._ok("%d. %s 第%s集" % (i + 1, t.get("dramaTitle") or t.get("title") or "",
                                                   t.get("episode") or t.get("index") or ""),
                                 "%s %s%%" % (t.get("status") or "", t.get("progress") or 0))
                        for i, t in enumerate(rows[:40])]
        except Exception:
            traceback.print_exc()
            return [self._ok("❌ 执行出错", traceback.format_exc(limit=1))]
        return [self._ok("剧库工具", "未知操作：%s" % vid)]

    @staticmethod
    def _ok(name, text):
        """结果卡片：壳子弹窗读 vod_name（标题）+ vod_remarks（正文）；兼写 vod_content 便于详情页查看。"""
        return {"vod_id": "acct:result", "vod_name": name, "vod_remarks": text, "vod_content": text}

    def _kick_update(self):
        """后台通知服务端刷新剧库（每源一次；同步等要 8～11 秒，壳子会当成无响应）。"""
        for group in SRC_ORDER:
            try:
                self._json("GET", "/api/ui/dramas", params={"update": 1, "source": group}, timeout=60)
            except Exception:
                traceback.print_exc()

    # ── 搜索 ──────────────────────────────────────────────────────────

    def searchContent(self, key, quick=False, pg=1, *a):
        keyword = str(key or "").strip()
        page = max(1, int(pg or 1)) if str(pg or "1").isdigit() else 1
        if not keyword:
            return {"list": [], "page": 1, "pagecount": 1, "limit": PAGE_SIZE, "total": 0}
        rows, seen = [], set()
        try:
            data = self._json("GET", "/api/ui/search", params={"q": keyword}, timeout=90) or {}
            for d in (data.get("data") or []):
                did = str(d.get("id") or "")
                if did and did not in seen:
                    seen.add(did)
                    rows.append(self._vod(d, "联网·%s" % SRC_LABEL.get(self._group(d), "结果")))
                elif not did:
                    rows.append(self._vod(d, "联网结果"))
        except Exception:
            traceback.print_exc()
        low = keyword.lower()
        try:
            for d in self._library(timeout=60):
                did = str(d.get("id") or "")
                if did in seen:
                    continue
                blob = ("%s %s" % (d.get("title") or d.get("name") or "", d.get("desc") or "")).lower()
                if low in blob:
                    seen.add(did)
                    rows.append(self._vod(d, "剧库·%s" % SRC_LABEL.get(self._group(d), "结果")))
        except Exception:
            traceback.print_exc()
        total = len(rows)
        chunk = rows[(page - 1) * PAGE_SIZE: page * PAGE_SIZE]
        return {"list": chunk, "page": page, "pagecount": max(1, (total + PAGE_SIZE - 1) // PAGE_SIZE),
                "limit": PAGE_SIZE, "total": total}

    def searchContentPage(self, key, quick, pg=1):
        return self.searchContent(key, quick, pg)

    # ── 播放 ─────────────────────────────────────────────────────────

    def playerContent(self, flag, pid, *a):
        target = str(pid or "")
        if target.startswith("jkpro|"):
            try:
                payload = json.loads(self._unb64(target.split("|", 1)[1]))
                return {"parse": 0, "url": payload.get("url", ""), "playUrl": "",
                        "header": payload.get("header") or self._play_header()}
            except Exception:
                traceback.print_exc()
        return {"parse": 0, "url": target if target.startswith("http") else "", "playUrl": "",
                "header": self._play_header()}

    def _play_header(self):
        # 直链由短剧库服务端转发（token 已带在 URL 里），这里只补常规头；
        # Referer 留着是给下游 CDN 兜底，服务端不校验。
        return {"User-Agent": self.headers["User-Agent"], "Referer": self._public_base() + "/"}

    def diag_urls(self):
        """站点改版时的分层探针（本源自解析，探的是服务端接口）。"""
        base = self._base()
        return [base + "/api/ui/viewer", base + "/api/ui/dramas?revision=0",
                base + "/api/ui/rankings?board=hongguo-hot&page=1", base + "/api/ui/search?q=%E5%A4%AB%E4%BA%BA"]

    def localProxy(self, params):
        return None

    def isVideoFormat(self, url):
        return False

    def manualVideoCheck(self):
        return False

    def destroy(self):
        try:
            if self._s is not None:
                self._s.close()
        except Exception:
            pass
        self._s = None

    def getName(self):
        return "短剧库"
