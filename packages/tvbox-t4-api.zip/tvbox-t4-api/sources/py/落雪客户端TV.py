# coding=utf-8
"""
洛雪音乐服务器的 ys Type 3 单文件爬虫。

提供 HomeUI v4 CSS-like 音乐首页、榜单/歌单/歌手/专辑、收藏读取、音乐播放解析，
以及通过 Action 管理 lxserver 自定义 JS 音源的能力。

@author @ccfork
"""

import base64
import hashlib
import json
import os
import re
import time
import threading
import socket
import hmac
import html
from http.cookies import SimpleCookie, CookieError
from copy import deepcopy
from urllib.parse import quote, urlsplit, parse_qs

try:
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from socketserver import ThreadingMixIn
except ImportError:
    BaseHTTPRequestHandler = HTTPServer = ThreadingMixIn = None

import requests
from requests import Session
from requests.exceptions import RequestException

from base.spider import Spider as BaseSpider


SOURCE_NAMES = {
    "kw": "酷我音乐",
    "kg": "酷狗音乐",
    "tx": "QQ音乐",
    "wy": "网易云音乐",
    "mg": "咪咕音乐",
}

QUALITY_NAMES = {
    "128k": "标准音质",
    "320k": "高品音质",
    "flac": "无损音质",
    "flac24bit": "Hi-Res",
}

SORT_IDS = {
    "kw": {"hot": "hot", "new": "new"},
    "kg": {"hot": "6", "new": "7", "recommend": "5"},
    "tx": {"hot": "5", "new": "2"},
    "wy": {"hot": "hot", "new": "hot"},
    "mg": {"hot": "15127315", "new": "15127315"},
}

DEFAULT_CONFIG = {
    "base_url": "http://127.0.0.1:9527",
    "username": "admin",
    "password": "123456",
    "api_token": "",
    "admin_password": "123456",
    "source": "kw",
    "playlist_source": "wy",
    "album_source": "wy",
    "sources": ["kw", "kg", "tx", "wy", "mg"],
    "quality": "320k",
    "qualities": ["128k", "320k", "flac"],
    "timeout": 12,
    "max_pages": 5,
    "max_songs": 500,
    "home_ttl": 180,
    "download_folder": "",
    "download_quality": "320k",
    "auto_download": "否",
    "device_mode": "auto",
    "mobile_web_enabled": True,
    "mobile_web_port": 40012,
}


class LxClientError(Exception):
    """lxserver 请求失败。"""


class LxHttpClient:
    """负责 lxserver HTTP、登录令牌和各业务接口调用。"""

    def __init__(self, config):
        self.config = config
        self.base_url = str(config.get("base_url") or DEFAULT_CONFIG["base_url"]).rstrip("/")
        self.timeout = self._positive_int(config.get("timeout"), 12, 3, 60)
        self.session = Session()
        self.session.headers.update({
            "User-Agent": "ys-LxClient/1.0",
            "Accept": "application/json, text/plain, */*",
        })
        self.token = str(config.get("api_token") or "")

    @staticmethod
    def _positive_int(value, fallback, minimum, maximum):
        try:
            return min(max(int(value), minimum), maximum)
        except (TypeError, ValueError):
            return fallback

    @property
    def username(self):
        return str(self.config.get("username") or "").strip()

    def _url(self, path):
        return self.base_url + "/" + str(path or "").lstrip("/")

    def _login(self, force=False):
        if self.token and not force:
            return self.token
        username = self.username
        password = str(self.config.get("password") or "")
        if not username or not password:
            raise LxClientError("收藏和私有音源需要配置 lxserver 用户名与密码")
        result = self._request(
            "POST",
            "/api/user/login",
            json_body={"username": username, "password": password},
            use_auth=False,
        )
        if not isinstance(result, dict) or not result.get("success") or not result.get("token"):
            raise LxClientError("lxserver 用户登录失败")
        self.token = str(result["token"])
        return self.token

    def _headers(self, use_auth=False, use_admin=False):
        headers = {}
        if use_auth:
            headers["X-User-Token"] = self._login()
            headers["X-User-Name"] = self.username
        if use_admin:
            headers["X-Frontend-Auth"] = str(self.config.get("admin_password") or "")
        return headers

    def _request(self, method, path, params=None, json_body=None, use_auth=False,
                 use_admin=False, retry_auth=True):
        try:
            response = self.session.request(
                method,
                self._url(path),
                params=params,
                json=json_body,
                headers=self._headers(use_auth, use_admin),
                timeout=self.timeout,
            )
        except RequestException as error:
            raise LxClientError("无法连接 lxserver: %s" % error)

        if response.status_code == 401 and use_auth and retry_auth:
            self.token = ""
            self._login(force=True)
            return self._request(
                method,
                path,
                params=params,
                json_body=json_body,
                use_auth=use_auth,
                use_admin=use_admin,
                retry_auth=False,
            )

        if response.status_code >= 400:
            message = response.text.strip()
            try:
                data = response.json()
                message = data.get("error") or data.get("message") or message
            except (ValueError, AttributeError):
                pass
            raise LxClientError("lxserver 返回 %s: %s" % (response.status_code, message or "请求失败"))

        if not response.content:
            return None
        try:
            return response.json()
        except ValueError:
            return response.text

    def ping(self):
        return self._request("GET", "/api/music/config")

    def search(self, source, keyword, search_type="song", page=1, limit=20):
        data = self._request("GET", "/api/music/search", params={
            "source": source,
            "type": search_type,
            "name": keyword,
            "page": page,
            "limit": limit,
        })
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            for key in ("list", "data", "result"):
                if isinstance(data.get(key), list):
                    return data[key]
        return []

    def hot_search(self, source):
        return self._request("GET", "/api/music/hotSearch", params={"source": source})

    def leaderboard_boards(self, source):
        return self._request("GET", "/api/music/leaderboard/boards", params={"source": source})

    def leaderboard_list(self, source, board_id, page=1):
        return self._request("GET", "/api/music/leaderboard/list", params={
            "source": source,
            "bangid": board_id,
            "page": page,
        })

    def playlist_list(self, source, sort_id="hot", tag_id="", page=1):
        return self._request("GET", "/api/music/songList/list", params={
            "source": source,
            "sortId": sort_id,
            "tagId": tag_id,
            "page": page,
        })

    def playlist_detail(self, source, playlist_id, page=1):
        return self._request("GET", "/api/music/songList/detail", params={
            "source": source,
            "id": playlist_id,
            "page": page,
        })

    def playlist_search(self, source, keyword, page=1):
        return self._request("GET", "/api/music/songList/search", params={
            "source": source,
            "text": keyword,
            "page": page,
        })

    def artist_detail(self, source, artist_id):
        return self._request("GET", "/api/music/artistDetail", params={
            "source": source,
            "id": artist_id,
        })

    def artist_songs(self, source, artist_id, order="hot"):
        return self._request("GET", "/api/music/artistSongs", params={
            "source": source,
            "id": artist_id,
            "order": order,
        }) or []

    def artist_albums(self, source, artist_id, page=1):
        return self._request("GET", "/api/music/artistAlbums", params={
            "source": source,
            "id": artist_id,
            "page": page,
        })

    def album_songs(self, source, album_id):
        return self._request("GET", "/api/music/albumSongs", params={
            "source": source,
            "id": album_id,
        })

    def music_url(self, song, quality):
        username = self.username
        use_auth = bool(username and username not in ("default", "open", "_open"))
        return self._request(
            "POST",
            "/api/music/url",
            json_body={
                "songInfo": song,
                "quality": quality,
                "enableAutoSwitchApiSource": True,
            },
            use_auth=use_auth,
        )

    def lyric(self, song):
        return self._request(
            "GET",
            "/api/music/lyric",
            params={
                "source": song.get("source") or "",
                "songmid": song.get("songmid") or song.get("songId") or "",
                "songId": song.get("songId") or "",
                "name": song.get("name") or "",
                "singer": song.get("singer") or "",
                "hash": song.get("hash") or "",
                "interval": song.get("interval") or "",
                "copyrightId": song.get("copyrightId") or "",
                "albumId": song.get("albumId") or "",
                "lrcUrl": song.get("lrcUrl") or "",
                "mrcUrl": song.get("mrcUrl") or "",
                "trcUrl": song.get("trcUrl") or "",
            },
            use_auth=bool(self.username),
        )

    def user_data(self):
        data = self._request("GET", "/api/user/list", use_auth=True)
        return data if isinstance(data, dict) else {}

    def favorite_artists(self):
        data = self._request("GET", "/api/user/library/artists", use_auth=True)
        return data if isinstance(data, list) else []

    def favorite_albums(self):
        data = self._request("GET", "/api/user/library/albums", use_auth=True)
        return data if isinstance(data, list) else []

    def source_list(self):
        data = self._request(
            "GET",
            "/api/custom-source/list",
            params={"username": self.username or "default"},
            use_auth=bool(self.username),
            use_admin=True,
        )
        return data if isinstance(data, list) else []

    def source_validate(self, content, allow_unsafe=False):
        return self._request(
            "POST",
            "/api/custom-source/validate",
            json_body={
                "script": content,
                "username": self.username or "default",
                "allowUnsafeVM": bool(allow_unsafe),
            },
            use_auth=bool(self.username),
            use_admin=True,
        )

    def source_upload(self, filename, content, allow_unsafe=False):
        return self._request(
            "POST",
            "/api/custom-source/upload",
            json_body={
                "filename": filename,
                "content": content,
                "username": self.username or "default",
                "allowUnsafeVM": bool(allow_unsafe),
            },
            use_auth=bool(self.username),
            use_admin=True,
        )

    def source_toggle(self, source_id, owner, enabled, allow_unsafe=False):
        username = "default" if owner == "open" else owner
        return self._request(
            "POST",
            "/api/custom-source/toggle",
            json_body={
                "id": source_id,
                "username": username,
                "enabled": bool(enabled),
                "allowUnsafeVM": bool(allow_unsafe),
            },
            use_auth=bool(self.username),
            use_admin=True,
        )

    def source_delete(self, source_id, owner):
        username = "default" if owner == "open" else owner
        return self._request(
            "POST",
            "/api/custom-source/delete",
            json_body={"id": source_id, "username": username},
            use_auth=bool(self.username),
            use_admin=True,
        )

    def source_reorder(self, source_ids):
        return self._request(
            "POST",
            "/api/custom-source/reorder",
            json_body={"username": self.username or "default", "sourceIds": source_ids},
            use_auth=bool(self.username),
            use_admin=True,
        )


def _mobile_web_private_address(address):
    """严格解析 IPv4 私网/本机，不将以 127./fd 开头的域名视作 IP。"""
    text = str(address or '').strip()
    if text == 'localhost':
        return True
    parts = text.split('.')
    if len(parts) != 4 or any(not re.fullmatch(r'[0-9]{1,3}', x) for x in parts):
        return False
    values = [int(x) for x in parts]
    if any(x > 255 for x in values):
        return False
    first, second = values[:2]
    return (first in (10, 127) or first == 172 and 16 <= second <= 31 or
            first == 192 and second == 168 or first == 169 and second == 254)


def _mobile_web_lan_addresses():
    """返回优先级较高的私网 IPv4；没有网络时安静返回空列表。"""
    found = []

    def add(address):
        text = str(address or "").split("%", 1)[0].strip()
        if ":" not in text and _mobile_web_private_address(text) and not text.startswith("127."):
            if text not in found:
                found.append(text)

    # UDP connect 只由系统选择路由，不会真正向公网发送应用数据。
    try:
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        probe.settimeout(0.2)
        probe.connect(("10.255.255.255", 1))
        add(probe.getsockname()[0])
        probe.close()
    except Exception:
        try:
            probe.close()
        except Exception:
            pass
    try:
        for item in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            add(item[4][0])
    except Exception:
        pass

    # Android 某些壳的 hostname 只有 127.0.0.1，补一次 NetworkInterface 枚举。
    try:
        from java import jclass
        NetworkInterface = jclass("java.net.NetworkInterface")
        interfaces = NetworkInterface.getNetworkInterfaces()
        while interfaces and interfaces.hasMoreElements():
            interface = interfaces.nextElement()
            try:
                if not interface.isUp() or interface.isLoopback():
                    continue
            except Exception:
                continue
            addresses = interface.getInetAddresses()
            while addresses and addresses.hasMoreElements():
                item = addresses.nextElement()
                try:
                    if not item.isLoopbackAddress():
                        add(item.getHostAddress())
                except Exception:
                    pass
    except Exception:
        pass
    return found



def _mobile_web_qr_matrix(text):
    """生成固定 Version 4-L 的 QR 矩阵（33×33）。

    二维码只承载固定的 http://IP:端口 地址，容量为 78 字节。
    使用内置实现，不依赖外部二维码网站；生成失败时回退为可复制的直连地址。
    """
    raw = str(text or "").encode("utf-8")
    # Version 4-L：80 数据 codewords、20 个 RS 校验 codewords、byte 容量 78。
    if not raw or len(raw) > 78:
        return None
    size, data_words, ecc_words = 33, 80, 20
    bits = [0, 1, 0, 0]  # Byte mode
    bits.extend((len(raw) >> shift) & 1 for shift in range(7, -1, -1))
    for byte in raw:
        bits.extend((byte >> shift) & 1 for shift in range(7, -1, -1))
    bits.extend([0] * min(4, data_words * 8 - len(bits)))
    while len(bits) % 8:
        bits.append(0)
    data = []
    for index in range(0, len(bits), 8):
        value = 0
        for bit in bits[index:index + 8]:
            value = (value << 1) | bit
        data.append(value)
    pad_values = (0xEC, 0x11)
    pad_index = 0
    while len(data) < data_words:
        data.append(pad_values[pad_index % 2])
        pad_index += 1

    # GF(256) Reed-Solomon，primitive polynomial 0x11d。
    exp = [0] * 512
    log = [0] * 256
    value = 1
    for index in range(255):
        exp[index] = value
        log[value] = index
        value <<= 1
        if value & 0x100:
            value ^= 0x11D
    for index in range(255, 512):
        exp[index] = exp[index - 255]

    def gf_mul(left, right):
        return 0 if not left or not right else exp[log[left] + log[right]]

    generator = [1]
    for index in range(ecc_words):
        next_poly = [0] * (len(generator) + 1)
        root = exp[index]
        for pos, coefficient in enumerate(generator):
            next_poly[pos] ^= coefficient
            next_poly[pos + 1] ^= gf_mul(coefficient, root)
        generator = next_poly
    remainder = [0] * ecc_words
    for byte in data:
        factor = byte ^ remainder.pop(0)
        remainder.append(0)
        for pos in range(ecc_words):
            remainder[pos] ^= gf_mul(generator[pos + 1], factor)
    codewords = data + remainder

    modules = [[False for _ in range(size)] for _ in range(size)]
    function = [[False for _ in range(size)] for _ in range(size)]

    def set_module(x, y, dark):
        if 0 <= x < size and 0 <= y < size:
            modules[y][x] = bool(dark)
            function[y][x] = True

    def finder(x, y):
        for dy in range(-1, 8):
            for dx in range(-1, 8):
                if 0 <= x + dx < size and 0 <= y + dy < size:
                    dark = (0 <= dx <= 6 and 0 <= dy <= 6 and
                            (dx in (0, 6) or dy in (0, 6) or
                             (2 <= dx <= 4 and 2 <= dy <= 4)))
                    set_module(x + dx, y + dy, dark)

    finder(0, 0)
    finder(size - 7, 0)
    finder(0, size - 7)
    # Version 4 的一个 alignment pattern，中心为 (26, 26)。
    for dy in range(-2, 3):
        for dx in range(-2, 3):
            set_module(26 + dx, 26 + dy,
                       max(abs(dx), abs(dy)) in (2, 0))
    for index in range(8, size - 8):
        if not function[6][index]:
            set_module(index, 6, index % 2 == 0)
        if not function[index][6]:
            set_module(6, index, index % 2 == 0)
    # 预留 format information，并设定固定 dark module。
    for index in range(9):
        if index != 6:
            set_module(8, index, False)
            set_module(index, 8, False)
    for index in range(8):
        set_module(size - 1 - index, 8, False)
        set_module(8, size - 1 - index, False)
    set_module(8, size - 8, True)

    def draw_format(mask):
        # L=01，拼成 format data 后用 BCH(0x537) 和标准 mask 0x5412。
        data_bits = (1 << 3) | int(mask)
        bits_value = data_bits << 10
        while bits_value.bit_length() >= 11:
            bits_value ^= 0x537 << (bits_value.bit_length() - 11)
        encoded = ((data_bits << 10) | bits_value) ^ 0x5412

        def bit(index):
            return bool((encoded >> index) & 1)

        for index in range(0, 6):
            set_module(8, index, bit(index))
        set_module(8, 7, bit(6))
        set_module(8, 8, bit(7))
        set_module(7, 8, bit(8))
        for index in range(9, 15):
            set_module(14 - index, 8, bit(index))
        for index in range(0, 8):
            set_module(size - 1 - index, 8, bit(index))
        for index in range(8, 15):
            set_module(8, size - 15 + index, bit(index))
        set_module(8, size - 8, True)

    # Mask 0 完全符合 QR 规范；短局域网 URL 的分布已足够均匀，避免为每次弹窗
    # 重复计算八套矩阵。format information 会明确告知读取器当前 mask。
    mask = 0
    bit_index = 0
    right = size - 1
    while right > 0:
        if right == 6:
            right -= 1
        upward = ((right + 1) & 2) == 0
        for vertical in range(size):
            y = size - 1 - vertical if upward else vertical
            for offset in range(2):
                x = right - offset
                if not function[y][x] and bit_index < len(codewords) * 8:
                    byte = codewords[bit_index >> 3]
                    dark = bool((byte >> (7 - (bit_index & 7))) & 1)
                    if (x + y) % 2 == 0:
                        dark = not dark
                    modules[y][x] = dark
                    bit_index += 1
        right -= 2
    draw_format(mask)
    return modules

# 局域网管理服务独立于 lxserver；无 Android/HTTP 支持时不影响音乐功能。
_DEVICE_OPTIONS = [('auto', '自动识别'), ('tv', 'TV / 遥控器'),
                   ('phone', '手机'), ('tablet', '平板'), ('tv_off', '关闭 TV 优化')]
_SECRET_KEYS = {'password', 'api_token', 'admin_password'}
_WEB_SERVICES = {}
_WEB_SERVICES_LOCK = threading.RLock()


def _lx_token():
    return base64.urlsafe_b64encode(os.urandom(16)).decode('ascii').rstrip('=')


class LxMobileService:
    """固定局域网地址、无时间期限会话、CSRF 与可切换端口的 HTTP 服务。"""

    def __init__(self, owner):
        self.owner = owner
        self.lock = threading.RLock()
        self.server = None
        self.thread = None
        self.sessions = {}
        self.error = ''
        self.port = int(owner.config['mobile_web_port'])

    def refresh_pairing(self, disconnect=False):
        # 二维码始终为 IP:端口；刷新不会改变已保存的访问地址。
        with self.lock:
            if disconnect:
                self.sessions.clear()

    def status(self, pairing=False):
        with self.lock:
            addresses = _mobile_web_lan_addresses() if pairing and self.server else []
            urls = ['http://%s:%s' % (ip, self.port) for ip in addresses]
            primary = urls[0] if urls else ''
            return {'enabled': bool(self.owner.config['mobile_web_enabled']),
                    'running': self.server is not None, 'port': self.port,
                    'error': self.error, 'urls': urls, 'primary_url': primary,
                    'qr_url': primary,
                    'sessions': len(self.sessions)}

    def start(self):
        if HTTPServer is None:
            self.error = '当前 Python 环境不支持 http.server，请继续使用客户端设置'
            return
        service = self

        class Server(ThreadingMixIn, HTTPServer):
            daemon_threads = True
            allow_reuse_address = True

        class Handler(BaseHTTPRequestHandler):
            server_version = 'LxMobile/1.0'
            sys_version = ''

            def setup(self):
                super().setup()
                self.connection.settimeout(15)

            def log_message(self, *args):
                pass  # 不记录二维码令牌、Cookie 或密码。

            def send(self, status, data, kind='application/json; charset=utf-8', cookie=None):
                raw = (data if isinstance(data, str) else json.dumps(data, ensure_ascii=False)).encode('utf-8')
                self.send_response(status)
                self.send_header('Content-Type', kind)
                self.send_header('Content-Length', str(len(raw)))
                self.send_header('Cache-Control', 'no-store')
                self.send_header('Referrer-Policy', 'no-referrer')
                self.send_header('X-Content-Type-Options', 'nosniff')
                self.send_header('X-Frame-Options', 'DENY')
                self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; base-uri 'none'; frame-ancestors 'none'")
                if cookie:
                    self.send_header('Set-Cookie', cookie)
                self.end_headers()
                try:
                    self.wfile.write(raw)
                except OSError:
                    pass

            def allowed(self):
                # Host 校验也阻止 DNS rebinding；不信任代理转发头。
                host = self.headers.get('Host', '')
                try:
                    parsed = urlsplit('http://' + host)
                    valid = parsed.port == service.port and _mobile_web_private_address(parsed.hostname)
                except ValueError:
                    valid = False
                if not valid or not _mobile_web_private_address(self.client_address[0]):
                    self.send(403, {'error': '仅允许通过本机或局域网 IP 访问'})
                    return False
                return True

            def session(self, write=False, create=False):
                cookie = SimpleCookie()
                try:
                    cookie.load(self.headers.get('Cookie', ''))
                    sid = cookie['lx_mobile_%s' % service.port].value
                except (KeyError, ValueError, CookieError):
                    sid = ''
                with service.lock:
                    item = service.sessions.get(sid)
                    if not item and create:
                        sid = _lx_token()
                        item = {'id': sid, 'csrf': _lx_token()}
                        service.sessions[sid] = item
                    if item and write:
                        csrf = self.headers.get('X-Lx-CSRF', '')
                        origin = self.headers.get('Origin')
                        expected = 'http://' + self.headers.get('Host', '')
                        if not hmac.compare_digest(csrf.encode('utf-8'), item['csrf'].encode('ascii')) or (origin and origin != expected):
                            item = None
                if not item:
                    self.send(403 if write else 401, {'error': '连接已断开，请重新打开保存的 IP:端口 地址'})
                return item

            def do_GET(self):
                if not self.allowed():
                    return
                parsed = urlsplit(self.path)
                query = parse_qs(parsed.query)
                if parsed.path == '/connect':
                    # 兼容旧二维码；新二维码与可保存地址只包含 IP:端口。
                    self.send_response(303)
                    self.send_header('Location', '/')
                    self.send_header('Content-Length', '0')
                    self.send_header('Cache-Control', 'no-store')
                    self.end_headers()
                    return
                if parsed.path == '/':
                    # 仅在已通过私网 IP / Host 校验的首页访问中签发会话。
                    # Cookie 由浏览器管理；服务端不按时间过期，重新打开地址可重建。
                    item = self.session(create=True)
                    cookie = 'lx_mobile_%s=%s; Path=/; HttpOnly; SameSite=Strict' % (service.port, item['id'])
                    self.send(200, _LX_MOBILE_PAGE, 'text/html; charset=utf-8', cookie=cookie)
                    return
                item = self.session()
                if not item:
                    return
                try:
                    with service.owner._settings_lock:
                        if parsed.path == '/api/state':
                            result = service.owner._mobile_snapshot(item['csrf'])
                        elif parsed.path == '/api/sources':
                            result = {'sources': service.owner.client.source_list()}
                        elif parsed.path == '/api/browse':
                            result = service.owner._mobile_browse(query.get('path', [''])[0])
                        else:
                            self.send(404, {'error': '未知接口'})
                            return
                    self.send(200, result)
                except (ValueError, OSError, LxClientError) as error:
                    self.send(400, {'error': str(error)})

            def do_POST(self):
                if not self.allowed() or not self.session(write=True):
                    return
                try:
                    size = int(self.headers.get('Content-Length', '0'))
                    if not 0 < size <= 7 * 1024 * 1024:
                        raise ValueError('请求内容为空或超过 7 MB')
                    if not self.headers.get('Content-Type', '').startswith('application/json'):
                        raise ValueError('请求必须为 JSON')
                    body = json.loads(self.rfile.read(size).decode('utf-8'))
                    if not isinstance(body, dict):
                        raise ValueError('请求必须为 JSON 对象')
                    with service.owner._settings_lock:
                        result = service.owner._mobile_command(urlsplit(self.path).path, body)
                    self.send(200, result)
                    # HTTP 响应已送出后切换端口/关闭服务，避免保存成功被误报为断线。
                    if result.get('restart'):
                        threading.Thread(target=service.owner._sync_mobile_service, daemon=True).start()
                except (ValueError, TypeError, OSError, LxClientError) as error:
                    self.send(400, {'error': str(error)})

        server = None
        try:
            server = Server(('0.0.0.0', self.port), Handler)
            self.server = server
            self.thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': 0.2}, daemon=True)
            self.thread.start()
            self.error = ''
        except Exception as error:
            self.error = '端口 %s 启动失败：%s（可在服务设置中修改端口）' % (self.port, error)
            self.server = None
            if server:
                server.server_close()

    def stop(self):
        with self.lock:
            server, self.server = self.server, None
            self.sessions.clear()
        if server:
            server.shutdown()
            server.server_close()


_LX_MOBILE_PAGE = r'''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>落雪移动管理</title>
<style>body{margin:0;background:#f0f6f3;color:#173129;font:16px system-ui}main{max-width:1000px;margin:auto;padding:20px}section{background:white;padding:20px;border-radius:16px;margin:16px 0}h1{font-size:26px}h2{font-size:20px}label{display:block;margin:14px 0}input,select,textarea,button{font:inherit;box-sizing:border-box;border:1px solid #b7cfc4;border-radius:8px;padding:12px;max-width:100%}input:not([type=checkbox]),select,textarea{width:100%;margin-top:5px}button{background:#e7f5ef;margin:5px;cursor:pointer;min-height:48px}button:focus-visible,input:focus-visible,select:focus-visible,a:focus-visible{outline:3px solid #047857;outline-offset:3px}button.primary{background:#047857;color:white}button:disabled{opacity:.5}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:0 20px}.sub{font-size:14px;color:#52695e;overflow-wrap:anywhere}#notice{position:sticky;top:0;padding:12px;background:#dcfce7;z-index:2;white-space:pre-wrap}.bad{color:#b91c1c}.source{border-top:1px solid #dde8e1;padding:12px 0}a{color:#047857}summary{cursor:pointer;min-height:40px}.hidden{display:none}pre{white-space:pre-wrap}button.danger{color:#b91c1c}</style></head>
<body><main><h1>落雪移动管理</h1><p class="sub">与客户端共享配置；设置保存后，新请求立即生效。手机与客户端须在同一局域网。</p><div id="notice" role="status">正在连接…</div><div id="app" class="hidden">
<section><h2>设备与服务</h2><p id="device" class="sub"></p><p id="service" class="sub"></p><button id="reload">重新读取</button><button id="ping">检测音乐服务器</button><button id="logout" class="danger">退出当前账号</button><button id="disconnect" class="danger">断开所有手机</button></section>
<section><h2>客户端全部设置</h2><form id="settings"><div class="grid" id="fields"></div><button type="submit" class="primary">保存设置</button></form><p class="sub">密码与 Token 留空表示保持原值；勾选“清空”才会删除。修改 Web 端口后请使用新的 IP:端口 地址；关闭服务后需在客户端重新开启。</p><button id="folder">浏览客户端目录 / 选择下载文件夹</button><div id="browser"></div></section>
<section><h2>JS 音源管理</h2><button id="sourcesReload">刷新音源</button><div id="sources"></div><h3>导入新音源</h3><input type="file" id="file" accept=".js"><label><input type="checkbox" id="unsafe"> 允许不安全 VM</label><button id="import" class="primary">校验并导入</button><p class="sub">从手机上传 JS 文件，校验与客户端相同，导入后默认停用。</p></section>
</div></main><script>
const q=s=>document.querySelector(s);let state={},csrf='',busy=false;
function note(s,bad=false){q('#notice').textContent=s;q('#notice').className=bad?'bad':''}
async function api(path,body){const r=await fetch(path,{method:body?'POST':'GET',headers:{'Content-Type':'application/json','X-Lx-CSRF':csrf},body:body?JSON.stringify(body):undefined});const d=await r.json();if(!r.ok||d.error)throw Error(d.error||'请求失败');return d}
async function run(fn){if(busy)return;busy=true;document.querySelectorAll('button').forEach(b=>b.disabled=true);try{await fn()}catch(e){note(e.message,true)}finally{busy=false;document.querySelectorAll('button').forEach(b=>b.disabled=false)}}
function field(item){const label=document.createElement('label');label.textContent=item.label;let e=document.createElement(item.options?'select':'input');e.id='f_'+item.key;e.dataset.key=item.key;if(item.options){item.options.forEach(([value,title])=>{const o=new Option(title,value);e.add(o)})}else e.type=item.secret?'password':item.kind==='int'?'number':'text';e.value=Array.isArray(item.value)?item.value.join(','):item.value;if(item.min!=null)e.min=item.min;if(item.max!=null)e.max=item.max;label.append(e);if(item.secret){e.placeholder=item.has_value?'已设置，留空保持':'未设置';const clear=document.createElement('input');clear.type='checkbox';clear.id='clear_'+item.key;label.append(clear,document.createTextNode(' 清空已保存的值'))}return label}
async function load(){state=await api('/api/state');csrf=state.csrf;q('#app').classList.remove('hidden');q('#fields').replaceChildren(...state.settings.map(field));q('#device').textContent='当前识别：'+state.device.detected_label+' · 生效：'+state.device.effective_label+' · '+state.device.reason;q('#service').textContent='端口 '+state.service.port+' · '+(state.service.running?'运行中':'已停止');note('已连接。')}
async function sources(){const d=await api('/api/sources');q('#sources').replaceChildren();if(!d.sources.length)q('#sources').textContent='暂无音源';d.sources.forEach(s=>{const row=document.createElement('div');row.className='source';const title=document.createElement('strong');title.textContent=(s.name||s.id)+' · '+(s.enabled?'已启用':'已停用');row.append(title);[['enable','启用'],['disable','停用'],['up','上移'],['down','下移'],['delete_confirm','删除']].forEach(([op,text])=>{const b=document.createElement('button');b.textContent=text;b.onclick=()=>run(async()=>{if(op==='delete_confirm'&&!confirm('确认永久删除音源 '+(s.name||s.id)+'？'))return;const r=await api('/api/source',{op,id:String(s.id),owner:s.owner||''});note(r.message);await sources()});row.append(b)});q('#sources').append(row)})}
async function browse(path){const d=await api('/api/browse?path='+encodeURIComponent(path||''));const root=q('#browser');root.replaceChildren();const p=document.createElement('p');p.textContent=d.path;root.append(p);const choose=document.createElement('button');choose.textContent='使用此目录（随后保存设置）';choose.onclick=()=>{q('#f_download_folder').value=d.path;note('已选择目录，请点击保存设置。')};root.append(choose);if(d.parent){const b=document.createElement('button');b.textContent='上级目录';b.onclick=()=>run(()=>browse(d.parent));root.append(b)}d.directories.forEach(x=>{const b=document.createElement('button');b.textContent=x.name;b.onclick=()=>run(()=>browse(x.path));root.append(b)});if(d.truncated){const p=document.createElement('p');p.textContent='目录较多，只显示前 300 项；也可直接填写完整路径。';root.append(p)}}
q('#settings').onsubmit=e=>{e.preventDefault();run(async()=>{const values={},clear=[];state.settings.forEach(f=>{const v=q('#f_'+f.key).value;if(f.secret){if(q('#clear_'+f.key).checked)clear.push(f.key);else if(v)values[f.key]=v}else values[f.key]=v});if(values.mobile_web_enabled==='false'&&!confirm('关闭 Web 服务后，需要在客户端重新开启。'))return;const d=await api('/api/settings',{revision:state.revision,values,clear});note(d.message);if(d.restart){q('#app').classList.add('hidden');note(d.message+' 端口更改后请用新的 IP:端口 访问；服务关闭后需在客户端重新开启。')}else {await load();note(d.message)}})};
q('#reload').onclick=()=>run(load);q('#sourcesReload').onclick=()=>run(sources);q('#folder').onclick=()=>run(()=>browse(q('#f_download_folder').value));q('#ping').onclick=()=>run(async()=>{note((await api('/api/check',{})).message)});
q('#logout').onclick=()=>run(async()=>{if(confirm('退出客户端当前账号？收藏和音源数据仍保留。')){await api('/api/logout',{});await load();note('已退出当前账号。')}});
q('#disconnect').onclick=()=>run(async()=>{if(confirm('断开包括本手机在内的所有连接？')){await api('/api/disconnect',{});q('#app').classList.add('hidden');note('已断开，重新打开保存的地址即可连接。')}});
q('#import').onclick=()=>run(async()=>{const file=q('#file').files[0];if(!file||!file.name.toLowerCase().endsWith('.js'))throw Error('请选择 .js 文件');if(file.size>5*1024*1024)throw Error('JS 文件不能超过 5 MB');const content=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(Error('文件读取失败'));reader.readAsText(file)});const d=await api('/api/import',{filename:file.name,content,unsafe:q('#unsafe').checked});note(d.message);await sources()});
run(async()=>{try{await load();await sources()}catch(e){note(e.message+'；请打开保存的 IP:端口 地址，或扫描客户端“音源管理 → 移动 Web”中的二维码。',true)}});
</script></body></html>'''


class LxMapper:
    """负责 lxserver 实体、Spider Vod 和自描述 ID 的相互转换。"""

    ID_PREFIX = "lxclient"

    @classmethod
    def pack(cls, kind, payload=None):
        raw = json.dumps(payload or {}, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        body = base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")
        return "%s:%s:%s" % (cls.ID_PREFIX, kind, body)

    @classmethod
    def unpack(cls, value):
        text = str(value or "")
        parts = text.split(":", 2)
        if len(parts) != 3 or parts[0] != cls.ID_PREFIX:
            return None
        try:
            body = parts[2] + "=" * (-len(parts[2]) % 4)
            data = json.loads(base64.urlsafe_b64decode(body.encode("ascii")).decode("utf-8"))
            return {"kind": parts[1], "data": data if isinstance(data, dict) else {}}
        except (ValueError, TypeError, UnicodeError):
            return None

    @staticmethod
    def text(value, fallback=""):
        if value is None or value == "":
            return fallback
        if isinstance(value, list):
            names = [LxMapper.text(item) for item in value]
            return "、".join(item for item in names if item) or fallback
        if isinstance(value, dict):
            for key in ("name", "title", "nickname", "singerName", "artistName", "author"):
                if value.get(key) not in (None, ""):
                    return LxMapper.text(value.get(key), fallback)
            return fallback
        return str(value)

    @staticmethod
    def first(item, keys, fallback=None):
        for key in keys:
            target = item
            for part in key.split("."):
                if not isinstance(target, dict):
                    target = None
                    break
                target = target.get(part)
            if target not in (None, ""):
                return target
        return fallback

    @classmethod
    def song(cls, raw, fallback_source=""):
        item = dict(raw or {})
        meta = item.get("meta")
        if isinstance(meta, dict):
            for key, value in meta.items():
                if item.get(key) in (None, ""):
                    item[key] = value
        source = cls.text(cls.first(item, ["source"], fallback_source))
        songmid = cls.text(cls.first(item, ["songmid", "songId", "id", "copyrightId", "hash"]))
        result = {
            "source": source,
            "songmid": songmid,
            "songId": cls.first(item, ["songId", "id"]),
            "name": cls.text(cls.first(item, ["name", "songName", "title"]), "未知歌曲"),
            "singer": cls.text(cls.first(item, ["singer", "artist", "author"]), "未知歌手"),
            "albumName": cls.text(cls.first(item, ["albumName", "album.name", "album"])),
            "albumId": cls.first(item, ["albumId", "album.id"]),
            "albumMid": cls.first(item, ["albumMid", "album.mid"]),
            "interval": cls.text(cls.first(item, ["interval", "duration"])),
            "img": cls.text(cls.first(item, ["img", "pic", "picUrl", "cover", "coverUrl"])),
            "hash": cls.first(item, ["hash"]),
            "strMediaMid": cls.first(item, ["strMediaMid"]),
            "copyrightId": cls.first(item, ["copyrightId"]),
            "lrcUrl": cls.first(item, ["lrcUrl"]),
            "mrcUrl": cls.first(item, ["mrcUrl"]),
            "trcUrl": cls.first(item, ["trcUrl"]),
            "types": item.get("types") if isinstance(item.get("types"), list) else [],
            "_types": item.get("_types") if isinstance(item.get("_types"), dict) else {},
            "typeUrl": item.get("typeUrl") if isinstance(item.get("typeUrl"), dict) else {},
        }
        if isinstance(meta, dict):
            result["meta"] = meta
        return result

    @classmethod
    def song_vod(cls, raw, fallback_source=""):
        song = cls.song(raw, fallback_source)
        remarks = " · ".join(item for item in (song["singer"], song["albumName"], song["interval"]) if item)
        return {
            "vod_id": cls.pack("song", song),
            "vod_name": song["name"],
            "vod_pic": song["img"],
            "vod_remarks": remarks,
            "vod_actor": song["singer"],
            "vod_content": remarks,
            "vod_player": "music",
            "style": {"type": "rect", "ratio": 1.0},
        }

    @classmethod
    def playlist_vod(cls, raw, fallback_source=""):
        item = dict(raw or {})
        source = cls.text(item.get("source"), fallback_source)
        playlist_id = cls.first(item, ["id", "sourceId", "playListId"])
        name = cls.text(cls.first(item, ["name", "title"]), "未命名歌单")
        pic = cls.text(cls.first(item, ["img", "pic", "picUrl", "cover", "coverUrl"]))
        author = cls.text(cls.first(item, ["author", "creator", "creator.nickname", "username", "userName"]))
        total = cls.first(item, ["total", "songCount", "trackCount", "count"], "")
        desc = cls.text(cls.first(item, ["desc", "description", "intro"]))
        payload = {
            "source": source,
            "id": playlist_id,
            "name": name,
            "pic": pic,
            "author": author,
            "desc": desc,
        }
        return {
            "vod_id": cls.pack("playlist", payload),
            "vod_name": name,
            "vod_pic": pic,
            "vod_remarks": " · ".join(item for item in (author, ("%s 首" % total) if total else "") if item),
            "vod_actor": author,
            "vod_content": desc,
            "vod_player": "music",
            "style": {"type": "rect", "ratio": 1.0},
        }

    @classmethod
    def board_vod(cls, raw, fallback_source=""):
        item = dict(raw or {})
        source = cls.text(item.get("source"), fallback_source)
        board_id = cls.first(item, ["bangid", "id", "sourceId"])
        if isinstance(board_id, str) and board_id.startswith(source + "__"):
            board_id = board_id[len(source) + 2:]
        name = cls.text(cls.first(item, ["name", "title"]), "未命名榜单")
        pic = cls.text(cls.first(item, ["img", "pic", "picUrl", "cover", "coverUrl"]))
        return cls.folder_vod("chart", {"source": source, "id": board_id, "name": name, "pic": pic}, name, pic, SOURCE_NAMES.get(source, source))

    @classmethod
    def album_vod(cls, raw, fallback_source=""):
        """增强的专辑转换，支持更多平台的数据格式"""
        item = dict(raw or {})
        source = cls.text(item.get("source"), fallback_source)
        
        # 更健壮的ID提取 - 支持多种字段名和嵌套结构
        album_id = (
            cls.first(item, ["id", "mid", "albumId", "album_id", "albumMid"]) or
            cls.first(item.get("album", {}), ["id", "mid", "albumId"]) or
            cls.first(item.get("info", {}), ["id", "albumId"]) or
            ""
        )
        
        # 处理腾讯音乐特殊前缀
        if source == "tx" and isinstance(album_id, str) and album_id.startswith("alb_tx_"):
            album_id = album_id[7:]
        
        # 更健壮的名称提取
        name = (
            cls.text(cls.first(item, ["name", "title", "album", "albumName"])) or
            cls.text(cls.first(item.get("album", {}), ["name", "title"])) or
            cls.text(cls.first(item.get("info", {}), ["name", "title"])) or
            cls.text(cls.first(item, ["songName"])) or
            "未命名专辑"
        )
        
        # 更健壮的封面提取
        pic = (
            cls.text(cls.first(item, ["img", "picUrl", "coverArt", "cover", "coverUrl", "pic"])) or
            cls.text(cls.first(item.get("album", {}), ["picUrl", "cover", "img"])) or
            cls.text(cls.first(item.get("info", {}), ["img", "picUrl"])) or
            cls.text(cls.first(item.get("cover", {}), ["url"])) or
            ""
        )
        
        # 更健壮的歌手提取
        singer = (
            cls.text(cls.first(item, ["singer", "artistName", "artist", "artists", "author"])) or
            cls.text(cls.first(item.get("album", {}), ["artistName", "artist", "singer"])) or
            cls.text(cls.first(item.get("info", {}), ["author", "singer"])) or
            ""
        )
        
        # 年份提取
        publish_time = (
            cls.first(item, ["publishTime", "created", "publish_date", "pubDate"]) or
            cls.first(item.get("info", {}), ["publishTime"])
        )
        year = ""
        try:
            if str(publish_time).isdigit() and len(str(publish_time)) >= 10:
                stamp = int(publish_time)
                if len(str(publish_time)) == 10:
                    stamp *= 1000
                year = time.strftime("%Y", time.localtime(stamp / 1000))
            elif publish_time:
                year = str(publish_time)[:4]
        except (ValueError, OSError, OverflowError):
            year = ""
        
        payload = {"source": source, "id": album_id, "name": name, "pic": pic, "singer": singer}
        
        return {
            "vod_id": cls.pack("album", payload),
            "vod_name": name,
            "vod_pic": pic,
            "vod_remarks": " · ".join(item for item in (singer, year) if item),
            "vod_actor": singer,
            "vod_year": year,
            "vod_player": "music",
            "style": {"type": "rect", "ratio": 1.0},
        }

    @classmethod
    def artist_vod(cls, raw, fallback_source=""):
        item = dict(raw or {})
        source = cls.text(item.get("source"), fallback_source)
        artist_id = cls.first(item, ["id", "mid", "artistId"])
        name = cls.text(cls.first(item, ["name", "artistName"]), "未知歌手")
        pic = cls.text(cls.first(item, ["picUrl", "img", "avatar", "pic"]))
        album_size = cls.first(item, ["albumSize", "albumNum"], "")
        remarks = ("%s 张专辑" % album_size) if album_size else SOURCE_NAMES.get(source, source)
        return cls.folder_vod("artist", {"source": source, "id": artist_id, "name": name, "pic": pic}, name, pic, remarks, circle=True)

    @classmethod
    def artist_from_song(cls, raw):
        song = cls.song(raw)
        return cls.folder_vod(
            "artist_query",
            {"name": song["singer"], "source": "wy", "pic": song["img"]},
            song["singer"],
            song["img"],
            "查看歌曲与专辑",
            circle=True,
        )

    @classmethod
    def folder_vod(cls, kind, payload, name, pic="", remarks="", circle=False):
        return {
            "vod_id": cls.pack(kind, payload),
            "vod_name": name,
            "vod_pic": pic,
            "vod_remarks": remarks,
            "vod_tag": "folder",
            "cate": {"land": 0 if circle else 1, "circle": 1 if circle else 0, "ratio": 1.0 if circle else 1.78},
        }

    @classmethod
    def action_vod(cls, name, config, remarks="", pic=""):
        return {
            "vod_id": json.dumps(config, ensure_ascii=False, separators=(",", ":")),
            "vod_name": name,
            "vod_pic": pic,
            "vod_remarks": remarks,
            "vod_tag": "action",
        }

    @staticmethod
    def clean_episode_name(value):
        return " ".join(str(value or "未知歌曲").replace("#", " ").replace("$", " ").split())

    @classmethod
    def music_detail(cls, entity, raw_songs, config):
        songs = []
        seen = set()
        for raw in raw_songs or []:
            song = cls.song(raw, entity.get("source", ""))
            key = "%s:%s" % (song.get("source"), song.get("songmid"))
            if not song.get("source") or not song.get("songmid") or key in seen:
                continue
            seen.add(key)
            songs.append(song)
        qualities = config.get("qualities") if isinstance(config.get("qualities"), list) else []
        qualities = [item for item in qualities if item in QUALITY_NAMES]
        preferred_quality = str(config.get("quality") or "320k")
        if preferred_quality in QUALITY_NAMES:
            qualities = [preferred_quality] + [item for item in qualities if item != preferred_quality]
        if not qualities:
            qualities = [preferred_quality if preferred_quality in QUALITY_NAMES else "320k"]

        play_from = []
        play_url = []
        for quality in qualities:
            episodes = []
            for song in songs:
                token = cls.pack("play", {"quality": quality, "song": song})
                episodes.append("%s$%s" % (cls.clean_episode_name(song["name"]), token))
            if episodes:
                play_from.append(QUALITY_NAMES.get(quality, quality))
                play_url.append("#".join(episodes))

        # 添加"下载"选项 - 使用 "download" 标记，音质由下载设置决定
        if songs:
            download_episodes = []
            for song in songs:
                token = cls.pack("play", {"quality": "download", "song": song})
                download_episodes.append("%s$%s" % (cls.clean_episode_name(song["name"]), token))
            if download_episodes:
                play_from.append("📥 下载")
                play_url.append("#".join(download_episodes))

        return {
            "vod_id": entity.get("id", ""),
            "vod_name": entity.get("name") or (songs[0]["name"] if songs else "洛雪音乐"),
            "vod_pic": entity.get("pic") or (songs[0]["img"] if songs else ""),
            "vod_remarks": entity.get("remarks") or ("%s 首歌曲" % len(songs)),
            "vod_actor": entity.get("singer") or (songs[0]["singer"] if songs else ""),
            "vod_content": entity.get("content") or entity.get("remarks") or "",
            "vod_play_from": "$$$".join(play_from),
            "vod_play_url": "$$$".join(play_url),
            "vod_player": "music",
        }


class LxHomeLayoutBuilder:
    """构建云雾白底与祖母绿点缀的 HomeUI v4 音乐主题。"""

    def __init__(self, base_url):
        self.base_url = base_url.rstrip("/") + "/"

    @staticmethod
    def _node(node_id, node_type, classes=None, source="", title="", subtitle="",
              items=None, attributes=None, slot="", action="", children=None, icon=None,
              states=None):
        node = {"id": node_id, "type": node_type}
        if classes:
            node["classes"] = classes
        if source:
            node["source"] = source
        if title:
            node["title"] = title
        if subtitle:
            node["subtitle"] = subtitle
        if items is not None:
            node["list"] = list(items)[:60]
        if attributes:
            node["attributes"] = {str(key): str(value) for key, value in attributes.items()}
        if slot:
            node["slot"] = slot
        if action:
            node["action"] = action
        if children is not None:
            node["children"] = children
        if icon is not None:
            node["icon"] = icon
        if states:
            node["states"] = states
        return node

    @staticmethod
    def _navigation_items(prefix=""):
        """统一生成可自定义激活色/激活图标的点播底部或 TV 侧栏入口。"""
        values = [
            ("vod", "点播", "music", "lx-vod", True),
            ("live", "直播", "live", "lx-live", False),
            ("setting", "设置", "settings", "lx-settings", False),
        ]
        result = []
        for key, title, icon, action, selected in values:
            result.append({
                "id": "%s-%s" % (prefix, key) if prefix else key,
                "type": "action_button",
                "classes": ["lx-tab"],
                "text": title,
                "icon": {"name": icon, "active_name": icon,
                         "tint": "#FF6B7280", "active_tint": "#FF059669"},
                "action": action,
                "attributes": {"role": "tab", "selected": "true" if selected else "false"},
                "states": {
                    "selected": {"color": "#FF059669", "icon-color": "#FF059669",
                                  "background": "#1910B981"},
                    "focused": {"color": "#FF059669", "icon-color": "#FF059669"},
                },
            })
        return result

    def _shortcuts(self, data):
        web_action = LxMapper.action_vod("洛雪网页", {
            "actionId": "lx_open_web",
            "type": "webview",
            "title": "洛雪音乐",
            "url": self.base_url,
            "height": -80,
            "textZoom": 90,
        }, "打开本机 lxserver")
        import_action = LxMapper.action_vod("导入音源", {
            "actionId": "lx_import_source",
            "type": "multiInput",
            "title": "导入 JS 音源",
            "msg": "选择本地 JS 文件，校验后上传到 lxserver。",
            "input": [
                {"id": "file", "name": "JS 音源文件", "tip": "请选择 .js 文件", "value": "", "selectData": "[file]"},
                {"id": "unsafe", "name": "允许不安全 VM", "tip": "一般保持否", "value": "否", "selectData": "否:=否,是:=是"},
            ],
        }, "选择本地 JS 文件")
        settings_action = LxMapper.action_vod("连接设置", {
            "actionId": "lx_connection_settings",
            "type": "multiInput",
            "title": "lxserver 连接设置",
            "msg": "设置会保存到当前站点，重新打开后仍然生效。",
            "input": data.get("settings_inputs") or [],
        }, "服务器地址、用户与默认平台")
        return [
            web_action,
            LxMapper.folder_vod("shortcut", {"target": "charts"}, "排行榜", "", "多平台榜单"),
            LxMapper.folder_vod("shortcut", {"target": "playlists"}, "歌单广场", "", "发现新歌单"),
            LxMapper.folder_vod("shortcut", {"target": "favorites"}, "我的收藏", "", "歌曲、专辑、歌手"),
            LxMapper.folder_vod("shortcut", {"target": "sources"}, "音源管理", "", "启停、排序与删除"),
            import_action,
            settings_action,
        ]

    @staticmethod
    def _css():
        return """
:root{--accent:#FF10B981;--accent-strong:#FF047857;--page:#FFFCFDFC;--panel:#FFFFFFFF;--soft:#FFF1F9F6;--hover:#FFF5FAF8;--text:#FF173129;--muted:#FF64766E;--line:#FFE5EFEB}
page{display:flex;color:var(--text);background:transparent;font-family:sans;font-size:13sp}
.lx-header{color:var(--text);font-size:17sp;font-weight:700;background:transparent}
.lx-nav,.lx-player{background:#EFFFFFFF;background-blur:18dp;border-color:var(--line)}
.lx-feed{display:flex;flex-direction:column;padding:10dp 14dp 154dp}
.lx-status{margin-top:4dp;margin-bottom:6dp;padding-inline:18dp;padding-block:15dp;section-radius:22dp;section-background:linear-gradient(135deg,#FF10B981,#FF047857);section-border:0dp solid transparent;color:#FFFFFFFF;heading-color:#FFFFFFFF;heading-size:22sp;heading-weight:700;meta-color:#E6FFFFFF;meta-font-size:13sp;meta-weight:normal;box-shadow:0dp 12dp 30dp #2410B981;animation:lx-enter 420ms ease-out both}
.lx-section{margin-top:4dp;margin-bottom:4dp;padding-inline:0dp;padding-top:0dp;padding-bottom:0dp;section-background:transparent;section-border:0dp solid transparent;heading-color:var(--text);heading-size:18sp;heading-weight:700;color:var(--text);font-size:13sp;font-weight:600;meta-color:var(--muted);meta-font-size:11sp;meta-weight:normal;title-lines:1;meta-lines:1}
.lx-shortcuts{orientation:horizontal;viewport-count:2.65;gap:8dp;item-height:64dp;item-ratio:2.7;card-padding:7dp;card-radius:16dp;card-background:var(--panel);card-border:1dp solid var(--line);show-meta:false;font-size:12sp}
.lx-hero{item-ratio:1.78;card-radius:20dp;card-background:transparent;card-border:0dp solid transparent;color:#FFFFFFFF;heading-color:var(--text);font-size:14sp;meta-color:#E8FFFFFF;meta-font-size:11sp;background-dim:.76;box-shadow:0dp 12dp 28dp #2010B981}
.lx-hot{orientation:horizontal;viewport-count:3.05;gap:8dp;item-height:42dp;item-ratio:3.6;card-padding:9dp;card-radius:999dp;card-background:var(--soft);card-border:1dp solid #FFD5EEE5;color:#FF176B55;font-size:12sp;show-image:false;show-meta:false;title-lines:1}
.lx-hot:selected{color:#FFFFFFFF;card-background:var(--accent)}
.lx-albums{orientation:horizontal;viewport-count:2.75;gap:12dp;item-ratio:1;card-padding:0dp;card-radius:14dp;card-background:transparent;card-border:0dp solid transparent;font-size:12sp;meta-font-size:10sp}
.lx-songs{orientation:horizontal;rows:4;viewport-count:1;gap:7dp;item-height:66dp;item-ratio:5.2;card-padding:7dp;card-radius:14dp;card-background:var(--panel);card-border:1dp solid var(--line);font-size:13sp;meta-font-size:10sp}
.lx-artists{orientation:horizontal;viewport-count:4.15;gap:12dp;item-ratio:1;card-padding:0dp;card-radius:999dp;card-background:transparent;card-border:0dp solid transparent;clip-shape:circle;text-align:center;font-size:11sp;show-meta:false}
.lx-ranking{orientation:horizontal;rows:3;viewport-count:1;gap:7dp;item-height:66dp;item-ratio:5;card-padding:7dp;card-radius:14dp;card-background:var(--panel);card-border:1dp solid var(--line);rank-font-size:14sp;font-size:13sp;meta-font-size:10sp}
.lx-bento{display:grid;grid-columns:2;grid-rows:3;gap:12dp;item-ratio:1;card-radius:16dp;card-background:var(--panel);card-border:1dp solid var(--line);mosaic-spans:2x2,1x1,1x1,2x1}
.lx-tab{color:#FF6B7280;icon-color:#FF6B7280;font-size:11sp;border-radius:18dp;transition:background 180ms ease-out,color 180ms ease-out,scale 160ms ease-out}
.lx-tab:selected{color:var(--accent-strong);icon-color:var(--accent-strong);background:#1910B981;scale:1.03}
.lx-player{position:fixed;left:14dp;right:14dp;bottom:84dp;height:60dp;border-radius:18dp;color:var(--text);box-shadow:0dp 10dp 26dp #1F10B981;z-index:24}
.lx-player:playing{color:var(--accent);icon-color:var(--accent);animation:lx-breathe 1500ms ease-in-out infinite}
.card:pressed{scale:.97;opacity:.88}
@media (orientation:landscape) and (max-width:959dp){.lx-feed{padding-left:94dp;padding-right:22dp}.lx-nav{orientation:vertical;position:fixed;left:10dp;top:72dp;bottom:14dp;width:70dp;border-radius:22dp}.lx-player{left:94dp;bottom:16dp}.lx-shortcuts{viewport-count:4.2}.lx-albums{viewport-count:5.2}.lx-artists{viewport-count:7.2}}
@media (tv){.lx-feed{padding:34dp 68dp 118dp 180dp}.lx-section{heading-size:26sp;font-size:18sp;meta-font-size:14sp}.lx-nav{orientation:vertical;position:fixed;left:34dp;top:96dp;bottom:34dp;width:110dp;border-radius:28dp}.lx-hero{item-ratio:2.5}.lx-albums{viewport-count:6.2;gap:20dp}.lx-songs{rows:3;viewport-count:2;gap:12dp;item-height:88dp}.lx-ranking{rows:2;viewport-count:3;item-height:88dp}.lx-artists{viewport-count:8.2}.lx-bento{grid-columns:6;grid-rows:2;gap:20dp}.lx-player{left:180dp;right:68dp;bottom:28dp;height:76dp}.card:focused{scale:1.06;border:3dp solid var(--accent);elevation:14dp}}
@media (prefers-reduced-motion:reduce){.card,.lx-tab,.lx-status,.lx-player{animation:none;transition:none}}
""".strip()

    def build(self, data):
        songs = (data.get("songs") or [])[:24]
        playlists = (data.get("playlists") or [])[:18]
        albums = (data.get("albums") or [])[:16]
        artists = (data.get("artists") or [])[:16]
        boards = (data.get("boards") or [])[:14]
        hot = (data.get("hot") or [])[:18]
        favorite_songs = (data.get("favorite_songs") or [])[:18]
        favorite_albums = (data.get("favorite_albums") or [])[:14]
        favorite_artists = (data.get("favorite_artists") or [])[:14]
        shortcuts = self._shortcuts(data)
        server_text = "已连接 lxserver · 发现你的下一首歌" if data.get("server_ok") else "尚未连接 lxserver · 请检查连接设置"

        mobile_content = [
            self._node("lx-mobile-status", "headline", ["lx-status"], title="洛雪音乐",
                       subtitle=server_text),
            self._node("lx-mobile-shortcuts", "shortcuts", ["lx-section", "lx-shortcuts"], source="inline",
                       title="音乐控制台", items=shortcuts, attributes={"limit": 7, "show-meta": "false"}),
            self._node("lx-mobile-hero", "spotlight", ["lx-section", "lx-hero"], source="inline",
                       title="现在流行",
                       items=songs[:5], attributes={"limit": 5, "autoplay-ms": 6500,
                                                   "show-indicator": "true",
                                                   "wallpaper-source": "selected-media"}),
            self._node("lx-mobile-hot", "chip_cloud", ["lx-section", "lx-hot"], source="inline",
                       title="大家都在搜", items=hot,
                       attributes={"limit": 18, "show-meta": "false"}),
            self._node("lx-mobile-favorites", "song_list", ["lx-section", "lx-songs"], source="inline",
                       title="我喜欢的音乐", subtitle="直接读取 lxserver 收藏",
                       items=favorite_songs, attributes={"limit": 18, "empty-text": "收藏歌曲后会出现在这里"}),
            self._node("lx-mobile-playlists", "album_shelf", ["lx-section", "lx-albums"], source="inline",
                       title="精选歌单", items=playlists, attributes={"limit": 18, "show-meta": "true"}),
            self._node("lx-mobile-albums", "cover_flow", ["lx-section", "lx-albums"], source="inline",
                       title="专辑唱片架", items=favorite_albums + albums,
                       attributes={"limit": 18, "show-meta": "true"}),
            self._node("lx-mobile-artists", "artist_rail", ["lx-section", "lx-artists"], source="inline",
                       title="热门音乐人", items=favorite_artists + artists,
                       attributes={"limit": 16}),
            self._node("lx-mobile-songs", "song_list", ["lx-section", "lx-songs"], source="inline",
                       title="热歌速递", items=songs[5:] or songs,
                       attributes={"limit": 18, "show-badge": "true"}),
            self._node("lx-mobile-ranking", "ranking", ["lx-section", "lx-ranking"], source="inline",
                       title="在线排行榜", items=boards, attributes={"limit": 14})
        ]

        tv_content = [
            self._node("lx-tv-status", "headline", ["lx-status"], title="LX MUSIC SERVER",
                       subtitle=server_text),
            self._node("lx-tv-hero", "hero", ["lx-hero"], source="inline",
                       title="今晚播放", items=songs[:6],
                       attributes={"limit": 6, "wallpaper-source": "focused-media"}),
            self._node("lx-tv-bento", "bento_grid", ["lx-bento"], source="inline",
                       title="精选歌单", items=playlists[:10],
                       attributes={"limit": 10, "wallpaper-source": "focused-media"}),
            self._node("lx-tv-favorites", "song_list", ["lx-songs"], source="inline",
                       title="我喜欢的音乐", items=favorite_songs,
                       attributes={"limit": 18, "empty-text": "暂无收藏歌曲"}),
            self._node("lx-tv-albums", "album_shelf", ["lx-albums"], source="inline",
                       title="专辑唱片架", items=favorite_albums + albums,
                       attributes={"limit": 18}),
            self._node("lx-tv-ranking", "ranking", ["lx-ranking"], source="inline",
                       title="多平台榜单", items=boards, attributes={"limit": 14}),
            self._node("lx-tv-artists", "artist_rail", ["lx-artists"], source="inline",
                       title="音乐人", items=favorite_artists + artists, attributes={"limit": 16})
        ]

        actions = [
            {"id": "lx-vod", "command": "system.vod"},
            {"id": "lx-search", "command": "system.search"},
            {"id": "lx-settings", "command": "system.settings"},
            {"id": "lx-live", "command": "system.live"},
            {"id": "lx-site", "command": "system.site"},
            {"id": "lx-history", "command": "system.history"},
            {"id": "lx-favorite", "command": "system.favorite"},
            {"id": "lx-player-open", "command": "player.open"},
            {"id": "lx-player-toggle", "command": "player.play_pause"},
            {"id": "lx-player-prev", "command": "player.previous"},
            {"id": "lx-player-next", "command": "player.next"},
        ]

        theme = {
            "name": "lx-cloud-emerald", "mode": "light",
            "variables": {
                "--accent": "#FF10B981", "--accent-strong": "#FF059669",
                "--page": "#FFFCFDFC", "--panel": "#FFFFFFFF",
                "--mist": "#FFF1F9F6",
            },
            "properties": {"font-family": "rounded", "content-max-width": "1760dp"},
            "backgrounds": [
                {"type": "solid", "color": "#FFFCFDFC", "media": "light"},
                {"type": "gradient", "color": "#FFFFFFFF", "color_end": "#FFEEF7F4",
                 "angle": 145, "opacity": 0.48, "media": "light"},
                {"type": "gradient", "color": "#FFF4FBF9", "color_end": "#FFFFFFFF",
                 "angle": 28, "opacity": 0.38, "media": "light"},
                {"type": "gradient", "color": "#FFF3F6FC", "color_end": "#FFFFFFFF",
                 "angle": 315, "opacity": 0.28, "media": "light"},
            ],
        }

        return {
            "version": 4,
            "document": {
                "id": "lx-emerald-player",
                "default_profile": "mobile",
                "variables": {
                    "--accent": "#FF10B981", "--accent-strong": "#FF059669",
                    "--page": "#FFFCFDFC", "--panel": "#FFFFFFFF",
                    "--hover": "#FFF5FAF8", "--text": "#FF173129",
                    "--muted": "#FF64766E", "--line": "#FFE5EFEB",
                },
                "theme": theme,
                "shell": {
                    "edge_to_edge": True,
                    "status_bar": {"visible": True, "style": "auto", "color": "#00FFFFFF"},
                    "navigation_bar": {"visible": True, "style": "auto", "color": "#F8FFFFFF"},
                    "backgrounds": [],
                },
                "styles": {
                    "css": self._css(),
                    "keyframes": [
                        {"name": "lx-enter", "frames": [
                            {"offset": "from", "declarations": {
                                "opacity": "0", "translate-y": "14dp", "scale": ".98"}},
                            {"offset": "to", "declarations": {
                                "opacity": "1", "translate-y": "0dp", "scale": "1"}},
                        ]},
                        {"name": "lx-breathe", "frames": [
                            {"offset": "0%", "declarations": {"opacity": ".78", "scale": ".99"}},
                            {"offset": "50%", "declarations": {"opacity": "1", "scale": "1.03"}},
                            {"offset": "100%", "declarations": {"opacity": ".78", "scale": ".99"}},
                        ]},
                    ],
                },
                "motion": {
                    "enabled": True,
                    "transitions": [
                        {"selector": ".card", "property": "scale",
                         "duration_ms": 180, "easing": "ease-out"},
                        {"selector": ".lx-player", "property": "background",
                         "duration_ms": 420, "easing": "ease-in-out"},
                    ],
                },
                "actions": actions,
                "profiles": {
                    "mobile": {
                        "enabled": True,
                        "canvas": {
                            "edge_to_edge": True, "clip_to_bounds": False,
                            "safe_area": "system", "backgrounds": [],
                        },
                        "chrome": {
                            "top": {
                                "enabled": True, "height": 58, "position": "sticky",
                                "logo": {"name": "music", "tint": "#FF10B981",
                                         "active_tint": "#FF059669"},
                                "title": "洛雪音乐",
                                "items": [
                                    {"id": "lx-mobile-search-item", "title": "搜索",
                                     "icon": {"name": "search", "tint": "#FF4B5563"},
                                     "action": "lx-search"},
                                    {"id": "lx-mobile-settings-item", "title": "设置",
                                     "icon": {"name": "settings", "tint": "#FF4B5563"},
                                     "action": "lx-settings"},
                                ],
                                "backgrounds": [{"type": "solid", "color": "#EFFFFFFF",
                                                 "opacity": 0.94}],
                            },
                            "bottom": {
                                "enabled": True, "height": 72, "position": "fixed",
                                "backgrounds": [{"type": "solid", "color": "#EFFFFFFF",
                                                 "opacity": 0.94}],
                            },
                            "floating": {
                                "enabled": True, "height": 70, "position": "fixed",
                                "backgrounds": [],
                            },
                        },
                        "nodes": [
                            self._node("lx-mobile-page", "page", children=[
                                self._node("lx-mobile-header", "top_bar", ["lx-header"],
                                           slot="top"),
                                self._node("lx-mobile-feed", "container", ["lx-feed"],
                                           slot="content", children=mobile_content),
                                self._node("lx-mobile-player", "mini_player", ["lx-player"],
                                           slot="floating", action="lx-player-open",
                                           attributes={"wallpaper-source": "playing-media",
                                                       "empty-text": "选择一首歌开始播放"}),
                                self._node("lx-mobile-nav", "bottom_tabs", ["lx-nav", "lx-tab"],
                                           slot="bottom", attributes={"role": "tablist"},
                                           children=self._navigation_items()),
                            ])
                        ],
                    },
                    "tv": {
                        "enabled": True,
                        "canvas": {
                            "edge_to_edge": True, "clip_to_bounds": False,
                            "safe_area": "system", "backgrounds": [],
                        },
                        "chrome": {
                            "top": {
                                "enabled": True, "height": 76, "position": "sticky",
                                "logo": {"name": "music", "tint": "#FF10B981"},
                                "title": "洛雪音乐",
                                "items": [
                                    {"id": "lx-tv-search-item", "title": "搜索",
                                     "icon": {"name": "search", "tint": "#FF4B5563"},
                                     "action": "lx-search"},
                                    {"id": "lx-tv-settings-item", "title": "设置",
                                     "icon": {"name": "settings", "tint": "#FF4B5563"},
                                     "action": "lx-settings"},
                                ],
                                "backgrounds": [{"type": "solid", "color": "#EFFFFFFF",
                                                 "opacity": 0.94}],
                            },
                            "bottom": {"enabled": False},
                            "floating": {
                                "enabled": True, "height": 84, "position": "fixed",
                                "backgrounds": [],
                            },
                        },
                        "nodes": [
                            self._node("lx-tv-page", "page", children=[
                                self._node("lx-tv-header", "top_bar", ["lx-header"],
                                           slot="top"),
                                self._node("lx-tv-nav", "side_tabs", ["lx-nav", "lx-tab"],
                                           slot="bottom", attributes={"role": "tablist"},
                                           children=self._navigation_items("lx-tv")),
                                self._node("lx-tv-feed", "container", ["lx-feed"],
                                           slot="content", children=tv_content),
                                self._node("lx-tv-player", "mini_player", ["lx-player"],
                                           slot="floating", action="lx-player-open",
                                           attributes={"wallpaper-source": "playing-media",
                                                       "empty-text": "暂无播放"}),
                            ])
                        ],
                    },
                },
            },
        }


class Spider(BaseSpider):
    """ys Spider 入口。"""

    def __init__(self):
        super().__init__()
        self.config = deepcopy(DEFAULT_CONFIG)
        self.client = LxHttpClient(self.config)
        self.settings_path = ""
        self.home_cache = None
        self.home_cache_at = 0
        self._settings_lock = threading.RLock()
        self._device_profile_cache = None
        self._mobile_service = None
        self._mobile_service_error = ''
        self._retired_clients = []
        self._native_dialogs = []
        self._ui_callbacks = []
        self.search_keyword = ""
        self.search_source = ""  # 搜索时选中的平台

    def getName(self):
        return "洛雪音乐"

    def init(self, extend=""):
        self.settings_path = self._settings_path()
        options = self._parse_options(extend)
        options.update(self._load_settings())
        self._apply_options(options)
        self._sync_mobile_service()

    def _settings_path(self):
        """按站点隔离配置文件，Android 使用应用私有 filesDir。"""
        site_key = str(getattr(self, "siteKey", "") or self.getName() or "lxclient")
        digest = hashlib.sha256(site_key.encode("utf-8")).hexdigest()[:20]
        root = os.environ.get("YS_LXCLIENT_CONFIG_DIR", "").strip()
        if not root:
            try:
                from com.chaquo.python import Python
                root = str(Python.getPlatform().getApplication().getFilesDir().getAbsolutePath())
            except Exception:
                root = os.path.join(os.path.expanduser("~"), ".ys")
        return os.path.join(root, "lxclient", "config-%s.json" % digest)

    def _load_settings(self):
        if not self.settings_path or not os.path.isfile(self.settings_path):
            return {}
        try:
            if os.path.getsize(self.settings_path) > 256 * 1024:
                return {}
            with open(self.settings_path, "r", encoding="utf-8") as settings_file:
                data = json.load(settings_file)
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError, TypeError):
            return {}

    def _save_settings(self):
        with self._settings_lock:
            return self._save_settings_locked()

    def _save_settings_locked(self):
        if not self.settings_path:
            return False
        directory = os.path.dirname(self.settings_path)
        temporary = self.settings_path + ".tmp"
        try:
            os.makedirs(directory, exist_ok=True)
            with open(temporary, "w", encoding="utf-8") as settings_file:
                json.dump(self.config, settings_file, ensure_ascii=False, separators=(",", ":"))
                settings_file.flush()
                try:
                    os.fsync(settings_file.fileno())
                except OSError:
                    pass
            os.replace(temporary, self.settings_path)
            return True
        except (OSError, TypeError, ValueError):
            try:
                if os.path.exists(temporary):
                    os.remove(temporary)
            except OSError:
                pass
            return False

    @staticmethod
    def _parse_options(value):
        if isinstance(value, dict):
            return value
        if not value:
            return {}
        try:
            data = json.loads(str(value))
            return data if isinstance(data, dict) else {}
        except (ValueError, TypeError):
            return {"base_url": str(value)} if str(value).startswith("http") else {}

    @staticmethod
    def _list_value(value, fallback):
        if isinstance(value, list):
            return [str(item).strip() for item in value if str(item).strip()]
        if isinstance(value, str):
            result = [item.strip() for item in value.split(",") if item.strip()]
            return result or fallback
        return fallback

    def _apply_options(self, options):
        aliases = {"server": "base_url", "url": "base_url", "user": "username", "token": "api_token"}
        normalized = dict(options or {})
        for source_key, target_key in aliases.items():
            if source_key in normalized and target_key not in normalized:
                normalized[target_key] = normalized[source_key]
        for key in DEFAULT_CONFIG:
            if key in normalized:
                self.config[key] = normalized[key]
        if self.config.get("device_mode") not in dict(_DEVICE_OPTIONS):
            self.config["device_mode"] = "auto"
        try:
            self.config["mobile_web_enabled"] = self._config_bool(self.config.get("mobile_web_enabled", True))
        except ValueError:
            self.config["mobile_web_enabled"] = True
        self.config["mobile_web_port"] = LxHttpClient._positive_int(self.config.get("mobile_web_port"), 40012, 1024, 65535)
        self.config["sources"] = self._list_value(self.config.get("sources"), DEFAULT_CONFIG["sources"])
        self.config["qualities"] = self._list_value(self.config.get("qualities"), DEFAULT_CONFIG["qualities"])
        self.config["base_url"] = str(self.config.get("base_url") or DEFAULT_CONFIG["base_url"]).rstrip("/")
        self._retired_clients.append(self.client)
        self.client = LxHttpClient(self.config)
        self.home_cache = None
        self.home_cache_at = 0

    def _settings_inputs(self):
        return [
            {"id": "base_url", "name": "服务器地址", "tip": "例如 http://127.0.0.1:9527", "value": self.config["base_url"]},
            {"id": "username", "name": "用户名", "tip": "用于收藏和私有音源", "value": str(self.config.get("username") or "")},
            {"id": "password", "name": "用户密码", "tip": "用于换取临时 Token", "value": str(self.config.get("password") or ""), "inputType": 129},
            {"id": "api_token", "name": "已有 Token", "tip": "可选，填写后优先使用；留空则自动登录", "value": str(self.config.get("api_token") or ""), "inputType": 129},
            {"id": "admin_password", "name": "管理密码", "tip": "管理公开音源或 unsafe VM", "value": str(self.config.get("admin_password") or ""), "inputType": 129},
            {"id": "source", "name": "默认歌曲平台", "value": str(self.config.get("source") or "kw"), "selectData": "酷我:=kw,酷狗:=kg,QQ:=tx,网易:=wy,咪咕:=mg"},
            {"id": "playlist_source", "name": "首页歌单平台", "value": str(self.config.get("playlist_source") or "wy"), "selectData": "网易:=wy,QQ:=tx,酷我:=kw,酷狗:=kg,咪咕:=mg"},
            {"id": "quality", "name": "默认音质", "value": str(self.config.get("quality") or "320k"), "selectData": "标准:=128k,高品:=320k,无损:=flac,Hi-Res:=flac24bit"},
            {"id": "download_folder", "name": "下载文件夹", "tip": "选择歌曲下载保存位置", "value": str(self.config.get("download_folder") or ""), "selectData": "[folder]"},
            {"id": "download_quality", "name": "下载音质", "value": str(self.config.get("download_quality") or "320k"), "selectData": "标准:=128k,高品:=320k,无损:=flac,Hi-Res:=flac24bit"},
            {"id": "auto_download", "name": "自动下载", "value": str(self.config.get("auto_download") or "否"), "selectData": "否:=否,是:=是"},
        ]

    @staticmethod
    def _source_values():
        return [{"n": name, "v": source} for source, name in SOURCE_NAMES.items()]

    def _classes(self):
        return [
            {"type_id": "song_search", "type_name": "搜索歌曲", "type_flag": "1", "land": 1, "ratio": 1.78},
            {"type_id": "charts", "type_name": "排行榜", "type_flag": "1", "land": 1, "ratio": 1.78},
            {"type_id": "playlists", "type_name": "歌单广场", "land": 1, "ratio": 1.0},
            {"type_id": "local_songs", "type_name": "🎵 本地歌曲", "land": 1, "ratio": 1.0},
            {"type_id": "favorites", "type_name": "我的收藏", "type_flag": "1", "land": 1, "ratio": 1.0},
            {"type_id": "account", "type_name": "用户账号", "type_flag": "1", "land": 1, "ratio": 1.78},
            {"type_id": "sources", "type_name": "音源管理", "type_flag": "1", "land": 1, "ratio": 1.78},
        ]

    def _filters(self):
        """筛选器配置 - song_search 的筛选器必须配置正确"""
        return {
            "charts": [{
                "key": "source", "name": "平台", "init": str(self.config.get("source") or "kw"),
                "value": self._source_values(),
            }],
            "playlists": [
                {
                    "key": "source", "name": "平台", "init": str(self.config.get("source") or "kw"),
                    "value": self._source_values(),
                },
                {
                    "key": "sort", "name": "排序", "init": "hot",
                    "value": [{"n": "最热", "v": "hot"}, {"n": "最新", "v": "new"}, {"n": "推荐", "v": "recommend"}],
                },
                {
                    "key": "tag", "name": "标签", "init": "",
                    "value": [
                        {"n": "全部", "v": ""}, {"n": "华语", "v": "华语"}, {"n": "欧美", "v": "欧美"},
                        {"n": "流行", "v": "流行"}, {"n": "摇滚", "v": "摇滚"}, {"n": "民谣", "v": "民谣"},
                        {"n": "电子", "v": "电子"}, {"n": "轻音乐", "v": "轻音乐"}, {"n": "ACG", "v": "ACG"},
                    ],
                },
            ],
            "local_songs": [
                {
                    "key": "delete_mode", "name": "删除模式", "init": "off",
                    "value": [{"n": "🔒 关闭", "v": "off"}, {"n": "🗑️ 开启删除", "v": "on"}],
                }
            ],
            "song_search": [
                {
                    "key": "source", 
                    "name": "平台", 
                    "init": str(self.config.get("source") or "kw"),
                    "value": self._source_values(),
                }
            ],
        }

    @staticmethod
    def _extract_list(data):
        if isinstance(data, list):
            return data
        if isinstance(data, dict) and isinstance(data.get("list"), list):
            return data["list"]
        return []

    def _favorites(self):
        result = {"songs": [], "albums": [], "artists": [], "user_lists": [], "error": ""}
        try:
            user_data = self.client.user_data()
            result["songs"] = user_data.get("loveList") if isinstance(user_data.get("loveList"), list) else []
            result["user_lists"] = user_data.get("userList") if isinstance(user_data.get("userList"), list) else []
            result["albums"] = self.client.favorite_albums()
            result["artists"] = self.client.favorite_artists()
        except LxClientError as error:
            result["error"] = str(error)
        return result

    @staticmethod
    def _page_number(value):
        try:
            return max(int(value or 1), 1)
        except (TypeError, ValueError):
            return 1

    def _load_home(self, force=False):
        ttl = LxHttpClient._positive_int(self.config.get("home_ttl"), 180, 30, 3600)
        if not force and self.home_cache and time.time() - self.home_cache_at < ttl:
            return self.home_cache
        data = {
            "server_ok": False,
            "playlists": [],
            "songs": [],
            "albums": [],
            "artists": [],
            "boards": [],
            "hot": [],
            "favorite_songs": [],
            "favorite_albums": [],
            "favorite_artists": [],
            "favorite_user_lists": [],
            "settings_inputs": self._settings_inputs(),
            "error": "",
        }
        try:
            self.client.ping()
            data["server_ok"] = True
        except LxClientError as error:
            data["error"] = str(error)
            self.home_cache = data
            self.home_cache_at = time.time()
            return data

        errors = []
        playlist_source = str(self.config.get("playlist_source") or "wy")
        try:
            raw_playlists = self.client.playlist_list(
                playlist_source,
                SORT_IDS.get(playlist_source, {}).get("hot", "hot"),
                "",
                1,
            )
            data["playlists"] = [LxMapper.playlist_vod(item, playlist_source) for item in self._extract_list(raw_playlists)[:15]]
        except LxClientError as error:
            errors.append("歌单: %s" % error)

        board_source = str(self.config.get("source") or "kw")
        board_items = []
        try:
            raw_boards = self.client.leaderboard_boards(board_source)
            board_items = self._extract_list(raw_boards)
            data["boards"] = [LxMapper.board_vod(item, board_source) for item in board_items[:12]]
        except LxClientError as error:
            errors.append("榜单: %s" % error)

        if board_items:
            board_id = LxMapper.first(board_items[0], ["bangid", "id"])
            if isinstance(board_id, str) and board_id.startswith(board_source + "__"):
                board_id = board_id[len(board_source) + 2:]
            song_items = []
            try:
                raw_songs = self.client.leaderboard_list(board_source, board_id, 1)
                song_items = self._extract_list(raw_songs)[:24]
                data["songs"] = [LxMapper.song_vod(item, board_source) for item in song_items]
            except LxClientError as error:
                errors.append("榜单歌曲: %s" % error)

            seen_artists = set()
            artists = []
            for item in song_items:
                name = LxMapper.song(item, board_source).get("singer")
                if not name or name in seen_artists:
                    continue
                seen_artists.add(name)
                artists.append(LxMapper.artist_from_song(item))
                if len(artists) >= 12:
                    break
            data["artists"] = artists

            album_keyword = LxMapper.song(song_items[0], board_source).get("singer") if song_items else "周杰伦"
            album_source = str(self.config.get("album_source") or "wy")
            try:
                raw_albums = self.client.search(album_source, album_keyword, "album", 1, 12)
                data["albums"] = [LxMapper.album_vod(item, album_source) for item in raw_albums[:12]]
            except LxClientError as error:
                errors.append("专辑: %s" % error)

        try:
            raw_hot = self.client.hot_search(board_source)
            hot_items = raw_hot.get("list") if isinstance(raw_hot, dict) else raw_hot
            if isinstance(hot_items, list):
                for item in hot_items[:18]:
                    keyword = item if isinstance(item, str) else LxMapper.first(item, ["keyword", "searchWord", "word", "name"])
                    if keyword:
                        data["hot"].append(LxMapper.folder_vod("keyword", {"keyword": str(keyword)}, str(keyword), "", "热门搜索"))
        except LxClientError as error:
            errors.append("热搜: %s" % error)

        favorites = self._favorites()
        data["favorite_songs"] = [LxMapper.song_vod(item, str(self.config.get("source") or "kw")) for item in favorites["songs"][:15]]
        data["favorite_albums"] = [LxMapper.album_vod(item, str(self.config.get("album_source") or "wy")) for item in favorites["albums"][:12]]
        data["favorite_artists"] = [LxMapper.artist_vod(item, str(self.config.get("source") or "kw")) for item in favorites["artists"][:12]]
        data["favorite_user_lists"] = favorites["user_lists"]
        if favorites["error"]:
            errors.append("收藏: %s" % favorites["error"])
        data["error"] = "；".join(errors)
        self.home_cache = data
        self.home_cache_at = time.time()
        return data

    def homeContent(self, filter):
        """首页只显示分类，不显示推荐内容"""
        return {
            "class": self._classes(),
            "filters": self._filters(),
            "list": [],
        }

    def homeLayout(self):
        data = self._load_home()
        layout = LxHomeLayoutBuilder(self.config["base_url"]).build(data)
        info = self._device_profile_info()
        document = layout["document"]
        document["default_profile"] = "tv" if info["tv_mode"] else "mobile"
        # 显式手工模式覆盖壳的自动 profile；auto 保留壳的正常选取机制。
        if info["selected"] != "auto":
            document["profiles"]["tv"]["enabled"] = info["tv_mode"]
            document["profiles"]["mobile"]["enabled"] = not info["tv_mode"]
        return layout

    def homeVideoContent(self):
        """首页推荐内容为空"""
        return {"list": []}

    def _page_result(self, items, page, limit=30, total=None):
        try:
            total = len(items) if total is None else max(int(total), 0)
        except (TypeError, ValueError):
            total = len(items)
        try:
            limit = max(int(limit), 1)
        except (TypeError, ValueError):
            limit = max(len(items), 1)
        pagecount = max(page, (total + limit - 1) // limit) if total else page
        if self._tv_mode_enabled():
            items = [self._tv_action_item(item) for item in items]
        return {"list": items, "page": page, "pagecount": pagecount, "limit": limit, "total": total}

    def categoryContent(self, tid, pg, filter, extend):
        """分类内容 - song_search 分支从筛选器获取平台"""
        page = self._page_number(pg)
        options = self._parse_options(extend)

        if tid == "song_search":
            # 从筛选器获取平台，如果没有则使用默认
            source = str(options.get("source") or self.config.get("source") or "kw")
            # 保存到实例变量供搜索使用
            self.search_source = source
            return self._search_root()

        if tid == "local_songs":
            delete_mode = str(options.get("delete_mode") or "off") == "on"
            return self._local_songs_root(delete_mode=delete_mode)

        ref = LxMapper.unpack(tid)
        if ref:
            return self._category_ref(ref["kind"], ref["data"], page)
        if tid == "charts":
            source = str(options.get("source") or self.config.get("source") or "kw")
            data = self.client.leaderboard_boards(source)
            items = [LxMapper.board_vod(item, source) for item in self._extract_list(data)]
            return self._page_result(items, 1, max(len(items), 1), len(items))
        if tid == "playlists":
            source = str(options.get("source") or self.config.get("source") or "kw")
            sort_name = str(options.get("sort") or "hot")
            sort_id = SORT_IDS.get(source, {}).get(sort_name, SORT_IDS.get(source, {}).get("hot", "hot"))
            tag_id = str(options.get("tag") or "") if source == "wy" else ""
            data = self.client.playlist_list(source, sort_id, tag_id, page)
            raw_items = self._extract_list(data)
            items = [LxMapper.playlist_vod(item, source) for item in raw_items]
            total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
            limit = data.get("limit", max(len(items), 1)) if isinstance(data, dict) else max(len(items), 1)
            return self._page_result(items, page, limit, total)
        if tid == "favorites":
            return self._favorite_root()
        if tid == "account":
            return self._account_root()
        if tid == "sources":
            return self._source_category()
        return self._page_result([], page)

    def _category_ref(self, kind, data, page):
        if kind == "shortcut":
            return self.categoryContent(data.get("target", ""), str(page), False, {})
        if kind == "chart":
            result = self.client.leaderboard_list(data.get("source"), data.get("id"), page)
            items = [LxMapper.song_vod(item, data.get("source")) for item in self._extract_list(result)]
            total = result.get("total", len(items)) if isinstance(result, dict) else len(items)
            limit = result.get("limit", max(len(items), 1)) if isinstance(result, dict) else max(len(items), 1)
            return self._page_result(items, page, limit, total)
        if kind == "keyword":
            self.search_keyword = data.get("keyword", "")
            source = data.get("source") or self.config.get("source") or "kw"
            self.search_source = source
            return self._search_root()
        if kind == "artist_query":
            keyword = data.get("name", "")
            source = data.get("source") or "wy"
            singers = self.client.search(source, keyword, "singer", 1, 10)
            if singers:
                return self._artist_root(LxMapper.artist_vod(singers[0], source))
            songs = self.client.search(str(self.config.get("source") or "kw"), keyword, "song", page, 30)
            return self._page_result([LxMapper.song_vod(item) for item in songs], page, 30)
        if kind == "artist":
            return self._artist_root(LxMapper.artist_vod(data, data.get("source", "wy")))
        if kind == "artist_songs":
            songs = self.client.artist_songs(data.get("source"), data.get("id"), data.get("order", "hot"))
            return self._page_result([LxMapper.song_vod(item, data.get("source")) for item in songs], 1, max(len(songs), 1), len(songs))
        if kind == "artist_albums":
            result = self.client.artist_albums(data.get("source"), data.get("id"), page)
            items = [LxMapper.album_vod(item, data.get("source")) for item in self._extract_list(result)]
            total = result.get("total", len(items)) if isinstance(result, dict) else len(items)
            return self._page_result(items, page, 50, total)
        if kind == "favorite_songs":
            favorites = self._favorites()
            items = [LxMapper.song_vod(item) for item in favorites["songs"]]
            return self._page_result(items, 1, max(len(items), 1), len(items))
        if kind == "favorite_albums":
            favorites = self._favorites()
            items = [LxMapper.album_vod(item) for item in favorites["albums"]]
            return self._page_result(items, 1, max(len(items), 1), len(items))
        if kind == "favorite_artists":
            favorites = self._favorites()
            items = [LxMapper.artist_vod(item) for item in favorites["artists"]]
            return self._page_result(items, 1, max(len(items), 1), len(items))
        if kind == "user_lists":
            favorites = self._favorites()
            items = []
            for playlist in favorites["user_lists"]:
                payload = {"id": playlist.get("id"), "name": playlist.get("name") or "自建歌单"}
                items.append({
                    "vod_id": LxMapper.pack("local_playlist", payload),
                    "vod_name": payload["name"],
                    "vod_pic": LxMapper.text(LxMapper.first(playlist, ["img", "pic", "cover"])),
                    "vod_remarks": "%s 首" % len(playlist.get("list") or []),
                    "vod_player": "music",
                })
            return self._page_result(items, 1, max(len(items), 1), len(items))
        return self._page_result([], page)

    def _favorite_root(self):
        favorites = self._favorites()
        items = [
            LxMapper.folder_vod("favorite_songs", {}, "收藏歌曲", "", "%s 首" % len(favorites["songs"])),
            LxMapper.folder_vod("favorite_albums", {}, "收藏专辑", "", "%s 张" % len(favorites["albums"])),
            LxMapper.folder_vod("favorite_artists", {}, "收藏歌手", "", "%s 位" % len(favorites["artists"]), circle=True),
            LxMapper.folder_vod("user_lists", {}, "自建歌单", "", "%s 个" % len(favorites["user_lists"])),
        ]
        if favorites["error"]:
            items.append(LxMapper.action_vod("收藏登录失败", {
                "actionId": "lx_connection_settings",
                "type": "multiInput",
                "title": "修正 lxserver 登录信息",
                "msg": favorites["error"],
                "input": self._settings_inputs(),
            }, "点击修改连接设置"))
        return self._page_result(items, 1, len(items), len(items))

    def _search_root(self):
        """搜索页面：搜索框在上面，结果在下面显示"""
        source = self.search_source or self.config.get("source") or "kw"
        source_name = SOURCE_NAMES.get(source, source)

        search_input = LxMapper.action_vod(
            f"🔍 输入关键词搜索 ({source_name})", 
            {
                "actionId": "lx_song_search",
                "type": "multiInput",
                "title": "搜索歌曲",
                "msg": f"当前平台：{source_name}，输入关键词搜索",
                "input": [
                    {
                        "id": "keyword",
                        "name": "关键词",
                        "tip": "例如：周杰伦、晴天、七里香",
                        "value": self.search_keyword or "",
                    }
                ],
            },
            f"当前平台：{source_name}，点击输入搜索词",
            ""
        )

        items = [search_input]

        if self.search_keyword:
            # 综合搜索：同时搜索歌曲、歌单、专辑、歌手
            result_items = self._do_comprehensive_search(self.search_keyword, source)
            if result_items:
                items.extend(result_items)
            else:
                items.append({
                    "vod_id": "lx_no_result",
                    "vod_name": f"😅 在 {source_name} 未找到相关结果",
                    "vod_remarks": "提示：可以切换平台重新搜索",
                    "vod_tag": "action",
                })
            items.extend(self._get_hot_search_items(source))
        else:
            items.extend(self._get_hot_search_items(source))

        return self._page_result(items, 1, max(len(items), 1), len(items))

    def _do_comprehensive_search(self, keyword, source):
        """综合搜索：同时搜索歌曲、歌单、专辑、歌手（增强专辑搜索）"""
        items = []
        
        # 1. 搜索歌曲
        try:
            result = self.client.search(source, keyword, "song", 1, 15)
            if result and isinstance(result, list):
                for item in result[:15]:
                    if isinstance(item, dict):
                        item["source"] = source
                    items.append(LxMapper.song_vod(item, source))
                if len(result) > 15:
                    # 添加"查看更多歌曲"入口
                    items.append(LxMapper.folder_vod(
                        "keyword", 
                        {"keyword": keyword, "source": source, "type": "song"}, 
                        f"🎵 查看更多歌曲...", 
                        "", 
                        f"共 {len(result)} 首"
                    ))
        except LxClientError:
            pass

        # 2. 搜索歌单
        try:
            result = self.client.playlist_search(source, keyword, 1)
            raw_items = self._extract_list(result)
            if raw_items:
                # 添加歌单分隔标题
                items.append({
                    "vod_id": "lx_playlist_sep",
                    "vod_name": "📋 相关歌单",
                    "vod_remarks": f"找到 {len(raw_items)} 个歌单",
                    "vod_tag": "folder",
                    "cate": {"land": 1, "ratio": 1.78},
                })
                for item in raw_items[:10]:
                    if isinstance(item, dict):
                        item["source"] = source
                    items.append(LxMapper.playlist_vod(item, source))
        except LxClientError:
            pass

        # 3. 搜索专辑 - 增强健壮性
        try:
            result = self.client.search(source, keyword, "album", 1, 8)
            if result and isinstance(result, list):
                valid_albums = []
                for item in result[:8]:
                    if isinstance(item, dict):
                        item["source"] = source
                    album_vod = LxMapper.album_vod(item, source)
                    # 验证专辑是否有有效数据
                    if album_vod.get("vod_name") and album_vod.get("vod_name") != "未命名专辑":
                        valid_albums.append(album_vod)
                    elif album_vod.get("vod_id") and album_vod.get("vod_name"):
                        valid_albums.append(album_vod)
                
                if valid_albums:
                    # 添加专辑分隔标题
                    items.append({
                        "vod_id": "lx_album_sep",
                        "vod_name": "💿 相关专辑",
                        "vod_remarks": f"找到 {len(valid_albums)} 张专辑",
                        "vod_tag": "folder",
                        "cate": {"land": 1, "ratio": 1.78},
                    })
                    items.extend(valid_albums)
        except LxClientError:
            pass

        # 4. 搜索歌手
        try:
            result = self.client.search(source, keyword, "singer", 1, 8)
            if result and isinstance(result, list):
                # 添加歌手分隔标题
                items.append({
                    "vod_id": "lx_singer_sep",
                    "vod_name": "🎤 相关歌手",
                    "vod_remarks": f"找到 {len(result)} 位歌手",
                    "vod_tag": "folder",
                    "cate": {"land": 1, "ratio": 1.78},
                })
                for item in result[:8]:
                    if isinstance(item, dict):
                        item["source"] = source
                    items.append(LxMapper.artist_vod(item, source))
        except LxClientError:
            pass

        return items

    def _get_hot_search_items(self, source):
        """获取热门搜索词列表"""
        items = []
        try:
            data = self.client.hot_search(source)
            hot_items = data.get("list") if isinstance(data, dict) else data
            if isinstance(hot_items, list):
                source_name = SOURCE_NAMES.get(source, source)
                items.append({
                    "vod_id": "lx_hot_title",
                    "vod_name": f"🔥 热门搜索 [{source_name}]",
                    "vod_remarks": "点击关键词快速搜索",
                    "vod_tag": "folder",
                    "cate": {"land": 1, "ratio": 1.78},
                })
                for item in hot_items[:30]:
                    keyword = item if isinstance(item, str) else LxMapper.first(item, ["keyword", "searchWord", "word", "name"])
                    if keyword:
                        items.append(LxMapper.folder_vod(
                            "keyword", {"keyword": str(keyword), "source": source}, 
                            str(keyword), "", f"在 {source_name} 搜索"
                        ))
        except LxClientError:
            pass
        return items

    def _account_root(self):
        username = self.client.username
        download_folder = str(self.config.get("download_folder") or "").strip()
        download_quality = str(self.config.get("download_quality") or "320k")
        quality_name = QUALITY_NAMES.get(download_quality, download_quality)
        items = [
            LxMapper.action_vod("当前用户：%s" % (username or "未登录"), {
                "actionId": "lx_account",
            }, "点击后可切换用户或退出当前用户"),
            LxMapper.action_vod("下载文件夹：%s" % (download_folder or "未设置"), {
                "actionId": "lx_connection_settings",
                "type": "multiInput",
                "title": "设置下载文件夹",
                "msg": "选择歌曲下载保存位置",
                "input": [
                    {"id": "download_folder", "name": "下载文件夹", "tip": "选择文件夹", "value": download_folder, "selectData": "[folder]"},
                ],
            }, "点击设置下载文件夹"),
            LxMapper.action_vod("下载音质：%s" % quality_name, {
                "actionId": "lx_connection_settings",
                "type": "multiInput",
                "title": "设置下载音质",
                "msg": "选择下载歌曲的音质",
                "input": [
                    {"id": "download_quality", "name": "下载音质", "value": download_quality, "selectData": "标准:=128k,高品:=320k,无损:=flac,Hi-Res:=flac24bit"},
                ],
            }, "点击设置下载音质"),
        ]
        if username:
            items.append(LxMapper.action_vod("退出当前用户", {
                "actionId": "lx_account",
                "value": {"menu": LxMapper.pack("account_command", {"op": "logout"})},
            }, "仅清除本脚本保存的登录信息"))
        else:
            items.append(LxMapper.action_vod("登录用户", {
                "actionId": "lx_connection_settings",
                "type": "multiInput",
                "title": "登录 lxserver 用户",
                "msg": "填写用户名和密码后保存。",
                "input": self._settings_inputs(),
            }, "登录后可读取个人收藏"))
        return self._page_result(items, 1, len(items), len(items))

    def _artist_root(self, artist_vod):
        ref = LxMapper.unpack(artist_vod.get("vod_id")) or {"data": {}}
        data = ref.get("data") or {}
        items = [
            LxMapper.folder_vod("artist_songs", dict(data, order="hot"), "热门歌曲", data.get("pic", ""), data.get("name", "")),
            LxMapper.folder_vod("artist_albums", data, "歌手专辑", data.get("pic", ""), data.get("name", "")),
        ]
        return self._page_result(items, 1, len(items), len(items))

    def _source_category(self):
        source_error = ""
        try:
            sources = self.client.source_list()
        except LxClientError as error:
            sources, source_error = [], str(error)
        items = []
        for source in sources:
            source_id = str(source.get("id") or "")
            owner = str(source.get("owner") or self.client.username or "open")
            enabled = bool(source.get("enabled"))
            status = str(source.get("status") or ("success" if enabled else "disabled"))
            supported = source.get("supportedSources") if isinstance(source.get("supportedSources"), list) else []
            command = lambda op, sid=source_id, own=owner: LxMapper.pack("source_command", {"op": op, "id": sid, "owner": own})
            config = {
                "actionId": "lx_source_operation",
                "type": "menu",
                "title": str(source.get("name") or source_id),
                "selectedIndex": 0,
                "option": [
                    {"name": "停用" if enabled else "启用", "action": command("disable" if enabled else "enable")},
                    {"name": "上移", "action": command("up")},
                    {"name": "下移", "action": command("down")},
                    {"name": "删除（不可恢复）", "action": command("delete")},
                ],
            }
            remarks = "%s · %s · %s" % (
                "已启用" if enabled else "已停用",
                status,
                "/".join(supported) if supported else "未识别平台",
            )
            items.append(LxMapper.action_vod(str(source.get("name") or source_id), config, remarks))
        items.insert(0, LxMapper.action_vod("导入新的 JS 音源", {
            "actionId": "lx_import_source",
            "type": "multiInput",
            "title": "导入 JS 音源",
            "msg": "选择文件后先校验，再上传到当前用户空间。",
            "input": [
                {"id": "file", "name": "JS 音源文件", "tip": "请选择 .js 文件", "value": "", "selectData": "[file]"},
                {"id": "unsafe", "name": "允许不安全 VM", "value": "否", "selectData": "否:=否,是:=是"},
            ],
        }, "支持文件选择器"))
        info = self._device_profile_info()
        items[0:0] = [
            LxMapper.action_vod("设备识别 / TV 模式：" + info["effective_label"], {"actionId": "lx_device_settings"}, info["reason"]),
            LxMapper.action_vod("移动 Web / 扫码管理", {"actionId": "lx_mobile_web"}, "默认 40012 · 当前 %s · 管理全部设置与音源" % self.config["mobile_web_port"]),
            LxMapper.action_vod("移动 Web 服务设置", self._web_settings_config(), "开启/关闭、修改端口"),
        ]
        if info["tv_mode"]:
            inputs = self._settings_inputs()
            # TV 提供遥控器表单；宿主的文件/目录选择入口继续保留在原分类。
            for field in inputs:
                if field.get("selectData") in ("[file]", "[folder]"):
                    field.pop("selectData", None)
                    field["tip"] = "填写设备路径，或在移动 Web 中浏览选择目录"
            items.insert(3, LxMapper.action_vod("TV 遥控器设置", {"actionId": "lx_connection_settings", "type": "multiInput", "title": "TV 遥控器设置", "input": inputs}, "连接、账号、音质、下载；方向键与 OK 操作"))
        if source_error:
            items.append(LxMapper.action_vod("音乐服务器连接失败", {"actionId": "lx_connection_settings", "type": "multiInput", "title": "连接设置", "input": self._settings_inputs()}, source_error))
        return self._page_result(items, 1, max(len(items), 1), len(items))

    # ========== 本地歌曲功能 ==========
    def _local_songs_root(self, delete_mode=False):
        """本地歌曲页面：只读取下载文件夹根目录中的音乐文件（不扫描子文件夹）"""
        download_folder = str(self.config.get("download_folder") or "").strip()
        
        if not download_folder:
            return self._page_result([{
                "vod_id": "lx_no_folder",
                "vod_name": "📁 请先设置下载文件夹",
                "vod_remarks": "点击下方「设置下载文件夹」",
                "vod_tag": "action",
            }, {
                "vod_id": json.dumps({
                    "actionId": "lx_connection_settings",
                    "type": "multiInput",
                    "title": "设置下载文件夹",
                    "msg": "选择歌曲下载保存位置",
                    "input": [
                        {"id": "download_folder", "name": "下载文件夹", "tip": "选择文件夹", "value": "", "selectData": "[folder]"},
                    ],
                }, ensure_ascii=False),
                "vod_name": "⚙️ 设置下载文件夹",
                "vod_remarks": "点击选择文件夹",
                "vod_tag": "action",
            }], 1, 2, 2)

        if not os.path.exists(download_folder):
            return self._page_result([{
                "vod_id": "lx_folder_not_exist",
                "vod_name": "❌ 文件夹不存在",
                "vod_remarks": f"请检查路径: {download_folder}",
                "vod_tag": "action",
            }], 1, 1, 1)

        music_extensions = {'.mp3', '.flac', '.wav', '.m4a', '.aac', '.ogg', '.wma', '.ape'}
        image_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'}
        lyric_extensions = {'.lrc', '.txt'}
        
        songs = []
        files_dict = {}
        
        try:
            for file in os.listdir(download_folder):
                file_path = os.path.join(download_folder, file)
                if os.path.isdir(file_path):
                    continue
                base_name = os.path.splitext(file)[0]
                ext = os.path.splitext(file)[1].lower()
                key = base_name
                
                if key not in files_dict:
                    files_dict[key] = {
                        "music": None, 
                        "cover": None, 
                        "lyric": None, 
                        "base_name": base_name,
                        "file_name": file
                    }
                
                if ext in music_extensions:
                    files_dict[key]["music"] = file_path
                    files_dict[key]["ext"] = ext
                elif ext in image_extensions:
                    files_dict[key]["cover"] = file_path
                elif ext in lyric_extensions:
                    files_dict[key]["lyric"] = file_path
            
            for key, info in files_dict.items():
                if info["music"]:
                    file_path = info["music"]
                    ext = info.get("ext", os.path.splitext(file_path)[1].lower())
                    base_name = info.get("base_name", os.path.splitext(os.path.basename(file_path))[0])
                    
                    name_parts = base_name.split(' - ')
                    if len(name_parts) >= 2:
                        song_name = name_parts[0].strip()
                        singer_name = name_parts[1].strip()
                    elif base_name.count(' - ') >= 1:
                        parts = base_name.split(' - ')
                        song_name = parts[0].strip()
                        singer_name = ' - '.join(parts[1:]).strip()
                    else:
                        song_name = base_name
                        singer_name = "本地歌曲"
                    
                    lyric_text = ""
                    if info["lyric"]:
                        try:
                            with open(info["lyric"], "r", encoding="utf-8") as f:
                                lyric_text = f.read()
                        except:
                            pass
                    
                    song = {
                        "source": "local",
                        "name": song_name,
                        "singer": singer_name,
                        "file_path": file_path,
                        "cover_path": info["cover"] or "",
                        "lyric_path": info["lyric"] or "",
                        "lyric_text": lyric_text,
                        "file_name": info.get("file_name", os.path.basename(file_path)),
                        "ext": ext,
                        "size": os.path.getsize(file_path),
                        "modified": os.path.getmtime(file_path),
                        "base_name": base_name,
                        "download_folder": download_folder,
                    }
                    songs.append(song)
                    
        except Exception as e:
            return self._page_result([{
                "vod_id": "lx_scan_error",
                "vod_name": "❌ 扫描文件夹失败",
                "vod_remarks": str(e),
                "vod_tag": "action",
            }], 1, 1, 1)

        songs.sort(key=lambda x: x.get("modified", 0), reverse=True)

        items = []
        for song in songs[:500]:
            cover_pic = song.get("cover_path", "")
            if cover_pic and os.path.exists(cover_pic):
                cover_pic = "file://" + cover_pic
            
            remarks = f"{song['singer']} · {song['ext'].upper()} · {self._format_size(song['size'])}"
            
            # 删除模式：使用 lx_delete_song_ 前缀
            if delete_mode:
                # 将文件路径编码到 vod_id 中
                encoded_path = base64.urlsafe_b64encode(song["file_path"].encode()).decode().rstrip("=")
                item = {
                    "vod_id": f"lx_delete_song_{encoded_path}",
                    "vod_name": f"🗑️ {song['name']}",
                    "vod_pic": cover_pic,
                    "vod_remarks": f"点击删除 · {remarks}",
                    "vod_actor": song["singer"],
                    "vod_content": f"文件路径: {song['file_path']}",
                    "vod_tag": "action",
                    "style": {"type": "rect", "ratio": 1.0},
                }
            else:
                # 浏览模式：正常播放
                item = {
                    "vod_id": LxMapper.pack("local_song", song),
                    "vod_name": song["name"],
                    "vod_pic": cover_pic,
                    "vod_remarks": remarks,
                    "vod_actor": song["singer"],
                    "vod_content": f"文件路径: {song['file_path']}",
                    "vod_player": "music",
                    "style": {"type": "rect", "ratio": 1.0},
                }
            
            items.append(item)

        if items:
            mode_text = "🗑️ 删除模式 (点击歌曲直接删除)" if delete_mode else "🎵 浏览模式 (点击歌曲播放)"
            items.insert(0, {
                "vod_id": "lx_local_stats",
                "vod_name": f"📁 共 {len(items)-1} 首本地歌曲",
                "vod_remarks": f"{mode_text} · {download_folder}",
                "vod_tag": "folder",
                "cate": {"land": 1, "ratio": 1.78},
            })

        return self._page_result(items, 1, max(len(items), 1), len(items))

    def _format_size(self, size):
        """格式化文件大小"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024.0:
                return f"{size:.1f}{unit}"
            size /= 1024.0
        return f"{size:.1f}TB"

    # ========== 删除功能 ==========
    def _delete_local_song_by_path(self, file_path):
        """根据文件路径删除本地歌曲及其关联文件"""
        if not file_path or not os.path.exists(file_path):
            return {
                "action": {"actionId": "__refresh_list__"},
                "toast": "❌ 文件不存在",
            }
        
        # 获取关联文件
        dir_path = os.path.dirname(file_path)
        base_name = os.path.splitext(os.path.basename(file_path))[0]
        
        deleted_files = []
        failed_files = []
        
        # 1. 删除歌曲文件
        try:
            os.remove(file_path)
            deleted_files.append(os.path.basename(file_path))
        except Exception as e:
            failed_files.append(f"{os.path.basename(file_path)}: {str(e)}")
        
        # 2. 删除封面文件
        cover_exts = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp']
        for ext in cover_exts:
            cover_path = os.path.join(dir_path, base_name + ext)
            if os.path.exists(cover_path):
                try:
                    os.remove(cover_path)
                    deleted_files.append(os.path.basename(cover_path))
                except:
                    pass
            cover_path_upper = os.path.join(dir_path, base_name + ext.upper())
            if os.path.exists(cover_path_upper):
                try:
                    os.remove(cover_path_upper)
                    deleted_files.append(os.path.basename(cover_path_upper))
                except:
                    pass
        
        # 3. 删除歌词文件
        lyric_path = os.path.join(dir_path, base_name + '.lrc')
        if os.path.exists(lyric_path):
            try:
                os.remove(lyric_path)
                deleted_files.append(os.path.basename(lyric_path))
            except:
                pass
        lyric_path_upper = os.path.join(dir_path, base_name + '.LRC')
        if os.path.exists(lyric_path_upper):
            try:
                os.remove(lyric_path_upper)
                deleted_files.append(os.path.basename(lyric_path_upper))
            except:
                pass
        
        # 构建返回结果
        if deleted_files:
            msg = f"✅ 已删除: {', '.join(deleted_files)}"
        else:
            msg = f"❌ 删除失败: {', '.join(failed_files)}"
        
        return {
            "action": {"actionId": "__refresh_list__"},
            "toast": msg,
        }

    def detailContent(self, ids):
        if isinstance(ids, (list, tuple)):
            ids = ids[0] if ids else ""
        item_id = str(ids or "").split(",", 1)[0]
        
        # 处理删除请求 - 兼容 detailContent 入口
        if item_id.startswith("lx_delete_song_"):
            return self._action_delete_local_song(item_id)
        
        ref = LxMapper.unpack(item_id)
        if not ref:
            return {"list": []}
        kind = ref["kind"]
        data = ref["data"]
        
        # ===== 本地歌曲 =====
        if kind == "local_song":
            song = data
            file_path = song.get("file_path", "")
            cover_path = song.get("cover_path", "")
            lyric_text = song.get("lyric_text", "")
            
            if not file_path or not os.path.exists(file_path):
                return {"list": [{
                    "vod_id": item_id,
                    "vod_name": "❌ 文件不存在",
                    "vod_remarks": "请检查文件是否已被删除或移动",
                    "vod_player": "music",
                }]}
            
            cover_pic = cover_path if cover_path else ""
            if cover_pic and os.path.exists(cover_pic):
                cover_pic = "file://" + cover_pic
            
            return {"list": [{
                "vod_id": item_id,
                "vod_name": song.get("name", "未知歌曲"),
                "vod_pic": cover_pic,
                "vod_remarks": f"{song.get('singer', '本地歌曲')} · {song.get('ext', '').upper()} · {self._format_size(song.get('size', 0))}",
                "vod_actor": song.get("singer", "本地歌曲"),
                "vod_content": f"文件路径: {file_path}",
                "vod_play_from": "本地播放",
                "vod_play_url": f"本地歌曲${item_id}",
                "vod_player": "music",
                "vod_lrc": lyric_text,
            }]}
        
        # ===== 原有的歌曲处理 =====
        if kind == "song":
            song = LxMapper.song(data)
            detail = LxMapper.music_detail({
                "id": item_id,
                "name": song["name"],
                "pic": song["img"],
                "singer": song["singer"],
                "remarks": " · ".join(item for item in (song["singer"], song["albumName"]) if item),
                "source": song["source"],
            }, [song], self.config)
            return {"list": [detail]}
        if kind == "playlist":
            songs = self._collect_playlist(data)
            detail = LxMapper.music_detail({
                "id": item_id,
                "name": data.get("name"),
                "pic": data.get("pic"),
                "singer": data.get("author"),
                "remarks": "%s 首歌曲" % len(songs),
                "content": data.get("desc"),
                "source": data.get("source"),
            }, songs, self.config)
            return {"list": [detail]}
        if kind == "album":
            songs = self._collect_album(data)
            detail = LxMapper.music_detail({
                "id": item_id,
                "name": data.get("name"),
                "pic": data.get("pic"),
                "singer": data.get("singer"),
                "remarks": "%s 首歌曲" % len(songs),
                "source": data.get("source"),
            }, songs, self.config)
            return {"list": [detail]}
        if kind == "local_playlist":
            favorites = self._favorites()
            playlist = next((item for item in favorites["user_lists"] if str(item.get("id")) == str(data.get("id"))), None)
            songs = []
            if isinstance(playlist, dict):
                for key in ("list", "songs", "songList", "tracks"):
                    if isinstance(playlist.get(key), list):
                        songs = playlist[key]
                        break
            detail = LxMapper.music_detail({
                "id": item_id,
                "name": data.get("name"),
                "remarks": "%s 首歌曲" % len(songs),
            }, songs, self.config)
            return {"list": [detail]}
        return {"list": []}

    def _collect_playlist(self, data):
        songs = []
        max_pages = LxHttpClient._positive_int(self.config.get("max_pages"), 5, 1, 20)
        max_songs = LxHttpClient._positive_int(self.config.get("max_songs"), 500, 1, 2000)
        source = data.get("source")
        for page in range(1, max_pages + 1):
            result = self.client.playlist_detail(source, data.get("id"), page)
            page_items = self._extract_list(result)
            songs.extend(page_items)
            total = result.get("total", 0) if isinstance(result, dict) else 0
            limit = result.get("limit", len(page_items)) if isinstance(result, dict) else len(page_items)
            if source == "tx" or not page_items or len(songs) >= max_songs:
                break
            if total and len(songs) >= int(total):
                break
            if limit and len(page_items) < int(limit):
                break
        return songs[:max_songs]

    def _collect_album(self, data):
        try:
            result = self.client.album_songs(data.get("source"), data.get("id"))
            songs = self._extract_list(result)
            if songs:
                return songs[:LxHttpClient._positive_int(self.config.get("max_songs"), 500, 1, 2000)]
        except LxClientError:
            pass
        keyword = " ".join(item for item in (str(data.get("name") or ""), str(data.get("singer") or "")) if item)
        fallback_source = data.get("source") if data.get("source") in SOURCE_NAMES else str(self.config.get("source") or "kw")
        songs = self.client.search(fallback_source, keyword, "song", 1, 20)
        album_name = str(data.get("name") or "")
        matched = [item for item in songs if LxMapper.song(item, fallback_source).get("albumName") == album_name]
        return matched or songs

    # ========== 搜索功能 ==========
    def searchContent(self, key, quick, pg="1"):
        """搜索方法 - 使用 search_source 平台优先，强制覆盖 source 字段"""
        page = self._page_number(pg)
        keyword = str(key or "").strip()
        if not keyword:
            return self._page_result([], page)

        # 解析搜索类型前缀
        search_type = "song"
        for prefix, target in (("歌曲:", "song"), ("歌曲：", "song"), ("歌手:", "singer"), ("歌手：", "singer"),
                               ("专辑:", "album"), ("专辑：", "album"), ("歌单:", "playlist"), ("歌单：", "playlist")):
            if keyword.startswith(prefix):
                keyword = keyword[len(prefix):].strip()
                search_type = target
                break

        quick_search = quick is True or str(quick).lower() in ("1", "true", "yes", "quick")
        
        # 使用 search_source（从筛选器选中的平台）
        search_source = self.search_source or self.config.get("source") or "kw"
        
        # 对于普通搜索（非快速搜索），使用综合搜索
        if not quick_search:
            return self._comprehensive_search_result(keyword, search_source, page)
        
        # 快速搜索：只搜索歌曲        if quick_search:
            sources = [search_source]
        else:
            sources = self.config.get("sources") or ["kw", "kg", "tx", "wy", "mg"]
            if search_source in sources:
                sources.remove(search_source)
                sources.insert(0, search_source)

        items = []

        if search_type == "singer":
            for source in sources:
                try:
                    result = self.client.search(source, keyword, "singer", page, 20)
                    if result:
                        for item in result:
                            if isinstance(item, dict):
                                item["source"] = source
                        items.extend(LxMapper.artist_vod(item, source) for item in result)
                except LxClientError:
                    continue
        elif search_type == "album":
            for source in sources:
                try:
                    result = self.client.search(source, keyword, "album", page, 20)
                    if result:
                        for item in result:
                            if isinstance(item, dict):
                                item["source"] = source
                        items.extend(LxMapper.album_vod(item, source) for item in result)
                except LxClientError:
                    continue
        elif search_type == "playlist":
            for source in sources:
                try:
                    result = self.client.playlist_search(source, keyword, page)
                    raw_items = self._extract_list(result)
                    if raw_items:
                        for item in raw_items:
                            if isinstance(item, dict):
                                item["source"] = source
                        items.extend(LxMapper.playlist_vod(item, source) for item in raw_items)
                except LxClientError:
                    continue
        else:
            # 歌曲搜索 - 使用 search_source 优先
            for source in sources:
                try:
                    result = self.client.search(source, keyword, "song", page, 30)
                    if result and isinstance(result, list):
                        for item in result:
                            if isinstance(item, dict):
                                item["source"] = source
                        items.extend(LxMapper.song_vod(item, source) for item in result)
                except LxClientError:
                    continue

        return {"list": items, "page": page, "pagecount": page + 1 if items else page, "limit": 30, "total": len(items)}

    def _comprehensive_search_result(self, keyword, source, page):
        """综合搜索结果 - 用于 searchContent 的非快速搜索（增强专辑搜索）"""
        items = []
        
        # 1. 搜索歌曲
        try:
            result = self.client.search(source, keyword, "song", page, 20)
            if result and isinstance(result, list):
                for item in result[:20]:
                    if isinstance(item, dict):
                        item["source"] = source
                    items.append(LxMapper.song_vod(item, source))
        except LxClientError:
            pass

        # 2. 搜索歌单
        try:
            result = self.client.playlist_search(source, keyword, page)
            raw_items = self._extract_list(result)
            if raw_items:
                items.append({
                    "vod_id": "lx_playlist_sep",
                    "vod_name": "📋 相关歌单",
                    "vod_remarks": f"找到 {len(raw_items)} 个歌单",
                    "vod_tag": "folder",
                    "cate": {"land": 1, "ratio": 1.78},
                })
                for item in raw_items[:10]:
                    if isinstance(item, dict):
                        item["source"] = source
                    items.append(LxMapper.playlist_vod(item, source))
        except LxClientError:
            pass

        # 3. 搜索专辑 - 增强健壮性
        try:
            result = self.client.search(source, keyword, "album", page, 8)
            if result and isinstance(result, list):
                valid_albums = []
                for item in result[:8]:
                    if isinstance(item, dict):
                        item["source"] = source
                    album_vod = LxMapper.album_vod(item, source)
                    # 验证专辑是否有有效数据
                    if album_vod.get("vod_name") and album_vod.get("vod_name") != "未命名专辑":
                        valid_albums.append(album_vod)
                    elif album_vod.get("vod_id") and album_vod.get("vod_name"):
                        valid_albums.append(album_vod)
                
                if valid_albums:
                    items.append({
                        "vod_id": "lx_album_sep",
                        "vod_name": "💿 相关专辑",
                        "vod_remarks": f"找到 {len(valid_albums)} 张专辑",
                        "vod_tag": "folder",
                        "cate": {"land": 1, "ratio": 1.78},
                    })
                    items.extend(valid_albums)
        except LxClientError:
            pass

        # 4. 搜索歌手
        try:
            result = self.client.search(source, keyword, "singer", page, 8)
            if result and isinstance(result, list):
                items.append({
                    "vod_id": "lx_singer_sep",
                    "vod_name": "🎤 相关歌手",
                    "vod_remarks": f"找到 {len(result)} 位歌手",
                    "vod_tag": "folder",
                    "cate": {"land": 1, "ratio": 1.78},
                })
                for item in result[:8]:
                    if isinstance(item, dict):
                        item["source"] = source
                    items.append(LxMapper.artist_vod(item, source))
        except LxClientError:
            pass

        if not items:
            items.append({
                "vod_id": "lx_no_result",
                "vod_name": f"😅 在 {SOURCE_NAMES.get(source, source)} 未找到相关结果",
                "vod_remarks": "提示：可以切换平台重新搜索",
                "vod_tag": "action",
            })

        return {"list": items, "page": page, "pagecount": page + 1 if items else page, "limit": 30, "total": len(items)}

    def _download_file(self, url, path, headers=None):
        """下载文件到指定路径，支持自定义headers"""
        try:
            # 使用和播放一样的请求头
            download_headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "Accept": "*/*",
                "Accept-Encoding": "gzip, deflate, br",
                "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
                "Connection": "keep-alive",
                "Referer": "http://www.kuwo.cn/",
                "Origin": "http://www.kuwo.cn",
            }
            if headers and isinstance(headers, dict):
                download_headers.update(headers)

            # 使用流式下载，跳过SSL验证
            response = requests.get(url, headers=download_headers, stream=True, timeout=60, verify=False)
            response.raise_for_status()

            total_size = int(response.headers.get('content-length', 0))
            downloaded = 0

            with open(path, "wb") as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)

            # 检查文件大小
            if total_size > 0 and downloaded < total_size:
                raise Exception("下载不完整")

            return True
        except Exception as e:
            raise Exception("下载失败: %s" % str(e))

    def _clean_filename(self, name):
        """清理文件名中的非法字符"""
        if not name:
            return "未知"
        return re.sub(r'[\\/*?:"<>|]', '', str(name).strip()) or "未知"

    def _download_song(self, song, quality=None):
        """下载歌曲、封面、歌词"""
        download_folder = str(self.config.get("download_folder") or "").strip()
        if not download_folder:
            return {"parse": 0, "url": "", "msg": "请先在「用户账号」中设置下载文件夹"}

        try:
            os.makedirs(download_folder, exist_ok=True)
        except Exception as e:
            return {"parse": 0, "url": "", "msg": "创建文件夹失败: %s" % str(e)}

        singer_name = self._clean_filename(song.get("singer", "未知歌手"))
        song_name = self._clean_filename(song.get("name", "未知歌曲"))
        base_name = f"{song_name} - {singer_name}"

        downloaded = []
        errors = []

        # 1. 下载歌曲 - 使用指定的音质
        if not quality:
            quality = str(self.config.get("download_quality") or "320k")

        audio_url = None
        audio_ext = "mp3"
        audio_headers = {}

        try:
            result = self.client.music_url(song, quality)
            if result and result.get("url"):
                audio_url = result.get("url")
                if audio_url:
                    url_path = audio_url.split('?')[0]
                    if '.flac' in url_path.lower():
                        audio_ext = "flac"
                    elif '.mp3' in url_path.lower():
                        audio_ext = "mp3"
                    elif '.m4a' in url_path.lower():
                        audio_ext = "m4a"
                    elif '.wav' in url_path.lower():
                        audio_ext = "wav"
                    else:
                        audio_ext = "mp3"
                    if result.get("header"):
                        audio_headers = result.get("header")
        except Exception:
            # 如果指定音质失败，降级到320k
            try:
                result = self.client.music_url(song, "320k")
                if result and result.get("url"):
                    audio_url = result.get("url")
                    audio_ext = "mp3"
                    if result.get("header"):
                        audio_headers = result.get("header")
            except Exception:
                pass

        if audio_url:
            try:
                audio_path = os.path.join(download_folder, f"{base_name}.{audio_ext}")
                self._download_file(audio_url, audio_path, audio_headers)
                downloaded.append("歌曲(%s)" % quality)
            except Exception as e:
                errors.append("歌曲下载失败: %s" % str(e))
                try:
                    audio_path = os.path.join(download_folder, f"{base_name}.{audio_ext}")
                    self._download_file(audio_url, audio_path, None)
                    downloaded.append("歌曲(%s)(重试成功)" % quality)
                except Exception as e2:
                    errors.append("歌曲下载重试失败: %s" % str(e2))
        else:
            errors.append("未找到可用的歌曲播放地址")

        # 2. 下载封面 (jpg)
        img_url = song.get("img") or song.get("picUrl") or ""
        if img_url:
            try:
                img_path = os.path.join(download_folder, f"{base_name}.jpg")
                self._download_file(img_url, img_path)
                downloaded.append("封面")
            except Exception as e:
                errors.append("封面下载失败: %s" % str(e))

        # 3. 下载歌词 (lrc)
        try:
            lyric_data = self.client.lyric(song)
            lyric_text = self._lyric_text(lyric_data)
            if lyric_text:
                lrc_path = os.path.join(download_folder, f"{base_name}.lrc")
                with open(lrc_path, "w", encoding="utf-8") as f:
                    f.write(lyric_text)
                downloaded.append("歌词")
        except Exception as e:
            errors.append("歌词下载失败: %s" % str(e))

        if downloaded:
            msg = "✅ 下载完成: %s" % "、".join(downloaded)
            msg += " → %s" % download_folder
        else:
            msg = "❌ 下载失败"

        if errors:
            msg += "；%s" % "; ".join(errors)

        return {
            "parse": 0,
            "url": audio_url or "",
            "msg": msg,
            "lrc": "下载完成" if downloaded else "下载失败",
            "artwork": song.get("img") or "",
            "flag": "📥 下载(%s)" % quality,
        }

    @staticmethod
    def _quality_for_song(song, requested, fallback):
        available = set()
        for item in song.get("types") or []:
            if isinstance(item, dict) and item.get("type"):
                available.add(str(item["type"]))
        available.update(str(item) for item in (song.get("_types") or {}).keys())
        preferred = [requested, fallback, "320k", "128k", "flac", "flac24bit"]
        if not available:
            return next((item for item in preferred if item), "320k")
        return next((item for item in preferred if item in available), next(iter(available)))

    @staticmethod
    def _lyric_text(value):
        if isinstance(value, str):
            return value
        if isinstance(value, dict):
            for key in ("lyric", "lrc", "rawLrc"):
                if isinstance(value.get(key), str):
                    return value[key]
        return ""

    def playerContent(self, flag, id, vipFlags):
        if isinstance(id, (list, tuple)):
            id = id[0] if id else ""
        ref = LxMapper.unpack(id)
        if not ref:
            return {"parse": 0, "url": "", "msg": "无效的播放参数"}
        
        kind = ref["kind"]
        data = ref["data"]
        
        # ===== 本地歌曲播放 =====
        if kind == "local_song":
            file_path = data.get("file_path", "")
            lyric_text = data.get("lyric_text", "")
            cover_path = data.get("cover_path", "")
            
            if not file_path or not os.path.exists(file_path):
                return {"parse": 0, "url": "", "msg": "文件不存在: %s" % file_path}
            
            artwork = ""
            if cover_path and os.path.exists(cover_path):
                artwork = "file://" + cover_path
            
            return {
                "parse": 0,
                "url": "file://" + file_path,
                "msg": "播放本地歌曲",
                "flag": "🎵 本地",
                "lrc": lyric_text,
                "artwork": artwork,
            }
        
        # ===== 原有的播放逻辑 =====
        if ref["kind"] == "play":
            song = LxMapper.song(ref["data"].get("song") or {})
            requested = str(ref["data"].get("quality") or "")
        else:
            song = LxMapper.song(ref["data"])
            requested = ""

        if requested == "download" or str(flag or "").lower() == "download":
            download_quality = str(self.config.get("download_quality") or "320k")
            return self._download_song(song, download_quality)

        for quality, name in QUALITY_NAMES.items():
            if str(flag or "").lower() in (quality.lower(), name.lower()):
                requested = quality
                break
        quality = self._quality_for_song(song, requested, str(self.config.get("quality") or "320k"))
        try:
            result = self.client.music_url(song, quality)
            if not isinstance(result, dict) or not result.get("url"):
                raise LxClientError("自定义音源没有返回播放地址")
            audio_url = result.get("url")
            lyric = ""
            try:
                lyric = self._lyric_text(self.client.lyric(song))
            except LxClientError:
                pass
            headers = result.get("header") or result.get("headers") or {}
            return {
                "parse": 0,
                "url": audio_url,
                "header": headers if isinstance(headers, dict) else {},
                "lrc": lyric,
                "artwork": song.get("img") or "",
                "flag": QUALITY_NAMES.get(quality, quality),
            }
        except LxClientError as error:
            return {"parse": 0, "url": "", "msg": str(error)}

    def action(self, action_str):
        with self._settings_lock:
            result = self._dispatch_action(action_str)
        config = result.get("action") if isinstance(result, dict) else None
        if config and config.get("type") in ("menu", "multiInput") and self._tv_mode_enabled():
            if not any(x.get("selectData") in ("[file]", "[folder]") for x in config.get("input", [])):
                return self._present_dialog(config)
        return result

    def _dispatch_action(self, action_str):
        try:
            payload = json.loads(action_str) if isinstance(action_str, str) else action_str
            action_id = (payload.get("action") or payload.get("actionId") or "") if isinstance(payload, dict) else str(action_str)
            value = payload.get("value", {}) if isinstance(payload, dict) else {}
        except (ValueError, TypeError):
            action_id = str(action_str or "")
            value = {}
        try:
            if action_id == "lx_tv_dialog":
                config = value.get("dialog") if isinstance(value, dict) else None
                if not isinstance(config, dict) or config.get("type") not in ("menu", "multiInput"):
                    raise ValueError("无效的 TV 弹窗")
                return self._present_dialog(config)
            if action_id == "lx_device_settings":
                return self._action_device_settings(value)
            if action_id == "lx_mobile_web":
                return self._action_mobile_web(value)
            if action_id == "lx_web_settings":
                return self._action_web_settings(value)
            # 处理本地歌曲删除 - 放在最前面
            if action_id.startswith("lx_delete_song_"):
                return self._action_delete_local_song(action_id)
            if action_id == "lx_import_source":
                return self._action_import_source(value)
            if action_id == "lx_source_operation":
                return self._action_source_operation(value)
            if action_id == "lx_connection_settings":
                return self._action_connection_settings(value)
            if action_id == "lx_account":
                return self._action_account(value)
            if action_id == "lx_song_search":
                return self._action_song_search(value)
            if action_id == "lx_open_web":
                return {"action": {
                    "actionId": "lx_open_web",
                    "type": "webview",
                    "title": "洛雪音乐",
                    "url": self.config["base_url"].rstrip("/") + "/",
                    "height": -80,
                    "textZoom": 90,
                }}
            if action_id == "lx_refresh":
                self.home_cache = None
                return {"action": {"actionId": "__refresh_list__"}, "toast": "已刷新洛雪数据"}
            return "未知的洛雪操作: %s" % action_id
        except (LxClientError, OSError, ValueError) as error:
            return {"action": {
                "actionId": "lx_error",
                "type": "msgbox",
                "title": "操作失败",
                "htmlMsg": str(error),
            }}

    def _action_delete_local_song(self, action_id):
        """处理本地歌曲删除"""
        encoded_path = action_id[len("lx_delete_song_"):]
        # 补齐 base64 padding
        padding = 4 - len(encoded_path) % 4
        if padding != 4:
            encoded_path += "=" * padding
        try:
            file_path = base64.urlsafe_b64decode(encoded_path).decode()
        except:
            return {"action": {"actionId": "__refresh_list__"}, "toast": "❌ 文件路径解析错误"}
        
        result = self._delete_local_song_by_path(file_path)
        return {
            "action": {"actionId": "__refresh_list__"},
            "toast": result.get("toast", "删除完成"),
        }

    def _action_import_source(self, value):
        values = value if isinstance(value, dict) else {}
        file_path = str(values.get("file") or "").strip()
        allow_unsafe = str(values.get("unsafe") or "否").strip() in ("是", "true", "1", "yes")
        if not file_path:
            raise ValueError("请选择 JS 音源文件")
        if not file_path.lower().endswith(".js"):
            raise ValueError("音源文件必须以 .js 结尾")
        with open(file_path, "r", encoding="utf-8-sig") as source_file:
            content = source_file.read()
        return self._import_source_content(os.path.basename(file_path), content, allow_unsafe)

    def _import_source_content(self, filename, content, allow_unsafe=False):
        if not filename.lower().endswith(".js"):
            raise ValueError("音源文件必须以 .js 结尾")
        if not isinstance(content, str) or not content.strip():
            raise ValueError("选择的 JS 文件为空")
        content = content.lstrip("\ufeff")
        if len(content.encode("utf-8")) > 5 * 1024 * 1024:
            raise ValueError("JS 音源文件不能超过 5 MB")
        validation = self.client.source_validate(content, allow_unsafe)
        if not isinstance(validation, dict) or not validation.get("valid"):
            if isinstance(validation, dict) and validation.get("disabledVM"):
                raise ValueError("服务器已禁用不安全 VM，该音源当前无法导入")
            if isinstance(validation, dict) and validation.get("requireUnsafe") and not allow_unsafe:
                raise ValueError("该音源需要不安全 VM，请重新导入并选择\"是\"")
            raise ValueError((validation or {}).get("error") if isinstance(validation, dict) else "音源校验失败")
        upload = self.client.source_upload(os.path.basename(filename), content, allow_unsafe)
        if not isinstance(upload, dict) or not upload.get("success"):
            message = "音源上传失败"
            if isinstance(upload, dict):
                message = upload.get("error") or upload.get("message") or message
            raise ValueError(message or "音源上传失败")
        self.home_cache = None
        platforms = upload.get("supportedSources") or validation.get("sources") or []
        return {
            "action": {"actionId": "__refresh_list__"},
            "toast": "音源已导入（默认停用），支持: %s" % ("/".join(platforms) if platforms else "待识别"),
        }

    def _action_source_operation(self, value):
        values = value if isinstance(value, dict) else {}
        command_ref = LxMapper.unpack(values.get("menu") or "")
        if not command_ref or command_ref["kind"] != "source_command":
            raise ValueError("无效的音源操作")
        command = command_ref["data"]
        source_id = command.get("id")
        owner = command.get("owner") or self.client.username or "open"
        operation = command.get("op")
        if not source_id:
            raise ValueError("音源 ID 为空")
        sources = self.client.source_list()
        target = next((item for item in sources if str(item.get("id")) == str(source_id)), None)
        if target is None and operation != "delete_cancel":
            raise ValueError("音源已不存在，请刷新列表")
        if target:
            owner = str(target.get("owner") or self.client.username or "open")
            source_id = str(target.get("id"))
        if operation in ("enable", "disable"):
            allow_unsafe = bool(target and target.get("allowUnsafeVM"))
            result = self.client.source_toggle(source_id, owner, operation == "enable", allow_unsafe)
            if isinstance(result, dict) and result.get("success") is False:
                raise ValueError(result.get("message") or result.get("error") or "音源状态切换失败")
            message = "已启用" if operation == "enable" else "已停用"
        elif operation == "delete":
            name = str((target or {}).get("name") or source_id)
            return {"action": {
                "actionId": "lx_source_operation",
                "type": "menu",
                "title": "确认删除音源",
                "msg": "删除后无法恢复：%s" % name,
                "option": [
                    {"name": "确认删除", "action": LxMapper.pack("source_command", {"op": "delete_confirm", "id": source_id, "owner": owner})},
                    {"name": "取消", "action": LxMapper.pack("source_command", {"op": "delete_cancel", "id": source_id, "owner": owner})},
                ],
            }}
        elif operation == "delete_confirm":
            self.client.source_delete(source_id, owner)
            message = "音源已删除"
        elif operation == "delete_cancel":
            return {"toast": "已取消删除"}
        elif operation in ("up", "down"):
            ids = [str(item.get("id")) for item in sources if item.get("id")]
            if source_id not in ids:
                raise ValueError("音源不在当前列表中")
            index = ids.index(source_id)
            target_index = index - 1 if operation == "up" else index + 1
            if target_index < 0 or target_index >= len(ids):
                message = "已经在最前" if operation == "up" else "已经在最后"
            else:
                ids[index], ids[target_index] = ids[target_index], ids[index]
                self.client.source_reorder(ids)
                message = "音源顺序已更新"
        else:
            raise ValueError("不支持的音源操作")
        self.home_cache = None
        return {"action": {"actionId": "__refresh_list__"}, "toast": message}

    def _action_connection_settings(self, value):
        values = value if isinstance(value, dict) else {}
        options = {}
        for key in ("base_url", "username", "password", "api_token", "admin_password", "source", "playlist_source", "quality", "download_folder", "download_quality", "auto_download"):
            if key in values:
                options[key] = str(values[key]).strip()
        self._apply_options(options)
        warnings = []
        saved = self._save_settings()
        if not saved:
            warnings.append("配置文件保存失败")
        try:
            self.client.ping()
        except LxClientError as error:
            warnings.append("服务器连接失败: %s" % error)
        try:
            if self.client.username:
                self.client._login(force=True)
        except LxClientError as error:
            warnings.append("用户登录失败: %s" % error)
        message = "连接设置已保存" if saved else "连接设置仅当前有效"
        if warnings:
            message += "；" + "；".join(warnings)
        return {
            "action": {"actionId": "__refresh_list__"},
            "toast": message,
        }

    def _action_song_search(self, value):
        """搜索Action：从输入中获取关键词，使用当前选中的平台"""
        values = value if isinstance(value, dict) else {}
        
        keyword = ""
        
        # 从 input 数组中提取关键词
        input_list = values.get("input")
        if isinstance(input_list, list):
            for item in input_list:
                if item.get("id") == "keyword":
                    keyword = str(item.get("value") or "").strip()
        
        # 如果从 input 没取到，尝试直接从 values 取
        if not keyword:
            keyword = str(values.get("keyword") or "").strip()
        
        if not keyword:
            raise ValueError("请输入要搜索的歌名、歌手或专辑")

        # 保存搜索关键词
        self.search_keyword = keyword
        
        # 使用当前选中的平台（从筛选器设置）
        source = self.search_source or self.config.get("source") or "kw"
        source_name = SOURCE_NAMES.get(source, source)
        
        return {
            "action": {"actionId": "__refresh_list__"},
            "toast": f"🔍 搜索: {keyword} ({source_name})",
        }

    def _action_account(self, value):
        """提供本地账号切换；不触碰 lxserver 上的收藏或音源数据。"""
        values = value if isinstance(value, dict) else {}
        command_ref = LxMapper.unpack(values.get("menu") or "")
        if not command_ref:
            return {"action": {
                "actionId": "lx_account",
                "type": "menu",
                "title": "用户账号",
                "msg": "当前用户：%s" % (self.client.username or "未登录"),
                "option": [
                    {"name": "切换用户", "action": LxMapper.pack("account_command", {"op": "switch"})},
                    {"name": "退出当前用户", "action": LxMapper.pack("account_command", {"op": "logout"})},
                ],
            }}
        if command_ref["kind"] != "account_command":
            raise ValueError("无效的账号操作")
        operation = command_ref["data"].get("op")
        if operation == "switch":
            return {"action": {
                "actionId": "lx_connection_settings",
                "type": "multiInput",
                "title": "切换 lxserver 用户",
                "msg": "填写新用户名和密码后保存即可切换。",
                "input": self._settings_inputs(),
            }}
        if operation == "logout":
            return {"action": {
                "actionId": "lx_account",
                "type": "menu",
                "title": "确认退出用户",
                "msg": "退出后仅清除此脚本保存的用户名、密码和 Token，不会删除服务器数据。",
                "option": [
                    {"name": "确认退出", "action": LxMapper.pack("account_command", {"op": "logout_confirm"})},
                    {"name": "取消", "action": LxMapper.pack("account_command", {"op": "logout_cancel"})},
                ],
            }}
        if operation == "logout_cancel":
            return {"toast": "已取消退出"}
        if operation != "logout_confirm":
            raise ValueError("不支持的账号操作")
        self._apply_options({"username": "", "password": "", "api_token": ""})
        saved = self._save_settings()
        return {
            "action": {"actionId": "__refresh_list__"},
            "toast": "已退出当前用户" if saved else "已退出当前用户（配置仅当前有效）",
        }

    # ========== 设备识别与移动管理（不依赖音乐服务器在线） ==========
    @staticmethod
    def _activity():
        try:
            from java import jclass
            cls = jclass('java.lang.Class').forName('android.app.ActivityThread')
            current = cls.getMethod('currentActivityThread').invoke(None)
            field = cls.getDeclaredField('mActivities')
            field.setAccessible(True)
            for record in field.get(current).values().toArray():
                paused = record.getClass().getDeclaredField('paused')
                paused.setAccessible(True)
                if not paused.getBoolean(record):
                    activity = record.getClass().getDeclaredField('activity')
                    activity.setAccessible(True)
                    return activity.get(record)
        except Exception:
            pass
        return None

    def _detect_android_device_profile(self):
        now = time.time()
        cached = self._device_profile_cache
        if cached and now - cached['time'] < 5:
            return cached['detected'], cached['reason']
        detected, reason = 'phone', '未获取 Android Activity，按手机交互处理'
        try:
            activity = self._activity()
            if activity:
                config = activity.getResources().getConfiguration()
                manager = activity.getPackageManager()
                ui_manager = activity.getSystemService('uimode')
                if int(config.uiMode) & 15 == 4:
                    detected, reason = 'tv', 'Android 电视 UI 模式'
                elif any(manager.hasSystemFeature(x) for x in (
                        'android.software.leanback', 'android.hardware.type.television')):
                    detected, reason = 'tv', 'Android Leanback / television 特性'
                elif ui_manager and int(ui_manager.getCurrentModeType()) == 4:
                    detected, reason = 'tv', 'UiModeManager 电视模式'
                else:
                    width = int(config.smallestScreenWidthDp)
                    if width <= 0:
                        metrics = activity.getResources().getDisplayMetrics()
                        width = int(min(metrics.widthPixels, metrics.heightPixels) / float(metrics.density or 1))
                    detected = 'tablet' if width >= 600 else 'phone'
                    reason = '最小屏幕宽度 %sdp' % width
        except Exception as error:
            reason = '自动识别暂不可用：%s；可手工指定模式' % error
        self._device_profile_cache = {'time': now, 'detected': detected, 'reason': reason}
        return detected, reason

    def _device_profile_info(self):
        detected, reason = self._detect_android_device_profile()
        selected = self.config.get('device_mode', 'auto')
        effective = detected if selected in ('auto', 'tv_off') else selected
        labels = {'tv': 'TV', 'phone': '手机', 'tablet': '平板'}
        return {'selected': selected, 'detected': detected, 'effective': effective,
                'tv_mode': effective == 'tv' and selected != 'tv_off', 'reason': reason,
                'detected_label': labels.get(detected, '手机'),
                'effective_label': labels.get(effective, '手机')}

    def _tv_mode_enabled(self):
        return self._device_profile_info()['tv_mode']

    @staticmethod
    def _config_bool(value):
        if isinstance(value, bool):
            return value
        if str(value).lower() in ('true', '1', 'yes', '是', '开启'):
            return True
        if str(value).lower() in ('false', '0', 'no', '否', '关闭'):
            return False
        raise ValueError('开关必须为 true 或 false')

    def _validated_settings(self, values):
        if not isinstance(values, dict) or any(k not in DEFAULT_CONFIG for k in values):
            raise ValueError('包含未知设置')
        result = dict(values)
        numbers = {'mobile_web_port': (1024, 65535), 'timeout': (3, 60),
                   'max_pages': (1, 100), 'max_songs': (1, 10000), 'home_ttl': (30, 3600)}
        for key, value in result.items():
            if key in numbers:
                if isinstance(value, bool) or not re.fullmatch(r'\d+', str(value)):
                    raise ValueError('%s 必须为整数' % key)
                minimum, maximum = numbers[key]
                value = int(value)
                if not minimum <= value <= maximum:
                    raise ValueError('%s 范围为 %s–%s' % (key, minimum, maximum))
            elif key == 'mobile_web_enabled':
                value = self._config_bool(value)
            elif key == 'device_mode':
                if value not in dict(_DEVICE_OPTIONS):
                    raise ValueError('无效的设备模式')
            elif key in ('source', 'playlist_source', 'album_source'):
                if value not in SOURCE_NAMES:
                    raise ValueError('无效的音乐平台')
            elif key in ('quality', 'download_quality'):
                if value not in QUALITY_NAMES:
                    raise ValueError('无效的音质')
            elif key in ('sources', 'qualities'):
                value = self._list_value(value, [])
                allowed = SOURCE_NAMES if key == 'sources' else QUALITY_NAMES
                if not value or any(x not in allowed for x in value):
                    raise ValueError('%s 必须填写有效平台/音质，以英文逗号分隔' % key)
                value = list(dict.fromkeys(value))
            else:
                if not isinstance(value, str) or len(value) > 8192:
                    raise ValueError('%s 必须为文本且不超过 8192 字符' % key)
                value = value if key in _SECRET_KEYS else value.strip()
                if key == 'base_url':
                    parsed = urlsplit(value)
                    if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or parsed.password:
                        raise ValueError('服务器地址必须是有效的 http/https 地址，账号请填写在独立字段中')
                    try:
                        parsed.port
                    except ValueError:
                        raise ValueError('服务器端口无效')
                    if parsed.query or parsed.fragment:
                        raise ValueError('服务器地址不能包含 query 或 fragment')
                    value = value.rstrip('/')
                if key == 'auto_download' and value not in ('是', '否'):
                    raise ValueError('自动下载只能选是或否')
                if key == 'download_folder' and value:
                    if not os.path.isabs(value) or '\x00' in value:
                        raise ValueError('下载文件夹请填写客户端设备上的绝对路径')
            result[key] = value
        return result

    def _commit_local_settings(self, values):
        with self._settings_lock:
            options = self._validated_settings(values)
            old = deepcopy(self.config)
            self.config.update(options)
            if not self._save_settings():
                self.config.clear()
                self.config.update(old)
                raise OSError('配置保存失败，已保留原设置')
            self._apply_options({})
            self._device_profile_cache = None

    def _sync_mobile_service(self):
        try:
            service = self._sync_mobile_service_impl()
            self._mobile_service_error = service.error if service else self._mobile_service_error
            return service
        except Exception as error:
            # 精简 Python/线程环境不支持 Web 时，仍继续加载全部音乐功能。
            self._mobile_service_error = '移动 Web 初始化失败：%s' % error
            return self._mobile_service

    def _sync_mobile_service_impl(self):
        with _WEB_SERVICES_LOCK:
            current = self._mobile_service
            port = int(self.config['mobile_web_port'])
            if current and (not self.config['mobile_web_enabled'] or current.port != port):
                current.stop()
                self._mobile_service = None
                if _WEB_SERVICES.get(self.settings_path) is current:
                    _WEB_SERVICES.pop(self.settings_path, None)
            if not self.config['mobile_web_enabled']:
                return None
            if not self._mobile_service:
                previous = _WEB_SERVICES.get(self.settings_path)
                if previous and previous.owner is not self:
                    previous.stop()
                self._mobile_service = LxMobileService(self)
                _WEB_SERVICES[self.settings_path] = self._mobile_service
            if not self._mobile_service.server:
                self._mobile_service.start()
            return self._mobile_service

    def _settings_revision(self):
        return hashlib.sha256(json.dumps(self.config, sort_keys=True, ensure_ascii=False).encode('utf-8')).hexdigest()

    def _mobile_snapshot(self, csrf):
        labels = {x['id']: x['name'] for x in self._settings_inputs()}
        labels.update({'album_source': '默认专辑平台', 'sources': '可用搜索平台（英文逗号分隔）',
                       'qualities': '播放音质列表（英文逗号分隔）', 'timeout': '请求超时（秒）',
                       'max_pages': '歌单最多读取页数', 'max_songs': '最多收集歌曲数',
                       'home_ttl': '首页缓存时间（秒）', 'device_mode': '设备识别 / TV 模式',
                       'mobile_web_enabled': '移动 Web 服务', 'mobile_web_port': '移动 Web 端口'})
        numbers = {'mobile_web_port': (1024, 65535), 'timeout': (3, 60),
                   'max_pages': (1, 100), 'max_songs': (1, 10000), 'home_ttl': (30, 3600)}
        fields = []
        for key in DEFAULT_CONFIG:
            item = {'key': key, 'label': labels.get(key, key), 'value': self.config[key]}
            if key in _SECRET_KEYS:
                item.update(value='', secret=True, has_value=bool(self.config[key]))
            elif key in ('source', 'playlist_source', 'album_source'):
                item['options'] = list(SOURCE_NAMES.items())
            elif key in ('quality', 'download_quality'):
                item['options'] = list(QUALITY_NAMES.items())
            elif key == 'auto_download':
                item['options'] = [('否', '否'), ('是', '是')]
            elif key == 'device_mode':
                item['options'] = _DEVICE_OPTIONS
            elif key == 'mobile_web_enabled':
                item.update(value='true' if self.config[key] else 'false', options=[('true', '开启'), ('false', '关闭')])
            elif key in numbers:
                item.update(kind='int', min=numbers[key][0], max=numbers[key][1])
            fields.append(item)
        service = self._mobile_service
        return {'settings': fields, 'revision': self._settings_revision(), 'csrf': csrf,
                'device': self._device_profile_info(), 'service': service.status() if service else {}}

    def _mobile_browse(self, path):
        path = path or self.config.get('download_folder') or ('/storage/emulated/0' if os.path.isdir('/storage/emulated/0') else os.path.expanduser('~'))
        path = os.path.abspath(path)
        if not os.path.isdir(path):
            raise ValueError('客户端目录不存在或不可访问：' + path)
        names = sorted(x for x in os.listdir(path) if os.path.isdir(os.path.join(path, x)))
        return {'path': path, 'parent': os.path.dirname(path) if os.path.dirname(path) != path else '',
                'directories': [{'name': x, 'path': os.path.join(path, x)} for x in names[:300]],
                'truncated': len(names) > 300}

    def _mobile_command(self, path, body):
        if path == '/api/settings':
            if body.get('revision') != self._settings_revision():
                raise ValueError('配置已在客户端或其他手机更改，请重新读取后保存')
            raw = body.get('values', {})
            if not isinstance(raw, dict):
                raise ValueError('values 必须为对象')
            values = dict(raw)
            clear = body.get('clear', [])
            if not isinstance(clear, list) or any(x not in _SECRET_KEYS for x in clear):
                raise ValueError('只能清空密码或 Token')
            for key in clear:
                values[key] = ''
            old_port, old_enabled = self.config['mobile_web_port'], self.config['mobile_web_enabled']
            self._commit_local_settings(values)
            restart = old_port != self.config['mobile_web_port'] or old_enabled != self.config['mobile_web_enabled']
            return {'message': '设置已保存' + ('，Web 端口/开关已变更' if restart else ''), 'restart': restart}
        if path == '/api/source':
            command = {key: body.get(key) for key in ('id', 'owner', 'op')}
            if command['op'] not in ('enable', 'disable', 'up', 'down', 'delete_confirm'):
                raise ValueError('不支持的音源操作')
            result = self._action_source_operation({'menu': LxMapper.pack('source_command', command)})
            return {'message': result.get('toast', '音源已更新')}
        if path == '/api/import':
            result = self._import_source_content(str(body.get('filename') or ''), body.get('content'),
                                                 self._config_bool(body.get('unsafe', False)))
            return {'message': result['toast']}
        if path == '/api/check':
            self.client.ping()
            if self.client.username:
                self.client._login(force=True)
            return {'message': '音乐服务器连接与登录正常'}
        if path == '/api/logout':
            self._commit_local_settings({'username': '', 'password': '', 'api_token': ''})
            return {'message': '已退出当前用户'}
        if path == '/api/disconnect':
            self._mobile_service.refresh_pairing(disconnect=True)
            return {'message': '所有手机连接已断开'}
        raise ValueError('未知操作')

    def _device_action_config(self):
        info = self._device_profile_info()
        return {'actionId': 'lx_device_settings', 'type': 'menu', 'title': '设备识别 / TV 模式',
                'msg': '识别：%s；%s\nTV 支持方向键导航、确认、返回、焦点高亮和大屏弹窗。' % (info['detected_label'], info['reason']),
                'selectedIndex': [x[0] for x in _DEVICE_OPTIONS].index(info['selected']),
                'option': [{'name': title, 'action': mode} for mode, title in _DEVICE_OPTIONS]}

    def _web_settings_config(self):
        return {'actionId': 'lx_web_settings', 'type': 'multiInput', 'title': '移动 Web 服务设置',
                'msg': '默认端口 40012；改端口后用新的 IP:端口 访问。', 'input': [
                    {'id': 'mobile_web_enabled', 'name': 'Web 服务', 'value': 'true' if self.config['mobile_web_enabled'] else 'false', 'selectData': '开启:=true,关闭:=false'},
                    {'id': 'mobile_web_port', 'name': '端口（1024–65535）', 'value': str(self.config['mobile_web_port']), 'inputType': 2}]}

    def _action_device_settings(self, value):
        selected = value.get('menu') if isinstance(value, dict) else None
        if selected is not None:
            self._commit_local_settings({'device_mode': selected})
            return {'action': {'actionId': '__refresh_list__'}, 'toast': '设备模式已保存：' + dict(_DEVICE_OPTIONS)[selected]}
        return self._present_dialog(self._device_action_config())

    def _action_web_settings(self, value):
        if not isinstance(value, dict) or not any(k in value for k in ('mobile_web_enabled', 'mobile_web_port')):
            return self._present_dialog(self._web_settings_config())
        options = {k: value[k] for k in ('mobile_web_enabled', 'mobile_web_port') if k in value}
        self._commit_local_settings(options)
        service = self._sync_mobile_service()
        error = service.error if service else self._mobile_service_error
        return {'action': {'actionId': '__refresh_list__'}, 'toast': 'Web 设置已保存' + ('；' + error if error else '')}

    def _action_mobile_web(self, value):
        operation = value.get('menu') if isinstance(value, dict) else None
        service = self._sync_mobile_service()
        if operation == 'settings':
            return self._present_dialog(self._web_settings_config())
        if operation == 'enable':
            return self._action_web_settings({'mobile_web_enabled': True})
        if operation == 'refresh' and service:
            service.refresh_pairing()
        if operation == 'disconnect' and service:
            service.refresh_pairing(disconnect=True)
        state = service.status(pairing=True) if service else {'port': self.config['mobile_web_port'], 'running': False, 'error': self._mobile_service_error}
        options = [{'name': 'Web 开关 / 修改端口', 'action': 'settings'}]
        if state['running']:
            options += [{'name': '刷新二维码', 'action': 'refresh'}, {'name': '断开全部手机', 'action': 'disconnect'}]
        else:
            options += [{'name': '开启 / 重新尝试启动', 'action': 'enable'}]
        title = '移动 Web · 端口 %s' % state['port']
        message = state.get('error') or ('同一 Wi-Fi 扫码或打开下方地址即可管理全部设置和 JS 音源。地址可收藏，服务运行期间不按时间过期。\n' + '\n'.join(state.get('urls', [])) if state['running'] else '服务已关闭')
        if state['running'] and not state.get('primary_url'):
            message += '\n未找到局域网 IPv4，请检查 Wi-Fi / 网络。'
        config = {'actionId': 'lx_mobile_web', 'type': 'menu', 'title': title, 'msg': message, 'option': options}
        if operation != 'qr' and self._show_native_dialog(config, qr_url=state.get('qr_url', '')):
            return {'toast': '移动 Web 管理'}
        # 无原生桥时使用壳的 HTML 对话框，二维码内置 SVG 不依赖外网。
        qr = self._qr_svg(state.get('qr_url', ''))
        if qr and operation == 'qr':
            return {'action': {'actionId': 'lx_web_qr', 'type': 'msgbox', 'title': title,
                               'htmlMsg': '<p>%s</p>%s<p>%s</p>' % (html.escape(message).replace('\n', '<br>'), qr, html.escape(state['qr_url']))},
                    'toast': '返回 Web 菜单可刷新二维码、断开手机或修改端口'}
        if qr:
            config['option'].insert(0, {'name': '显示扫码二维码', 'action': 'qr'})
            config['msg'] += '\n扫码地址：' + state['qr_url']
        return {'action': config}

    @staticmethod
    def _qr_svg(url):
        matrix = _mobile_web_qr_matrix(url)
        if not matrix:
            return ''
        rects = ''.join('<rect x="%s" y="%s" width="1" height="1"/>' % (x + 4, y + 4)
                        for y, row in enumerate(matrix) for x, dark in enumerate(row) if dark)
        return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 41 41" width="246" height="246"><rect width="41" height="41" fill="white"/><g fill="black">%s</g></svg>' % rects

    def _present_dialog(self, config):
        if self._tv_mode_enabled() and self._show_native_dialog(config):
            return {'toast': config.get('title', '')}
        return {'action': config}

    def _tv_action_item(self, item):
        """只包装可直接渲染的菜单/表单；文件选择器继续使用壳的既有实现。"""
        if item.get('vod_tag') != 'action':
            return item
        try:
            config = json.loads(item['vod_id'])
            if config.get('type') not in ('menu', 'multiInput'):
                return item
            if any(x.get('selectData') in ('[file]', '[folder]') for x in config.get('input', [])):
                return item
            result = dict(item)
            result['vod_id'] = json.dumps({'actionId': 'lx_tv_dialog', 'value': {'dialog': config}}, ensure_ascii=False)
            return result
        except (ValueError, TypeError, KeyError):
            return item

    def _show_native_dialog(self, config, qr_url=''):
        """UI 线程显示；耗时网络操作在后台执行。Android 桥失败则由壳显示原 Action。"""
        activity = self._activity()
        if not activity:
            return False
        try:
            from java import jclass, dynamic_proxy
            Runnable = jclass('java.lang.Runnable')
            Click = jclass('android.view.View$OnClickListener')
            Focus = jclass('android.view.View$OnFocusChangeListener')
            Key = jclass('android.view.View$OnKeyListener')
            Dismiss = jclass('android.content.DialogInterface$OnDismissListener')
            widgets = {name: jclass('android.widget.' + name) for name in ('LinearLayout', 'ScrollView', 'TextView', 'EditText', 'Button')}
            Dialog = jclass('android.app.Dialog')
            Color = jclass('android.graphics.Color')
            Drawable = jclass('android.graphics.drawable.GradientDrawable')
            LP = jclass('android.widget.LinearLayout$LayoutParams')
            # 在调用 UI 线程前解析所有核心类型，精简壳缺失 API 时直接回退。
        except Exception:
            return False
        spider = self
        tv = self._tv_mode_enabled()
        callbacks = []
        shown = threading.Event()
        render_ok = [False]

        class Task(dynamic_proxy(Runnable)):
            def __init__(self, fn):
                super().__init__()
                self.fn = fn

            def run(self):
                self.fn()

        def post(fn):
            task = Task(fn)
            callbacks.append(task)
            activity.runOnUiThread(task)

        def show():
            try:
                dialog = Dialog(activity)
                dialog.setTitle(config.get('title', '落雪设置'))
                dialog.setCancelable(True)  # 返回键关闭当前弹窗，由宿主保持原页面焦点。
                body = widgets['LinearLayout'](activity)
                body.setOrientation(1)
                density = float(activity.getResources().getDisplayMetrics().density or 1)
                dp = lambda value: int(value * density + .5)
                body.setPadding(dp(28 if tv else 18), dp(16), dp(28 if tv else 18), dp(16))
                scroll = widgets['ScrollView'](activity)
                scroll.setFillViewport(True)
                scroll.addView(body)
                dialog.setContentView(scroll)
                focusables = []
                fields = {}

                def text(value):
                    view = widgets['TextView'](activity)
                    view.setText(str(value))
                    view.setTextSize(19 if tv else 16)
                    view.setTextColor(Color.parseColor('#173129'))
                    view.setPadding(0, dp(8), 0, dp(8))
                    body.addView(view, LP(-1, -2))
                    return view

                text(config.get('msg', ''))
                if tv:
                    text('遥控器：↑↓移动焦点 · OK 确认 · 返回关闭；输入框按 OK 呼出键盘。')

                def background(focused):
                    drawable = Drawable()
                    drawable.setColor(Color.parseColor('#dcfce7' if focused else '#f0f6f3'))
                    drawable.setCornerRadius(float(dp(10)))
                    drawable.setStroke(dp(3 if focused else 1), Color.parseColor('#047857' if focused else '#b7cfc4'))
                    return drawable

                class FocusListener(dynamic_proxy(Focus)):
                    def onFocusChange(self, view, focused):
                        view.setBackgroundDrawable(background(focused))
                        if focused:
                            view.getParent().requestChildFocus(view, view)

                def focusable(view):
                    view.setId(jclass('android.view.View').generateViewId())
                    view.setFocusable(True)
                    view.setFocusableInTouchMode(True)
                    view.setMinimumHeight(dp(56 if tv else 48))
                    view.setTextSize(20 if tv else 16)
                    view.setTextColor(Color.parseColor('#173129'))
                    view.setBackgroundDrawable(background(False))
                    listener = FocusListener()
                    callbacks.append(listener)
                    view.setOnFocusChangeListener(listener)
                    focusables.append(view)

                def button(title, fn):
                    view = widgets['Button'](activity)
                    view.setText(str(title))
                    view.setContentDescription(str(title))
                    focusable(view)

                    class Listener(dynamic_proxy(Click)):
                        def onClick(self, target):
                            fn()
                    listener = Listener()
                    callbacks.append(listener)
                    view.setOnClickListener(listener)
                    params = LP(-1, -2)
                    params.setMargins(0, dp(5), 0, dp(5))
                    body.addView(view, params)
                    return view

                feedback = text('')
                working = [False]

                def submit(values):
                    if working[0]:
                        return
                    working[0] = True
                    for view in focusables:
                        view.setEnabled(False)
                    feedback.setText('正在处理…')

                    def worker():
                        try:
                            with spider._settings_lock:
                                result = spider._dispatch_action({'actionId': config['actionId'], 'value': values})
                        except Exception as error:
                            result = {'toast': '操作失败：' + str(error)}

                        def finish():
                            working[0] = False
                            for view in focusables:
                                view.setEnabled(True)
                            next_action = result.get('action') if isinstance(result, dict) else None
                            if config.get('actionId') == 'lx_mobile_web' and not (next_action and next_action.get('type') == 'msgbox'):
                                dialog.dismiss()
                                return
                            if next_action and next_action.get('type') in ('menu', 'multiInput'):
                                dialog.dismiss()
                                spider._present_dialog(next_action)
                            elif next_action and next_action.get('type') == 'msgbox':
                                feedback.setText(re.sub('<[^>]+>', '', str(next_action.get('htmlMsg', '操作失败'))))
                            else:
                                feedback.setText(result.get('toast', '操作完成；返回并重新进入分类可看到更新') if isinstance(result, dict) else str(result))
                                if focusables:
                                    focusables[0].requestFocus()
                        post(finish)
                    threading.Thread(target=worker, daemon=True).start()

                if qr_url:
                    matrix = _mobile_web_qr_matrix(qr_url)
                    if matrix:
                        try:
                            Bitmap = jclass('android.graphics.Bitmap')
                            Paint = jclass('android.graphics.Paint')
                            Canvas = jclass('android.graphics.Canvas')
                            image = jclass('android.widget.ImageView')(activity)
                            scale = max(4, dp(5 if tv else 4))
                            bitmap = Bitmap.createBitmap(41 * scale, 41 * scale, Bitmap.Config.ARGB_8888)
                            canvas = Canvas(bitmap)
                            paint = Paint()
                            paint.setARGB(255, 255, 255, 255)
                            canvas.drawPaint(paint)
                            paint.setARGB(255, 0, 0, 0)
                            for y, row in enumerate(matrix):
                                for x, dark in enumerate(row):
                                    if dark:
                                        left, top = (x + 4) * scale, (y + 4) * scale
                                        canvas.drawRect(float(left), float(top), float(left + scale), float(top + scale), paint)
                            image.setImageBitmap(bitmap)
                            image.setAdjustViewBounds(True)
                            image.setContentDescription('移动 Web 固定访问地址二维码')
                            body.addView(image, LP(-1, 41 * scale))
                        except Exception:
                            text('二维码绘制不可用，请在浏览器输入下方扫码地址。')
                    text('访问地址：' + qr_url)

                if config.get('type') == 'menu':
                    for option in config.get('option', []):
                        button(option.get('name', ''), lambda opt=option: submit({'menu': opt.get('action', '')}))
                else:
                    for item in config.get('input', []):
                        key = item['id']
                        text(item.get('name', key))
                        choices = item.get('selectData', '')
                        if choices and not choices.startswith('['):
                            options = [x.split(':=', 1) if ':=' in x else [x, x] for x in choices.split(',')]
                            current = [str(item.get('value', ''))]
                            fields[key] = lambda v=current: v[0]
                            view_ref = []

                            def cycle(v=current, opts=options, ref=view_ref):
                                index = next((i for i, x in enumerate(opts) if x[1] == v[0]), -1)
                                chosen = opts[(index + 1) % len(opts)]
                                v[0] = chosen[1]
                                ref[0].setText(chosen[0] + '（OK 切换）')
                            title = next((x[0] for x in options if x[1] == current[0]), current[0])
                            view_ref.append(button(title + '（OK 切换）', cycle))
                        else:
                            view = widgets['EditText'](activity)
                            view.setInputType(int(item.get('inputType', 1)))
                            view.setSingleLine(True)
                            view.setText(str(item.get('value', '')))
                            view.setHint(str(item.get('tip', '')))
                            focusable(view)
                            if tv:
                                class InputKeyListener(dynamic_proxy(Key)):
                                    def onKey(self, target, key_code, event):
                                        if int(key_code) not in (23, 66):
                                            return False
                                        if int(event.getAction()) == 1:
                                            target.requestFocus()
                                            keyboard = activity.getSystemService('input_method')
                                            if keyboard:
                                                keyboard.showSoftInput(target, 1)
                                        return True
                                key_listener = InputKeyListener()
                                callbacks.append(key_listener)
                                view.setOnKeyListener(key_listener)
                            body.addView(view, LP(-1, -2))
                            fields[key] = lambda v=view: str(v.getText())
                    button('保存 / 确认', lambda: submit({key: getter() for key, getter in fields.items()}))
                button('返回 / 关闭', dialog.dismiss)
                for index, view in enumerate(focusables):
                    # 首尾停留，不形成焦点陷阱；横向键交给编辑框移动光标。
                    view.setNextFocusUpId(focusables[max(0, index - 1)].getId())
                    view.setNextFocusDownId(focusables[min(len(focusables) - 1, index + 1)].getId())

                class DismissListener(dynamic_proxy(Dismiss)):
                    def onDismiss(self, target):
                        if dialog in spider._native_dialogs:
                            spider._native_dialogs.remove(dialog)
                        for callback in callbacks[:]:
                            if callback in spider._ui_callbacks:
                                spider._ui_callbacks.remove(callback)
                listener = DismissListener()
                callbacks.append(listener)
                dialog.setOnDismissListener(listener)
                spider._native_dialogs.append(dialog)
                spider._ui_callbacks.extend(callbacks)
                dialog.show()
                window = dialog.getWindow()
                if window:
                    window.setBackgroundDrawable(background(False))
                    metrics = activity.getResources().getDisplayMetrics()
                    window.setLayout(int(metrics.widthPixels * (.84 if tv else .94)), int(metrics.heightPixels * .86))
                    window.setSoftInputMode(2)  # 首次进入不弹软键盘；OK 可手工呼出。
                if focusables:
                    index = int(config.get('selectedIndex', 0)) if config.get('type') == 'menu' else 0
                    focusables[min(max(0, index), len(focusables) - 1)].requestFocus()
                render_ok[0] = True
            except Exception as error:
                # Java 桥异常时关闭未完成的窗口，让调用方回退宿主 Action。
                try:
                    if 'dialog' in locals():
                        dialog.dismiss()
                    jclass('android.widget.Toast').makeText(activity, 'TV 弹窗不可用：%s，请使用移动 Web 或关闭 TV 优化' % error, 1).show()
                except Exception:
                    pass
            finally:
                shown.set()
        try:
            post(show)
            # 已在 UI 线程会立即执行；后台调用等候短时间，确认渲染失败则回退。
            return render_ok[0] if shown.wait(1) else True
        except Exception:
            return False

    def destroy(self):
        with _WEB_SERVICES_LOCK:
            service, self._mobile_service = self._mobile_service, None
            if service:
                service.stop()
            if _WEB_SERVICES.get(self.settings_path) is service:
                _WEB_SERVICES.pop(self.settings_path, None)
        activity = self._activity()
        if activity and self._native_dialogs:
            try:
                from java import jclass, dynamic_proxy
                spider = self
                class CloseDialogs(dynamic_proxy(jclass('java.lang.Runnable'))):
                    def run(self):
                        for dialog in spider._native_dialogs[:]:
                            dialog.dismiss()
                activity.runOnUiThread(CloseDialogs())
            except Exception:
                pass
        for client in self._retired_clients + [self.client]:
            try:
                client.session.close()
            except Exception:
                pass
        self._retired_clients.clear()

    def isVideoFormat(self, url):
        return False

    def manualVideoCheck(self):
        return False

    def localProxy(self, param):
        return None
