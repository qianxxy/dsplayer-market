# coding=utf-8
"""
目标站: 55yy5 / 555dy / 555kp0 系列
"""
import re
import sys
import json
import urllib.parse
from bs4 import BeautifulSoup

sys.path.append('..')
from base.spider import Spider


class Spider(Spider):

    def init(self, extend=""):
        self.site_url = "https://www.55yy5.com"
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        }
        self.categories = [
            {"type_id": "1", "type_name": "电影"},
            {"type_id": "2", "type_name": "连续剧"},
            {"type_id": "3", "type_name": "综艺"},
            {"type_id": "4", "type_name": "动漫"},
            {"type_id": "124", "type_name": "福利"},
            {"type_id": "126", "type_name": "擦边短剧"},
        ]
        self.filters = {}

    def get_domain_for_tid(self, tid):
        # 福利分类在独立域名
        if tid == "124":
            return "https://www.555kp0.com"
        return self.site_url

    def homeContent(self, filter):
        url = self.site_url + "/index/home.html"
        resp = self.fetch(url, headers=self.headers)
        video_list = []
        if resp:
            soup = BeautifulSoup(resp.text, 'html.parser')
            items = soup.select('a.module-poster-item')
            for item in items[:20]:
                href = item.get('href', '')
                vod_id_match = re.search(r'/voddetail/(\d+)\.html', href)
                if not vod_id_match:
                    continue
                vod_id = vod_id_match.group(1)
                title_tag = item.select_one('.module-poster-item-title')
                vod_name = title_tag.get_text(strip=True) if title_tag else ''
                img_tag = item.select_one('img.lazyload') or item.select_one('img')
                vod_pic = ''
                if img_tag:
                    src = img_tag.get('data-original') or img_tag.get('data-src') or img_tag.get('src')
                    if src and not src.startswith('http'):
                        src = 'https:' + src
                    vod_pic = src if src else ''
                remark_tag = item.select_one('.module-item-note')
                vod_remarks = remark_tag.get_text(strip=True) if remark_tag else ''
                if vod_name:
                    video_list.append({
                        "vod_id": vod_id,
                        "vod_name": vod_name,
                        "vod_pic": vod_pic,
                        "vod_remarks": vod_remarks
                    })
        return {"class": self.categories, "list": video_list, "filters": self.filters}

    def homeVideoContent(self):
        return self.homeContent(False)

    def categoryContent(self, tid, pg, filter, extend):
        page = int(pg) if pg else 1
        base = self.get_domain_for_tid(tid)
        # 真实分页格式: /vodshow/{tid}--------{page}---.html
        url = f"{base}/vodshow/{tid}--------{page}---.html"
        resp = self.fetch(url, headers=self.headers)
        if not resp:
            return {"list": [], "page": page, "pagecount": 1, "limit": 24, "total": 0}

        soup = BeautifulSoup(resp.text, 'html.parser')
        video_list = []
        items = soup.select('a.module-poster-item')
        for item in items:
            href = item.get('href', '')
            vod_id_match = re.search(r'/voddetail/(\d+)\.html', href)
            if not vod_id_match:
                continue
            vod_id = vod_id_match.group(1)
            title_tag = item.select_one('.module-poster-item-title')
            vod_name = title_tag.get_text(strip=True) if title_tag else ''
            img_tag = item.select_one('img.lazyload') or item.select_one('img')
            vod_pic = ''
            if img_tag:
                src = img_tag.get('data-original') or img_tag.get('data-src') or img_tag.get('src')
                if src and not src.startswith('http'):
                    src = 'https:' + src
                vod_pic = src if src else ''
            remark_tag = item.select_one('.module-item-note')
            vod_remarks = remark_tag.get_text(strip=True) if remark_tag else ''
            if vod_name:
                video_list.append({
                    "vod_id": vod_id,
                    "vod_name": vod_name,
                    "vod_pic": vod_pic,
                    "vod_remarks": vod_remarks
                })

        # 分页
        pagecount = 1
        pagination = soup.select_one('#page')
        if pagination:
            max_page = page
            for a in pagination.select('a'):
                txt = a.get_text(strip=True)
                if txt.isdigit():
                    max_page = max(max_page, int(txt))
            pagecount = max_page

        return {
            "list": video_list,
            "page": page,
            "pagecount": pagecount,
            "limit": 24,
            "total": len(video_list) * pagecount
        }

    def detailContent(self, ids):
        if not ids:
            return {"list": []}
        vod_id = ids[0]
        # 尝试多个域名
        urls = [
            f"{self.site_url}/voddetail/{vod_id}.html",
            f"https://www.555kp0.com/voddetail/{vod_id}.html",
        ]
        resp = None
        for u in urls:
            r = self.fetch(u, headers=self.headers)
            if r and r.status_code == 200:
                resp = r
                break
        if not resp:
            return {"list": []}

        soup = BeautifulSoup(resp.text, 'html.parser')

        title_elem = soup.select_one('.module-info-heading h1') or soup.select_one('h1')
        vod_name = title_elem.get_text(strip=True) if title_elem else vod_id

        vod_pic = ''
        img_elem = soup.select_one('.module-info-poster img') or soup.select_one('.module-item-pic img')
        if img_elem:
            src = img_elem.get('data-original') or img_elem.get('data-src') or img_elem.get('src')
            if src and not src.startswith('http'):
                src = 'https:' + src
            vod_pic = src if src else ''

        vod_content = ''
        vod_actor = ''
        vod_director = ''
        vod_area = ''
        vod_year = ''

        info_items = soup.select('.module-info-content .module-info-item')
        for item in info_items:
            text = item.get_text(strip=True)
            if '导演' in text:
                vod_director = text.split('：')[-1].split(':')[-1].strip()
            elif '主演' in text:
                vod_actor = text.split('：')[-1].split(':')[-1].strip()
            elif '地区' in text:
                vod_area = text.split('：')[-1].split(':')[-1].strip()
            elif '年份' in text or '年代' in text:
                vod_year = text.split('：')[-1].split(':')[-1].strip()

        desc_elem = soup.select_one('.module-info-introduction-content') or soup.select_one('.module-info-introduction .module-info-introduction-content')
        if desc_elem:
            vod_content = desc_elem.get_text(strip=True)
        if not vod_content:
            meta_desc = soup.select_one('meta[name="description"]')
            if meta_desc:
                vod_content = meta_desc.get('content', '')

        # 播放列表
        play_from_list = []
        play_url_list = []
        tab_items = soup.select('.module-tab-item span')
        if tab_items:
            play_blocks = soup.select('.module-play-list')
            for idx, tab in enumerate(tab_items):
                if idx < len(play_blocks):
                    episodes = []
                    for a in play_blocks[idx].select('a'):
                        ep_name = a.get_text(strip=True)
                        href = a.get('href', '')
                        if ep_name and href:
                            episodes.append(f"{ep_name}${href}")
                    if episodes:
                        play_from_list.append(tab.get_text(strip=True))
                        play_url_list.append('#'.join(episodes))
        else:
            # 备用
            list_content = soup.select('.module-play-list-content')
            for block in list_content:
                a_tags = block.select('a')
                if a_tags:
                    episodes = [f"{a.get_text(strip=True)}${a.get('href', '')}" for a in a_tags if a.get_text(strip=True) and a.get('href')]
                    if episodes:
                        play_from_list.append('默认线路')
                        play_url_list.append('#'.join(episodes))
                        break

        vod_play_from = '$$$'.join(play_from_list) if play_from_list else '默认线路'
        vod_play_url = '$$$'.join(play_url_list) if play_url_list else ''

        return {
            "list": [{
                "vod_id": vod_id,
                "vod_name": vod_name,
                "vod_pic": vod_pic,
                "vod_content": vod_content,
                "vod_actor": vod_actor,
                "vod_director": vod_director,
                "vod_area": vod_area,
                "vod_year": vod_year,
                "vod_play_from": vod_play_from,
                "vod_play_url": vod_play_url
            }]
        }

    def searchContent(self, key, quick, pg="1"):
        page = int(pg) if pg else 1
        params = {'wd': key}
        if page > 1:
            params['page'] = page
        url = f"{self.site_url}/vodsearch/-------------.html?{urllib.parse.urlencode(params)}"
        resp = self.fetch(url, headers=self.headers)
        if not resp:
            return {"list": [], "page": page, "pagecount": 1}

        soup = BeautifulSoup(resp.text, 'html.parser')
        video_list = []
        items = soup.select('a.module-poster-item')
        for item in items:
            href = item.get('href', '')
            vod_id_match = re.search(r'/voddetail/(\d+)\.html', href)
            if not vod_id_match:
                continue
            vod_id = vod_id_match.group(1)
            title_tag = item.select_one('.module-poster-item-title')
            vod_name = title_tag.get_text(strip=True) if title_tag else ''
            img_tag = item.select_one('img.lazyload') or item.select_one('img')
            vod_pic = ''
            if img_tag:
                src = img_tag.get('data-original') or img_tag.get('data-src') or img_tag.get('src')
                if src and not src.startswith('http'):
                    src = 'https:' + src
                vod_pic = src if src else ''
            remark_tag = item.select_one('.module-item-note')
            vod_remarks = remark_tag.get_text(strip=True) if remark_tag else ''
            if vod_name:
                video_list.append({
                    "vod_id": vod_id,
                    "vod_name": vod_name,
                    "vod_pic": vod_pic,
                    "vod_remarks": vod_remarks
                })

        pagecount = 1
        pagination = soup.select_one('#page')
        if pagination:
            max_page = page
            for a in pagination.select('a'):
                if a.get_text(strip=True).isdigit():
                    max_page = max(max_page, int(a.get_text(strip=True)))
            pagecount = max_page

        return {"list": video_list, "page": page, "pagecount": pagecount}

    def playerContent(self, flag, id, vipFlags):
        if not id.startswith('http'):
            url = self.site_url + id
        else:
            url = id
        return {"parse": 1, "url": url, "header": self.headers}