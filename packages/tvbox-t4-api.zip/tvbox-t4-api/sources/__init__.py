"""VOD handler registry —— 自动扫描 + 硬化校验 + 热加载。

用法:把写好源文件丢进 sources/ 就行,不用改本文件、不用改 main.py、
不用重启容器(默认 3 秒内自动识别;就算 uvicorn --reload 的 inotify 事件
在 bind mount 上传不过来,这里的后台重扫也能兜住)。

本文件对外的三样东西(全部向后兼容):
    ALL_HANDLERS    list[VodHandler]   —— main.py 照常 `for h in ALL_HANDLERS: register(h)`
    LOAD_REPORT     list[dict]         —— 每个文件加载成没成、为什么没成
    rescan()        () -> dict         —— 手动触发重扫
支持子目录分类:sources/ 下可以随便建目录,源文件放进去照样自动生效,例如
    sources/短剧/星芽短剧.py   →  模块名 短剧.星芽短剧(接口路径只由源自己的 source_name 决定,跟目录名无关)
    sources/音乐/酷我音乐.py
目录名或文件名以 `_` 开头的一律跳过不加载(当抽屉用:`_待用/`、`_废弃/` 丢进去只收纳、不生效)
子目录里不需要 __init__.py。

被拒的文件会写明原因,而不是静悄悄消失:
    skipped   文件名叫 _x.py / template / example
    bad_name  source_name 不合法(必须小写字母数字,可带 - 和 _)
    dup       source_name 与先加载的源撞名(报出占用方+本文件两个相对路径,后者不注册)
    template  类里 HOST 还是 example.com / 有 IS_TEMPLATE = True
    import    import 报错(语法错 / 依赖缺)
    init      实例化报错(__init__ 里抛异常)
"""
from __future__ import annotations

import importlib
import logging
import os
import importlib.util
import re
import sys
import threading
import time
from pathlib import Path

from core.base import VodHandler

logger = logging.getLogger("sources")

# main.py 里 logging.basicConfig() 往往排在 `from sources import ALL_HANDLERS`
# 之后执行 —— 那样首次扫描的日志会被整个吞掉(根 logger 还没 handler)。
# 这里自己兜一层:根 logger 没 handler 就先装上,保证加载报告一定看得见。
if not logging.getLogger().handlers:
    logging.basicConfig(
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%Y/%m/%d %H:%M:%S",
        level=logging.INFO,
    )

PKG_DIR = Path(__file__).parent
NAME_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,63}$")

# 文件名黑名单(小写、不含 .py)。SOURCES_TEMPLATE.py 直接丢进来不会被注册。
SKIP_MODULES = {
    "__init__",
    "sources_template",
    "template",
    "example",
    "example_source",
    "sample",
    "demo_template",
}
# 这些名字不能出现在 sources/ 里,否则会遮蔽框架模块
FORBIDDEN_MODULES = {"core", "main", "settings", "router", "t4", "base"}
# 占位 HOST,认出来就当模板,不注册(防止模板副本污染 /t4/sites)
PLACEHOLDER_HOSTS = ("example.com", "example.org", "example.net", "your-site.com")

_lock = threading.RLock()
_report: list[dict] = []
_loaded: dict[str, dict] = {}  # source_name -> {file, module, cls, instance}
_snapshot: dict[str, tuple[float, int]] = {}
_seen_files: dict[str, str] = {}  # module_name -> source_name


# ── 单文件加载 ─────────────────────────────────────────────────────────


def _entry(**kw) -> dict:
    base = {
        "file": "",
        "module": "",
        "cls": "",
        "source_name": "",
        "status": "",
        "detail": "",
    }
    base.update(kw)
    return base


def _is_placeholder(cls: type) -> str:
    """模板/占位文件识别:返回原因,空串 = 是真源。"""
    if getattr(cls, "IS_TEMPLATE", False):
        return "IS_TEMPLATE = True"
    host = str(getattr(cls, "HOST", "") or "").lower()
    for bad in PLACEHOLDER_HOSTS:
        if bad in host:
            return f"HOST 还是占位地址 ({host})"
    return ""


def _load_module(module_name: str, rel: str = ""):
    """导入一个源文件。

    同目录的老源一行不变:照旧走包导入(`from . import x` 这类相对导入可用)。
    子目录里的文件万一因为环境较老导不进来,退一步按文件路径直接加载 ——
    所以子目录里不需要放 __init__.py。
    """
    try:
        module = importlib.import_module(f".{module_name}", __package__)
        return module, ""
    except Exception as exc:  # noqa: BLE001
        if rel:
            module, _path_err = _load_by_path(module_name, rel)
            if module is not None:
                return module, ""
        logger.error(
            "源文件 %s 导入失败: %s: %s",
            rel or f"{module_name}.py",
            type(exc).__name__,
            exc,
        )
        return None, f"{type(exc).__name__}: {exc}"


def _load_by_path(module_name: str, rel: str):
    """按文件路径加载(不依赖包结构);成功返回 module,失败返回 (None, 原因)。"""
    path = PKG_DIR / rel
    try:
        spec = importlib.util.spec_from_file_location(module_name, str(path))
        if spec is None or spec.loader is None:
            return None, "spec 建不起来"
        module = importlib.util.module_from_spec(spec)
        module.__package__ = module_name.rpartition(".")[0] or (__package__ or "sources")
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
        return module, ""
    except Exception as exc:  # noqa: BLE001
        sys.modules.pop(module_name, None)
        return None, f"{type(exc).__name__}: {exc}"


def _own_classes(module) -> list[type]:
    """只认本模块里定义的 VodHandler 子类。

    顺手把 `from sources.javday import JavDay` 这种再导出挡掉 —— 否则
    一个文件能把别的源重复注册一遍。
    """
    out: list[type] = []
    for attr_name in dir(module):
        attr = getattr(module, attr_name)
        if (
            isinstance(attr, type)
            and issubclass(attr, VodHandler)
            and attr is not VodHandler
            and getattr(attr, "__module__", "") == module.__name__
        ):
            out.append(attr)
    return out


def _register_into_router(handler: VodHandler) -> bool:
    """把实例挂进 core.router 的注册表。

    优先直接写 _registry(这样「同一个源换新版」能就地替换,不会因为
    register() 的撞名保护而抛错);拿不到私有表就退回调 register()。
    """
    try:
        from core import router as core_router
    except Exception as exc:  # noqa: BLE001
        logger.error("拿不到 core.router,新源无法生效: %s", exc)
        return False

    reg = getattr(core_router, "_registry", None)
    if isinstance(reg, dict):
        reg[handler.source_name] = handler
        return True

    try:
        core_router.register(handler)
        return True
    except Exception as exc:  # noqa: BLE001
        logger.error("注册 %s 被拒: %s(可能需要重启容器)", handler.source_name, exc)
        return False


# ── 依赖自动补齐（原生 T4 源）────────────────────────────────────────────
# 壳子源那套在 sources/tvbox_compat.py；这里是 VodHandler 原生源的同款保障：
# 文件一落盘先做一次依赖体检（纯 AST + find_spec，不装东西、不阻塞扫描），
# 缺的模块丢后台线程自动装（三镜像 → 先只要 wheel → 装不上才上编译），
# 装完立刻重扫该文件并挂进路由 —— 所以「丢进去就不管」＝服务端自己收拾干净。
# 开关：TVBOX_DEPS_AUTO=0 可关（默认开）。
_deps_lock = threading.Lock()
_deps_busy: set[str] = set()        # 正在后台补依赖的模块
_deps_done: dict[str, str] = {}     # 模块 → 最近一次处理结论（给 /sources 看）
_deps_warn: dict[str, str] = {}     # 模块 → 仍缺的依赖（没补齐时留着）
_deps_sig: dict[str, tuple] = {}    # 模块 → 上次体检时的文件指纹（防重复扫）


def _deps_enabled() -> bool:
    val = (os.getenv("TVBOX_DEPS_AUTO", "1") or "1").strip().lower()
    return val not in ("0", "false", "no", "off")


def _looks_native(path) -> bool:
    """只给原生 VodHandler 源兜底；DS/壳子源由 sources/tvbox_compat.py 自己管（它也会装）。"""
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as fh:
            return "VodHandler" in fh.read()
    except OSError:
        return False


def _missing_deps(path) -> list[str]:
    """快速体检：只解析 import + 查 find_spec，不装任何东西。"""
    try:
        from deps_auto import is_available, third_party_imports
    except Exception:  # noqa: BLE001
        return []
    try:
        return [m for m in third_party_imports(path) if not is_available(m)]
    except Exception as exc:  # noqa: BLE001
        logger.debug("依赖体检出错(%s): %s", path, exc)
        return []


def _deps_fix_async(module_name: str, rel: str, missing: list[str]) -> None:
    """后台补齐依赖 → 装完自动重扫该文件（上线）。"""

    with _deps_lock:
        if module_name in _deps_busy:
            return
        _deps_busy.add(module_name)

    def _work() -> None:
        try:
            from deps_auto import ensure_deps_for_file, summarize
        except Exception as exc:  # noqa: BLE001
            with _deps_lock:
                _deps_busy.discard(module_name)
            logger.debug("deps_auto 不可用，放弃自动装依赖：%s", exc)
            return
        path = PKG_DIR / rel
        note = ""
        try:
            logger.info("源 %s 缺依赖 [%s]，后台自动安装…", rel, ", ".join(missing))
            note = summarize(ensure_deps_for_file(path, install=True) or {}) or ""
        except Exception as exc:  # noqa: BLE001
            note = f"装依赖出错: {exc}"
            logger.warning("源 %s 依赖自动安装失败：%s", rel, exc)
        still = _missing_deps(path)
        with _deps_lock:
            _deps_done[module_name] = note or "依赖已齐"
            if still:
                _deps_warn[module_name] = ", ".join(still)
            else:
                _deps_warn.pop(module_name, None)
            _deps_busy.discard(module_name)
        if note:
            logger.info("源 %s 依赖处理结果：%s", rel, note)
        if still:
            logger.warning("源 %s 仍缺依赖：%s（可手动 pip 装）", rel, ", ".join(still))
        # 装上了就上线；没装上也要重扫一次，把最新报错刷进报告
        try:
            _evs = _handle_module(module_name, publish=True, rel=rel)
        except Exception:  # noqa: BLE001
            logger.exception("依赖处理后重扫 %s 失败", rel)
            _evs = []
        if _evs:
            with _lock:
                # 补装前的旧报错作废，只留本轮最新结果，免得 /sources 一直挂着假问题
                _touched = {e.get("file") for e in _evs if e.get("file")}
                if _touched:
                    _report[:] = [e for e in _report if e.get("file") not in _touched]
                _report.extend(_evs)
                del _report[: max(0, len(_report) - 500)]

    threading.Thread(target=_work, name=f"deps-{module_name}", daemon=True).start()


def _deps_precheck(module_name: str, rel: str) -> list[str]:
    """体检 + 按需起后台安装线程；返回本次缺的模块名。"""
    if not rel or not _deps_enabled():
        return []
    path = PKG_DIR / rel
    try:
        st = path.stat()
    except OSError:
        return []
    if not _looks_native(path):
        return []  # 壳子/DS 源交给 tvbox_compat，避免两套同时 pip 打架
    sig = (st.st_mtime_ns, st.st_size)
    with _deps_lock:
        busy = module_name in _deps_busy
        fresh = _deps_sig.get(module_name) == sig
        warned = [m for m in (_deps_warn.get(module_name, "") or "").split(", ") if m]
    if busy or fresh:  # 正在装 / 这个版本已体检过 → 不重复扫
        return warned
    missing = _missing_deps(path)
    with _deps_lock:
        _deps_sig[module_name] = sig
        if missing:
            _deps_warn[module_name] = ", ".join(missing)
        else:
            _deps_warn.pop(module_name, None)
    if missing:
        _deps_fix_async(module_name, rel, missing)
    return missing



def _handle_module(module_name: str, publish: bool, rel: str = "") -> list[dict]:
    """加载一个文件。publish=True 时立刻挂进路由(热加载路径)。

    rel = 相对 sources/ 的路径(如 `短剧/星芽短剧.py`),只用于报告显示;不给就按模块名推。
    """
    entries: list[dict] = []
    filename = rel or _display_file(module_name)
    missing = _deps_precheck(module_name, rel or filename)

    module, err = _load_module(module_name, filename)
    if module is None:
        if missing:
            err = f"{err}｜缺依赖 {', '.join(missing)}(已丢后台自动安装,装完自动重扫)"
        return [_entry(file=filename, module=module_name, status="import", detail=err)]

    classes = _own_classes(module)
    if not classes:
        return [
            _entry(
                file=filename,
                module=module_name,
                status="skipped",
                detail="这个文件里没有 VodHandler 子类",
            )
        ]

    for cls in classes:
        name = str(getattr(cls, "source_name", "") or "")
        base = {"file": filename, "module": module_name, "cls": cls.__name__}

        if not name:
            entries.append(_entry(**base, status="bad_name", detail="source_name 是空的"))
            continue
        if not NAME_RE.match(name):
            entries.append(
                _entry(
                    **base,
                    source_name=name,
                    status="bad_name",
                    detail="source_name 只能用 a-z0-9 和 - _(小写,字母或数字开头)",
                )
            )
            continue
        reason = _is_placeholder(cls)
        if reason:
            entries.append(
                _entry(**base, source_name=name, status="template", detail=reason)
            )
            continue
        if name in _loaded and _loaded[name]["file"] != filename:
            entries.append(
                _entry(
                    **base,
                    source_name=name,
                    status="dup",
                    detail=(
                        f"撞名:已被 {_loaded[name]['file']} 占用,"
                        f"本文件({filename})不注册"
                    ),
                )
            )
            continue

        try:
            instance = cls()
        except Exception as exc:  # noqa: BLE001
            entries.append(
                _entry(
                    **base,
                    source_name=name,
                    status="init",
                    detail=f"{type(exc).__name__}: {exc}",
                )
            )
            continue

        _loaded[name] = {
            "file": filename,
            "module": module_name,
            "cls": cls.__name__,
            "instance": instance,
        }
        _seen_files[module_name] = name

        ok = True
        if publish:
            ok = _register_into_router(instance)
        entries.append(
            _entry(
                **base,
                source_name=name,
                status="ok" if ok else "publish_failed",
                detail="" if ok else "没能挂进路由,可能需要重启",
            )
        )

    return entries


# ── 全量扫描 ───────────────────────────────────────────────────────────


def _source_files() -> list[tuple[str, str]]:
    """递归枚举 sources/ 下的源文件 → [(点分模块名, 相对路径)]。

    - 支持任意层级子目录分类:`sources/短剧/星芽短剧.py` → `短剧.星芽短剧` / `短剧/星芽短剧.py`
    - 目录名或文件名以 `_` 开头的整棵跳过(抽屉目录:丢进去只收纳、不加载)
    - 跳过隐藏目录(.git 等)、__pycache__、非 .py 文件、黑名单名字
    """
    out: list[tuple[str, str]] = []
    for dirpath, dirnames, filenames in os.walk(str(PKG_DIR)):
        # 原地过滤:os.walk 就不会往这些目录里走
        dirnames[:] = sorted(
            d for d in dirnames if not d.startswith("_") and not d.startswith(".")
        )
        rel_dir = Path(dirpath).relative_to(PKG_DIR)
        for name in sorted(filenames):
            if not name.endswith(".py") or name.startswith("."):
                continue
            stem = name[:-3]
            if not stem or stem.startswith("_") or "." in stem:
                continue
            low = stem.lower()
            if low in SKIP_MODULES or low in FORBIDDEN_MODULES:
                continue
            rel = Path(rel_dir) / name
            out.append((".".join(rel.with_suffix("").parts), rel.as_posix()))
    return sorted(out)


def _display_file(module_name: str) -> str:
    """点分模块名 → 人看的相对路径(`短剧.星芽短剧` → `短剧/星芽短剧.py`)。"""
    return module_name.replace(".", "/") + ".py"


def _rel_map() -> dict[str, str]:
    """点分模块名 → 相对路径(热加载报路径用)。"""
    return {module_name: rel for module_name, rel in _source_files()}


def _module_files() -> list[str]:
    """兼容旧调用:只要点分模块名(已排序)。"""
    return [module_name for module_name, _rel in _source_files()]


def _snapshot_now() -> dict[str, tuple[float, int]]:
    snap: dict[str, tuple[float, int]] = {}
    for name, rel in _source_files():
        try:
            st = (PKG_DIR / rel).stat()
        except OSError:
            continue
        snap[name] = (st.st_mtime, st.st_size)
    return snap


def _scan(publish: bool, only: list[str] | None = None) -> list[dict]:
    with _lock:
        pairs = _source_files()
        if only is not None:
            want = set(only)
            pairs = [(m, rel) for m, rel in pairs if m in want]
        out: list[dict] = []
        for module_name, rel in pairs:
            out.extend(_handle_module(module_name, publish=publish, rel=rel))
        return out


# ── 首次扫描(给 main.py 用,不 publish —— main.py 自己会 register)──────

_report = _scan(publish=False)
ALL_HANDLERS: list[VodHandler] = [v["instance"] for v in _loaded.values()]
_snapshot = _snapshot_now()

_ok = [e for e in _report if e["status"] == "ok"]
_bad = [e for e in _report if e["status"] not in {"ok"}]
logger.info(
    "扫描 sources/: 生效 %d 个 → %s",
    len(_ok),
    ", ".join(e["source_name"] for e in _ok) or "(无)",
)
for e in _bad:
    logger.warning(
        "未生效 [%s] %s: %s", e["status"], e["file"], e["detail"] or e["source_name"]
    )


# ── 热加载看门狗 ───────────────────────────────────────────────────────


def _watch_once() -> list[dict]:
    """比一次文件指纹,有新增/改动就重新加载并挂上路由。"""
    global _snapshot
    now = _snapshot_now()
    changed = [n for n, sig in now.items() if _snapshot.get(n) != sig]
    deleted = [n for n in _snapshot if n not in now]
    _snapshot = now
    if not changed and not deleted:
        return []

    events: list[dict] = []
    for module_name in deleted:
        name = _seen_files.pop(module_name, "")
        if name and name in _loaded and _loaded[name]["file"] == _display_file(module_name):
            _loaded.pop(name, None)
            try:
                from core import router as core_router

                unreg = getattr(core_router, "unregister", None)
                if callable(unreg):
                    unreg(name)
                else:
                    reg = getattr(core_router, "_registry", None)
                    if isinstance(reg, dict):
                        reg.pop(name, None)
            except Exception:  # noqa: BLE001
                pass
            events.append(_entry(file=_display_file(module_name), source_name=name, status="removed"))
            logger.info("源 %s 下线(文件已删除)", name)

    for module_name in changed:
        ents = _handle_module(module_name, publish=True, rel=_rel_map().get(module_name, ""))
        events.extend(ents)
        for e in ents:
            if e["status"] == "ok":
                logger.info("热加载生效: %s → /t4/%s/...", e["file"], e["source_name"])
            else:
                logger.error(
                    "热加载未生效 [%s] %s: %s", e["status"], e["file"], e["detail"]
                )
    if events:
        with _lock:
            # 同一文件的历史条目作废，只留本轮最新结果（否则补装依赖成功后 /sources 里旧报错一直挂着）
            _touched = {e.get("file") for e in events if e.get("file")}
            if _touched:
                _report[:] = [e for e in _report if e.get("file") not in _touched]
            _report.extend(events)
            del _report[: max(0, len(_report) - 500)]
    return events


def rescan() -> dict:
    """手动全量重扫 + 重挂(排查时用)。"""
    with _lock:
        _report.clear()
        _report.extend(_scan(publish=False))
        for name in _loaded:
            _report.extend(_handle_module(_loaded[name]["module"], publish=True))
    return report()


def report() -> dict:
    with _lock:
        return {
            "loaded": [
                {"source_name": n, "file": v["file"], "cls": v["cls"]}
                for n, v in sorted(_loaded.items())
            ],
            "active": sorted(_loaded.keys()),
            "report": list(_report),
            "problems": [e for e in _report if e["status"] != "ok"],
            "deps_native": {
                "enabled": _deps_enabled(),
                "busy": sorted(_deps_busy),
                "missing": dict(sorted(_deps_warn.items())),
                "recent": dict(sorted(_deps_done.items())),
            },
        }


def _watcher_loop(interval: float) -> None:
    while True:
        try:
            time.sleep(interval)
            _watch_once()
        except Exception:  # noqa: BLE001
            logger.exception("源热加载看门狗出错(已忽略,继续运行)")


_WATCH_INTERVAL = float(os.getenv("SOURCE_WATCH_INTERVAL", "3") or 0)
if _WATCH_INTERVAL > 0:
    threading.Thread(
        target=_watcher_loop, args=(_WATCH_INTERVAL,), name="source-watcher", daemon=True
    ).start()
    logger.info("源热加载看门狗已启动:每 %.1fs 重扫一次 sources/", _WATCH_INTERVAL)


# ── 可选的加载报告接口(挂在 /sources)────────────────────────────────


def _expose_report_route() -> None:
    try:
        from core import router as core_router

        core_router.router.add_api_route(
            "/sources", lambda: report(), methods=["GET"], name="sources_report"
        )
        logger.info("加载报告接口已挂上:GET /sources")
    except Exception as exc:  # noqa: BLE001
        logger.debug("挂 /sources 报告接口失败(不影响服务): %s", exc)


try:
    from core import settings as _settings

    if getattr(_settings, "EXPOSE_SOURCE_REPORT", True) and os.getenv(
        "EXPOSE_SOURCE_REPORT", "1"
    ).lower() not in {"0", "false", "no", "off"}:
        _expose_report_route()
except Exception as _exc:  # noqa: BLE001
    logger.debug("跳过 /sources 报告接口: %s", _exc)
