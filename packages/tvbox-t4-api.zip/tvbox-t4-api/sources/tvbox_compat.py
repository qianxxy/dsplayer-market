# -*- coding: utf-8 -*-
"""TVBox 壳子源自动桥接：把 sources/ 里的 TVBox Python 源接成 T4 源。

规则很简单 —— 只要某个 .py 是壳子风格（有 homeContent / categoryContent /
detailContent / searchContent / playerContent，且不是本项目的 VodHandler 源），
就自动加载、桥接、注册成 ``/t4/<源名>/...`` 接口。

- 源文件**一行不改**；改文件后 5 秒内自动重载（``TVBOX_WATCH_INTERVAL`` 可调）。
- 新文件丢进 sources/ 自动上线；删掉文件自动下线。
- 桥接结果会并进 ``/sources`` 报告（``bridged`` 段），另有 ``GET /tb-sources``。
- ``getProxyUrl()`` 走 ``GET /tbproxy/<源名>?…``（原样转发给源的 localProxy）。

命名：能用中文名映射的走映射（见 tvbox_bridge.NAME_MAP），其余走 ``src<md5前8>``。
"""

from __future__ import annotations

import logging
import os
import sys
import threading
import time
from pathlib import Path
from urllib.parse import parse_qs

from core.base import VodHandler
from tvbox_bridge import NAME_MAP, TvboxSource, load_spider_instance, slug_for

# ⚠️ 必须放模块顶层：本文件用了 `from __future__ import annotations`，
# 注解会变成字符串再按模块全局名字解析 —— 函数内局部 import 的 Request
# 解析不到，FastAPI 会把它当成查询参数（422 Field required）。
try:
    from fastapi import Request, Response
    from fastapi.responses import RedirectResponse
except Exception:  # pragma: no cover - 没装 fastapi 时只做纯扫描
    Request = Response = RedirectResponse = None  # type: ignore

log = logging.getLogger("tvbox-compat")

PKG_DIR = Path(__file__).parent
PROJECT_DIR = PKG_DIR.parent

# 依赖自动化层（缺啥装啥 + 装不上用内置实现兜底）；加载不到就退化为空实现，不影响桥接
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))
try:
    from deps_auto import ensure_deps_for_file, summarize as deps_summary
except Exception as _deps_exc:  # noqa: BLE001
    log.warning("依赖自动化层加载失败（%s），本进程按无依赖层运行", _deps_exc)

    def ensure_deps_for_file(path, **_kw):  # type: ignore[misc]
        return {
            "file": Path(path).name,
            "third_party": [],
            "missing": [],
            "installed": [],
            "shimmed": [],
            "failed": [],
            "blacklisted": [],
            "skipped_recent_fail": [],
        }

    def deps_summary(_res):  # type: ignore[misc]
        return ""


def _resolve_app_port() -> None:
    """把真实监听端口写进 APP_PORT，供 base.spider.getProxyUrl 拼自访问地址。

    main.py --port X 只把 X 交给 uvicorn，不会回写 settings/env；这里从 argv 兜住，
    否则源里的 getProxyUrl() 会指向 12333 而不是实际端口。
    """
    if os.getenv("APP_PORT"):
        return
    argv = list(sys.argv)
    if "--port" in argv:
        idx = argv.index("--port")
        if idx + 1 < len(argv) and str(argv[idx + 1]).isdigit():
            os.environ["APP_PORT"] = str(argv[idx + 1])
            return
    try:
        from core import settings

        os.environ["APP_PORT"] = str(getattr(settings, "APP_PORT", 12333))
    except Exception:  # noqa: BLE001
        os.environ.setdefault("APP_PORT", "12333")


_resolve_app_port()
SKIP_FILES = {"__init__.py", "tvbox_compat.py", "sources_template.py"}
SKIP_STEMS = {"template", "example", "sample", "demo", "demo_template", "example_source"}

# source_name → {file, cls, instance, class, mtime}
_bridged: dict[str, dict] = {}
_failed: list[dict] = []
_deps_map: dict[str, dict] = {}      # file → 最近一次依赖体检结果
_lock = threading.RLock()


def _remember_failure(res: dict) -> None:
    """同一个文件的失败只留最新一条（否则看门狗每轮都追加一堆重复条目）。"""
    with _lock:
        for i, old in enumerate(_failed):
            if old.get("file") == res.get("file"):
                _failed[i] = res
                return
        _failed.append(res)
        if len(_failed) > 200:
            del _failed[:-200]


def _forget_failure(file_name: str) -> None:
    """源后来加载成功 → 把它的失败记录删掉，报告里不留假失败。"""
    with _lock:
        _failed[:] = [f for f in _failed if f.get("file") != file_name]


def _deps_public() -> list[dict]:
    with _lock:
        return [
            {
                "file": name,
                "third_party": d.get("third_party", []),
                "missing": d.get("missing", []),
                "installed": d.get("installed", []),
                "shimmed": d.get("shimmed", []),
                "failed": d.get("failed", []),
                "blacklisted": d.get("blacklisted", []),
            }
            for name, d in sorted(_deps_map.items())
        ]


# ── 识别 ────────────────────────────────────────────────────────────


def _rel_of(path: Path) -> str:
    """源文件相对 sources/ 的路径(子目录会带目录名);不在 sources/ 下时退回文件名。"""
    try:
        return path.relative_to(PKG_DIR).as_posix()
    except ValueError:
        return path.name


def _dotted_of(rel: str) -> str:
    """相对路径 → 点分模块名(`短剧/星芽短剧.py` → `短剧.星芽短剧`)，与加载器内部键对齐。"""
    return rel[:-3].replace("/", ".") if rel.endswith(".py") else rel


def _candidate_files() -> list[Path]:
    """递归扫 sources/(含子目录)下的壳子源。

    - 目录名或文件名以 `_` 开头的整棵跳过(与加载器同一口径,`_待用/` 这类抽屉不加载)
    - 跳过隐藏目录、__pycache__、SKIP_FILES/SKIP_STEMS、以及本来就是 T4 源的文件
    """
    out: list[Path] = []
    for dirpath, dirnames, filenames in os.walk(str(PKG_DIR)):
        dirnames[:] = sorted(
            d for d in dirnames if not d.startswith("_") and not d.startswith(".")
        )
        for name in sorted(filenames):
            if not name.endswith(".py") or name.startswith("."):
                continue
            low = name.lower()
            if name in SKIP_FILES or low in SKIP_FILES:
                continue
            if name.startswith("_") or name[:-3].lower() in SKIP_STEMS:
                continue
            path = Path(dirpath) / name
            try:
                text = path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            if "VodHandler" in text:            # 本来就是 T4 源，交给原加载器
                continue
            if "homeContent" not in text:       # 不像壳子源
                continue
            out.append(path)
    return sorted(out)


def _load_one(path: Path, install_deps: bool = True) -> dict:
    """加载单个壳子源 → 结果字典（先做依赖体检：缺的自动装、能兜底的兜底）。"""
    slug, display = slug_for(path)
    deps: dict = {}
    try:
        deps = ensure_deps_for_file(path, install=install_deps) or {}
    except Exception as exc:  # noqa: BLE001
        log.warning("依赖体检异常（忽略，照常加载）：%s", exc)
    if deps:
        with _lock:
            _deps_map[_rel_of(path)] = deps
    deps_note = deps_summary(deps) if deps else ""

    try:
        spider = load_spider_instance(path, slug)
    except Exception as exc:  # noqa: BLE001
        msg = f"{type(exc).__name__}: {exc}"
        if deps_note:
            msg = f"{msg}｜依赖：{deps_note}"
        log.error("桥接 %s 失败：%s", _rel_of(path), msg)
        return {"file": _rel_of(path), "source_name": slug, "display_name": display, "status": "import", "detail": msg}
    if spider is None:
        msg = "文件里没有壳子风格源类（或缺 5 个契约方法）"
        if deps_note:
            msg = f"{msg}｜依赖：{deps_note}"
        log.error("桥接 %s 失败：%s", _rel_of(path), msg)
        return {"file": _rel_of(path), "source_name": slug, "display_name": display, "status": "no_class", "detail": msg}

    name = ""
    try:
        name = str(spider.getName() or "")
    except Exception:  # noqa: BLE001
        pass
    if name and path.stem not in NAME_MAP:
        display = name or display

    try:
        instance = type(
            "Tvbox_" + slug,
            (TvboxSource,),
            {
                "source_name": slug,
                "display_name": display,
                "spider_file": str(path),
                "spider": spider,
            },
        )()
    except Exception as exc:  # noqa: BLE001
        msg = f"{type(exc).__name__}: {exc}"
        log.error("桥接 %s 实例化失败：%s", _rel_of(path), msg)
        return {"file": _rel_of(path), "source_name": slug, "display_name": display, "status": "init", "detail": msg}

    _bridged[slug] = {
        "file": _rel_of(path),
        "cls": type(spider).__name__,
        "display_name": display,
        "instance": instance,
        "mtime": path.stat().st_mtime,
    }
    _forget_failure(_rel_of(path))  # 之前因缺依赖失败过 → 现在成功了，报告里不留假失败
    log.info(
        "桥接生效：%s → /t4/%s/...（显示名 %s）%s",
        _rel_of(path),
        slug,
        display,
        f"｜依赖：{deps_note}" if deps_note else "",
    )
    return {"file": _rel_of(path), "source_name": slug, "display_name": display, "status": "ok", "detail": deps_note}


# ── 首次扫描（在 sources/__init__ 的扫描过程中执行）────────────────


def _boot() -> None:
    with _lock:
        for path in _candidate_files():
            # 启动阶段只做"零耗时"处理（内置兜底立即生效），pip 安装交给后台线程，
            # 免得一个源缺依赖把整个服务启动卡住
            res = _load_one(path, install_deps=False)
            if res["status"] != "ok":
                _remember_failure(res)
            _publish(res)
    log.info(
        "TVBox 壳子源桥接：生效 %d 个 → %s",
        len(_bridged),
        ", ".join(f"{k}({v['file']})" for k, v in _bridged.items()) or "(无)",
    )
    for f in _failed:
        log.warning("桥接未生效 [%s] %s: %s", f["status"], f["file"], f["detail"])


def _deps_warmup() -> None:
    """后台补齐依赖：给每个壳子源跑一次体检（缺的自动装），装完立刻重试加载。"""
    try:
        time.sleep(1.0)  # 等服务先起来
        for path in _candidate_files():
            with _lock:
                known = _deps_map.get(_rel_of(path))
            if known and not known.get("failed") and not known.get("missing"):
                continue  # 依赖本来就齐
            try:
                ensure_deps_for_file(path, install=True)
            except Exception:  # noqa: BLE001
                log.exception("依赖预热出错（忽略）：%s", _rel_of(path))
        _watch_once()  # 装完的源立刻上线，不用等下一个扫描周期
    except Exception:  # noqa: BLE001
        log.exception("依赖预热线程出错（已忽略）")


def _publish(res: dict) -> None:
    """把桥接结果并进 sources 加载报告（/sources 就能一起看到）。"""
    try:
        from sources import _loaded, _seen_files  # 加载器内部表（同一进程）
    except Exception:  # noqa: BLE001
        return
    if res["status"] != "ok":
        return
    slug = res["source_name"]
    entry = _bridged.get(slug)
    if not entry:
        return
    _loaded[slug] = {
        "file": entry["file"],
        "module": f"tvbox:{Path(entry['file']).stem}",
        "cls": entry["cls"],
        "instance": entry["instance"],
    }
    _seen_files[_dotted_of(entry["file"])] = slug


def _register_into_router(instance) -> None:
    """把桥接实例挂进路由（新文件在线时用；首次由 main.py 统一注册）。"""
    try:
        from core import router as core_router

        reg = getattr(core_router, "_registry", None)
        if isinstance(reg, dict):
            reg[instance.source_name] = instance
    except Exception as exc:  # noqa: BLE001
        log.error("挂路由失败 %s: %s", instance.source_name, exc)


def _unregister(slug: str) -> None:
    try:
        from core import router as core_router

        reg = getattr(core_router, "_registry", None)
        if isinstance(reg, dict):
            reg.pop(slug, None)
        from sources import _loaded

        _loaded.pop(slug, None)
    except Exception:  # noqa: BLE001
        pass


# ── 热加载看门狗 ────────────────────────────────────────────────────


def _watch_once() -> None:
    # 首次扫描时 sources/__init__ 还没执行完（report 函数尚不存在），到这里补挂
    _wrap_loader_report()
    with _lock:
        files = {_rel_of(p): p for p in _candidate_files()}
        # 新增
        for name, path in files.items():
            slug, _display = slug_for(path)
            if slug in _bridged:
                if _bridged[slug].get("file") != name:
                    log.warning(
                        "桥接跳过(撞名):%s 已被 %s 占用,本文件(%s)不注册",
                        slug,
                        _bridged[slug].get("file"),
                        name,
                    )
                continue
            res = _load_one(path)
            if res["status"] != "ok":
                _remember_failure(res)
                continue
            inst = _bridged[res["source_name"]]["instance"]
            _register_into_router(inst)
            _publish(res)
            log.info("桥接上线：%s", name)
        # 变更
        for slug, entry in list(_bridged.items()):
            path = files.get(entry["file"])
            if path is None:
                continue
            try:
                mt = path.stat().st_mtime
            except OSError:
                continue
            if mt != entry["mtime"]:
                entry["mtime"] = mt
                if entry["instance"].reload():
                    entry["display_name"] = entry["instance"].display_name
                    log.info("桥接重载：%s（显示名 %s）", entry["file"], entry["display_name"])
        # 删除
        for slug, entry in list(_bridged.items()):
            if entry["file"] not in files:
                _bridged.pop(slug, None)
                _unregister(slug)
                log.info("桥接下线：%s（文件已删除）", entry["file"])


def _watch_loop(interval: float) -> None:
    while True:
        try:
            time.sleep(interval)
            _watch_once()
        except Exception:  # noqa: BLE001
            log.exception("桥接看门狗出错（已忽略，继续运行）")


def report() -> dict:
    _wrap_loader_report()
    with _lock:
        return {
            "bridged": [
                {"source_name": k, "file": v["file"], "cls": v["cls"], "display_name": v["display_name"], "status": "ok"}
                for k, v in sorted(_bridged.items())
            ],
            "failed": list(_failed),
            "deps": _deps_public(),
            "count": len(_bridged),
        }


# ── /tbproxy（源自己的 localProxy，原样回二进制）────────────────────


def _expose_routes() -> None:
    try:
        from core.router import get_handler

        async def tbproxy(source: str, request: Request):
            handler = get_handler(source)
            if not isinstance(handler, TvboxSource):
                return Response(content=b"unknown bridged source", status_code=404)
            params = {
                k: (v[0] if v else "") for k, v in parse_qs(str(request.url.query or "")).items()
            }
            try:
                status, ctype, body = handler.proxy_response(params)
            except NotImplementedError:
                return Response(content=b"localProxy not implemented", status_code=404)
            except Exception:  # noqa: BLE001
                log.exception("[%s] tbproxy 失败", source)
                return Response(content=b"proxy error", status_code=502)
            if status in (301, 302, 303, 307, 308) and body:
                return RedirectResponse(body.decode("utf-8", "ignore"), status_code=status)
            return Response(content=body, status_code=status, media_type=ctype or None)

        from core import router as core_router

        core_router.router.add_api_route("/tbproxy/{source}", tbproxy, methods=["GET"], name="tvbox_local_proxy")
        core_router.router.add_api_route("/tb-sources", lambda: report(), methods=["GET"], name="tvbox_bridge_report")
        log.info("桥接路由已挂上：GET /tbproxy/{source}、GET /tb-sources")
    except Exception as exc:  # pragma: no cover
        log.debug("挂桥接路由失败（不影响服务）：%s", exc)


def _wrap_loader_report() -> None:
    """让 /sources 报告里不再把壳子源当“未生效”噪音，但桥接失败的真实原因要露出来。"""
    try:
        import sources as _sources

        original = _sources.report
        if getattr(original, "_tvbox_wrapped", False):
            return

        def wrapped():
            data = original()
            with _lock:
                bridged_files = {v["file"] for v in _bridged.values()}
                failed = list(_failed)
            handled = bridged_files | {f.get("file") for f in failed} | {"tvbox_compat.py"}
            # 加载器对壳子源的 skip/import 报错属于噪音（桥接自己会报），去掉
            problems = [p for p in data.get("problems", []) if p.get("file") not in handled]
            # 但桥接失败的必须露出（含缺依赖/代理等真实原因）
            for f in failed:
                problems.append(
                    {
                        "file": f.get("file", ""),
                        "module": f.get("source_name", "") or Path(f.get("file", "")).stem,
                        "cls": "",
                        "source_name": f.get("source_name", ""),
                        "status": "bridge-" + str(f.get("status", "fail")),
                        "detail": f.get("detail", ""),
                    }
                )
            data["problems"] = problems
            data["bridged"] = report()["bridged"]
            data["bridged_failed"] = failed
            data["deps"] = _deps_public()
            return data

        wrapped._tvbox_wrapped = True
        _sources.report = wrapped
        log.info("已把桥接结果并入 /sources 报告")
    except Exception as exc:  # pragma: no cover
        log.debug("包装 /sources 报告失败：%s", exc)


# ── 启动 ────────────────────────────────────────────────────────────

_boot()
_expose_routes()
_wrap_loader_report()

# 依赖预热：启动阶段没装的包，后台补齐（不阻塞服务启动），装完立刻重试上线
threading.Thread(target=_deps_warmup, name="tvbox-deps-warmup", daemon=True).start()

# sources/__init__ 的扫描还在进行时 report() 尚未定义，稍后再补挂一次
threading.Timer(0.3, _wrap_loader_report).start()

_WATCH = float(os.getenv("TVBOX_WATCH_INTERVAL", "5") or 0)
if _WATCH > 0:
    threading.Thread(target=_watch_loop, args=(_WATCH,), name="tvbox-bridge-watch", daemon=True).start()
    log.info("桥接看门狗已启动：每 %.1fs 检查一次壳子源", _WATCH)
